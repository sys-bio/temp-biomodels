from numpy import zeros, concatenate
from scipy.integrate import odeint
import math
from pylab import *


def cell_equations(cell_to_coordinates, edges_to_source, edges_to_target, edges_to_wall, border,
                              Auxin, Cytokinin, AHP6m, AHP6p, IAA2m, IAA2p, ARR5m, ARR5p, PHBm, PHBp, CKX3m, CKX3p,
                              PIN1m, PIN1, PIN1cells,PIN3m, PIN3, PIN3cells,PIN7m, PIN7, PIN7cells,
                              AUX1, AUX1cells, miRNA, dt, nPIN1, nPIN3, nPIN7, nAUX1, cell_type,V,S,surf_normalization,
                              PIN1_wall_fraction, PIN3_wall_fraction, PIN7_wall_fraction):
                              

        
        """
        Compute diffusion (permeability) and transport of a substance along the edges of an oriented graph.        
        V is cell volume, S is wall surface, edges_to_wall the correspondancy between edges and wall.
        """
        
        substAuxin       = zeros( len(Auxin) )
        substCytokinin   = zeros( len(Cytokinin) )
        substAHP6m       = zeros( len(AHP6m) )
        substAHP6p       = zeros( len(AHP6p) )
        substIAA2m       = zeros( len(IAA2m) )
        substIAA2p       = zeros( len(IAA2p) )
        substARR5m       = zeros( len(ARR5m) )
        substARR5p       = zeros( len(ARR5p) )
        substPHBm        = zeros( len(PHBm) )
        substPHBp        = zeros( len(PHBp) )
        substCKX3m       = zeros( len(CKX3m) )
        substCKX3p       = zeros( len(CKX3p) )
        substPIN1m       = zeros( len(PIN1m) )
        substPIN1        = zeros( len(PIN1) )
        substPIN3m       = zeros( len(PIN3m) )
        substPIN3        = zeros( len(PIN3) )
        substPIN7m       = zeros( len(PIN7m) )
        substPIN7        = zeros( len(PIN7) )
        substAUX1        = zeros( len(AUX1) )
        substmiRNA       = zeros( len(miRNA) )
        
        
        
        #building map of index to find back the values that will go into the integrated 1D array
        Auxin_map     = {}
        Cytokinin_map = {}
        AHP6m_map     = {}
        AHP6p_map     = {}
        IAA2m_map     = {}
        IAA2p_map     = {}
        ARR5m_map     = {}
        ARR5p_map     = {}
        PHBm_map      = {}
        PHBp_map      = {}
        CKX3m_map     = {}
        CKX3p_map     = {}
        PIN1m_map     = {}
        PIN1_map      = {}
        PIN3m_map     = {}
        PIN3_map      = {}
        PIN7m_map     = {}
        PIN7_map      = {}
        AUX1_map      = {}
        miRNA_map     = {}

        
        for ind,cid in enumerate(cell_to_coordinates.keys()) :
            
            substAuxin[ind] = Auxin[cid]
            Auxin_map[cid] = ind
            
            substCytokinin[ind] = Cytokinin[cid]
            Cytokinin_map[cid] = len(Auxin)+ind
            
            substAHP6m[ind] = AHP6m[cid]
            AHP6m_map[cid] = len(Auxin)+len(Cytokinin)+ind
            
            substAHP6p[ind] = AHP6p[cid]
            AHP6p_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+ind
            
            substIAA2m[ind] = IAA2m[cid]
            IAA2m_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+ind
            
            substIAA2p[ind] = IAA2p[cid]
            IAA2p_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+ind
            
            substARR5m[ind] = ARR5m[cid]
            ARR5m_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+ind
            
            substARR5p[ind] = ARR5p[cid]
            ARR5p_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+ind
            
            substPHBm[ind] = PHBm[cid]
            PHBm_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+ind
            
            substPHBp[ind] = PHBp[cid]
            PHBp_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+ind

            substCKX3m[ind] = CKX3m[cid]
            CKX3m_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+ind

            substCKX3p[ind] = CKX3p[cid]
            CKX3p_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+ind
                        
            substmiRNA[ind] = miRNA[cid]
            miRNA_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+ind

            substPIN1m[ind] = PIN1m[cid]
            PIN1m_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+len(miRNA)+ind

            substPIN3m[ind] = PIN3m[cid]
            PIN3m_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+len(miRNA)+len(PIN1m)+ind

            substPIN7m[ind] = PIN7m[cid]
            PIN7m_map[cid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+len(miRNA)+len(PIN1m)+len(PIN3m)+ind


		
        for ind,eid in enumerate(edges_to_wall.keys()):
            
            substPIN1[ind] = PIN1[eid]
            PIN1_map[eid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+len(miRNA)+len(PIN1m)+len(PIN3m)+len(PIN7m)+ind

            substPIN3[ind] = PIN3[eid]
            PIN3_map[eid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+len(miRNA)+len(PIN1m)+len(PIN3m)+len(PIN7m)+len(PIN1)+ind

            substPIN7[ind] = PIN7[eid]
            PIN7_map[eid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+len(miRNA)+len(PIN1m)+len(PIN3m)+len(PIN7m)+len(PIN1)+len(PIN3)+ind

            substAUX1[ind] = AUX1[eid]
            AUX1_map[eid] = len(Auxin)+len(Cytokinin)+len(AHP6m)+len(AHP6p)+len(IAA2m)+len(IAA2p)+len(ARR5m)+len(ARR5p)+len(PHBm)+len(PHBp)+\
            len(CKX3m)+len(CKX3p)+len(miRNA)+len(PIN1m)+len(PIN3m)+len(PIN7m)+len(PIN1)+len(PIN3)+len(PIN7)+ind

 
        to_integrate = concatenate((substAuxin,substCytokinin,substAHP6m,substAHP6p,substIAA2m,substIAA2p,substARR5m,substARR5p,substPHBm,substPHBp,\
        substCKX3m,substCKX3p,substmiRNA,substPIN1m,substPIN3m,substPIN7m,substPIN1,substPIN3,substPIN7,substAUX1))



        p_ax=0.06
        p_ck=2.0
        d_ax=1.0
        d_ck=10.0
        
        D_ck=10.0
        D_ax=1.0
        T_ax=20.0
        D_miRNA=1.5
        T_aux1 =20.0
        
        Flux_Out_Ax=T_ax
        Flux_Out_Ck=100.0        
        
        phloem_rate_ax=1.0
        all_section_rate_ax=1.0

        phloem_rate_ck=1.0
        all_section_rate_ck=1.0

        lambda_AHP6=2.0
        lambda_IAA2=10.0
        lambda_ARR5=20.0
        lambda_PIN1=0.0
        lambda_PIN3=0.0
        lambda_PIN7=1.0

        mu_m_PHB =1.0
        mu_m_AHP6=1.0
        mu_m_IAA2=10.0
        mu_m_ARR5=10.0
        mu_m_PIN1=0.0
        mu_m_PIN3=0.0
        mu_m_PIN7=1.0

        delta_PHB =1.0
        delta_AHP6=1.0
        delta_IAA2=10.0
        delta_ARR5=10.0
        delta_PIN1=0.0
        delta_PIN3=0.0
        delta_PIN7=5.0
        delta_CKX3=1.0

        mu_p_PHB =1.0
        mu_p_AHP6=1.0
        mu_p_IAA2=10.0
        mu_p_ARR5=10.0
        mu_p_PIN1=0.0
        mu_p_PIN3=0.0
        mu_p_PIN7=1.0
        mu_p_CKX3=1.0

        theta_Ax  = 0.25
        theta_Ck  = 0.5
        theta_AHP6= 0.04
        theta_ARR5= 0.1
        theta_PHB = 0.4
        theta_CKX3= 0.05

        p_phb=2.0
        d_phb=1.0

        p_mirna=32.5
        d_mirna=1.0
        d_mirna_mrna=10
        
        p_ckx3=5.0
        d_ckx3=1.0
        
        b_pin3=1.0
        b_pin1=0.0
        b_pin7=0.0
        b_ahp6=0.0
        b_arr5=0.0
        b_iaa2=0.0        

        hill_ax   =2.0
        hill_ck   =2.0     
        hill_arr5 =3.0
        hill_ckx3 =5.0
        hill_ahp6 =3.0
        hill_phb  =3.0
	      
        
	def deriv (y, t) :

            ret = zeros( (len(y),) )                
		
            for sid in cell_to_coordinates.keys():

                    Axid_s          = Auxin_map[sid]
                    Ckid_s          = Cytokinin_map[sid]
                    AHP6mid_s       = AHP6m_map[sid]
                    AHP6pid_s       = AHP6p_map[sid]
                    IAA2mid_s       = IAA2m_map[sid]
                    IAA2pid_s       = IAA2p_map[sid]
                    ARR5mid_s       = ARR5m_map[sid]
                    ARR5pid_s       = ARR5p_map[sid]
                    PIN1mid_s       = PIN1m_map[sid]
                    PIN3mid_s       = PIN3m_map[sid]
                    PIN7mid_s       = PIN7m_map[sid]
                    PHBmid_s        = PHBm_map[sid]
                    PHBpid_s        = PHBp_map[sid]
                    CKX3mid_s       = CKX3m_map[sid]
                    CKX3pid_s       = CKX3p_map[sid]
                    miRNAid_s       = miRNA_map[sid]



                    F_AHP6 = (b_ahp6 + pow((y[Axid_s]/theta_Ax),hill_ax)) / ( 1 + pow((y[Axid_s]/theta_Ax),hill_ax) + pow((y[PHBpid_s]/theta_PHB),hill_phb) )
                    F_CK   = 1.0 / ( 1 + pow((y[CKX3pid_s]/theta_CKX3),hill_ckx3) )                     
                    F_IAA2 = (b_iaa2 + pow((y[Axid_s]/theta_Ax),hill_ax)) / ( 1 + pow((y[Axid_s]/theta_Ax),hill_ax) )
                    F_ARR5 = (b_arr5 + pow((y[Ckid_s]/theta_Ck),hill_ck)) / ( 1 + pow((y[Ckid_s]/theta_Ck),hill_ck) + pow((y[AHP6pid_s]/theta_AHP6),hill_ahp6) )
                    F_PIN1 = (b_pin1 + pow((y[ARR5pid_s]/theta_ARR5),hill_arr5)) / ( 1 + pow( (y[ARR5pid_s]/theta_ARR5),hill_arr5) )
                    F_PIN7 = (b_pin7 + pow((y[ARR5pid_s]/theta_ARR5),hill_arr5)) / ( 1 + pow( (y[ARR5pid_s]/theta_ARR5),hill_arr5) )
                    F_PIN3 = b_pin3


                    if cell_type[sid]!=0 and cell_type[sid]!=6:
                        ret[Axid_s]    += all_section_rate_ax * p_ax       - d_ax*y[Axid_s]
                        ret[Ckid_s]    += all_section_rate_ck * p_ck*F_CK  - d_ck*y[Ckid_s]


                    if cell_type[sid]==0:
                        ret[Axid_s]    += phloem_rate_ax * p_ax      - d_ax*y[Axid_s]
                        ret[Ckid_s]    += phloem_rate_ck * p_ck*F_CK - d_ck*y[Ckid_s]
  

                    if cell_type[sid]==6:
                        ret[Axid_s]  = 0.0
                        ret[Ckid_s]  = 0.0
 
                    if cell_type[sid]==6:
                        ret[miRNAid_s] += p_mirna - d_mirna*y[miRNAid_s] - d_mirna_mrna*y[PHBmid_s]*y[miRNAid_s]
                    else:
                        ret[miRNAid_s] += - d_mirna*y[miRNAid_s] - d_mirna_mrna*y[PHBmid_s]*y[miRNAid_s]

                    if cell_type[sid]==2 and border.has_key(sid):
                        ret[CKX3mid_s] += p_ckx3-d_ckx3*y[CKX3mid_s]
                        
                    ret[PHBmid_s]  += p_phb - d_phb*y[PHBmid_s] - d_mirna_mrna*y[PHBmid_s]*y[miRNAid_s]
                    ret[AHP6mid_s] += lambda_AHP6*F_AHP6 - mu_m_AHP6*y[AHP6mid_s]                    
                    ret[IAA2mid_s] += lambda_IAA2*F_IAA2 - mu_m_IAA2*y[IAA2mid_s]                    
                    ret[ARR5mid_s] += lambda_ARR5*F_ARR5 - mu_m_ARR5*y[ARR5mid_s]                    
                    ret[PIN1mid_s] += lambda_PIN1*F_PIN1 - mu_m_PIN1*y[PIN1mid_s]
                    ret[PIN3mid_s] += lambda_PIN3*F_PIN3 - mu_m_PIN3*y[PIN3mid_s]
                    ret[PIN7mid_s] += lambda_PIN7*F_PIN7 - mu_m_PIN7*y[PIN7mid_s]

                    ret[AHP6pid_s] += delta_AHP6*y[AHP6mid_s] - mu_p_AHP6*y[AHP6pid_s]                    
                    ret[IAA2pid_s] += delta_IAA2*y[IAA2mid_s] - mu_p_IAA2*y[IAA2pid_s]                    
                    ret[ARR5pid_s] += delta_ARR5*y[ARR5mid_s] - mu_p_ARR5*y[ARR5pid_s]                    
                    ret[PHBpid_s]  += delta_PHB *y[PHBmid_s]  - mu_p_PHB *y[PHBpid_s]                    
                    ret[CKX3pid_s] += delta_CKX3*y[CKX3mid_s] - mu_p_CKX3*y[CKX3pid_s]                    

			
		
            for eid in edges_to_wall.keys() :

                    sid = edges_to_source[eid]
                    tid = edges_to_target[eid]

                    surf = S[edges_to_wall[eid]]
                    Vs   = V[sid]
                    Vt   = V[tid]
                    
                    SV_s = surf_normalization*(surf/Vs)
                    SV_t = surf_normalization*(surf/Vt)
                    
                    Axid_s = Auxin_map[sid]
                    Axid_t = Auxin_map[tid]

                    Ckid_s = Cytokinin_map[sid]
                    Ckid_t = Cytokinin_map[tid]

                    miRNAid_s = miRNA_map[sid]
                    miRNAid_t = miRNA_map[tid]

                    PIN1mid_s = PIN1m_map[sid]
                    Pid1_s    = PIN1_map[eid]

                    PIN3mid_s = PIN3m_map[sid]
                    Pid3_s    = PIN3_map[eid]

                    PIN7mid_s = PIN7m_map[sid]
                    Pid7_s    = PIN7_map[eid]
                    
                    if (PIN7[eid]!=0):
                        ret[Pid7_s] += (delta_PIN7*y[PIN7mid_s])*PIN7_wall_fraction[eid] - mu_p_PIN7*y[Pid7_s]
                                            
                    Ax_flux = y[Axid_s] * D_ax +  T_ax *  y[Pid7_s] * y[Axid_s] - T_aux1 * AUX1[eid] * y[Axid_s]
                    ret[Axid_s] += - SV_s*Ax_flux
                    ret[Axid_t] += + SV_t*Ax_flux

                    Ck_flux = y[Ckid_s] * D_ck 
                    ret[Ckid_s] += - SV_s*Ck_flux
                    ret[Ckid_t] += + SV_t*Ck_flux


                    if cell_type[sid]==6:                    
                        ret[Ckid_s] += - SV_s*( y[Ckid_s] * Flux_Out_Ck )
                        ret[Axid_s] += - SV_s*( y[Axid_s] * Flux_Out_Ax )

                    mirna_flux = y[miRNAid_s] * D_miRNA
                    ret[miRNAid_s] += - SV_s*mirna_flux
                    ret[miRNAid_t] += + SV_t*mirna_flux

            return ret


        integrated = odeint(deriv,to_integrate,[0.,dt],mxstep=100)
        

        for cid,ind in Auxin_map.iteritems() :
		Auxin[cid] = float(integrated[-1,ind])

        for cid,ind in Cytokinin_map.iteritems() :
		Cytokinin[cid] = float(integrated[-1,ind])

        for cid,ind in AHP6m_map.iteritems() :
		AHP6m[cid] = float(integrated[-1,ind])

        for cid,ind in AHP6p_map.iteritems() :
		AHP6p[cid] = float(integrated[-1,ind])

        for cid,ind in IAA2m_map.iteritems() :
		IAA2m[cid] = float(integrated[-1,ind])

        for cid,ind in IAA2p_map.iteritems() :
		IAA2p[cid] = float(integrated[-1,ind])

        for cid,ind in ARR5m_map.iteritems() :
		ARR5m[cid] = float(integrated[-1,ind])

        for cid,ind in ARR5p_map.iteritems() :
		ARR5p[cid] = float(integrated[-1,ind])

        for cid,ind in PHBm_map.iteritems() :
		PHBm[cid] = float(integrated[-1,ind])

        for cid,ind in PHBp_map.iteritems() :
		PHBp[cid] = float(integrated[-1,ind])

        for cid,ind in CKX3m_map.iteritems() :
		CKX3m[cid] = float(integrated[-1,ind])

        for cid,ind in CKX3p_map.iteritems() :
		CKX3p[cid] = float(integrated[-1,ind])

        for cid,ind in PIN1m_map.iteritems() :
		PIN1m[cid] = float(integrated[-1,ind])

        for eid,ind in PIN1_map.iteritems() :
		PIN1[eid] = float(integrated[-1,ind])

        for cid,ind in PIN3m_map.iteritems() :
		PIN3m[cid] = float(integrated[-1,ind])

        for eid,ind in PIN3_map.iteritems() :
		PIN3[eid] = float(integrated[-1,ind])

        for cid,ind in PIN7m_map.iteritems() :
		PIN7m[cid] = float(integrated[-1,ind])

        for eid,ind in PIN7_map.iteritems() :
		PIN7[eid] = float(integrated[-1,ind])

        for eid,ind in AUX1_map.iteritems() :
		AUX1[eid] = float(integrated[-1,ind])

        for eid,ind in miRNA_map.iteritems() :
		miRNA[eid] = float(integrated[-1,ind])


        for ind,cid in enumerate(cell_to_coordinates.keys()) :
                PIN1cells[cid]=0
                PIN3cells[cid]=0
                PIN7cells[cid]=0
                AUX1cells[cid]=0

        for ind,eid in enumerate(edges_to_wall.keys()):
                cid = edges_to_source[eid]
                PIN1cells[cid]+=PIN1[eid]
                PIN3cells[cid]+=PIN3[eid]
                PIN7cells[cid]+=PIN7[eid]
                AUX1cells[cid]+=AUX1[eid]


	return None,


