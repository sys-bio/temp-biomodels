from reactions_sm9 import *

from numpy import *
from pylab import *
from math  import modf
import pickle
import matplotlib
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
import matplotlib.pyplot as plt
import matplotlib.mathtext as mathtext
import os, sys


pj = os.path.join
PATH=os.getcwd()
sys.path.append(PATH)



# Parameters simulation
#N_ITERATIONS=15
N_ITERATIONS=15
dt=0.01
N_dt=100


# Parameters figures
n_pics=[3,4];
x_graph=[0.04,0.28,0.52,0.76]
y_graph=[0.64,0.33,0.02]
width_root=0.20
height_root=0.29

xmin=-350
xmax=350
ymin=-350
ymax=350

vmin=0
Ax_vmax=0.5
Ck_vmax=0.2
PHB_vmax=2.4
AHP6_vmax=0.3
IAA2_vmax=0.5
ARR5_vmax=0.5
PIN1_vmax =1.2
PIN3_vmax =1.2
PIN7_vmax =7.0
miRNA_vmax=30.0
CKX3_vmax=7.0
AUX1_vmax = 1.2

title_x_position=2250




def CellToCoordinates(mesh,cell_to_walls,border_to_coordinates):

    ptc=[]
    for ncid,cid in enumerate(mesh.wisps(2)):
        ptc.append([])
        patches=[]
  
        for i in range(len(cell_to_walls[cid])):
            patches.append(border_to_coordinates[cell_to_walls[cid][i]])

        ptc[ncid]=[]
        ptc[ncid].append(patches[0][0])
        ptc[ncid].append(patches[0][1])
        patches.remove(patches[0])
        i=0
        while i <len(patches):
            if patches[i].count(ptc[ncid][-1])==1:
                id1=patches[i].index(ptc[ncid][-1])
		id2=abs(-1+id1)
                ptc[ncid].append(patches[i][id2])
                patches.remove(patches[i])
                i=-1
            i=i+1

    cell_to_coordinates = dict((cid,ptc[ncid]) for ncid,cid in enumerate(mesh.wisps(2)))
 
    return cell_to_coordinates

    

# Read geometry
TISSUE='tissue'
tissue_file='%s.txt'%TISSUE
f=open(tissue_file,'r')

msg='#cell_type:\n'
LineRead=f.readline()
if (LineRead==msg):
    cell_type=pickle.load(f)

msg='#border:\n'
LineRead=f.readline()
if (LineRead==msg):
    border=pickle.load(f)

msg='#cell_to_coordinates:\n'
LineRead=f.readline()
if (LineRead==msg):
    cell_to_coordinates=pickle.load(f)

msg='#edges_to_source:\n'
LineRead=f.readline()
if (LineRead==msg):
    edges_to_source=pickle.load(f)

msg='#edges_to_target:\n'
LineRead=f.readline()
if (LineRead==msg):
    edges_to_target=pickle.load(f)

msg='#edges_to_wall:\n'
LineRead=f.readline()
if (LineRead==msg):
    edges_to_wall=pickle.load(f)

msg='#V:\n'
LineRead=f.readline()
if (LineRead==msg):
    V=pickle.load(f)
    
msg='#S:\n'
LineRead=f.readline()
if (LineRead==msg):
    S=pickle.load(f)

msg='#PIN1_tissue:\n'
LineRead=f.readline()
if (LineRead==msg):
    PIN1_tissue=pickle.load(f)

msg='#PIN3_tissue:\n'
LineRead=f.readline()
if (LineRead==msg):
    PIN3_tissue=pickle.load(f)

msg='#PIN7_tissue:\n'
LineRead=f.readline()
if (LineRead==msg):
    PIN7_tissue=pickle.load(f)

msg='#sPIN1:\n'
LineRead=f.readline()
if (LineRead==msg):
    sPIN1=pickle.load(f)

msg='#sPIN3:\n'
LineRead=f.readline()
if (LineRead==msg):
    sPIN3=pickle.load(f)

msg='#sPIN7:\n'
LineRead=f.readline()
if (LineRead==msg):
    sPIN7=pickle.load(f)

msg='#wall_decomposition:\n'
LineRead=f.readline()
if (LineRead==msg):
    wall_decomposition=pickle.load(f)

msg='#tS:\n'
LineRead=f.readline()
if (LineRead==msg):
    tS=pickle.load(f)

f.close()


# Evaluate normalisation constant
max_S_pericycle=0
for eid in edges_to_wall.keys() :
    sid = edges_to_source[eid]
    tid = edges_to_target[eid]
    if cell_type[sid]==1 and cell_type[tid]==6: 
        if S[edges_to_wall[eid]]>max_S_pericycle: 
            max_S_pericycle=S[edges_to_wall[eid]]
surf_normalization=max_S_pericycle/10.0


# Initialise variables    
Auxin         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
Cytokinin     =dict((cid,0.0) for cid in cell_to_coordinates.keys())
miRNA         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
CKX3m         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
CKX3p         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PHBm          =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PHBp          =dict((cid,0.0) for cid in cell_to_coordinates.keys())
AHP6m         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
AHP6p         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
IAA2m         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
IAA2p         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
ARR5m         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
ARR5p         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PIN1m         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PIN1cells     =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PIN1          =dict((eid,0.0) for eid in edges_to_wall.keys())
PIN3m         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PIN3cells     =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PIN3          =dict((eid,0.0) for eid in edges_to_wall.keys())
PIN7m         =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PIN7cells     =dict((cid,0.0) for cid in cell_to_coordinates.keys())
PIN7          =dict((eid,0.0) for eid in edges_to_wall.keys())
AUX1          =dict((eid,0.0) for eid in edges_to_wall.keys())
AUX1cells     =dict((cid,0.0) for cid in cell_to_coordinates.keys())


# Evaluate PIN and AUX1 distributions on cell walls
for eid in PIN1_tissue.keys():
        PIN1[eid]=PIN1_tissue[eid]
        AUX1[eid]=PIN1[eid]

for eid in PIN7_tissue.keys():
    sid = edges_to_source[eid]
    if cell_type[sid]!=2 and border.has_key(sid)==False:
        PIN7[eid]=PIN7_tissue[eid]

nPIN1={}
nPIN3={}
nPIN7={}
nAUX1={}
PIN1_wall_fraction = dict((eid,0.0) for eid in edges_to_wall.keys())
PIN3_wall_fraction = dict((eid,0.0) for eid in edges_to_wall.keys())
PIN7_wall_fraction = dict((eid,0.0) for eid in edges_to_wall.keys())

for eid in edges_to_wall.keys() :    
    for wid,(eid1,eid2) in wall_decomposition.iteritems() :
        if eid1==eid:
            Swall = float(S[wid])
        if eid2==eid:
            Swall = float(S[wid])

    if PIN1[eid]!=0:
        sid = edges_to_source[eid]  
        sPIN1[sid]+=Swall
        PIN1_wall_fraction[eid] = Swall
    if PIN3[eid]!=0:
        sid = edges_to_source[eid]  
        sPIN3[sid]+=Swall
        PIN3_wall_fraction[eid] = Swall
    if PIN7[eid]!=0:
        sid = edges_to_source[eid]  
        sPIN7[sid]+=Swall
        PIN7_wall_fraction[eid] = Swall
    sid = edges_to_source[eid] 
    tS[sid]+=Swall


for ind,eid in enumerate(edges_to_wall.keys()):
        cid = edges_to_source[eid]
        if PIN1[eid]!=0:
            PIN1_wall_fraction[eid] = PIN1_wall_fraction[eid]/sPIN1[cid] 
        if PIN3[eid]!=0:
            PIN3_wall_fraction[eid] = PIN3_wall_fraction[eid]/sPIN3[cid] 
        if PIN7[eid]!=0:
            PIN7_wall_fraction[eid] = PIN7_wall_fraction[eid]/sPIN7[cid] 


for ind,eid in enumerate(edges_to_wall.keys()):
        cid = edges_to_source[eid]
        if PIN1[eid]!=0:
                PIN1[eid]=PIN1_wall_fraction[eid]              


# Evaluate PIN and AUX1 concentrations in cells
PIN1tmp       =dict((cid,0.0) for cid in cell_to_coordinates.keys())
for ind,eid in enumerate(edges_to_wall.keys()):
        cid = edges_to_source[eid]
        if PIN1[eid]!=0:
                PIN1tmp[cid] += PIN1[eid]             

for ind,eid in enumerate(edges_to_wall.keys()):
        cid = edges_to_source[eid]
        if PIN1[eid]!=0:
                PIN1[eid] = PIN1[eid] / PIN1tmp[cid]            
                AUX1[eid] = PIN1[eid]
        else:
            AUX1[eid] = 0.0

for ind,eid in enumerate(edges_to_wall.keys()):
        cid = edges_to_source[eid]
        PIN1cells[cid]+=PIN1[eid]
        AUX1cells[cid]+=AUX1[eid]


# Plot figures
iteration = 0

pat = []
#for ncid,cid in enumerate(mesh.wisps(2)):
for cid in cell_to_coordinates.keys():
    polygon = Polygon(cell_to_coordinates[cid], True)
    pat.append(polygon)


# auxin mediated graph
fig=figure(figsize=((40.0/3.0)*4.0,40))


params={'xtick.labelsize':30,
        'ytick.labelsize':30}
rcParams.update(params)


# CKX3 graph
ckx3=fig.add_subplot(n_pics[0],n_pics[1],1)
ckx3.set_position([x_graph[0],y_graph[0],width_root,height_root])

ckx3.set_yticklabels([])
ckx3.set_xticklabels([])

ckx3.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

CKX3_colors = []
for cid in cell_to_coordinates.keys():
    CKX3_colors.append(CKX3p[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(CKX3_colors))

p.set_clim(vmin, CKX3_vmax)

ckx3.add_collection(p)
colorbar(p)
ylabel("CKIN",fontsize=50)


# Cytokinin graph
ck=fig.add_subplot(n_pics[0],n_pics[1],5)
#ck.set_position([x_graph[0], y_graph[1], width_root, height_root])

ck.set_yticklabels([])
ck.set_xticklabels([])

ck.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

Ck_colors = []
for cid in cell_to_coordinates.keys():
    Ck_colors.append(Cytokinin[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(Ck_colors))

p.set_clim(vmin, Ck_vmax)

ck.add_collection(p)
colorbar(p)
ylabel("Cytokinin",fontsize=50)


# ARR5 graph
arr5=fig.add_subplot(n_pics[0],n_pics[1],9)
#arr5.set_position([x_graph[0],y_graph[2],width_root,height_root])

arr5.set_yticklabels([])
arr5.set_xticklabels([])

arr5.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

ARR5_colors = []
for cid in cell_to_coordinates.keys():
    ARR5_colors.append(ARR5p[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(ARR5_colors))

p.set_clim(vmin, ARR5_vmax)

arr5.add_collection(p)
colorbar(p)
ylabel("ARR5",fontsize=50)


# PIN7 graph
pin7=fig.add_subplot(n_pics[0],n_pics[1],2)
#pin7.set_position([x_graph[1],y_graph[0],width_root,height_root])

pin7.set_yticklabels([])
pin7.set_xticklabels([])

pin7.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

PIN7_colors = []
for cid in cell_to_coordinates.keys():
    PIN7_colors.append(PIN7cells[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(PIN7_colors))

p.set_clim(vmin, PIN7_vmax)

pin7.add_collection(p)
colorbar(p)
ylabel("PIN7",fontsize=50)


# Auxin graph
ax=fig.add_subplot(n_pics[0],n_pics[1],6)
#ax.set_position([x_graph[1],y_graph[1],width_root,height_root])

ax.set_yticklabels([])
ax.set_xticklabels([])

ax.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

Ax_colors = []
for cid in cell_to_coordinates.keys():
    Ax_colors.append(Auxin[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(Ax_colors))

p.set_clim(vmin, Ax_vmax)

ax.add_collection(p)
colorbar(p)
ylabel("Auxin",fontsize=50)


# IAA2 graph
iaa2=fig.add_subplot(n_pics[0],n_pics[1],10)
#iaa2.set_position([x_graph[1],y_graph[2],width_root,height_root])

iaa2.set_yticklabels([])
iaa2.set_xticklabels([])

iaa2.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

IAA2_colors = []
for cid in cell_to_coordinates.keys():
    IAA2_colors.append(IAA2p[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(IAA2_colors))

p.set_clim(vmin, IAA2_vmax)

iaa2.add_collection(p)
colorbar(p)
ylabel("IAA2",fontsize=50)


# miRNA graph
miRNAf=fig.add_subplot(n_pics[0],n_pics[1],3)
#miRNAf.set_position([x_graph[2],y_graph[0],width_root,height_root])

miRNAf.set_yticklabels([])
miRNAf.set_xticklabels([])

miRNAf.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

miRNA_colors = []
for cid in cell_to_coordinates.keys():
    miRNA_colors.append(miRNA[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(miRNA_colors))

p.set_clim(vmin, miRNA_vmax)

miRNAf.add_collection(p)
colorbar(p)
ylabel("miRNA165/6",fontsize=50)


# PHB graph
phb=fig.add_subplot(n_pics[0],n_pics[1],7)
#phb.set_position([x_graph[2],y_graph[1],width_root,height_root])

phb.set_yticklabels([])
phb.set_xticklabels([])

phb.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

PHB_colors = []
for cid in cell_to_coordinates.keys():
    PHB_colors.append(PHBp[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(PHB_colors))

p.set_clim(vmin, PHB_vmax)

phb.add_collection(p)
colorbar(p)
ylabel("PHB",fontsize=50)


# AHP6 graph
ahp6=fig.add_subplot(n_pics[0],n_pics[1],11)
#ahp6.set_position([x_graph[2],y_graph[2],width_root,height_root])

ahp6.set_yticklabels([])
ahp6.set_xticklabels([])

ahp6.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

AHP6_colors = []
for cid in cell_to_coordinates.keys():
    AHP6_colors.append(AHP6p[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(AHP6_colors))

p.set_clim(vmin, AHP6_vmax)

ahp6.add_collection(p)
colorbar(p)
ylabel("AHP6",fontsize=50)


# AUX1 graph
aux1=fig.add_subplot(n_pics[0],n_pics[1],4)
#aux1.set_position([x_graph[3],y_graph[0],width_root,height_root])

aux1.set_yticklabels([])
aux1.set_xticklabels([])

aux1.axis('equal')

xlim( xmin, xmax )    # set the xlim to xmin, xmax
ylim( ymin, ymax )    # set the xlim to xmin, xmax

AUX1_colors = []
for cid in cell_to_coordinates.keys():
    AUX1_colors.append(AUX1cells[cid])

p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
p.set_array(array(AUX1_colors))

p.set_clim(vmin, AUX1_vmax)

aux1.add_collection(p)
colorbar(p)
ylabel("AUX1",fontsize=50)


parser = mathtext.MathTextParser("Bitmap")
rgba1, depth1 = parser.to_rgba('Time: %1.0f sec.'%(0*N_dt*dt), color='black', fontsize=40, dpi=200)
figimage(rgba1.astype(float)/255., title_x_position, 3800)


ax_fname = '%s/fig_%02d.png'%(PATH,iteration)
savefig(ax_fname)
fig.clf()







# ITERATIONS
for iteration in range(1,N_ITERATIONS+1):

    for i in range(N_dt):
        cell_equations(cell_to_coordinates, edges_to_source, edges_to_target, edges_to_wall, border,
                                  Auxin, Cytokinin, AHP6m, AHP6p, IAA2m, IAA2p, ARR5m, ARR5p, PHBm, PHBp, CKX3m, CKX3p,
                                  PIN1m, PIN1, PIN1cells,PIN3m, PIN3, PIN3cells,PIN7m, PIN7, PIN7cells,
                                  AUX1, AUX1cells, miRNA, dt, nPIN1, nPIN3, nPIN7, nAUX1, cell_type,V,S,surf_normalization,
                                  PIN1_wall_fraction, PIN3_wall_fraction, PIN7_wall_fraction)
                                                              

    print "\nITERATION: %d -- TOTAL ITERATIONS: %d"%(iteration,N_ITERATIONS)

    params={'xtick.labelsize':30,
            'ytick.labelsize':30}
    rcParams.update(params)
       

    # CKX3 graph
    ckx3=fig.add_subplot(n_pics[0],n_pics[1],1)
    ckx3.set_position([x_graph[0],y_graph[0],width_root,height_root])
    
    ckx3.set_yticklabels([])
    ckx3.set_xticklabels([])
    
    ckx3.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    CKX3_colors = []
    for cid in cell_to_coordinates.keys():
        CKX3_colors.append(CKX3p[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(CKX3_colors))
    
    p.set_clim(vmin, CKX3_vmax)
    
    ckx3.add_collection(p)
    colorbar(p)
    ylabel("CKIN",fontsize=50)
    
    
    # Cytokinin graph
    ck=fig.add_subplot(n_pics[0],n_pics[1],5)
    #ck.set_position([x_graph[0], y_graph[1], width_root, height_root])
    
    ck.set_yticklabels([])
    ck.set_xticklabels([])
    
    ck.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    Ck_colors = []
    for cid in cell_to_coordinates.keys():
        Ck_colors.append(Cytokinin[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(Ck_colors))
    
    p.set_clim(vmin, Ck_vmax)
    
    ck.add_collection(p)
    colorbar(p)
    ylabel("Cytokinin",fontsize=50)
    
    
    # ARR5 graph
    arr5=fig.add_subplot(n_pics[0],n_pics[1],9)
    #arr5.set_position([x_graph[0],y_graph[2],width_root,height_root])
    
    arr5.set_yticklabels([])
    arr5.set_xticklabels([])
    
    arr5.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    ARR5_colors = []
    for cid in cell_to_coordinates.keys():
        ARR5_colors.append(ARR5p[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(ARR5_colors))
    
    p.set_clim(vmin, ARR5_vmax)
    
    arr5.add_collection(p)
    colorbar(p)
    ylabel("ARR5",fontsize=50)
    
    
    # PIN7 graph
    pin7=fig.add_subplot(n_pics[0],n_pics[1],2)
    #pin7.set_position([x_graph[1],y_graph[0],width_root,height_root])
    
    pin7.set_yticklabels([])
    pin7.set_xticklabels([])
    
    pin7.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    PIN7_colors = []
    for cid in cell_to_coordinates.keys():
        PIN7_colors.append(PIN7cells[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(PIN7_colors))
    
    p.set_clim(vmin, PIN7_vmax)
    
    pin7.add_collection(p)
    colorbar(p)
    ylabel("PIN7",fontsize=50)
    
    
    # Auxin graph
    ax=fig.add_subplot(n_pics[0],n_pics[1],6)
    #ax.set_position([x_graph[1],y_graph[1],width_root,height_root])
    
    ax.set_yticklabels([])
    ax.set_xticklabels([])
    
    ax.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    Ax_colors = []
    for cid in cell_to_coordinates.keys():
        Ax_colors.append(Auxin[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(Ax_colors))
    
    p.set_clim(vmin, Ax_vmax)
    
    ax.add_collection(p)
    colorbar(p)
    ylabel("Auxin",fontsize=50)
    
    
    # IAA2 graph
    iaa2=fig.add_subplot(n_pics[0],n_pics[1],10)
    #iaa2.set_position([x_graph[1],y_graph[2],width_root,height_root])
    
    iaa2.set_yticklabels([])
    iaa2.set_xticklabels([])
    
    iaa2.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    IAA2_colors = []
    for cid in cell_to_coordinates.keys():
        IAA2_colors.append(IAA2p[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(IAA2_colors))
    
    p.set_clim(vmin, IAA2_vmax)
    
    iaa2.add_collection(p)
    colorbar(p)
    ylabel("IAA2",fontsize=50)
    
    
    # miRNA graph
    miRNAf=fig.add_subplot(n_pics[0],n_pics[1],3)
    #miRNAf.set_position([x_graph[2],y_graph[0],width_root,height_root])
    
    miRNAf.set_yticklabels([])
    miRNAf.set_xticklabels([])
    
    miRNAf.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    miRNA_colors = []
    for cid in cell_to_coordinates.keys():
        miRNA_colors.append(miRNA[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(miRNA_colors))
    
    p.set_clim(vmin, miRNA_vmax)
    
    miRNAf.add_collection(p)
    colorbar(p)
    ylabel("miRNA165/6",fontsize=50)
    
    
    # PHB graph
    phb=fig.add_subplot(n_pics[0],n_pics[1],7)
    #phb.set_position([x_graph[2],y_graph[1],width_root,height_root])
    
    phb.set_yticklabels([])
    phb.set_xticklabels([])
    
    phb.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    PHB_colors = []
    for cid in cell_to_coordinates.keys():
        PHB_colors.append(PHBp[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(PHB_colors))
    
    p.set_clim(vmin, PHB_vmax)
    
    phb.add_collection(p)
    colorbar(p)
    ylabel("PHB",fontsize=50)
    
    
    # AHP6 graph
    ahp6=fig.add_subplot(n_pics[0],n_pics[1],11)
    #ahp6.set_position([x_graph[2],y_graph[2],width_root,height_root])
    
    ahp6.set_yticklabels([])
    ahp6.set_xticklabels([])
    
    ahp6.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    AHP6_colors = []
    for cid in cell_to_coordinates.keys():
        AHP6_colors.append(AHP6p[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(AHP6_colors))
    
    p.set_clim(vmin, AHP6_vmax)
    
    ahp6.add_collection(p)
    colorbar(p)
    ylabel("AHP6",fontsize=50)
    
    
    # AUX1 graph
    aux1=fig.add_subplot(n_pics[0],n_pics[1],4)
    #aux1.set_position([x_graph[3],y_graph[0],width_root,height_root])
    
    aux1.set_yticklabels([])
    aux1.set_xticklabels([])
    
    aux1.axis('equal')
    
    xlim( xmin, xmax )    # set the xlim to xmin, xmax
    ylim( ymin, ymax )    # set the xlim to xmin, xmax
    
    AUX1_colors = []
    for cid in cell_to_coordinates.keys():
        AUX1_colors.append(AUX1cells[cid])
    
    p = PatchCollection(pat, cmap=matplotlib.cm.jet, alpha=1.)
    p.set_array(array(AUX1_colors))
    
    p.set_clim(vmin, AUX1_vmax)
    
    aux1.add_collection(p)
    colorbar(p)
    ylabel("AUX1",fontsize=50)
    

        
    parser = mathtext.MathTextParser("Bitmap")
    rgba1, depth1 = parser.to_rgba('Time: %1.0f sec.'%(iteration*N_dt*dt), color='black', fontsize=40, dpi=200)
    figimage(rgba1.astype(float)/255., title_x_position, 3800)
    
    
    ax_fname = '%s/fig_%02d.png'%(PATH,iteration)
    savefig(ax_fname)
    fig.clf()
    


