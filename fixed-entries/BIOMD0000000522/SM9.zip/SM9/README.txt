Movie S9.
Simulation of our multicellular model of vascular patterning containing a phloem-localized auxin influx carrier, AUX1. 
AUX1 is modeled as a PIN in the inverse direction (influx instead of efflux) with the same transport rate as for the PINs. 
AUX1 is localized on all of the membranes of the phloem cells and constantly expressed in the phloem, its unitary concentration being proportionally divided on the cell walls. The inclusion of such a component has little effect on the overall expression of the reporter genes. All parameters have been set to the values reported in SI Appendix, Tables S2 and S3.

The code is written in Python and depends on the libraries matplotlib and numpy.
To run the simulation from a unix shell use the command:

>> python run_sm9.py

The single cell model associated with Movie S9 can be run with the command:

>> python run_cell_model.py

