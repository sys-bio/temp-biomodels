from matplotlib import pyplot as plt
import numpy as np
from scipy.integrate import odeint



# Parameters    
t_final = 10.0
dt = 0.01
cell_type = 0

p_ax=0.06
p_ck=2.0
d_ax=1.0
d_ck=10.0

D_ck=10.0
D_ax=1.0
T_ax=20.0
D_miRNA=1.5
T_aux1 =20.0

Flux_Out_Ax=T_ax
Flux_Out_Ck=100.0        

phloem_rate_ax=1.0
all_section_rate_ax=1.0

phloem_rate_ck=1.0
all_section_rate_ck=1.0

lambda_AHP6=2.0
lambda_IAA2=10.0
lambda_ARR5=20.0
lambda_PIN1=0.0
lambda_PIN3=0.0
lambda_PIN7=1.0

mu_m_PHB =1.0
mu_m_AHP6=1.0
mu_m_IAA2=10.0
mu_m_ARR5=10.0
mu_m_PIN1=0.0
mu_m_PIN3=0.0
mu_m_PIN7=1.0

delta_PHB =1.0
delta_AHP6=1.0
delta_IAA2=10.0
delta_ARR5=10.0
delta_PIN1=0.0
delta_PIN3=0.0
delta_PIN7=5.0
delta_CKX3=1.0

mu_p_PHB =1.0
mu_p_AHP6=1.0
mu_p_IAA2=10.0
mu_p_ARR5=10.0
mu_p_PIN1=0.0
mu_p_PIN3=0.0
mu_p_PIN7=1.0
mu_p_CKX3=1.0

theta_Ax  = 0.25
theta_Ck  = 0.5
theta_AHP6= 0.04
theta_ARR5= 0.1
theta_PHB = 0.4
theta_CKX3= 0.05

p_phb=2.0
d_phb=1.0

p_mirna=32.5
d_mirna=1.0
d_mirna_mrna=10

p_ckx3=5.0
d_ckx3=1.0

b_pin3=1.0
b_pin1=0.0
b_pin7=0.0
b_ahp6=0.0
b_arr5=0.0
b_iaa2=0.0        

hill_ax   =2.0
hill_ck   =2.0     
hill_arr5 =3.0
hill_ckx3 =5.0
hill_ahp6 =3.0
hill_phb  =3.0


#Initial conditions
Auxin       = 0.0
Cytokinin   = 0.0
AHP6m       = 0.0
AHP6p       = 0.0
IAA2m       = 0.0
IAA2p       = 0.0
ARR5m       = 0.0
ARR5p       = 0.0
PHBm        = 0.0
PHBp        = 0.0
CKX3m       = 0.0
CKX3p       = 0.0
PIN1m       = 0.0
PIN3m       = 0.0
PIN7m       = 0.0
miRNA       = 0.0


        

def deriv (y, t) :

    ret = np.zeros( (len(y),) )                
		
    ind=0;  Axid_s     = ind
    ind+=1; Ckid_s     = ind
    ind+=1; AHP6mid_s  = ind
    ind+=1; AHP6pid_s  = ind
    ind+=1; IAA2mid_s  = ind
    ind+=1; IAA2pid_s  = ind
    ind+=1; ARR5mid_s  = ind
    ind+=1; ARR5pid_s  = ind
    ind+=1; PHBmid_s   = ind
    ind+=1; PHBpid_s   = ind    
    ind+=1; CKX3mid_s  = ind
    ind+=1; CKX3pid_s  = ind
    ind+=1; miRNAid_s  = ind
    ind+=1; PIN1mid_s  = ind
    ind+=1; PIN3mid_s  = ind
    ind+=1; PIN7mid_s  = ind



    F_AHP6 = (b_ahp6 + pow((y[Axid_s]/theta_Ax),hill_ax)) / ( 1 + pow((y[Axid_s]/theta_Ax),hill_ax) + pow((y[PHBpid_s]/theta_PHB),hill_phb) )
    F_CK   = 1.0 / ( 1 + pow((y[CKX3pid_s]/theta_CKX3),hill_ckx3) )                     
    F_IAA2 = (b_iaa2 + pow((y[Axid_s]/theta_Ax),hill_ax)) / ( 1 + pow((y[Axid_s]/theta_Ax),hill_ax) )
    F_ARR5 = (b_arr5 + pow((y[Ckid_s]/theta_Ck),hill_ck)) / ( 1 + pow((y[Ckid_s]/theta_Ck),hill_ck) + pow((y[AHP6pid_s]/theta_AHP6),hill_ahp6) )
    F_PIN1 = (b_pin1 + pow((y[ARR5pid_s]/theta_ARR5),hill_arr5)) / ( 1 + pow( (y[ARR5pid_s]/theta_ARR5),hill_arr5) )
    F_PIN7 = (b_pin7 + pow((y[ARR5pid_s]/theta_ARR5),hill_arr5)) / ( 1 + pow( (y[ARR5pid_s]/theta_ARR5),hill_arr5) )
    F_PIN3 = b_pin3


    if cell_type!=0 and cell_type!=6:
        ret[Axid_s]    += all_section_rate_ax * p_ax       - d_ax*y[Axid_s]
        ret[Ckid_s]    += all_section_rate_ck * p_ck*F_CK  - d_ck*y[Ckid_s]


    if cell_type==0:
        ret[Axid_s]    += phloem_rate_ax * p_ax      - d_ax*y[Axid_s]
        ret[Ckid_s]    += phloem_rate_ck * p_ck*F_CK - d_ck*y[Ckid_s]
  

    if cell_type==6:
        ret[Axid_s]  = 0.0
        ret[Ckid_s]  = 0.0
 
    if cell_type==6:
        ret[miRNAid_s] += p_mirna - d_mirna*y[miRNAid_s] - d_mirna_mrna*y[PHBmid_s]*y[miRNAid_s]
    else:
        ret[miRNAid_s] += - d_mirna*y[miRNAid_s] - d_mirna_mrna*y[PHBmid_s]*y[miRNAid_s]

    """
    if cell_type==2 and border.has_key(sid):
        ret[CKX3mid_s] += p_ckx3-d_ckx3*y[CKX3mid_s]
    """
    
    ret[PHBmid_s]  += p_phb - d_phb*y[PHBmid_s] - d_mirna_mrna*y[PHBmid_s]*y[miRNAid_s]
    ret[AHP6mid_s] += lambda_AHP6*F_AHP6 - mu_m_AHP6*y[AHP6mid_s]                    
    ret[IAA2mid_s] += lambda_IAA2*F_IAA2 - mu_m_IAA2*y[IAA2mid_s]                    
    ret[ARR5mid_s] += lambda_ARR5*F_ARR5 - mu_m_ARR5*y[ARR5mid_s]                    
    ret[PIN1mid_s] += lambda_PIN1*F_PIN1 - mu_m_PIN1*y[PIN1mid_s]
    ret[PIN3mid_s] += lambda_PIN3*F_PIN3 - mu_m_PIN3*y[PIN3mid_s]
    ret[PIN7mid_s] += lambda_PIN7*F_PIN7 - mu_m_PIN7*y[PIN7mid_s]

    ret[AHP6pid_s] += delta_AHP6*y[AHP6mid_s] - mu_p_AHP6*y[AHP6pid_s]                    
    ret[IAA2pid_s] += delta_IAA2*y[IAA2mid_s] - mu_p_IAA2*y[IAA2pid_s]                    
    ret[ARR5pid_s] += delta_ARR5*y[ARR5mid_s] - mu_p_ARR5*y[ARR5pid_s]                    
    ret[PHBpid_s]  += delta_PHB *y[PHBmid_s]  - mu_p_PHB *y[PHBpid_s]                    
    ret[CKX3pid_s] += delta_CKX3*y[CKX3mid_s] - mu_p_CKX3*y[CKX3pid_s]                    


    return ret


to_integrate = np.array([Auxin,Cytokinin,AHP6m,AHP6p,IAA2m,IAA2p,ARR5m,ARR5p,PHBm,PHBp,\
                         CKX3m,CKX3p,miRNA,PIN1m,PIN3m,PIN7m])

t_output = np.arange(0.,t_final,dt)
integrated = odeint(deriv,to_integrate,t_output)


ind=0
Auxin_res = integrated[:, ind]  
ind+=1
Cytokinin_res = integrated[:, ind]  
ind+=1
AHP6m_res = integrated[:, ind]  
ind+=1
AHP6p_res = integrated[:, ind]  
ind+=1
IAA2m_res = integrated[:, ind]  
ind+=1
IAA2p_res = integrated[:, ind]  
ind+=1
ARR5m_res = integrated[:, ind]  
ind+=1
ARR5p_res = integrated[:, ind]  
ind+=1
PHBm_res = integrated[:, ind]  
ind+=1
PHBp_res = integrated[:, ind]  
ind+=1
CKX3m_res = integrated[:, ind]  
ind+=1
CKX3p_res = integrated[:, ind]  
ind+=1
miRNA_res = integrated[:, ind]  
ind+=1
PIN1m_res = integrated[:, ind]  
ind+=1
PIN3m_res = integrated[:, ind]  
ind+=1
PIN7m_res = integrated[:, ind]  



plt.plot(t_output, Auxin_res)
plt.show()
