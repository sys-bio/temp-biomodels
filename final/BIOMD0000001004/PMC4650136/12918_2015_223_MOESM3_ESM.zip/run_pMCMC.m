function result = run_pMCMC

% active parameters, model 8
theta_ind = [1:12 14:18];

% input data
[DATA, PHI, T, STAT3_init, RORC_init, FOXP3_init, M, C] = prepare_input_data;

% define log-likelihood and prior distribution
pMCMC_params.log_likelihood = @(theta)logLH(theta,theta_ind,DATA,PHI,T,STAT3_init,RORC_init,FOXP3_init,M,C);
pMCMC_params.log_prior      = @(theta)logPRIOR(theta);

% prepare input for population MCMC
beta_N                 = 30;                              % number of temperatures
pMCMC_params.beta      = ((0:(beta_N-1))./(beta_N-1)).^5; % annealing schedule
pMCMC_params.d         = length(theta_ind);               % dimension of param. space
pMCMC_params.N_samples = 5000000;                         % total number of samples including burn-in
pMCMC_params.N_subsamp = 1000;                            % interval for sub-sampling
pMCMC_params.N_burn_in = 0;                               % number of burn-in samples
pMCMC_params.N_diag    = 1000;                            % interval for showing diagnostics

% load the initial state and R (cholesky factorization of covariance matrix for proposal)
load mod8_R_and_cur_theta;

% run population MCMC
result = pMCMC(pMCMC_params,mod8_R_and_cur_theta);

% plot posterior samples
figure;
for k = 1:length(theta_ind)
    subplot(3,6,k);
    plot(squeeze(result.SAMPLES(30,k,:)),'.');
    ylabel(['log(\theta_{', int2str(theta_ind(k)), '})'])
end

% plot est. marg. post. density
figure;
for k = 1:length(theta_ind)
    subplot(3,6,k);
    ksdensity(squeeze(result.SAMPLES(30,k,:)));
    xlabel(['log(\theta_{', int2str(theta_ind(k)), '})'])
end

end

function result = pMCMC(pMCMC_params,mod8_R_and_cur_theta)

% set random seed
rng('default');

% functions for loglikelihood and logprior
log_likelihood = pMCMC_params.log_likelihood;
log_prior      = pMCMC_params.log_prior;

% set general parameters
beta        = pMCMC_params.beta;      % schedule
d           = pMCMC_params.d;         % dimension of the targer dist.
N_samples   = pMCMC_params.N_samples; % total number of samples including burn-in
N_subsamp   = pMCMC_params.N_subsamp; % interval for sub-sampling
N_burn_in   = pMCMC_params.N_burn_in; % number of burn-in samples
N_diag      = pMCMC_params.N_diag;    % interval for showing/plotting diagnostics

% covariance for proposal distributions
R           = mod8_R_and_cur_theta.R; % cholesky factorization of the proposal covariance in different temperatures

% initialize vectors and matrices for internal book keeping
log_lh    = zeros(1,length(beta));          % log likelihood at the current points
cur_f     = zeros(1,length(beta));          % log target at the current points i.e. log_lh(i) + log_pr(i)
cur_theta = mod8_R_and_cur_theta.cur_theta; % initial state

% initialize matrices to store diagnostics and samples
n_accepted_local     = zeros(1,length(beta));
n_accepted_global    = zeros(1,length(beta));
n_local_updates      = zeros(1,length(beta));
n_global_updates     = zeros(1,length(beta));
LOG_LH               = zeros(floor(N_samples/N_subsamp),length(beta));
CUR_F                = zeros(floor(N_samples/N_subsamp),length(beta));
SAMPLES              = zeros(length(beta),d,floor((N_samples - N_burn_in)/N_subsamp));

% initializes counters for subsampling and samples
count        = 1;
sample_count = 1;

% compute target vals using the initial state of the chain
cur_f(1)  = log_prior(cur_theta(1,:));      % density directly from prior
log_lh(1) = log_likelihood(cur_theta(1,:));
for j = 2:length(beta)
    log_lh_temp0 = log_likelihood(cur_theta(j,:));
    log_lh(j) = log_lh_temp0; % update the log-likelihood value
    cur_f(j) = beta(j)*log_lh_temp0 + log_prior(cur_theta(j,:));
end

for i = 1:N_samples
    % sample the temperature for local move
    j = find(rand < (0:length(beta))./(length(beta)),1)-1;
    
    % keep track of the number of local updates in different
    % temperatures
    n_local_updates(j) = n_local_updates(j) + 1;
    
    % in the case of j=1 (i.e. beta = 0), sample directly from the prior
    if(j == 1)
        cur_theta(j,:) = randn(1,d);
        cur_f(j)  = logPRIOR(cur_theta(j,:));       % update the target value
        log_lh(j) = log_likelihood(cur_theta(j,:)); % update the log-likelihood value
    % otherwise run metropolis
    else
        % generate a sample using normal proposal
        theta_star = cur_theta(j,:) + randn(size(cur_theta(j,:)))*R(:,:,j);
        log_lh_temp1 = log_likelihood(theta_star);
        star_f = beta(j)*log_lh_temp1 + log_prior(theta_star);
        % check acceptance
        if ( log(rand) < (star_f - cur_f(j)) )
            cur_theta(j,:) = theta_star; % update theta_j by the proposed value
            cur_f(j) = star_f;           % update the target value
            log_lh(j) = log_lh_temp1;    % update the log-likelihood value
            n_accepted_local(j) = n_accepted_local(j) + 1;
        end
    end
    
    % global moves
    for j_index = [ 2:length(beta), fliplr(2:length(beta))]
        % keep track of updates
        n_global_updates(j_index) = n_global_updates(j_index) + 1;
        % compute acceptance ratio
        logratio = (beta(j_index-1)*log_lh(j_index) + beta(j_index)*log_lh(j_index-1)) - (beta(j_index-1)*log_lh(j_index-1) + beta(j_index)*log_lh(j_index));

        % check acceptance
        if ( log(rand) < logratio )
            cur_f(j_index)   = beta(j_index)   * log_lh(j_index-1) + log_prior(cur_theta(j_index-1,:)); % update the target value
            cur_f(j_index-1) = beta(j_index-1) * log_lh(j_index)  + log_prior(cur_theta(j_index,:));    % update the target value
            % swap parameter vectors
            THETA_temp = cur_theta;
            cur_theta(j_index,:)   = THETA_temp(j_index-1,:);
            cur_theta(j_index-1,:) = THETA_temp(j_index,:);
            log_lh_temp2 = log_lh;
            log_lh(j_index)   = log_lh_temp2(j_index-1); % update the log-likelihood value
            log_lh(j_index-1) = log_lh_temp2(j_index);   % update the log-likelihood value            
            n_accepted_global(j_index) = n_accepted_global(j_index) + 1;
        end
    end
    
    if(mod(i,N_subsamp)==0)
        LOG_LH(count,:) = log_lh;
        CUR_F(count,:) = cur_f;
        count = count + 1;
        % if the burn-in is finished, collect also samples
        if(i > N_burn_in)
            SAMPLES(:,:,sample_count) = cur_theta;
            sample_count = sample_count + 1;
        end
    end
    
    % show diagnostics
    if(mod(i,N_diag)==0)
        display([num2str(100*i/N_samples), '% done.']);
        display(['Acceptance rate ', num2str(100*(sum(n_accepted_local) + sum(n_accepted_global)) / (sum(n_local_updates) + sum(n_global_updates)) ), '%']);
        display(['Acceptance rate, local moves ', num2str(100*(sum(n_accepted_local)) / (sum(n_local_updates)) ), '%']);
        display(['Acceptance rate, global moves ', num2str(100*(sum(n_accepted_global)) / (sum(n_global_updates)) ), '%']);
        display('--------------');
    end
end

% result
result.n_accepted_local  = n_accepted_local;
result.n_local_updates   = n_local_updates;
result.n_accepted_global = n_accepted_global;
result.n_global_updates  = n_global_updates;
result.LOG_LH            = LOG_LH;
result.CUR_F             = CUR_F;
result.SAMPLES           = SAMPLES;

end

function dx = ode_system(t,x,theta,init_IL6,init_TGFb)

% input levels for scaling
IL6_th17input  = 20; TGFb_th17input = 1;

% analytical solution for intracellular cytokine levels
IL6_int  = (init_IL6/IL6_th17input)   * (1 - exp(-theta(1)*t));
TGFb_int = (init_TGFb/TGFb_th17input) * (1 - exp(-theta(9)*t));

dx = zeros(6,1);
% x(1) - Stat3_mRNA
dx(1) =   theta(2) ...
        + theta(3)*x(3) ...
        - theta(4)*x(1);
% x(2) - Stat3_prot
dx(2) =   theta(5)*x(1) ...
        - theta(6)*IL6_int*x(2) ...
        - theta(7)*x(2);
% x(3) - Stat3_phosphoprot     
dx(3) =   theta(6)*IL6_int*x(2) ...
        - theta(8)*x(3);    
% x(4) - Rorc_mRNA
dx(4) =   theta(10)*TGFb_int*x(3) ...
        - theta(11)*x(6)*x(4) ...  % inhibition by foxp3
        - theta(12)*x(4);
% x(5) - Foxp3_mRNA
dx(5) =   theta(13) ...            % basal activation
        + theta(14)*TGFb_int ...   % activation by TGFb
        - theta(15)*x(3)*x(5) ...  % inhibition by stat3
        - theta(16)*x(5);
% x(6) - Foxp3_prot
dx(6) =   theta(17)*x(5) ...
        - theta(18)*x(6);
    
end

function log_prior = logPRIOR(theta)

log_prior = length(theta)*log(1/(sqrt(2*pi))) - 0.5*sum(theta.^2);

end

function log_lhood = logLH(theta,theta_ind,DATA, PHI, T, STAT3_init, RORC_init, FOXP3_init, M, C)

init_IL6  = 20;
init_TGFb = 1;

theta_lin = zeros(1,18);
theta_lin(theta_ind) = exp(theta);

try
    % solve response
    [t X] = ode15s(@(t,X)ode_system(t,X,theta_lin,init_IL6,init_TGFb),[0 T],[STAT3_init/C 1 0 RORC_init/C FOXP3_init/C 1]);
    % scale
    MU = max(C*[repmat(X(2:end,1),1,3) repmat(X(2:end,4),1,3) repmat(X(2:end,5),1,3)].*[M M M],0);
    % compute likelihood based on the NB distribution
    log_lhood = sum(sum(      gammaln(DATA + (1./PHI)) ...
        - gammaln((1./PHI)) ...
        - gammaln(DATA + 1) ...
        + (1./PHI) .* log(1 ./ (1 + MU .* PHI)) ...
        + DATA .* log(MU ./ ((1./PHI) + MU)) ...
        ));

catch
    log_lhood = -1e6;
end     

end

function [DATA, PHI, T, STAT3_init, RORC_init, FOXP3_init, M, C] = prepare_input_data

% Thp data (at 0 hours)
STAT3_thp = [6807
             4893
             8686];
         
RORC_thp =  [9
             55
             38];
         
FOXP3_thp = [2238
             1607
             2580];
         
M_thp = [16410829
         10804012
          17192850];
      
% initial abundances based on averages of thp measurements
STAT3_init = mean(STAT3_thp./M_thp);
RORC_init  = mean(RORC_thp./M_thp);
FOXP3_init = mean(FOXP3_thp./M_thp);

% library sizes
M =      [17657582    15875968    18991346    16496678    16118519    17493780    16432535    18280419    23446761
          11926410    13055612    15109892    17119113    15979147    14852672    16999116    17429518    20762331
          16581768    19445890    12841317    14228551    15986800    17346748    19052670    21273105    21587524]';

% data at 9 time points, read counts
STAT3 =      [8413       20556       43406       14371        7566       12123       10904       12619       17865
              5006       15971       31584       13910        7049        9581       10807       12765       17548
              7545       20473       22646       12129        7267       11774       13016       14390       15932]';
         
RORC =       [ 7           6         146         902        1545        5066        5313        4541        4989
              41          40         223         998        1531        3972        5133        4407        5074
              73         108         149         703        1316        4688        5978        5632        4568]';
         
FOXP3 =      [1869        1139         485         836        1233        1133        1268        1336        1526
              1493        1046         420        1016        1253        1063        1155        1201        1208
              2257        1732         440         880        1427        1292        1405        1588        1222]';

% Measurement times (th0 and th17 conditions)
T = [0.5 1 2 4 6 12 24 48 72];

% global dispersion estimated from data
phi = [0.007827293 0.0017415661   0.0027156614   0.0020994483   0.0020447991   0.0011874179   0.0007739092  0.0030286538   0.0437877137   0.1037737656];

% scaling constant for model
C = 1e-3;

% organize
PHI = repmat(phi(2:end)',1,9);
DATA = [STAT3 RORC FOXP3];

end