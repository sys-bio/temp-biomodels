# Project Name

 Name of Model Folder ghosh2022-BHK2022-Project9. This work is done in the framework of the Biohackathon 2022- Project 9. 

## Table of Contents

- [Description](#description)
	This is a use case developed during Biohackathon 2022 to show that, given any automatic classification model for the documents, we can convert them to ONNX format. This conversion ensures interoperability and open access. The ONNX (Open Neural Network Exchange) format utility can perform the following essential tasks: model conversion, inference, inspection, and optimization. We add a Dockerfile to this folder so that one can prepare the Docker image to use the model seamlessly. 
- [Installation](#installation)
	It needs to download & Install:
	1. To download https://gitlab.ebi.ac.uk/literature-services/public-projects/emerald_metagenomics_annotations and install.
	2. It need to download the zip file onnx-metagene-text-classifier from the ghosh2022-BHK2022-Project9 (MODEL2304210001). It needs to unzip the files inside "emerald_metagenomics_annotations" folder.
- [Usage](#usage)
	-First to create the Docker image using Dockerfile from the downloaded zip from onnx-metagene-text-classifier using 'docker build -t <name of image> .
	-copy or move the classify_texts_update.py of the onnx-metagene-text-classifier into emerald_metagenomics_annotations/scripts/classify_texts.py
	-move run_metagene.sh of  the onnx-metagene-text-classifier into emerald_metagenomics_annotations/run_metagene.sh
- [Contributing](#contributing) & [License](#license)
	This model is built upon the model of the following publication: A machine learning framework for discovery and enrichment of metagenomics metadata from open access publications. Maaly Nassar, Rogers AB, Talo' F, Sanchez S, Shafique Z, Finn RD, McEntyre J GigaScience , 8/ 2022 , Volume 11 , pages: giac077 , PubMed ID: 35950838 

## License
	This work is done in the framework of the Biohackathon 2022- Project 9.
Specify the license under which the project is distributed. If you're unsure about licensing, consult with your team or consider using an open-source license like MIT or Apache 2.0.

