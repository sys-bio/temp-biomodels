function create_single_triplex_png(result_file)

n=-1:0.025:2;
Interval=10.^n;

%for j = index1:index2
    
%     result_dir = ['cps_dir_',int2str(j)];
%     
%     eval(['cd ',result_dir,'\results\'])
    
    
   % A = dir;
    
   % for i = 3:size(A,1)
            
        
        set(0,'DefaultFigureVisible','off');
%         result_file = A(i).name;
        result_matrix = read_copasi_results(result_file);
        
        
        Labels = regexp(result_file,'_','split');
        Label_x_components = regexp(cell2mat(Labels(3)),'-','split');
        Label_x = strcat(Label_x_components(2),'-', Label_x_components(3));
        Label_y_components = regexp(cell2mat(Labels(4)),'-','split');
        Label_y = strcat(Label_y_components(2),'-', Label_y_components(3));
        Label_title_components = regexp(cell2mat(Labels(5)),'\.','split');
%        Label_title_MFE = strcat('(',Label_title_components(1),'.', Label_title_components(2),' kcal/mol)');
        Label_title_MFE = strcat('(',Label_title_components(1),'.', Label_title_components(2), ')');
        Label_file_MFE = strcat(Label_title_components(1),'.', Label_title_components(2));
        Label_title = [cell2mat(Labels(2)) ' ', cell2mat(Label_title_MFE) ];
        
        outfile = ['.\',cell2mat(Labels(2)),'_',cell2mat(Labels(3)),'_',cell2mat(Labels(4)),'_',cell2mat(Label_file_MFE),'.png'];
        
        fig_handle = figure(111);
        
        plotdata=result_matrix';
        plotdata(end,end)=0;
        pcolor(Interval, Interval, plotdata)
        shading flat
        hold on
        plot([1,1],[1,10],'-ow', 'MarkerFaceColor','w','MarkerSize',3)
        plot([1,10],[1,1],'-ow', 'MarkerFaceColor','w','MarkerSize',3)
        plot([1,5],[1,5],'-ow', 'MarkerFaceColor','w','MarkerSize',5)
        plot(1,10,'^w', 'MarkerFaceColor','w','MarkerSize',8)
        plot(10,1,'>w', 'MarkerFaceColor','w','MarkerSize',8)
        plot(5,5,'dw', 'MarkerFaceColor','w','MarkerSize',8)
        text1=num2str(plotdata(41,41)-plotdata(41,81),3);
        text2=num2str(plotdata(41,41)-plotdata(81,41),3);
        text3=num2str(plotdata(41,41)-plotdata(69,69),3);
        text([10,0.5,6],[0.6,15,6],{text1,text2,text3},'color','white','fontsize',12)
        
        set(gca,'DataAspectRatio',[1 1 1],...
            'PlotBoxAspectRatio',[1 1 1],'ZLim',[-0.6 0.6])
        set(gca,'xscale','log','yscale','log','xlim',[0 100],'ylim',[0 100],'xtick',[10e-2 10e-1 10e0 10e1 10e2],'ytick',[10e-2 10e-1 10e0 10e1 10e2],'Fontsize',16);
        title(Label_title)
        ylabel(Label_y)
        xlabel(Label_x)
        
        saveas(fig_handle,outfile,'png');
        close all;
        
    %end
    %cd ..
    %cd ..
    
%end




end