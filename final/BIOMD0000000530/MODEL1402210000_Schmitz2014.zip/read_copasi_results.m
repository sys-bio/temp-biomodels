function m_new = read_copasi_results(filename)

M=csvread(filename);
m_size = sqrt(size(M,1));
m_new = zeros(m_size,m_size);

 
for i = 1:m_size
    m_new(i,:) = M((i-1)*m_size+1:i*m_size);
end


end