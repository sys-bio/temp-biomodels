from PlayerPython import * 
####
#### The simulation code is compatible with CompuCell3D Version:3.6.2 Revision: 20130208
#### 
#### J. Sluka, A. Cosmanescu, M. Swat, X. Fu
#### March 11, 2014
#### October 5, 2012
#### Original File: Liver_PBPK_CC3D_SBML_v05.py
####
#### This simultions is based on Liver_PBPK_CC3D_SBML_v02.py
#### This version is an attempt to get the simulation running faster than 
#### ~45 wall clock days needed to simulate ~3hrs real time.
####
#### This version is for the PBPB-CC3D-SBML integration test
#### New version of CC3D randomly assigns the parent and child cells after mitosis, which
#### is different than previous versions. Need to properly assign the parent cell after mitosis
#### to keep it adjacent to the left hand wall of the model


##################
#### Global variables are in the steppables file
##################

##################
##########  Compucell configurations: (XML file replacement)
##################
def configureSimulation(sim):
    import CompuCellSetup
    from XMLUtils import ElementCC3D
    from math import log

    cc3d=ElementCC3D("CompuCell3D")
    
    meta=cc3d.ElementCC3D("Metadata")
#    meta.ElementCC3D("VirtualProcessingUnits",{"ThreadsPerCPU":"2"},2)
    meta.ElementCC3D("VirtualProcessingUnits",{"ThreadsPerCPU":"1"},1)
    
    mcssteps = 2160001*8 ## 17280001 is 8h if 1 s = 600 mcs
    potts=cc3d.ElementCC3D("Potts")
    potts.ElementCC3D("DebugOutputFrequency",{},0)
    potts.ElementCC3D("Dimensions",{"x":200,"y":60,"z":1})
    potts.ElementCC3D("Steps",{},mcssteps)   # 60MMCS is about 4.2 hours of simulated time (4KMCS/sim.sec)
    potts.ElementCC3D("Temperature",{},5)
    potts.ElementCC3D("Flip2DimRatio",{},1)
    potts.ElementCC3D("NeighborOrder",{},2)
#     potts.ElementCC3D("RandomSeed",{},"987")        **$**


    cellType=cc3d.ElementCC3D("Plugin",{"Name":"CellType"})
    cellType.ElementCC3D("CellType", {"TypeName":"Medium",             "TypeId":"0"             })
    cellType.ElementCC3D("CellType", {"TypeName":"Hepatocyte",         "TypeId":"1", "Freeze":""})
    cellType.ElementCC3D("CellType", {"TypeName":"BloodPortion",       "TypeId":"2"             })
    cellType.ElementCC3D("CellType", {"TypeName":"BloodPortion_source","TypeId":"3"             })
    cellType.ElementCC3D("CellType", {"TypeName":"RedBloodCell",       "TypeId":"4"             })
    cellType.ElementCC3D("CellType", {"TypeName":"DeadHepatocyte",     "TypeId":"5", "Freeze":""})

    PlaySet =cc3d.ElementCC3D("Plugin",{"Name":"PlayerSettings"})
    PlaySet.ElementCC3D("Cell", {"Type":0, "Color":"#000000"}) #black
    PlaySet.ElementCC3D("Cell", {"Type":1, "Color":"#00FF00"}) #green
    PlaySet.ElementCC3D("Cell", {"Type":2, "Color":"#0000FF"}) #blue
    PlaySet.ElementCC3D("Cell", {"Type":3, "Color":"#990000"}) #dark red
    PlaySet.ElementCC3D("Cell", {"Type":4, "Color":"#FF0000"}) #red
    PlaySet.ElementCC3D("Cell", {"Type":5, "Color":"#CCCCCC"}) #grey
    PlaySet.ElementCC3D("VisualControl", {"ScreenshotFrequency":180000, "ScreenUpdateFrequency":36000})
 
 
 #   PlaySet.ElementCC3D("TypesInvisibleIn3D",{"Types":"0,3,4"})
 #   PlaySet.ElementCC3D("VisualControl", {"ScreenshotFrequency":int(10**round(log(6e7,10))/1e3),\
 #                                         "ScreenUpdateFrequency":int(10**round(log(6e7,10))/2e3)})
 #   PlaySet.ElementCC3D("MainWindow",{"Projection":"2D", "XZProj":20})
 #   PlaySet.ElementCC3D("NewWindow", {"Projection":"3D", "WindowNumber":1, "CameraClippingRange":"0.13 129.9","CameraDistance":56.7, "CameraViewUp":"0.01 0.99 0.02"})
 #   PlaySet.ElementCC3D("NewWindow", {"Projection":"3D", "WindowNumber":2, "CameraFocalPoint":"-16 18 61","CameraPos":"-19 17. 66."})

    contact=cc3d.ElementCC3D("Plugin",{"Name":"Contact"})  # bigger values are less adhesive
    contact.ElementCC3D("Energy", {"Type1":"Medium",             "Type2":"Medium"},              5)  # doesn't matter since the cells are "frozen"
    contact.ElementCC3D("Energy", {"Type1":"Medium",             "Type2":"Hepatocyte"},          5)
    contact.ElementCC3D("Energy", {"Type1":"Medium",             "Type2":"BloodPortion"},        5)
    contact.ElementCC3D("Energy", {"Type1":"Medium",             "Type2":"BloodPortion_source"}, 5)
    contact.ElementCC3D("Energy", {"Type1":"Medium",             "Type2":"RedBloodCell"},        5)
    contact.ElementCC3D("Energy", {"Type1":"Medium",             "Type2":"DeadHepatocyte"},      5)
    
    contact.ElementCC3D("Energy", {"Type1":"Hepatocyte",         "Type2":"Hepatocyte"},          5)
    contact.ElementCC3D("Energy", {"Type1":"Hepatocyte",         "Type2":"BloodPortion"},        5)
    contact.ElementCC3D("Energy", {"Type1":"Hepatocyte",         "Type2":"BloodPortion_source"}, 5)
    contact.ElementCC3D("Energy", {"Type1":"Hepatocyte",         "Type2":"RedBloodCell"},        10)
    contact.ElementCC3D("Energy", {"Type1":"Hepatocyte",         "Type2":"DeadHepatocyte"},      5)
    
    contact.ElementCC3D("Energy", {"Type1":"BloodPortion",       "Type2":"BloodPortion"},        5)
    contact.ElementCC3D("Energy", {"Type1":"BloodPortion",       "Type2":"BloodPortion_source"}, 40)
    contact.ElementCC3D("Energy", {"Type1":"BloodPortion",       "Type2":"RedBloodCell"},        5)  #10   May 6 2014
    contact.ElementCC3D("Energy", {"Type1":"BloodPortion",       "Type2":"DeadHepatocyte"},      5)
    
    contact.ElementCC3D("Energy", {"Type1":"BloodPortion_source","Type2":"BloodPortion_source"}, 5)
    contact.ElementCC3D("Energy", {"Type1":"BloodPortion_source","Type2":"RedBloodCell"},        40)
    contact.ElementCC3D("Energy", {"Type1":"BloodPortion_source","Type2":"DeadHepatocyte"},      5)
    
    contact.ElementCC3D("Energy", {"Type1":"RedBloodCell","Type2":"RedBloodCell"},               10)
    contact.ElementCC3D("Energy", {"Type1":"RedBloodCell","Type2":"DeadHepatocyte"},             10)
    
    contact.ElementCC3D("Energy", {"Type1":"DeadHepatocyte","Type2":"DeadHepatocyte"},           5)

    contact.ElementCC3D("NeighborOrder",{},4)

    centerOfMass    =cc3d.ElementCC3D("Plugin",{"Name":"CenterOfMass"    })
    neighborTracker =cc3d.ElementCC3D("Plugin",{"Name":"NeighborTracker" })    
#    surfaceTracker  =cc3d.ElementCC3D("Plugin",{"Name":"SurfaceTracker"  })
#    volumeTracker   =cc3d.ElementCC3D("Plugin",{"Name":"VolumeTracker"   })
    VolumeLocalFlex =cc3d.ElementCC3D("Plugin",{"Name":"VolumeLocalFlex" })
#    SurfaceLocalFlex=cc3d.ElementCC3D("Plugin",{"Name":"SurfaceLocalFlex"})

    # force to move the BloodPortion (in addition to any forces caused by the growing BloodPortions)
    # Bigger cells get bigger force
    # 10/4/12 the forces moved to ForceSourceCells steppable
    externalPotential=cc3d.ElementCC3D("Plugin",{"Name":"ExternalPotential"})
    #externalPotential.ElementCC3D("ExternalPotentialParameters", {"CellType":"BloodPortion", "x":" -20",  "y":"0", "z":"0"})
    #externalPotential.ElementCC3D("ExternalPotentialParameters", {"CellType":"RedBloodCell", "x":"-100", "y":"0", "z":"0"})
    # for CC3D v3.6.2 added force to push the blood source cells back to the LH wall since the mitosis
    # now randomly decides which of the two cells is the child and which is the parent
    # in the big run of late sept 2012 source cells still drift off the left wall with a forcing potential of "x":"5" so
    # changed to a cell by cell forcing based on the inital BloodPortion_source COM in the steppable
    #externalPotential.ElementCC3D("ExternalPotentialParameters", {"CellType":"BloodPortion_source", "x":"10", "y":"0", "z":"0"})



#     pifInit=cc3d.ElementCC3D("Steppable",{"Type":"PIFInitializer"})
#     pifInit.ElementCC3D('PIFName',{},'Simulation/Sinusoid.piff')
    ### Initialize the cells  200x60
    uniformInit=cc3d.ElementCC3D("Steppable",{"Type":"UniformInitializer"})
    # BloodPortion
    region=uniformInit.ElementCC3D("Region")
    region.ElementCC3D("BoxMin",{"x":5 , "y":20, "z":0})  #  8/21/2012 region.ElementCC3D("BoxMin",{"x":5,  "y":20,"z":0})
    region.ElementCC3D("BoxMax",{"x":200,"y":39,"z":1})
    region.ElementCC3D("Types",{},"BloodPortion")
    region.ElementCC3D("Width",{},5)
    region.ElementCC3D("Gap",{},0)
    # BloodPortion_source (column of "cells")
    region=uniformInit.ElementCC3D("Region")
    region.ElementCC3D("BoxMin",{"x":0,  "y":20, "z":0})
    region.ElementCC3D("BoxMax",{"x":4,  "y":39,"z":1})  #  leaves a gap for the sources to expand into
    region.ElementCC3D("Types",{},"BloodPortion_source")
    region.ElementCC3D("Width",{},5)
    region.ElementCC3D("Gap",{},0)

    # Hepatocytes as 20x20 cells across the top and bottom
    region=uniformInit.ElementCC3D("Region")
    region.ElementCC3D("BoxMin",{"x":0,  "y":0, "z":0})
    region.ElementCC3D("BoxMax",{"x":200,"y":19,"z":1})
    region.ElementCC3D("Types",{},"Hepatocyte")
    region.ElementCC3D("Width",{},20)  
    region=uniformInit.ElementCC3D("Region")
    region.ElementCC3D("BoxMin",{"x":0,  "y":40,"z":0})
    region.ElementCC3D("BoxMax",{"x":200,"y":59,"z":1})
    region.ElementCC3D("Types",{},"Hepatocyte")
    region.ElementCC3D("Width",{},20)


    # next line is very important and very easy to forget about. It registers XML description and points
    # CC3D to the right XML file (or XML tree data structure in this case)
    CompuCellSetup.setSimulationXMLDescription(cc3d)

#####################################################################################
#### --------------------------------------------------------------------------------
import sys
from os import environ
from os import getcwd
import string
sys.path.append(environ["PYTHON_MODULE_PATH"])

#  import CompuCellSetup  # duplicates above
sim,simthread = CompuCellSetup.getCoreSimulationObjects()
#NOTE: Importing CompuCell to main script has to be done after call to getCoreSimulationObjects()
configureSimulation(sim)
CompuCellSetup.initializeSimulationObjects(sim,simthread)
import CompuCell #notice importing CompuCell to main script has to be done after call to getCoreSimulationObjects()

dim=sim.getPotts().getCellFieldG().getDim()

#Create extra player fields here or add attributes, need a dictionary to hold the chemical loads
pyAttributeAdder,dictAdder=CompuCellSetup.attachDictionaryToCells(sim)
loadField=simthread.createFloatFieldPy(dim,"loadField") # initializing load Field - this location in the code is important this must be called before
APAPconc =simthread.createFloatFieldPy(dim,"APAPconc" ) # preStartInit or otherwise field list will not be initialized properly
GSHconc  =simthread.createFloatFieldPy(dim,"GSHconc"  ) 
NAPQIconc=simthread.createFloatFieldPy(dim,"NAPQIconc") 
APAPconj =simthread.createFloatFieldPy(dim,"APAPconj" ) 
NAPQIGSH =simthread.createFloatFieldPy(dim,"NAPQIGSH" ) 


#
######################
##########  PLUGINS
######################
#


#
#######################
##########  STEPPABLES
#######################
#
from PySteppables import SteppableRegistry
steppableRegistry=SteppableRegistry()

from PBPK_SBML_MULTISteppables import *
#                                   sim,frequency
volumeParamSteppable=VolumeParamSteppable(_simulator=sim,_frequency=1)
steppableRegistry.registerSteppable(volumeParamSteppable)

loadAttribute=LoadAttribute(_simulator=sim,_frequency=10)  # python dictionary to hold the molecule load of the cells
steppableRegistry.registerSteppable(loadAttribute)         # and does the 'PDE' calcs, links to the PBPK and SBML models

mitosisSteppable=MitosisSteppable(sim,10)
steppableRegistry.registerSteppable(mitosisSteppable)

  #******* commented out for sensitivity analysis *******
tissueLevelsFromPBPK=TissueLevelsFromPBPK(_simulator=sim,_frequency=1000) # shows the tissue levels from the PBPK model
steppableRegistry.registerSteppable(tissueLevelsFromPBPK)   

forceSourceCells=ForceSourceCells(_simulator=sim,_frequency=20) # forces the source cells back near their original COM
steppableRegistry.registerSteppable(forceSourceCells)   


# loadFieldVisualizationSteppable=LoadFieldVisualizationSteppable(_simulator=sim,_frequency=1000)
# loadFieldVisualizationSteppable.setScalarField(loadField)
# steppableRegistry.registerSteppable(loadFieldVisualizationSteppable)

  #******* commented out for sensitivity analysis *******
# concentrationFieldVisualizationSteppable=ConcentrationFieldVisualizationSteppable(_simulator=sim,_frequency=1000)
# concentrationFieldVisualizationSteppable.setScalarField(APAPconc)
# steppableRegistry.registerSteppable(concentrationFieldVisualizationSteppable)
 
  #******* commented out for sensitivity analysis *******
# gSHConcentrationFieldVisualizationSteppable=GSHConcentrationFieldVisualizationSteppable(_simulator=sim,_frequency=1000)
# gSHConcentrationFieldVisualizationSteppable.setScalarField(GSHconc)
# steppableRegistry.registerSteppable(gSHConcentrationFieldVisualizationSteppable)

# nAPQIConcentrationFieldVisualizationSteppable=NAPQIConcentrationFieldVisualizationSteppable(_simulator=sim,_frequency=1000)
# nAPQIConcentrationFieldVisualizationSteppable.setScalarField(NAPQIconc)
# steppableRegistry.registerSteppable(nAPQIConcentrationFieldVisualizationSteppable)

# aPAPconjConcentrationFieldVisualizationSteppable=APAPconjConcentrationFieldVisualizationSteppable(_simulator=sim,_frequency=1000)
# aPAPconjConcentrationFieldVisualizationSteppable.setScalarField(APAPconj)
# steppableRegistry.registerSteppable(aPAPconjConcentrationFieldVisualizationSteppable)

# nAPQIGSHConcentrationFieldVisualizationSteppable=NAPQIGSHConcentrationFieldVisualizationSteppable(_simulator=sim,_frequency=1000)
# nAPQIGSHConcentrationFieldVisualizationSteppable.setScalarField(NAPQIGSH)
# steppableRegistry.registerSteppable(nAPQIGSHConcentrationFieldVisualizationSteppable)

##################
##########  COMPUCELL3D LOOPS
##################


# from Liver_PBPK_CC3D_SBML_v05Steppables import VolumeCheckSteppable
# instanceOfVolumeCheckSteppable=VolumeCheckSteppable(_simulator=sim,_frequency=1)
# steppableRegistry.registerSteppable(instanceOfVolumeCheckSteppable)


# from Liver_PBPK_CC3D_SBML_v05Steppables import CountDeadCellNumber
# instanceOfCountDeadCellNumber=CountDeadCellNumber(_simulator=sim,_frequency=1)
# steppableRegistry.registerSteppable(instanceOfCountDeadCellNumber)


from PBPK_SBML_MULTISteppables import DrugMetab
instanceOfDrugMetab=DrugMetab(_simulator=sim,_frequency=1)
steppableRegistry.registerSteppable(instanceOfDrugMetab)


from PBPK_SBML_MULTISteppables import MetabVisualization
instanceOfMetabVisualization=MetabVisualization(_simulator=sim,_frequency=1)
steppableRegistry.registerSteppable(instanceOfMetabVisualization)

CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)
