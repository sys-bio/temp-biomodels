####
#### The simulation code is compatible with CompuCell3D ver 3.7.3
#### 
#### J. Sluka, A. Cosmanescu, M. Swat, X. Fu
#### Janurary, 2015
####
#### File: PBPK_SBML_MULTI.py
#### This version uses SBMLSolver
#### 

###### Defined Cell Types and IDs
### "Medium",             "TypeId":"0"
### "Hepatocyte",         "TypeId":"1"
### "BloodPortion",       "TypeId":"2"
### "BloodPortion_source","TypeId":"3"
### "RedBloodCell",       "TypeId":"4"


###### Major changes on 10/03/14 ########
## 1. outflux partitioned into all neighbors uniformly
## 2. Fup involved in all processes, except APAPG, APAPS export (Fup not in subcellular reactions!)
## 3. equalibrium constant of transfer between RBC and SP (see below)           ->   line: 139
## 4*. To be added on Monday is updated PBPK module with Q and V scaled according to body weight, and new parameter Fraction Clearance (dimensionless)
#########################################

###### equalibrium constant ######
## cc3d_Ke_PD_R2S = cc3d_k_PD_R2S / cc3d_k_PD_S2R       (forward / reverse)
## at equalibrium, cc3d_k_PD_R2S * [RBC]e - cc3d_k_PD_S2R * [SP]e = 0      =>        cc3d_Ke_PD_R2S = [SP]e / [RBC]e   
## meanwhile, Rb2p = ([RBC]e*H + [SP]e*(1-H)) / [SP]e = 1/cc3d_Ke_PD_R2S*H + 1-H
## So, cc3d_Ke_PD_R2S = H/(Rb2p+H-1)
##################################

'''
Note for BR2:
modified on 10/01/14: parameter values; 
                      calculating plasma concentraion (need update class DrugMetab!); 
                      include new passive diffusion routine (need update class loadAttribute!)
'''

'''
Rb2p = ([RBC]*0.45 + [Plasma]*0.55) / [Plasma]
Prescott 1980: [RBC]/[Plasma] = 1.2  ==> Rb2p = 1.09
APAPG, APAPS not distributed into RBC   ==>  Rb2pG, Rb2pS = 0.55
Prescott 1981: Qgfr = 11.9+/-4.9; QgfrG = 131+/-22 ; QgfrS = 166+/-29  (mL/min)
               (0.714+/-0.294)    (7.86+/-1.32)      (9.96+/-1.74)     (L/h)
Morris 1983: Fup ~ 20% ; FupG < 10% ; FupS > 50%
'''

'''
k_pd 1e-3 / 
FupS, FupG : 1
Kr2p:1.6 / Kr2pG: 0.4 / Kr2pS: 0.2
VmaxG 1e-3 / VmaxS 1.75e-4
'''

from random import random,gauss,choice,seed as randomseed   
from PySteppables import *
from PySteppablesExamples import MitosisSteppableBase
import CompuCell
from math import sqrt
from PlayerPython import *
import sys
import time
import os

#GLOBALS
# Variables to integrate the load (and volume of blood) leaving the sinusoid
global SumLoadExit, SumVolumeExit, LoadInTransit, TotalCellsCreated, TotalCellsDeleted, SinusoidVolume, line2Print, ParaName, ParaIniVal, ParaCurVal, ParaDict
global APAPconjGluExit, APAPconjSulExit, totalMCS, dirResult, dirSim
global freqAll
freqAll = 180000
totalMCS = 2160001*8 
#totalMCS = 5001
SumLoadExit   = 0.0
SumVolumeExit = 0.0
LoadInTransit = 0.0
APAPconjGluExit = 0.0
APAPconjSulExit = 0.0
TotalCellsCreated = 0
TotalCellsDeleted = 0
LitersPerMicron = (1e-5)**3  # Convert 1 voxel in volume to liter
SinusoidVolume=200*20*4*LitersPerMicron ## For sinusoid, we consider a thickness of 4um instead of 20um to make the crosssection area to be 20X4 = 80 um^2 ~ pi*5*5 um^2, which roughly represents a cylinder with radius of 5um
line2Print = "" # string to send stuff to the output log file
hepatocyteList=[] # list of hepatocytes
hepatocyteListZoneIII=[] # list of hepatocytes in zone III
ParaName = ""
ParaIniVal = 0.0
ParaCurVal = 0.0

'''   Original parameter values based on Ochoa / Wambaugh
ParaDict={'Vmax_AT_APAP':3.1E-3,'Km_AT_APAP':0.066,'k_PD_APAP':0.005,'Vmax_GLUC':4.7E-4,\
          'Km_GLUC':6,'Vmax_SULF':3.82E-5,'Km_SULF':0.3,'k_AT_APAPG':4.5E-4,'k_AT_APAPS':1.9E-3,\
          'kGutabs':1,'Fup':1,'FupG':1,'FupS':1,'Kr2p':1,'Kk2p':1,'Kr2pG':1,'Kk2pG':1,\
          'Kr2pS':1,'Kk2pS':1,'Qgfr':126,'QgfrG':126,'QgfrS':126,'Rb2p':1,'Rb2pG':1,'Rb2pS':1,\
          'Km_2E1_APAP':1.29,'Vmax_2E1_APAP':1.67e-5,'kNapqiGsh':0.1,'kGsh':0.0001,\
          'dose':1.4,'copy':1}
''' 

ParaDict={}


##### Parameters used in aREF simulation
## CC3D Parameters
# R -> RBC; S -> Serum; H -> Hepatocyte
ParaDict.update({'cc3d_k_PD_R2R':1e-3,'cc3d_k_PD_R2S':1e-3,'cc3d_k_PD_R2H':1e-3,\
                 'cc3d_k_PD_S2R':1e-3,'cc3d_k_PD_S2S':1e-2,'cc3d_k_PD_S2H':1e-3,\
                 'cc3d_k_PD_H2R':1e-3,'cc3d_k_PD_H2S':1e-3,'cc3d_k_PD_H2H':1e-3,\
                 'cc3d_Vmax_AT_APAP':1e-2,'cc3d_Km_AT_APAP':1e-2,'cc3d_k_AT_APAPG':4.5e-4,'cc3d_k_AT_APAPS':1.9e-3})

## PBPK Parameters
ParaDict.update({'pbpk_hemat':0.45,'pbpk_bw':70,'pbpk_kGutabs':1.5,'pbpk_Fup':0.8,'pbpk_FupG':1,'pbpk_FupS':1,\
                 'pbpk_Kr2p':1.6 ,'pbpk_Kk2p':1,'pbpk_Kr2pG':0.4,'pbpk_Kk2pG':1,'pbpk_Kr2pS':0.2,'pbpk_Kk2pS':1,\
                 'pbpk_Qgfr':0.714,'pbpk_QgfrG':7.86,'pbpk_QgfrS':9.96,'pbpk_Rb2p':1.09,'pbpk_Rb2pG':0.55,'pbpk_Rb2pS':0.55})

## SUBCELL Parameters
ParaDict.update({'sc_Vmax_GLUC':1e-3,'sc_Km_GLUC':1,'sc_Vmax_SULF':1.75e-4,'sc_Km_SULF':0.2,\
                 'sc_Km_2E1_APAP':1.29,'sc_Vmax_2E1_APAP':2e-5,\
                 'sc_kNapqiGsh':0.1,'sc_kGsh':0.0001})

## Special
ParaDict.update({'pbpk_dose':1.4,'copy':1,'parameter':'aREF'})

#''# update the reverse PD transfer rate from SP to RBC based on the Rb2P
# cc3d_k_PD_S2R = cc3d_k_PD_R2S / cc3d_Ke_PD_R2S
H = ParaDict['pbpk_hemat']
a = ParaDict['cc3d_k_PD_R2S'] / (H/(ParaDict['pbpk_Rb2p']+H-1))         # originally too many digits!
ParaDict['cc3d_k_PD_S2R'] = float("{0:.6f}".format(a))
#####

###HERE_011215###

### import human experimental data file
dirResult = ""; dirSim = ""
dirResult += "H:/ShareToVB/Dropbox/"
# dirSim += "C:\\Users\\xfu\\Documents\\CC3DWorkspace" 

class VolumeParamSteppable(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        self.simulator=_simulator
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.nTrackerPlugin=CompuCell.getNeighborTrackerPlugin()
        self.cellFieldG=self.simulator.getPotts().getCellFieldG()
        self.dim=self.cellFieldG.getDim() # get the model params like self.dim.x,self.dim.y,self.dim.z,
        self.NumOfBloodPortionDead=0
        self.NumOfRedBloodDead=0

    def start(self):  
        self.setMaxMCS(totalMCS)
        
        import CompuCellSetup 
        try:
            self.output_file,outFullFileName=CompuCellSetup.openFileInSimulationOutputDirectory("AOut_Data.txt","a")
        except IOError:
            sys.exit("\n\nIOError: Problem opening the log file.\n >>> IS THE PLAYER OPTION \"SAVE IMAGE EVERY NTH MCS\" NOT CHECKED? <<<\n") # requires import sys
        except:
            sys.exit("\n\n >>> Unkown Error: Problem opening the log file. <<<\n") # requires import sys

        import datetime
        timeStamp=datetime.datetime.now()
        self.output_file.write("'=====start===== "+timeStamp.ctime()+"\n")
        self.output_file.write("VolumeParamSteppable.step\tMCS\ttype\tdMCS\tsourceCellID\tCenMass-yExit\tExitLoad\tInitialLoad\tDeltaLoad\t\n")
        self.output_file.write("VolumeParamSteppable:cellCounts\tMCS\tTotalCellsCreated\tTotalCellsDeleted\tcellCount\tError\n")
        self.output_file.write("MitosisSteppable.new flow portion\tMCS\tCellType\tFlowType\tLoad\n")
        self.output_file.write("MitosisSteppable.DidMitosis.Swaped.sourceList\tMCS\tsources[0]\tsources[1]\tsources[2]\tsources[3]\n")
        self.output_file.write("MitosisSteppable.step\tMCS\tCGut\tQGut\tCArt\tCLiver\tQLiver\tVLiver\n")
        self.output_file.write("TissueLevelsFromSBML\tMCS\tcellID\thep_GSH\thep_APAP\thep_NAPQI\thep_NAPQIGSH\thep_APAP_Glucuronide\thep_APAP_Sulfate\n")
        
        #''# targetSurface and lambdaSurface were NOT used / Volume given is two dimensional, there is a hidden thickness of 4um
        for cell in self.cellList:
            dictionary=CompuCell.getPyAttrib(cell)
            dictionary["startMCS"]=0
            dictionary["exitMCS"]=0
            dictionary["sourceCellID"]=-1  # track which BloodPortion_source created this BloodPortion or RBC
            dictionary["deleting"]=0
            dictionary["Load"]=0
            dictionary["InitialLoad"]=0
            dictionary["ExitLoad"]=0
            dictionary["Load_Glu"]=0
            dictionary["Load_Sul"]=0
            
            dictionary["copies"] = 1
            if cell.type==self.HEPATOCYTE:  ## Hepatocyte at 20x20
                cell.targetVolume=400
                dictionary["ultimateVolume"]=400
                cell.lambdaVolume=50
#                cell.targetSurface=80
#                cell.lambdaSurface=20  # !! also change in UpdateAtributes in the mitosis steppable!
            elif cell.type==self.BLOODPORTION:  ## BloodPortion at 5x5 
                cell.targetVolume=25
                dictionary["ultimateVolume"]=25
                cell.lambdaVolume=10
#                cell.targetSurface=20
#                cell.lambdaSurface=10 # !! also change in UpdateAtributes in the mitosis steppable!
            elif cell.type==self.BLOODPORTION_SOURCE:  ## BloodPortion_source at 5x10 (previous to 8/21/12 these were 5x5)
                cell.targetVolume=50   # 50
                dictionary["ultimateVolume"]=50
                cell.lambdaVolume=40
#                 # change to 2*20      cell.lambdaVolume=20   # 30, 100
#                 cell.targetSurface=30  # 30
#                 cell.lambdaSurface=20 # 100 # !! also change in UpdateAtributes in the mitosis steppable!
            elif cell.type==self.REDBLOODCELL:  ## RedBloodCells at 10x10 are larger than BloodPortions
                cell.targetVolume=100
                dictionary["ultimateVolume"]=100
                cell.lambdaVolume=10
#                cell.targetSurface=40
#                cell.lambdaSurface=10 # !! also change in UpdateAtributes in the mitosis steppable!
                            

    def step(self,mcs):        
        global SumLoadExit, SumVolumeExit, LoadInTransit, TotalCellsCreated, TotalCellsDeleted, SinusoidVolume, line2Print
        global APAPconjGluExit, APAPconjSulExit
        global freqAll

        ## check and log the Y-location of the source cells
        ## doesn't look like you can individually assign lambdaVecX (Y, Z) if the main python sets them by type
        ## have to do it manually including in mitosis?
                    
        ## Grow any small cells
        if mcs % 10 == 0:
            cellCount = 0
            for cell in self.cellList:
                dict=CompuCell.getPyAttrib(cell)
                if dict["deleting"] != 1:
                    cellCount +=1
                if   cell.type == 2 and cell.targetVolume < dict["ultimateVolume"] and dict["deleting"] != 1:     # BloodPortion
                    cell.targetVolume = min(25,cell.targetVolume*1.2)  # takes ~4 cycles
                    print "cell.type,cell.targetSurface,cell.targetVolume)",cell.type,cell.targetSurface,cell.targetVolume
                    cell.targetSurface = 4.*sqrt(cell.targetVolume)
                elif cell.type == 3 and cell.targetVolume < dict["ultimateVolume"]  and dict["deleting"] != 1:   # BloodPortion_source
                    cell.targetVolume = min(50,cell.targetVolume*1.2)  # takes ~4 cycles
                    cell.targetSurface = 4.*sqrt(cell.targetVolume)
                elif cell.type == 4 and cell.targetVolume < dict["ultimateVolume"] and dict["deleting"] != 1:  # RedBloodCell
                    cell.targetVolume = min(100,cell.targetVolume*1.2)  # takes ~4 cycles
                    cell.targetSurface = 4.*sqrt(cell.targetVolume)
            if (TotalCellsCreated-TotalCellsDeleted-cellCount+181) != 0 and not mcs%freqAll:
                self.output_file.write("VolumeParamSteppable:cellCounts\t"+str(mcs)+"\t"+str(TotalCellsCreated)+"\t"+str(TotalCellsDeleted))
                self.output_file.write("\t"+str(cellCount)+"\t"+str(TotalCellsCreated-TotalCellsDeleted-cellCount+181)+"\tERROR!\n")
        
        ## Delete BloodPortion and RedBloodCell that hits the right end of model
        ## Since the RedBlodCells are much bigger than the BloodPortions a single "death radius" 
        ## doesn't work well instead, we use a radius dependent on the cell type.
        ## (Could use say the sqrt(area)/2 but that's a lot of sqrt calcs for something so simple.)
        global freqAll
        if mcs % 5 == 0:       # 20 4
            for cell in self.cellListByType(2,4):
                x=round(cell.xCOM)
                y=round(cell.yCOM)
                ## 2=BloodPortion, 4=RedBloodCell
                if (cell.type == 2 and x >= (self.dim.x-4)) \
                or (cell.type == 4 and x >= (self.dim.x-10)):
                    dict1=CompuCell.getPyAttrib(cell)
                    if dict1["deleting"] != 1:  # only log when the cell starts to be deleted
                        dict1["deleting"] = 1
                        dict1["exitMCS"] = mcs
                        dict1["ExitLoad"] = dict1["Load"]
                        TotalCellsDeleted += 1
                        SumLoadExit   += dict1["Load"]
                        APAPconjGluExit += dict1["Load_Glu"]            ## forget to multiply by number of sinusoids???
                        APAPconjSulExit += dict1["Load_Sul"]
                        SumVolumeExit += cell.targetVolume
                        LoadInTransit -= dict1["Load"]
                        if not mcs%freqAll:
                            self.output_file.write("VolumeParamSteppable.step\t"+str(mcs)+"\t"+str(cell.type)+"\t"+str(mcs-dict1["startMCS"])+"\t")
                            self.output_file.write(str(dict1["sourceCellID"])+"\t"+str(y)+"\t"+str(dict1["Load"])+"\t")
                            self.output_file.write(str(dict1["InitialLoad"])+"\t"+str(dict1["InitialLoad"]-dict1["Load"])+"\n")
                        #print "                 %%%%% DELETING cell.id,cell.type,dictionary: ",cell.id,cell.type,dict1
                    # don't go to zero too fast
                    cell.targetVolume = cell.targetVolume - 12  # let it go negative
                    if (cell.type==self.REDBLOODCELL):
                        cell.targetVolume = cell.targetVolume - 12                    
                    #cell.targetSurface= max(0,cell.targetSurface - 5)  # cell.targetSurface= cell.surface - 5                
#                    cell.targetSurface= 4.*sqrt(max(0,cell.targetVolume))

            if line2Print and not mcs%freqAll:
                self.output_file.write(line2Print)
                line2Print = ""
        
    def stop(self):
        self.output_file.close()


from random import random,gauss,choice
#############################################################################################
class MitosisSteppable(MitosisSteppableBase):
    def __init__(self,_simulator,_frequency=1):
        MitosisSteppableBase.__init__(self,_simulator,_frequency)
        
        # 0 - parent child position will be randomized between mitosis event (new in CC3D version 3.6.2)
        # negative integer - parent appears on the 'left' of the child
        # positive integer - parent appears on the 'right' of the child
        self.setParentChildPositionFlag(-1)    
        
        self.sources=[0,0,0,0]
        self.creatingRBC = 0
        self.sourceOffset= 0
        self.doingRBCfromCellId = 0
    
    def start(self):
        # array to hold the cell.id of the source cells. This is a kluge fix for the new cell cleavage algorithm
        # in CC3D that doesn't always give the same parent / daughter configuration
        # here we init to the starting cell ids. Later we will have to update the cell.ids as new cells are created and
        # the parent cell ID changes
#         self.sources = [0 for x in range(4)]        
        self.sources = []
        for cell in self.cellListByType(self.BLOODPORTION_SOURCE):
            self.sources.append(cell.id) 
#         self.sources[0]=157  # Gut flow; zero referenced, these are magic numbers!
#         self.sources[1]=158  # Gut flow
#         self.sources[2]=159  # Gut flow
#         self.sources[3]=160  # Arterial flow (usually)
        self.carryOverGut = 0.0  # carry over from one cycle to the next when creating RBC (for the other flow)
        self.carryOverArt = 0.0  # carry over from one cycle to the next when creating RBC (for the other flow)
        self.carryOverGut_Glu = 0.0  # carry over from one cycle to the next when creating RBC (for the other flow)
        self.carryOverArt_Glu = 0.0
        self.carryOverGut_Sul = 0.0  # carry over from one cycle to the next when creating RBC (for the other flow)
        self.carryOverArt_Sul = 0.0
        

    #''# First, decide which of the four source cells produce RBC
    def step(self,mcs):
        # print "INSIDE MITOSIS STEPPABLE"
        global SumLoadExit, SumVolumeExit, LoadInTransit, TotalCellsCreated, TotalCellsDeleted, SinusoidVolume, line2Print  
        global APAPconjGluExit, APAPconjSulExit

        # The number below basically controls how fast the blood moves through the pipe.
        # Creating a 5x5 BloodPortion evey 40 (was 100) MCS means the cells move 5/40=0.125 pixel/MCS
        if mcs >= 20 and mcs % 20 == 0:  # only create new cells every XXX steps
            ### First decide if we will create 4 serum portions (one for each BloodPortion_source) 
            ###    OR create a single RBC (one RBC has the same volume as four BloodPortion)
            if random() > (1-ParaDict['pbpk_hemat']):  # 0.88 # Hematocrit value goes here, need to take into account the different "cell" sizes             ###FIX_HERE###  Load Hematocrit from PBPK file
                self.creatingRBC = 1
                # decide which of the four BloodPortion_source will be creating the RBC
                self.sourceOffset = choice(range(0,4,1))  # returns one from the list of 0-3
                self.doingRBCfromCellId = self.sources[self.sourceOffset]  # returns one of the cell source ids
                #print "888888888888888888888888888888888888 Creating RBC, sourceOffset:",self.sourceOffset,"  ",self.sources
            else:
                self.creatingRBC = 0
                self.sourceOffset = -1
                #print "777777777777777777777777777777777777 Creating BloodPortions, sourceOffset:",self.sourceOffset,"  ",self.sources
                self.doingRBCfromCellId = -1
            if mcs==1000:
                print "\n\n",random(),"\n\n"
                
            #-----------------------------------------------------
            # get the current values for the flow from the gut and artery into the liver from the PBPK model
            # inputs to the liver:
            # CGut   -> CLiver    QGut*CGut/VGut;
            
            state=self.getSBMLState(_modelName='PBPKWambaugh') 
            state1=self.getSBMLState(_modelName='PBPKWambaugh_cG') 
            state2=self.getSBMLState(_modelName='PBPKWambaugh_cS') 
            CGut   = state['CGut']
            CGut_Glu   = state1['CGut']
            CGut_Sul   = state2['CGut']
            CArt   = state['CArt']
            CArt_Glu   = state1['CArt']
            CArt_Sul   = state2['CArt']
            CLiver = state['CLiver'] 
            CLiver_Glu = state1['CLiver'] 
            CLiver_Sul = state2['CLiver'] 
            AGutlumen = state['AGutlumen'] 
            AGutlumen_Glu = state1['AGutlumen'] 
            AGutlumen_Sul = state2['AGutlumen'] 

           
            QGut   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='QGut')
            VGut   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VGut')
            VArt   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VArt')
            QLiver = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='QLiver')
            VLiver = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VLiver') 
           
#             print "from PBPK in mitosis        ))))))))))))))))))))))) CGut,QGut,CArt,CLiver,QLiver,VLiver",CGut,QGut,CArt,CLiver,QLiver,VLiver
            line2Print += "MitosisSteppable.step\t"+str(mcs)+"\t"+str(CGut)+"\t"+str(QGut)+"\t"+str(CArt)+"\t"+str(CLiver)+"\t"+str(QLiver)+"\t"+str(VLiver)+"\n"
            #-----------------------------------------------------

            # to avoid corrupting the cell list with the divisions first collect the set of cells
            # to be divided
            cell_to_divide=[]  # list 
            for cell in self.cellList:
                # Periodically split the type 3 (BloodPortion_source) cells into type 2 (BloodPortion) or a single RBC cells
                if cell.type==3 :  # BloodPortion_source is what divided
                    # Currently the venous (Gut) flow is 3 of 4 of the source cells, the arterial flow is one cell
                    # so the ratio is 3:1. It should be closer to 4:1.
                    if self.creatingRBC:  # create a single RBC
                        if cell.id == self.doingRBCfromCellId:
                            cell_to_divide.append(cell)
                    else:   # create 4 regular BloodPortions
                        cell_to_divide.append(cell)
                # mitosis for other cells types (not BloodPortion_source)
                else:
                    pass
                          
            # ==========================================================================            
            # actually divide the cells on the list  
            DidMitosis = 0
            fractionGut = (CGut*QGut/VGut)/(CGut*QGut/VGut + CArt*QLiver/VArt) # fraction of the Liver(g) from Gut flow
            fractionArt = 1.0 - fractionGut                                    # fraction of the Liver(g) from Art flow
            
            fractionGut_Glu = (CGut_Glu*QGut/VGut)/(CGut_Glu*QGut/VGut + CArt_Glu*QLiver/VArt) # fraction of the Liver(g) from Gut flow     FOR GLUCURONIDE
            fractionArt_Glu = 1.0 - fractionGut_Glu                                    # fraction of the Liver(g) from Art flow           
            
            fractionGut_Sul = (CGut_Sul*QGut/VGut)/(CGut_Sul*QGut/VGut + CArt_Sul*QLiver/VArt) # fraction of the Liver(g) from Gut flow     FOR SULFATE
            fractionArt_Sul = 1.0 - fractionGut_Sul                                    # fraction of the Liver(g) from Art flow
            
            for cell in cell_to_divide:  
                self.divideCellOrientationVectorBased(cell,1,0,0) # Cleave along YZ plane
                 
                # need to find the offset in sources[] for this cell.id
                theOffset = self.sources.index(cell.id)
                TotalCellsCreated += 1
                DidMitosis = 1
                childCell =self.mitosisSteppable.childCell
                parentCell=self.mitosisSteppable.parentCell
                parentCell.targetVolume = 50  
                parentCell.lambdaVolume = 40
#                parentCell.targetSurface= 20
#                parentCell.lambdaSurface= 20  # 
                parentCell.lambdaVecX=5  # force to the left
                self.copySBMLs(_fromCell=parentCell,_toCell=childCell)
                
                #''# create cells and input load
                
                if cell.id == self.doingRBCfromCellId:  # creating a single RBC
                    # 9/5/2012 added carry over so that mass isn't lost when creating an RBC (the mass in the other flow)
                    childCell.type = 4  ###  this is a RedBloodCell 
                    childCell.targetVolume = 25  
                    childCell.lambdaVolume = 10
#                    childCell.targetSurface= 20
#                    childCell.lambdaSurface= 10
                    childCell.lambdaVecX=-150  # force to the right
                    dictionary=CompuCell.getPyAttrib(childCell)
                    dictionary["startMCS"] = mcs
                    dictionary["deleting"] = 0
                    dictionary["sourceCellID"] = theOffset
                    dictionary["ultimateVolume"] = 100
                    
                    # RedBloodCells (RBC) are also carrying the chemical load (for APAP model)
                    if theOffset <= 2:  # Venous (Gut) RBC flow (the source offset is 0->3)
                        # the first term below attempts to back-calculate the proportion of CLiver that came from Gut flow
                        #dictionary["Load"] = (fractionGut*CLiver+self.carryOverGut)/(VLiver/SinusoidVolume)
                        dictionary["Load"] = (fractionGut*CLiver+self.carryOverGut)/(VLiver*0.074/SinusoidVolume) # 0.074 fraction of VLiver that is actually sinusoid (Drasdo)
                        dictionary["Load_Glu"] = (fractionGut_Glu*CLiver_Glu+self.carryOverGut_Glu)/(VLiver*0.074/SinusoidVolume)
                        dictionary["Load_Sul"] = (fractionGut_Sul*CLiver_Sul+self.carryOverGut_Sul)/(VLiver*0.074/SinusoidVolume)               ##
                        self.carryOverGut = 0.0
                        self.carryOverGut_Glu = 0.0
                        self.carryOverGut_Sul = 0.0
                        self.carryOverArt += fractionArt*CLiver
                        self.carryOverArt_Glu += fractionArt_Glu*CLiver_Glu
                        self.carryOverArt_Sul += fractionArt_Sul*CLiver_Sul
                        dictionary["InitialLoad"] = dictionary["Load"]
                        LoadInTransit += dictionary["Load"]
                        #print "In updateAtributes: new GUT flow RBC, load=", dictionary["Load"],"    carryOverArt=",self.carryOverArt 
                        line2Print += "MitosisSteppable.new flow portion\t"+str(mcs)+"\tGut\tRBC\t"+str(dictionary["Load"])+"\n"           
                    else:  # theOffset > 2: Arterial RBC flow (the source offset is 0->3)
                        # HERE IS WHERE TO FIX THE DIFF BETWEEN QGut vs. QLiver AND THE PROPORTION OF Ven vs. Art BLOODPORTION SOURCES
                        # the first term below attempts to back-calculate the proportion of CLiver that came from Art flow
                        dictionary["Load"] = (fractionArt*CLiver+self.carryOverArt)/(VLiver*0.074/SinusoidVolume) # 0.074 fraction of VLiver that is actually sinusoid (Drasdo)
                        dictionary["Load_Glu"] = (fractionArt_Glu*CLiver_Glu+self.carryOverArt_Glu)/(VLiver*0.074/SinusoidVolume)
                        dictionary["Load_Sul"] = (fractionArt_Sul*CLiver_Sul+self.carryOverArt_Sul)/(VLiver*0.074/SinusoidVolume)
                        self.carryOverArt = 0.0
                        self.carryOverArt_Glu = 0.0
                        self.carryOverArt_Sul = 0.0
                        self.carryOverGut += fractionGut*CLiver
                        self.carryOverGut_Glu += fractionGut_Glu*CLiver_Glu
                        self.carryOverGut_Sul += fractionGut_Sul*CLiver_Sul
                        dictionary["InitialLoad"] = dictionary["Load"]
                        LoadInTransit += dictionary["Load"]
                        #print "In updateAtributes: new ARTERIAL flow RBC, load=", dictionary["Load"],"    carryOverGut=",self.carryOverGut 
                        line2Print += "MitosisSteppable.new flow portion\t"+str(mcs)+"\tArt\tRBC\t"+str(dictionary["Load"])+"\n"      
                
                else:   # create 4 regular BloodPortions  (this is called four seperate times!)      
                    #print "@@  @@ theOffset,val:",theOffset,self.sources[theOffset], self.sources
                    childCell.type = 2  ###  this is a regular BloodPortion
                    childCell.targetVolume = 25  
                    childCell.lambdaVolume = 10
#                    childCell.targetSurface= 20
#                    childCell.lambdaSurface= 10
                    childCell.lambdaVecX=-30  # force to the right
                    # blood portions are carrying the chemical load
                    dictionary=CompuCell.getPyAttrib(childCell)
                    dictionary["startMCS"] = mcs
                    dictionary["deleting"] = 0
                    dictionary["sourceCellID"] = theOffset
                    dictionary["ultimateVolume"] = 25
                    if theOffset <= 2:  # Venous (Gut) flow (the source offset is 0->3)
                        # the first term below attempts to back-calculate the proportion of CLiver that came from Gut flow
                        # note the divisor of 3!
                        dictionary["Load"] = (fractionGut*CLiver+self.carryOverGut)/(VLiver*0.074/SinusoidVolume)/3 #*0.074 Drasdo
                        dictionary["Load_Glu"] = (fractionGut_Glu*CLiver_Glu+self.carryOverGut_Glu)/(VLiver*0.074/SinusoidVolume)/3
                        dictionary["Load_Sul"] = (fractionGut_Sul*CLiver_Sul+self.carryOverGut_Sul)/(VLiver*0.074/SinusoidVolume)/3
                        #self.carryOverGut = 0.0  # can't zero this until all three protions are created!
                        dictionary["InitialLoad"] = dictionary["Load"]
                        LoadInTransit += dictionary["Load"]
                        #print "In updateAtributes: new GUT flow bloodportion, load=", dictionary["Load"],"    carryOverGut=",self.carryOverGut   
                        line2Print += "MitosisSteppable.new flow portion\t"+str(mcs)+"\tGut\tPortion\t"+str(dictionary["Load"])+"\n"      
                    else:  # theOffset > 2: Arterial flow (the source offset is 0->3)
                        # HERE IS WHERE TO FIX THE DIFF BETWEEN QGut vs. QLiver AND THE PROPORTION OF Ven vs. Art BLOODPORTION SOURCES
                        # the first term below attempts to back-calculate the proportion of CLiver that came from Art flow
                        dictionary["Load"] = (fractionArt*CLiver+self.carryOverArt)/(VLiver*0.074/SinusoidVolume) #*0.074 Drasdo
                        dictionary["Load_Glu"] = (fractionArt_Glu*CLiver_Glu+self.carryOverArt_Glu)/(VLiver*0.074/SinusoidVolume)
                        dictionary["Load_Sul"] = (fractionArt_Sul*CLiver_Sul+self.carryOverArt_Sul)/(VLiver*0.074/SinusoidVolume)
                        #self.carryOverArt = 0.0 # can't zero this until all three protions are created! (just being consitent with how the Gut flow is done)
                        dictionary["InitialLoad"] = dictionary["Load"]
                        LoadInTransit += dictionary["Load"]
                        #print "In updateAtributes: new ARTERIAL flow bloodportion, load=", dictionary["Load"],"    carryOverArt=",self.carryOverArt  
                        line2Print += "MitosisSteppable.new flow portion\t"+str(mcs)+"\tArt\tPortion\t"+str(dictionary["Load"])+"\n"      
                          
                if DidMitosis:
                    #print "    Updated sources list? parentCell:xCOM, childCell:xCOM ",parentCell.id,parentCell.xCOM,"    ",childCell.id,childCell.xCOM, self.sources
                    if parentCell.xCOM > childCell.xCOM:   # need to swap the parent and child cells?
                        # need to find the offset in sources[] for this cell.id
                        theOffset = self.sources.index(parentCell.id)
                        #print "    pppppppppppppppppppppppppppppppppp 1 SWAPPING, parentCell.id,childCell.id,theOffset,sources[]",parentCell.id,childCell.id,theOffset,self.sources
                        self.sources[theOffset] = childCell.id
                        #print "    pppppppppppppppppppppppppppppppppp 2 SWAPPING, parentCell.id,childCell.id,theOffset,sources[]",parentCell.id,childCell.id,theOffset,self.sources
                        #self.sources[self.sourceOffset] = childCell.id
                        
                        parentCell.type=childCell.type
                        childCell.type=3
                        
                        t=childCell.targetVolume
                        childCell.targetVolume=parentCell.targetVolume
                        parentCell.targetVolume=t
                        t=childCell.lambdaVolume
                        childCell.lambdaVolume=parentCell.lambdaVolume
                        parentCell.lambdaVolume=t
                        
#                         t=childCell.targetSurface
#                         childCell.targetSurface=parentCell.targetSurface
#                         parentCell.targetSurface=t
#                         t=childCell.lambdaSurface
#                         childCell.lambdaSurface=parentCell.lambdaSurface
#                         parentCell.lambdaSurface=t
                       
                        childDict=CompuCell.getPyAttrib(childCell)
                        tempDict=childDict.copy()
                        parentDict=CompuCell.getPyAttrib(parentCell)                            
                        for k, v in tempDict.iteritems():
                            tv=v
                            childDict[k]=parentDict[k]
                            parentDict[k]=tv                            
                        print "parent,child dict:\n",parentDict,"\n",childDict

                        print "                      Updated sources list, sourceOffset, cellid: ",  self.sourceOffset, self.sources[self.sourceOffset], self.sources
                        line2Print += "MitosisSteppable.DidMitosis.Swaped.sourceList\t"+str(mcs)+"\t"+str(self.sources[0])+"\t"+str(self.sources[1])+"\t"+str(self.sources[2])+"\t"+str(self.sources[3])+"\n" 
    
                    #print "   in mitosis summary: cellID, type:",childCell.id,childCell.type
                    #print "Targets: ",parentCell.targetVolume,parentCell.targetSurface,childCell.targetVolume,childCell.targetSurface
                    #print "Lambdas: ",parentCell.lambdaVolume,parentCell.lambdaSurface,childCell.lambdaVolume,childCell.lambdaSurface
                    #print "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"

            if not self.creatingRBC:   # created serum portions so the serum portion carry overs can be cleared
                self.carryOverGut = 0.0
                self.carryOverArt = 0.0
                self.carryOverArt_Glu = 0.0
                self.carryOverArt_Sul = 0.0
                self.carryOverGut_Glu = 0.0
                self.carryOverGut_Sul = 0.0
                        
            # zero CLiver in the PBPK model since we have transfered the CLiver conc to new BloodPortions and/or RBCs
            # this is done after all of the mitosis are done and updateAttributes for each new cell has finished                                   
           
            self.setSBMLValue(_modelName='PBPKWambaugh',_valueName='CLiver',_value=0.0) # value name can be e.g. species name 
            self.setSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='CLiver',_value=0.0) # value name can be e.g. species name 
            self.setSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='CLiver',_value=0.0) # value name can be e.g. species name 
            
                    
    def updateAttributes(self):
        pass  # it is all done above
        
    def stop(self): pass
#         self.output_file200.close()
#####################################################################
########### 
########### Python dictionary to hold the chemical load of each cell
########### and to do the rough PDE (actually ODE) diffusion calc
########### also does the communication with the subcellular SBML model via Bionet
###########
class LoadAttribute(SteppableBasePy):
    def __init__(self,_simulator,_frequency=10):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        self.simulator=_simulator
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.nTrackerPlugin=CompuCell.getNeighborTrackerPlugin()
    
    def BW2QV(self,bw,QV_bw):
	VTotal = 1.7355*bw**0.75
	VArt = VTotal*0.0357
        print 'VArt (Old, New)', QV_bw['VArt'], VArt
        QV_bw['VArt'] = VArt
        
	VVen = VTotal*0.0812
        print 'VVen (Old, New)', QV_bw['VVen'], VVen
        QV_bw['VVen'] = VVen
        
	QCardiac = 15*bw**0.75
        print 'QCardiac (Old, New)', QV_bw['QCardiac'], QCardiac
        QV_bw['QCardiac'] = QCardiac
        
	#Qgfr = 0.31*bw**0.75
	QGut = QCardiac*0.205; VGut = VTotal*0.0263
        print 'QGut (Old, New)', QV_bw['QGut'], QGut
        QV_bw['QGut'] = QGut
        print 'VGut (Old, New)', QV_bw['VGut'], VGut
        QV_bw['VGut'] = VGut
                
	QLiver = QCardiac*0.0535; VLiver = VTotal*0.0408
        print 'QLiver (Old, New)', QV_bw['QLiver'], QLiver
        QV_bw['QLiver'] = QLiver
        print 'VLiver (Old, New)', QV_bw['VLiver'], VLiver
        QV_bw['VLiver'] = VLiver
        
	QKidney = QCardiac*0.2214; VKidney = VTotal*0.007
        print 'QKidney (Old, New)', QV_bw['QKidney'], QKidney
        QV_bw['QKidney'] = QKidney
        print 'VKidney (Old, New)', QV_bw['VKidney'], VKidney
        QV_bw['VKidney'] = VKidney
        
	VLung = 0.0121*VTotal
        print 'VLung (Old, New)', QV_bw['VLung'], VLung
        QV_bw['VLung'] = VLung
        
	QRest = QCardiac-QGut-QLiver-QKidney; VRest = VTotal-VLung-VArt-VVen-VGut-VLiver-VKidney
        print 'QRest (Old, New)', QV_bw['QRest'], QRest
        QV_bw['QRest'] = QRest
        print 'VRest (Old, New)', QV_bw['VRest'], VRest
        QV_bw['VRest'] = VRest
        
# 	print 'Body_Weight\tVTotal\tVArt\tVVen\tVLung\tQCardiac\tQGut\tVGut\tQLiver\tVLiver\tQKidney\tVKidney\tQRest\tVRest\n'
# 	print bw,VTotal,VArt,VVen,VLung,QCardiac,QGut,VGut,QLiver,VLiver,QKidney,VKidney,QRest,VRest
	

    def start(self):
        global ParaName, ParaIniVal, ParaCurVal, ParaDict, Dose
        global line2Print,hepatocyteList,hepatocyteListZoneIII, hr, sec
        import os
        
        QV_bw = {'VArt':1.49996,'VVen':3.409,'VLung':0.5061,'QGut':69.0144,'VGut':1.106,'QLiver':17.976,'VLiver':1.7136,\
                 'QKidney':74.3904,'VKidney':0.2933,'QRest':174.6192,'VRest':33.47204,'QCardiac':336}
        self.BW2QV(ParaDict['pbpk_bw'],QV_bw)
        
        Dose = 1.4
        
        #''# initialize the SUBCELL and PBPK models
        
        # how often to do the diffusion in CC3D (originally was every 5 MCS)
        self.doDiffuseEvery=10  # in MCS  (initial 10)
        # the time step is based on 800 MCS = 1 second (1 second for blood to move the length of the sinusoid)
        self.MCS2Time=1./600.  # 800MCS = 1 second simulated time
        self.deltaTime=self.doDiffuseEvery*self.MCS2Time    # self.doDiffuseEvery/5  old dT=10, new dT=0.0125 simulated second
 
        hr = self.MCS2Time/3600
        sec = self.MCS2Time
        line2Print += "'=====x\tdoDiffuseEvery (MCS)=\t"+str(self.doDiffuseEvery)+"\tdeltaTime (seconds)=\t"+str(self.deltaTime)+"\n"

        # vvvvvvvvvvvvvvvvvvvv Create subcellular SBML models via SBML Solver vvvvvvvvvvvvvvvvvvvv
        sbmlModelName = "ApapGshModel"
#         self.timeStepOfIntegration = 0.0125  # 0.0625 #0.01 0.01 0.1 # initial 0.0125
        self.timeStepOfIntegration = self.deltaTime#0.016667  # 0.0625 #0.01 0.01 0.1 # initial 0.0125
        modelFile = 'Simulation/APAP_GSH_Liver_Metab_Sul_Glu.xml'
        initialConditions={}
        initialConditions['GSH']=9.9999
        initialConditions['APAP']=0.0
        initialConditions['NAPQI']=0.0
#         initialConditions['kApapNapqi']=1.0
        initialConditions['APAPconj_Glu']=0.0
        initialConditions['APAPconj_Sul']=0.0
        initialConditions['NAPQIGSH']=0.0
        initialConditions['Vmax_PhaseIIEnzGlu_APAP']= ParaDict['sc_Vmax_GLUC'] ##4.74e-4#                          2.7e-4        
        initialConditions['Km_PhaseIIEnzGlu_APAP']=ParaDict['sc_Km_GLUC'] ##6     #                               6.89         
        initialConditions['Vmax_PhaseIIEnzSul_APAP']=ParaDict['sc_Vmax_SULF'] ##3.82e-5#Ochoa          Reith 3.1e-6
        initialConditions['Km_PhaseIIEnzSul_APAP']=ParaDict['sc_Km_SULF'] ##0.3#                         0.097        
        initialConditions['Vmax_2E1_APAP']= ParaDict['sc_Vmax_2E1_APAP']#                    0.121
        initialConditions['Km_2E1_APAP']=ParaDict['sc_Km_2E1_APAP']
        initialConditions['kNapqiGsh']=ParaDict['sc_kNapqiGsh']
        initialConditions['kGsh']=ParaDict['sc_kGsh']
        self.addSBMLToCellTypes(_modelFile=modelFile,_modelName='ApapGshModel',_types=[self.HEPATOCYTE],_stepSize=self.timeStepOfIntegration,_initialConditions=initialConditions) 

        # vvvvvvvvvvvvvvvvvvvv Create whole body PBPK model for APAP via FreeFloatingSBML vvvvvvvvvvvvvvvvvvvv
        sbmlModelName2 = "PBPKWambaugh"
        self.timeStepOfIntegration2 = self.deltaTime/3600#4.63E-6  #0.0001042  # for the ~12 hr CPU runs=0.001, for testing=0.01, for very fast=0.1
        modelFile='Simulation/Wambaugh_vLiver_PBPK_based_v4.xml' # this can be e.g. partial path 'Simulation/osci.sbml'         
        initialConditions={}
        initialConditions['CLmetabolism']=0.0
        initialConditions['Kliver2plasma']=1e+300              
        initialConditions['Ratioblood2plasma']=ParaDict['pbpk_Rb2p']
        initialConditions['Fraction_unbound_plasma']=ParaDict['pbpk_Fup'] ##1
        initialConditions['Kkidney2plasma']=ParaDict['pbpk_Kk2p'] ## 1
        initialConditions['KRest2plasma']=ParaDict['pbpk_Kr2p'] ## 1
        initialConditions['Qgfr'] = ParaDict['pbpk_Qgfr']
        initialConditions['AGutlumen']=ParaDict['pbpk_dose']
        initialConditions['kGutabs']=ParaDict['pbpk_kGutabs']
        
        for keys in QV_bw:
            initialConditions[keys]=QV_bw[keys]
        
        self.addFreeFloatingSBML(_modelFile=modelFile,_modelName='PBPKWambaugh',_stepSize=self.timeStepOfIntegration2,_initialConditions=initialConditions)        

        # vvvvvvvvvvvvvvvvvvvv Create whole body PBPK model for APAPconj_Glu via FreeFloatingSBML vvvvvvvvvvvvvvvvvvvv
        sbmlModelName3 = "PBPKWambaugh_cG"
        self.timeStepOfIntegration3 = self.deltaTime/3600  #0.0001042  # for the ~12 hr CPU runs=0.001, for testing=0.01, for very fast=0.1
        modelFile='Simulation/Wambaugh_vLiver_PBPK_based_v4_APAPconj_Glu.xml' # this can be e.g. partial path 'Simulation/osci.sbml'         
        initialConditions={}
        initialConditions['CLiver']=0.0
        initialConditions['CLmetabolism']=0.0
        initialConditions['Kliver2plasma']=1e+300
        initialConditions['Ratioblood2plasma']=ParaDict['pbpk_Rb2pG']
        initialConditions['Fraction_unbound_plasma']=ParaDict['pbpk_FupG'] ##1
        initialConditions['Kkidney2plasma']=ParaDict['pbpk_Kk2pG'] ##1
        initialConditions['KRest2plasma']=ParaDict['pbpk_Kr2pG'] ##1
        initialConditions['CGut']=1e-30
        initialConditions['Qgfr'] = ParaDict['pbpk_QgfrG']
        
        for keys in QV_bw:
            initialConditions[keys]=QV_bw[keys]
        
        self.addFreeFloatingSBML(_modelFile=modelFile,_modelName='PBPKWambaugh_cG',_stepSize=self.timeStepOfIntegration3,_initialConditions=initialConditions)  

        # vvvvvvvvvvvvvvvvvvvv Create whole body PBPK model for APAPconj_Sul via FreeFloatingSBML vvvvvvvvvvvvvvvvvvvv
        sbmlModelName4 = "PBPKWambaugh_cS"
        self.timeStepOfIntegration4 = self.deltaTime/3600
        modelFile='Simulation/Wambaugh_vLiver_PBPK_based_v4_APAPconj_Sul.xml' # this can be e.g. partial path 'Simulation/osci.sbml'         
        initialConditions={}
        initialConditions['CLiver']=0.0
        initialConditions['CLmetabolism']=0.0
        initialConditions['Kliver2plasma']=1e+300
        initialConditions['Ratioblood2plasma']=ParaDict['pbpk_Rb2pS']
        initialConditions['Fraction_unbound_plasma']=ParaDict['pbpk_FupS'] ##1
        initialConditions['Kkidney2plasma']=ParaDict['pbpk_Kk2pS'] ##1
        initialConditions['KRest2plasma']=ParaDict['pbpk_Kr2pS'] ##1
        initialConditions['CGut']=1e-30
        initialConditions['Qgfr'] = ParaDict['pbpk_QgfrS']
        
        for keys in QV_bw:
            initialConditions[keys]=QV_bw[keys]
        
        self.addFreeFloatingSBML(_modelFile=modelFile,_modelName='PBPKWambaugh_cS',_stepSize=self.timeStepOfIntegration4,_initialConditions=initialConditions)  

        ###### initialize the dictionaries ####################################################################
        for cell in self.cellList:
            dictionary=CompuCell.getPyAttrib(cell)
            dictionary["Load"]=0
            dictionary["InitialLoad"]=0
            dictionary["APAPconc"] =0   #mMolar
            dictionary["Load_Glu"]=0
            dictionary["Load_Sul"]=0
            dictionary["NAPQIconc"]=0
            if cell.type == 1:   # hepatocytes
                state=self.getSBMLState(_modelName='ApapGshModel',_cell=cell) # returns dictionary of values
                dictionary["GSHconc"]=state['GSH']  # GSH is 3-10mMolar
                #print "       >>>>>>>>>>>>>>>>>>>>>>>>>>>>> getBionetworkState [GSH]: ",cell.id,cell.type,dictionary["GSHconc"]   
            else:
                dictionary["GSHconc"]=0
                #print "       >>>>>>>>>>>>>>>>>>>>>>>>>>>>> getBionetworkState: not a hepatocyte",cell.id,cell.type  

        ###### initialize ZONATION by zeroing the APAP->NAPQI rate constant in the early Hep's #####################
        for cell in self.cellListByType(self.HEPATOCYTE):
            hepatocyteList.append(cell)
        import operator
        hepatocyteList.sort(key=operator.attrgetter('xCOM','id')) # sorts hepatocyte cells first by xCOM then by id
        for cell in hepatocyteList:
            print 'cell.id=',cell.id
        #last 6 hepatocytes belong to zone III
        hepatocyteListZoneIII=hepatocyteList[-6:]
#        for cell in hepatocyteListZoneIII:
#           print 'Zone III cell.id=',cell.id,' type=',cell.type

        
        ## P450 2E1 for HEPs ##
        ## "copies" for each hep ##
        for cell in self.cellList:
            if cell.type == 1:
                cellDict=self.getDictionaryAttribute(cell)
                
                if cell.id<=170: # 161 -170
                    state={}
                    x=pow(3,cell.id-166)
                    state['Vmax_2E1_APAP']=0.8*ParaDict['sc_Vmax_2E1_APAP']+0.2*ParaDict['sc_Vmax_2E1_APAP']*x/(1+x)                    ###0.121###
#                     bionetAPI.setBionetworkState(cell.id,'ApapGshModel',state)
                    self.setSBMLState(_modelName='ApapGshModel',_cell=cell,_state=state)
                    print cell.id,state['Vmax_2E1_APAP'],"\n"
 
                else:   # 171 - 180
                    state={}
                    x=pow(3,cell.id-176)
                    state['Vmax_2E1_APAP']=0.8*ParaDict['sc_Vmax_2E1_APAP']+0.2*ParaDict['sc_Vmax_2E1_APAP']*x/(1+x)
#                     bionetAPI.setBionetworkState(cell.id,'ApapGshModel',state)
                    self.setSBMLState(_modelName='ApapGshModel',_cell=cell,_state=state)
                    print cell.id,state['Vmax_2E1_APAP'],"\n"

        # square, non-symmetric matrix to store exchange rate constants
        self.k = [[0 for x in range(10)] for y in range(10)]
        #### Rate constants
        ### "Medium",             "TypeId":"0"
        ### "Hepatocyte",         "TypeId":"1"
        ### "BloodPortion",       "TypeId":"2"
        ### "BloodPortion_source","TypeId":"3"
        ### "RedBloodCell",       "TypeId":"4"
        ### For BloodPortions carrying load, RBC have load but it transfers slowly, these were for diffusion calc'd evey 5MCS
        ### For BloodPortions carrying load, RBC have load but it transfers slower, 
        ### rescaled for explicit dt in diffusion calc using units of 1/seconds

    def step(self,mcs):

#         import CompuCellSetup
#         from XMLUtils import ElementCC3D
#         if mcs==500:
#             cc3d=ElementCC3D("CompuCell3D")
#             PlaySet =cc3d.ElementCC3D("Plugin",{"Name":"PlayerSettings"})
#             PlaySet.ElementCC3D("VisualControl", {"ScreenshotFrequency":10, "ScreenUpdateFrequency":10})
                            

        import time
        start_time=time.time()     
        #################################################################################################
        # Simple diffusion solver using the chemical load carried by the cells (stored in a dictionary for each cells)
        # cells in the process of being deleted do not enter into the diffusion calc.
        ###print "\n\n                                        >>>>>>>>>>>>>>>>>>>>>>>>>>>>> LoadAttribute step"
        global SumLoadExit, SumVolumeExit, LoadInTransit, TotalCellsCreated, TotalCellsDeleted, SinusoidVolume, line2Print
        global APAPconjGluExit, APAPconjSulExit

        # returns a randomly shuffled iter for a list (the original list is unchanged)
        import random
        def randomly(seq):
            shuffled = list(seq)
            random.shuffle(shuffled)
            return iter(shuffled)

        #''# passive and active transport rates / Units: Passive -- 1/s , Vmax -- mmol/s , Km -- mmol
        
        ## Do Diffusion ##
        Vmax_import = ParaDict['cc3d_Vmax_AT_APAP'] ##3.1E-3  # mmol/L /s       
        Km_import = ParaDict['cc3d_Km_AT_APAP']   # mmol/L
        k_exAPAPG = ParaDict['cc3d_k_AT_APAPG'] ##0.00045 # 0.028 1/min
        k_exAPAPS = ParaDict['cc3d_k_AT_APAPS'] ##0.0019 # 0.115 1/min
        
        # 1 -> H; 2 -> S; 4 -> R
        self.k[1][1] = ParaDict['cc3d_k_PD_H2H']; self.k[1][2] = ParaDict['cc3d_k_PD_H2S']; self.k[1][4] = ParaDict['cc3d_k_PD_H2R']
        self.k[2][2] = ParaDict['cc3d_k_PD_S2S']; self.k[2][1] = ParaDict['cc3d_k_PD_S2H']; self.k[2][4] = ParaDict['cc3d_k_PD_S2R']
        self.k[4][4] = ParaDict['cc3d_k_PD_R2R']; self.k[4][1] = ParaDict['cc3d_k_PD_R2H']; self.k[4][2] = ParaDict['cc3d_k_PD_R2S']

#         for i in range(10):
#             aline = ""
#             for j in range(10):
#                 if self.k[i][j] <> 0:
#                     aline += "k["+str(i)+"]["+str(j)+"]=\t"+str(self.k[i][j])+"\t"
#             if aline <> "":
#                 line2Print += "'=====y\tCC3D Diffusion Constants\t"+aline+"\n"
                

        if not mcs % self.doDiffuseEvery:   # frequency to do the diffusion calc and update BioNetworks
       
            ##########################################################################################################
            ### (1) Get sub-cell concentration (mM) and convert to quantity (g); (2) diffusion calculation; (3) convert back to concentration and update SBML ###
            
            # get the values back from the SBML model and update CC3D  
#             print "*********** getting values from subcellular SBML to HEP", mcs
            for cell in self.cellListByType(self.HEPATOCYTE):
                ###print "\n\n                                        >>>>>>>>>>>>>>>>>>>>>>>>>>>>> LoadAttribute SBML for cell in self.cellList THIRD\n\n\n"
                state=self.getSBMLState(_modelName='ApapGshModel',_cell=cell) # returns dictionary of values
                
                dict_1=CompuCell.getPyAttrib(cell)
                # Remember that Load isn't a concentration, multiply SBML conc by the Hep's area (volume)                
                dict_1["Load"]     = state['APAP']*20**3/1e15*151/1e3                   #(g) <-> (mM)
                dict_1["Load_Glu"] = state['APAPconj_Glu']*20**3/1e15*322/1e3
                dict_1["Load_Sul"] = state['APAPconj_Sul']*20**3/1e15*231/1e3   
                dict_1["GSHconc"]  = state['GSH']
                dict_1["NAPQIGSH"] = state['NAPQIGSH']
        
            ##### iterate over the cells and do the diffusional transfers
            #self.cellList=CellList(self.inventory)
            #for cell in self.cellList:
            #### new in version 14 Sept. 2012: Iterate over the cell list in random order
            for cell in randomly(self.cellList):   # the randomly function is defined above                
                #print "\n     >>>>>>>>>>>>>>>>>>>>>>>>>>>>> LoadAttribute cell in self.cellList, cellID=:",cell.id,"\n"
                # only allowing transfer from/between cells types 1, 2 & 4 (Hepatocytes, BloodPortions and RedBloodCells)                
                if (cell.type==1 or cell.type==2 or cell.type==4):
                    ###print "\n     >>>>>>>>>>>>>>>>>>>>>>>>>>>>> LoadAttribute cell.type==1 or cell.type==2 or cell.type==4\n\n\n"
                    dict_1=CompuCell.getPyAttrib(cell)
                    
                    
                    ## update 10/03/14: record number of neighbors
                    if "Load" in dict_1:
                        dict_1['nbTotal'] = 0
                        if dict_1["deleting"] != 1:                    
                            cellNeighborList=CellNeighborListAuto(self.nTrackerPlugin,cell)
                            for neighbor , commonSurfaceArea in self.getCellNeighborDataList(cell):                
                                if neighbor and commonSurfaceArea:
                                    dict_1['nbTotal']+=1
#                             print         dict_1['nbTotal']
                            
                     
                    if "Load" in dict_1:
                        if dict_1["deleting"] != 1:
                            # iterate over all neighbors of this cell
                            cellNeighborList=CellNeighborListAuto(self.nTrackerPlugin,cell)

                            #print "***** PDE NEIGHBORS OF CELL WITH ID ",cell.id," load ",dict_1," *****************"
                            for neighborSurfaceData in randomly(cellNeighborList):  # Randomly added 2 Oct 2012
                                if neighborSurfaceData.neighborAddress:
                                    # only allowing transfer from/between cells types 1, 2 & 4
                                    if (neighborSurfaceData.neighborAddress.type==1 or neighborSurfaceData.neighborAddress.type==2 or neighborSurfaceData.neighborAddress.type==4):
                                        dict_2=CompuCell.getPyAttrib(neighborSurfaceData.neighborAddress)  
                                        #print "nghbr.id:",neighborSurfaceData.neighborAddress.id," commSurfArea=",neighborSurfaceData.commonSurfaceArea," nghbrDict=",dict_2
                                        if "Load" in dict_2:  
                                            # cell.targetSurface goes to zero when the cell is being deleted
                                            if dict_2["deleting"] != 1:
                                                #transfer = (0.005)*dict_1["Load"]*neighborSurfaceData.commonSurfaceArea/cell.targetSurface
                                                # 9/26/12 added explicit timestep
                                                #transfer = k[cell.type][neighborSurfaceData.neighborAddress.type]*dict_1["Load"]*neighborSurfaceData.commonSurfaceArea/cell.targetSurface
                                                # 10/4/12 changed how hep's are done. Now the hep->non-hep transfer is scaled such that the surface area of the 
                                                #    hep is 2x the actual value. This can be thought of as either a represneation of the hep surface roughness, or 
                                                #    the presence of an unmodeled sinusoid on the other side of the hep. In either case, this removes the bias in the 
                                                #    equilibrium constant caused by the hep's export surface only being 3/4 of it's actual surface (since the wall side is never
                                                #    a diffusion surface). There is no change when the hep is the target of a transfer, onloy when it is the source.
                                                effectiveComSurfArea=neighborSurfaceData.commonSurfaceArea
#prior to 5 Oct 2012                             if cell.type == 1 and neighborSurfaceData.neighborAddress.type != 1 :  # hepatocyte is the source but not target, use 2x the common surface area
#                                                     effectiveComSurfArea = 2*effectiveComSurfArea
#                                                 transfer = self.deltaTime*k[cell.type][neighborSurfaceData.neighborAddress.type]*dict_1["Load"]*effectiveComSurfArea/cell.targetSurface
#                                                 dict_2["Load"] = max(0,dict_2["Load"] + transfer)
#                                                 dict_1["Load"] = max(0,dict_1["Load"] - transfer)
                                                # after 5 Oct 2012 
                                                

                                                #''#  1. use real volume (4x2D volume)
                                                #''#  2. use unbound fraction of blood APAP
                                                
                                                # active transport      Need to consider Fup ! 10/03/14
                                                APAP_import = 0 
                                                if cell.type == 1 and neighborSurfaceData.neighborAddress.type == 2:    # only serum to HEP
                                                    Fup = ParaDict['pbpk_Fup']  # used for serum to hep
                                                    
                                                    APAP_hep = dict_1["Load"]; APAP_blood = dict_2["Load"]
                                                    Vol_blood = neighborSurfaceData.neighborAddress.targetVolume * 4    # think about the shape of sin-hep interface
                                                    APAP_blood_conc = APAP_blood / (Vol_blood * LitersPerMicron * 151 / 1e3) * Fup
                                                    APAP_import = self.deltaTime*  Vmax_import* APAP_blood_conc / (APAP_blood_conc + Km_import) *Vol_blood/1e15*151/1e3      # mass (g)

                                                    dict_1["Load"] += APAP_import
                                                    dict_2["Load"] -= APAP_import
                                                    
                                                    if dict_2["Load"] < 0:
                                                        print "transport mechanism wrong!"
                                                        exit(1)
                                                
#                                                 # hepatocyte is the source but not target, use 2x the common surface area
                                                if cell.type == 1 and neighborSurfaceData.neighborAddress.type != 1: 
                                                    effectiveComSurfArea = 2.*effectiveComSurfArea
#                                                print "\t99999999", self.deltaTime       
#                                                 transfer = self.deltaTime*self.k[cell.type][neighborSurfaceData.neighborAddress.type]\
#                                                            *(dict_1["Load"]/float(cell.targetVolume)\
#                                                            -dict_2["Load"]/float(neighborSurfaceData.neighborAddress.targetVolume) )\
#                                                            *effectiveComSurfArea/(max(cell.surface,4*sqrt(cell.targetVolume)))    
#                                                 transfer = self.deltaTime*self.k[cell.type][neighborSurfaceData.neighborAddress.type]\
#                                                            *(dict_1["Load"]/float(cell.targetVolume)\
#                                                            -dict_2["Load"]/float(neighborSurfaceData.neighborAddress.targetVolume) )
#                                                            *effectiveComSurfArea/(4*sqrt(cell.targetVolume))


#                                                  # update sep24
#                                                 transfer = self.deltaTime*self.k[cell.type][neighborSurfaceData.neighborAddress.type]*dict_1["Load"]/float(cell.targetVolume)\
#                                                             - self.deltaTime*self.k[neighborSurfaceData.neighborAddress.type][cell.type]*dict_2["Load"]/float(neighborSurfaceData.neighborAddress.targetVolume)
                                                
#                                                 if transfer > 0:
#                                                     dict_2["Load"] = max(0,dict_2["Load"] + 0.5*transfer*cell.targetVolume) #yes, cell-2 uses cell-1's volume
#                                                     dict_1["Load"] = max(0,dict_1["Load"] - 0.5*transfer*cell.targetVolume)
                                                
                                                #''#  1. outflow flux scaled by number of neighbors
                                                #''#  2. NO protein binding considered in HEP and RBC / ONLY load transfered from serum portion scaled by Fup
                                                                                                
                                                # update 10/03/14: need partition outflux into nb 
                                                scaling = 1./float(dict_1['nbTotal'])
                                                if cell.type == 2:
                                                    Fup = ParaDict['pbpk_Fup']  # used for apap coming out of serum only
                                                    scaling = 1./float(dict_1['nbTotal'])*Fup
#                                                 print dict_1['nbTotal']
#                                                 exit(98)
                                                
                                                transfer = self.deltaTime*self.k[cell.type][neighborSurfaceData.neighborAddress.type]*dict_1["Load"]/float(cell.targetVolume) *scaling
                                                dict_2["Load"] = max(0,dict_2["Load"] + transfer*cell.targetVolume) #yes, cell-2 uses cell-1's volume
                                                dict_1["Load"] = max(0,dict_1["Load"] - transfer*cell.targetVolume ) 


                                                #''#   No Fup of metabolites considered in HEP
                                                
                                                # exporting mechanism for metabolites
                                                if cell.type == 1 and neighborSurfaceData.neighborAddress.type != 1:
                                                    
                                                    if ("Load_Glu" in dict_1) and ("Load_Glu" in dict_2):
                                                        APAPG_hep = dict_1["Load_Glu"]; APAPG_blood = dict_2["Load_Glu"]
                                                        APAPG_hep_temp = APAPG_hep
                                                        APAPG_blood += self.deltaTime * k_exAPAPG * APAPG_hep_temp 
                                                        APAPG_hep -= self.deltaTime * k_exAPAPG * APAPG_hep_temp  
                                                        
                                                        if APAPG_hep < 0:
                                                            print "transport mechanism wrong!"
                                                            exit(1)
                                                                                                                
                                                        dict_2["Load_Glu"] =  APAPG_blood
                                                        dict_1["Load_Glu"] =  APAPG_hep
                                                    
                                                    if ("Load_Sul" in dict_1) and ("Load_Sul" in dict_2):
                                                        APAPS_hep = dict_1["Load_Sul"]; APAPS_blood = dict_2["Load_Sul"]
                                                        APAPS_hep_temp = APAPS_hep
                                                        APAPS_blood += self.deltaTime * k_exAPAPS * APAPS_hep_temp  
                                                        APAPS_hep -= self.deltaTime * k_exAPAPS * APAPS_hep_temp  
                                                        
                                                        if APAPS_hep < 0:
                                                            print "transport mechanism wrong!"
                                                            exit(1)
                                                       
                                                        dict_2["Load_Sul"] =  APAPS_blood
                                                        dict_1["Load_Sul"] =  APAPS_hep
                                                                                                           
                                        else: 
                                            print "\n\n missing key cell 2 'Load' for cell.id, cell.type",cell.id,cell.type,"\n\n"
                    else:
                        print "\n\n missing key cell 1 'Load' for cell.id, cell.type",cell.id,cell.type,"\n\n"

            
            #################################################################
            ## Update Sub-Cell model ##
            # Iterate over all the cells and update the SBML model with the new concentrations for the cells
            # Can't do this until the diffusions have all been calculated
#             print "************", "APAP_conc writen to subcellular SBML", mcs
            for cell in self.cellListByType(self.HEPATOCYTE):                
                dict_1=CompuCell.getPyAttrib(cell)
                APAP_conc=dict_1["Load"]/20**3*1e15/151*1e3  # treat as a true volume, gives millimolar
                APAP_Glu_conc=dict_1["Load_Glu"]/20**3*1e15/322*1e3
                APAP_Sul_conc=dict_1["Load_Sul"]/20**3*1e15/231*1e3
                self.setSBMLValue(_modelName='ApapGshModel',_valueName='APAP',_value=APAP_conc,_cell=cell) # value name can be e.g. species name 
                self.setSBMLValue(_modelName='ApapGshModel',_valueName='APAPconj_Glu',_value=APAP_Glu_conc,_cell=cell) # value name can be e.g. species name 
                self.setSBMLValue(_modelName='ApapGshModel',_valueName='APAPconj_Sul',_value=APAP_Sul_conc,_cell=cell) # value name can be e.g. species name 
           
            self.timestepCellSBML()
             
            
            ##########################################################################################################
            ##########################################     APAP    ##################################################
            ##########################################################################################################
            # get the values from the PBPK/SBML model and update CC3D
            CVen = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='CVen')
            VLiver = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VLiver')
            
            global freqAll
            if SumLoadExit > 0:
                if not mcs%freqAll:
                    print "CC3D --> PBPK    PASSING SumLoadExit, SumVolumeExit, ratio=", SumLoadExit,SumVolumeExit,(SumLoadExit/SumVolumeExit)
                # Add the quantity to the Vein (Ven) compartment
#                 CVen = state['CVen']
                CVen   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='CVen')
                ### 8/24/2012
                ### J10: CLiver  -> CVen
                ###   ODE: (QLiver+QGut)*CLiver*Ratioblood2plasma/Kliver2plasma/Fraction_unbound_plasma/VLiver;
                ###   With the turning off the PBPK metabolism and flow, simplifies to:
                ###   ODE: (QLiver+QGut)*CLiver/VLiver;  
                NewCVen =  CVen + SumLoadExit*(VLiver*0.074/SinusoidVolume)  #d: 8/28/2012 10/4/2012 *0.074 Drasdostate={}
#                 state['CVen']=NewCVen 
                self.setSBMLValue(_modelName='PBPKWambaugh',_valueName='CVen',_value=NewCVen) # value name can be e.g. species name 
                SumLoadExit   = 0.0
                vExit = SumVolumeExit
                SumVolumeExit = 0.0
            
            ## Update PBPK models ##
            ##########################################################################################################
            ########################################    APAPconj_Glu  ################################################
            ##########################################################################################################
            
#             state1=self.getSBMLState(_modelName='PBPKWambaugh_cG') #
            if APAPconjGluExit > 0: 

                CVen_cG = self.getSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='CVen')
                NewCVen_cG =  CVen_cG + APAPconjGluExit*(VLiver*0.074/SinusoidVolume)
                self.setSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='CVen',_value=NewCVen_cG) # value name can be e.g. species name 
                APAPconjGluExit = 0.0
            ##########################################################################################################
            ########################################    APAPconj_Glu  ################################################
            ##########################################################################################################
            
#             state2=self.getSBMLState(_modelName='PBPKWambaugh_cS') #
            if APAPconjSulExit > 0:
                CVen_cS = self.getSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='CVen')
                NewCVen_cS =  CVen_cS + APAPconjSulExit*(VLiver*0.074/SinusoidVolume)
                self.setSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='CVen',_value=NewCVen_cS) # value name can be e.g. species name 
                APAPconjSulExit = 0.0
                vExit = 0
            ##########################################################################################################
            ##########################################################################################################
            
            self.timestepFreeFloatingSBML()
                
            
        end_time=time.time()
#         print 'LOAD ATTRIB RUN TIME=',end_time-start_time    

    def stop(self): pass
#         self.output_file101.close()
#         self.output_file102.close()

########################################################################################
###########
########### Apply a force to keep the BloodPortion_source cells where they belong 
########### (near their starting COM), sources are nominally 5x10 pixels
########### also applies the standard forcing to the bloodPortions and RBCs (see also mitosis)
########### New 10/5/2012
class ForceSourceCells(SteppablePy):
    def __init__(self,_simulator,_frequency=10):
        SteppablePy.__init__(self,_frequency)
        self.simulator=_simulator
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        
    def start(self):
        import CompuCellSetup 
        try:  # create an output file just for this forcing data
            self.output_file2,outFullFileName2=CompuCellSetup.openFileInSimulationOutputDirectory("AOut_Data_sourceForcing.txt","a")
        except IOError:
            sys.exit("\n\nIOError: Problem opening the 2nd log file.\n >>> IS THE PLAYER OPTION \"SAVE IMAGE EVERY NTH MCS\" NOT CHECKED? <<<\n") # requires import sys
        except:
            sys.exit("\n\n >>> Unkown Error: Problem opening the 2nd log file. <<<\n") # requires import sys
        self.output_file2.write("VolumeParamSteppable.checkSourceLoc\tMCS\ttype\tcell.xCOM\tcell.yCOM\tError\n")
        self.output_file2.write("VolumeParamSteppable.checkSourceForcing\tMCS\tcell.type\tcell.id\tInitcell.xCOM\tcell.xCOM\tlambdaVecX\tInitcell.yCOM\tcell.yCOM\tlambdaVecY\n") 

        global freqAll
        for cell in self.cellList:
            cell.lambdaVecX = 0.0
            cell.lambdaVecY = 0.0
            if cell.type == 3:   # blood portion sources, new 2 Oct 2012, save the intial x,y coords for forcing
                dict=CompuCell.getPyAttrib(cell)
                dict["initXCom"]=5  # source cells start at 5x5 but go to 10x5
                dict["initYCom"]=cell.yCOM
                cell.lambdaVecX=5  # positive values force to the left
                self.output_file2.write("VolumeParamSteppable.checkSourceForcing\t0\t"+str(cell.type)+"\t"+str(cell.id)\
                    +"\t"+"%6.2f"%dict["initXCom"]+"\t"+"%6.2f"%cell.xCOM+"\t"+"%6.2f"%cell.lambdaVecX +"\t"+"%6.2f"%dict["initYCom"]\
                    +"\t"+"%6.2f"%cell.yCOM+"\t"+"%6.2f"%cell.lambdaVecY+"\n")
            if cell.type == 2:  # BloodPortion
                cell.lambdaVecX=-30 # negative values force to the right
                #externalPotential.ElementCC3D("ExternalPotentialParameters", {"CellType":"BloodPortion", "x":" -20",  "y":"0", "z":"0"})
            if cell.type == 4:  # RedBloodCell
                cell.lambdaVecX=-150 # negative values force to the right
                #externalPotential.ElementCC3D("ExternalPotentialParameters", {"CellType":"RedBloodCell", "x":"-100", "y":"0", "z":"0"})

    def step(self,mcs):
#         cnt=0
#         for cell in self.cellList:
#             if cell.type == 3:  # BloodPortion_source
#                 cnt+=1
#         print "                                        Source count=",cnt

        for cell in self.cellList:
            if cell.type == 3:  # BloodPortion_source
                ## check and log the Y-location of the source cells
                ## doesn't look like you can individually assign lambdaVecX (Y, Z) if the main python sets them by type
                ## have to do it manually including in mitosis?
                global line2Print
                dict=CompuCell.getPyAttrib(cell)
                if cell.xCOM > 10:  # log an error
                    self.output_file2.write("VolumeParamSteppable.checkSourceLoc\t"+str(mcs)+"\t"+str(cell.id)+"\t"+str(cell.xCOM)+"\t"+str(cell.yCOM)+"\tERROR\n")      
                if abs(cell.xCOM-dict["initXCom"]) >= 3:  # add forcing on X-axis
                    cell.lambdaVecX=20.*cmp((cell.xCOM-dict["initXCom"]),0)*(cell.xCOM-dict["initXCom"])**2  # positive numbers push to the left
                else:
                    cell.lambdaVecX=20.0   # the default x force for sources
                if abs(cell.yCOM-dict["initYCom"]) >= 3:  # add forcing on Y-axis
                    cell.lambdaVecY=20.*cmp((cell.yCOM-dict["initYCom"]),0)*(cell.yCOM-dict["initYCom"])**2  # positive numbers push down, negative pushes up 
                else:
                    cell.lambdaVecY=0.0   # the default y force for sources 
                #### TEST vvvvvvvvvvvvvvvvv 
                #if mcs >= 300 and mcs < 1000:  # push sources to the right then let the auto routine push'm back
                #    if cell.id == 158 or cell.id == 159 :
                #        cell.lambdaVecX=-500.  # positive numbers push to the left
                #        print "     ? ? ? ? ? ? ? ? ? ? ? ? ",cell.type,cell.id,cell.lambdaVecX,cell.lambdaVecY
                #### TEST ^^^^^^^^^^^^^^^^^
                # only log if there is a problem
                if (cell.lambdaVecX != 10. or cell.lambdaVecY != 0.) or not mcs % 5000:  # the 10 on X is the default condition
                    self.output_file2.write("VolumeParamSteppable.checkSourceForcing\t"+str(mcs)+"\t"+str(cell.type)+"\t"+str(cell.id)\
                        +"\t"+"%6.2f"%dict["initXCom"]+"\t"+"%6.2f"%cell.xCOM+"\t"+"%6.2f"%cell.lambdaVecX +"\t"+"%6.2f"%dict["initYCom"]\
                        +"\t"+"%6.2f"%cell.yCOM+"\t"+"%6.2f"%cell.lambdaVecY+"\n")

    def stop(self):
        self.output_file2.close()

########################################################################################
###########
########### graph the tissue quantities and concentrations from the PBPK model
###########
class TissueLevelsFromPBPK(SteppableBasePy):
    def __init__(self,_simulator,_frequency=100):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        
    def start(self):
        import CompuCellSetup 
        global Dose, freqAll

# Graph 11111111111111111111111111111111
        # prior to 10/19/12
        #self.XaxisMaximum=10000 # this is the global maximum X for the x-axis of the plots, X-Axis is in KMCS (20000KMCS=83 sim.minutes)
        #self.savePlots=  200000 # how often to save the plots as PNG, should match CC3D's image saving dwell
        # after 10/19/12
        self.XaxisMaximum=100000  # this is the global maximum X for the x-axis of the plots, X-Axis is in KMCS (100000KMCS=6.9 sim.hours)
        self.savePlots= freqAll  #100000  # how often to save the plots as PNG, should match CC3D's image saving dwell
        # setup a graph for PBPK values in grams
        import CompuCellSetup  
        self.pPBPKgrams=CompuCellSetup.viewManager.plotManager.getNewPlotWindow()
        if not self.pPBPKgrams:
            return
        #Plot Title - properties           
        self.pPBPKgrams.setTitle("PBPK Tissue Quantities")
        self.pPBPKgrams.setTitleSize(12)
        self.pPBPKgrams.setTitleColor("black") # you may choose different color - type its name
        #plot background
        self.pPBPKgrams.setPlotBackgroundColor("white") # you may choose different color - type its name
        # properties of x axis
        self.pPBPKgrams.setXAxisTitle("Hour")
        self.pPBPKgrams.setXAxisTitleSize(10)      
        self.pPBPKgrams.setXAxisTitleColor("black")  # you may choose different color - type its name 
        #self.pPBPKgrams.setXAxisScale(0,self.XaxisMaximum) # turn off the axis autoscaling and force it to be these values        
        # properties of y axis
        self.pPBPKgrams.setYAxisTitle("Quantity (g)")        
        #self.pPBPKgrams.setYAxisLogScale()
        self.pPBPKgrams.setYAxisTitleSize(10)        
        self.pPBPKgrams.setYAxisTitleColor("black")  # you may choose different color - type its name  
        self.pPBPKgrams.setYAxisScale(0,1.05 * Dose) # 12.5    turn off the axis autoscaling and force it to be these values        
        # choices for style are NoCurve,Lines,Sticks,Steps,Dots
        self.pPBPKgrams.addPlot("AGutlumen",_style='Lines')
        self.pPBPKgrams.addPlot("AGut",     _style='Lines')
        self.pPBPKgrams.addPlot("CTubules", _style='Lines')
        self.pPBPKgrams.addPlot("AVen",     _style='Lines')
        self.pPBPKgrams.addPlot("ARest",    _style='Lines')
        self.pPBPKgrams.addPlot("ALiver",   _style='Lines')
        self.pPBPKgrams.addPlot("Transit",  _style='Lines')
        # plot MCS
        self.pPBPKgrams.changePlotProperty("AGutlumen","LineWidth",2)
        self.pPBPKgrams.changePlotProperty("AGutlumen","LineColor","red")  
        self.pPBPKgrams.changePlotProperty("AGut",     "LineWidth",2)
        self.pPBPKgrams.changePlotProperty("AGut",     "LineColor","pink")  
        self.pPBPKgrams.changePlotProperty("CTubules", "LineWidth",2)
        self.pPBPKgrams.changePlotProperty("CTubules", "LineColor","blue")        
        self.pPBPKgrams.changePlotProperty("AVen",     "LineWidth",2)
        self.pPBPKgrams.changePlotProperty("AVen",     "LineColor","purple")        
        self.pPBPKgrams.changePlotProperty("ARest",    "LineWidth",2)
        self.pPBPKgrams.changePlotProperty("ARest",    "LineColor","black")        
        self.pPBPKgrams.changePlotProperty("ALiver",   "LineWidth",2)
        self.pPBPKgrams.changePlotProperty("ALiver",   "LineColor","green")        
        self.pPBPKgrams.changePlotProperty("Transit",  "LineWidth",4)
        self.pPBPKgrams.changePlotProperty("Transit",  "LineColor","green")        
        self.pPBPKgrams.addGrid()
        # adding automatically generated legend
        # default possition is at the bottom of the plot but here we put it at the top
        self.pPBPKgrams.addAutoLegend("top")
        self.clearFlag=False

# Graph 222222222222222222222222222
        # setup a graph for PBPK values in grams/Liter
        self.pPBPKconc=CompuCellSetup.viewManager.plotManager.getNewPlotWindow()
        if not self.pPBPKconc:
            return
        #Plot Title - properties           
        self.pPBPKconc.setTitle("PBPK Tissue Concentrations")
        self.pPBPKconc.setTitleSize(12)
        self.pPBPKconc.setTitleColor("black") # you may choose different color - type its name
        #plot background
        self.pPBPKconc.setPlotBackgroundColor("white") # you may choose different color - type its name
        # properties of x axis
        self.pPBPKconc.setXAxisTitle("Hour")
        self.pPBPKconc.setXAxisTitleSize(10)      
        self.pPBPKconc.setXAxisTitleColor("black")  # you may choose different color - type its name   
        #self.pPBPKconc.setXAxisScale(0,self.XaxisMaximum) # turn off the axis autoscaling and force it to be these values
        # properties of y axis
        self.pPBPKconc.setYAxisTitle("Concentration (g/L)")        
        #self.pPBPKconc.setYAxisLogScale()
        self.pPBPKconc.setYAxisTitleSize(10)        
        self.pPBPKconc.setYAxisTitleColor("black")  # you may choose different color - type its name    
        self.pPBPKconc.setYAxisScale(0,0.025 * Dose)  # 0.25 # turn off the axis autoscaling and force it to be these values
        # choices for style are NoCurve,Lines,Sticks,Steps,Dots
        self.pPBPKconc.addPlot("AGutlumen",_style='Lines')
        self.pPBPKconc.addPlot("AGut",     _style='Lines')
        self.pPBPKconc.addPlot("CTubules", _style='Lines')
        self.pPBPKconc.addPlot("AVen",     _style='Lines')
        self.pPBPKconc.addPlot("AArt",     _style='Lines')
        self.pPBPKconc.addPlot("ARest",    _style='Lines')
        self.pPBPKconc.addPlot("ALiver",   _style='Lines')
        self.pPBPKconc.addPlot("Transit",  _style='Lines')
        self.pPBPKconc.addPlot("ALung",    _style='Lines')
        self.pPBPKconc.addPlot("AKidney",  _style='Lines')

        # plot MCS
        self.pPBPKconc.changePlotProperty("AGutlumen","LineWidth",2)
        self.pPBPKconc.changePlotProperty("AGutlumen","LineColor","red")  
        self.pPBPKconc.changePlotProperty("AGut",     "LineWidth",2)
        self.pPBPKconc.changePlotProperty("AGut",     "LineColor","pink")  
        self.pPBPKconc.changePlotProperty("CTubules", "LineWidth",2)
        self.pPBPKconc.changePlotProperty("CTubules", "LineColor","blue")        
        self.pPBPKconc.changePlotProperty("AVen",     "LineWidth",3)
        self.pPBPKconc.changePlotProperty("AVen",     "LineColor","purple")        
        self.pPBPKconc.changePlotProperty("AArt",     "LineWidth",1)
        self.pPBPKconc.changePlotProperty("AArt",     "LineColor","purple")        
        self.pPBPKconc.changePlotProperty("ARest",    "LineWidth",2)
        self.pPBPKconc.changePlotProperty("ARest",    "LineColor","black")        
        self.pPBPKconc.changePlotProperty("ALiver",   "LineWidth",2)
        self.pPBPKconc.changePlotProperty("ALiver",   "LineColor","green")        
        self.pPBPKconc.changePlotProperty("Transit",  "LineWidth",4)
        self.pPBPKconc.changePlotProperty("Transit",  "LineColor","green")  
        self.pPBPKconc.changePlotProperty("ALung",    "LineWidth",2)
        self.pPBPKconc.changePlotProperty("ALung",    "LineColor","yellow")   
        self.pPBPKconc.changePlotProperty("AKidney",  "LineWidth",2)
        self.pPBPKconc.changePlotProperty("AKidney",  "LineColor","orange")   
      
        self.pPBPKconc.addGrid()
        # adding automatically generated legend
        # default possition is at the bottom of the plot but here we put it at the top
        self.pPBPKconc.addAutoLegend("top")
        self.clearFlag=False

# Graph 33333333333333333333333333333333
        # setup a graph for SBML values
        self.pSBML=CompuCellSetup.viewManager.plotManager.getNewPlotWindow()
        if not self.pSBML:
            return
        #Plot Title - properties           
        self.pSBML.setTitle("SBML Cell Concentrations")
        self.pSBML.setTitleSize(12)
        self.pSBML.setTitleColor("black") # you may choose different color - type its name
        #plot background
        self.pSBML.setPlotBackgroundColor("white") # you may choose different color - type its name
        # properties of x axis
        self.pSBML.setXAxisTitle("Second")
        self.pSBML.setXAxisTitleSize(10)      
        self.pSBML.setXAxisTitleColor("black")  # you may choose different color - type its name  
        #self.pSBML.setXAxisScale(0,self.XaxisMaximum) # turn off the axis autoscaling and force it to be these values        
        # properties of y axis
        self.pSBML.setYAxisTitle("Hep [GSH] (mM)")       
        self.pSBML.setYAxisScale(5,10) # turn off the axis autoscaling and force it to be these values 
        #self.pPBPKgrams.setYAxisLogScale()
        self.pSBML.setYAxisTitleSize(10)        
        self.pSBML.setYAxisTitleColor("black")  # you may choose different color - type its name                                
        # choices for style are NoCurve,Lines,Sticks,Steps,Dots    # ***$*
        self.pSBML.addPlot("Hep_1 GSH", _style='Lines')
        self.pSBML.addPlot("Hep_11 GSH", _style='Lines')
        self.pSBML.addPlot("Hep_16 GSH", _style='Lines')
        self.pSBML.addPlot("Hep_8 GSH", _style='Lines')
        self.pSBML.addPlot("Hep_20 GSH",_style='Lines')
        # plot MCS
        self.pSBML.changePlotProperty("Hep_1 GSH","LineWidth",2)
        self.pSBML.changePlotProperty("Hep_1 GSH","LineColor","red") 
        self.pSBML.changePlotProperty("Hep_11 GSH","LineWidth",2)
        self.pSBML.changePlotProperty("Hep_11 GSH","LineColor","cyan")
        self.pSBML.changePlotProperty("Hep_16 GSH","LineWidth",2)
        self.pSBML.changePlotProperty("Hep_16 GSH","LineColor","yellow") 
        self.pSBML.changePlotProperty("Hep_8 GSH","LineWidth",2)
        self.pSBML.changePlotProperty("Hep_8 GSH","LineColor","blue")  
        self.pSBML.changePlotProperty("Hep_20 GSH","LineWidth",2)
        self.pSBML.changePlotProperty("Hep_20 GSH","LineColor","green")  
        self.pSBML.addGrid()
        # adding automatically generated legend
        # default possition is at the bottom of the plot but here we put it at the top
        self.pSBML.addAutoLegend("top")
        self.clearFlag=False
        
        global SumLoadExit, SumVolumeExit, LoadInTransit, TotalCellsCreated, TotalCellsDeleted, SinusoidVolume, line2Print
        global APAPconjGluExit, APAPconjSulExit

        line2Print += "TissueLevelsFromPBPK\tMCS\tAGutlumen\tCGut\tCLiver"
        line2Print += "\tCArt\tCVen\tCLung\tCKidney\tCRest"
        line2Print += "\tCTubules\tCMetab\tLoadInTransit\n"
         
            
    def step(self,mcs):
        import CompuCellSetup  
        KMCS=float(mcs)/1000.
#         for cell in self.cellList:
        global SumLoadExit, SumVolumeExit, LoadInTransit, TotalCellsCreated, TotalCellsDeleted, SinusoidVolume, line2Print
        global hepatocyteList,hepatocyteListZoneIII, hr, sec
        ######## Update PBPK Graph

        state=self.getSBMLState(_modelName='PBPKWambaugh') 
        CGut   = state['CGut']
        CArt   = state['CArt']
        CLiver = state['CLiver'] 
        CLung  = state['CLung']
        CKidney= state['CKidney']
        CVen   = state['CVen']
        AGutlumen = state['AGutlumen'] 
        CTubules = state['CTubules']
        #VTubules= state['VTubules']  # there is no VTubules in the PBPK!               
        CMetab   = state['CMetabolized']
        CRest    = state['CRest']
        
#             self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VALUE_NAME') # value name can be e.g. species name 
        
        QGut   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='QGut')
        VGut   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VGut')
        VArt   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VArt')
        QLiver = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='QLiver')
        VLiver = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VLiver')
        VLung = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VLung')
        VKidney = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VKidney') 
        VVen   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VVen')
        VRest   = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VRest')
        


        # In the PBPK C's are actually amounts (grams), not concentrations
#                try:
        if not mcs %self.savePlots:  # save to the log file this often (this is only checked every 100 MCS)
            print "\n\n============== Quantity    Conc      Vol ====== at MCS:",mcs,"============================"
            print "    AGutlumen: %7.4f" % (AGutlumen)
            print "          Gut: %7.4f  %7.4f  %7.4f" % (CGut,CGut/VGut,VGut)
            print "        Liver: %7.4f  %7.4f  %7.4f" % (CLiver,CLiver/VLiver,VLiver)
            print "          Art: %7.4f  %7.4f  %7.4f" % (CArt,CArt/VArt,VArt)
            print "          Ven: %7.4f  %7.4f  %7.4f" % (CVen,CVen/VVen,VVen)
            print "         Lung: %7.4f  %7.4f  %7.4f" % (CLung,CLung/VLung,VLung)
            print "       Kidney: %7.4f  %7.4f  %7.4f" % (CKidney,CKidney/VKidney,VKidney)
            print "         Rest: %7.4f  %7.4f  %7.4f" % (CRest,CRest/VRest,VRest)
            print "      Tubules: %7.4f              " % (CTubules)
            print "       CMetab: %7.4f              " % (CMetab)
            print "   TOTAL Quan: %7.4f              " % (AGutlumen+CGut+CLiver+CArt+CVen+CLung+CKidney+CRest+CTubules+CMetab)
            print "LoadInTransit: %7.4f  %7.4f       " % (LoadInTransit/SinusoidVolume*VLiver*0.074,LoadInTransit/SinusoidVolume) # *0.074 Drasdo
            print "        TOTAL: %7.4f              " % (AGutlumen+CGut+CLiver+CArt+CVen+CLung+CKidney+CRest+CTubules+CMetab+LoadInTransit/SinusoidVolume*VLiver*0.074) # *0.074 Drasdo
            print "=========================================================================================\n\n"
            line2Print += "TissueLevelsFromPBPK\t"+str(mcs)+"\t"+str(AGutlumen)+"\t"+str(CGut)+"\t"+str(CLiver)
            line2Print += "\t"+str(CArt)+"\t"+str(CVen)+"\t"+str(CLung)+"\t"+str(CKidney)+"\t"+str(CRest)
            line2Print += "\t"+str(CTubules)+"\t"+str(CMetab)+"\t"+str(LoadInTransit/SinusoidVolume*VLiver*0.074)+"\n"
               
        # add to the plot
        #self.pPBPKgrams.eraseAllData() # this is how you erase previous content of the plot
        #self.pPBPKconc.addDataPoint("AGutlumen",mcs,AGutlumen) # arguments are (name of the data series, x, y)
        self.pPBPKconc.addDataPoint("AGut",   hr*mcs,CGut/VGut)
        #self.pPBPKconc.addDataPoint("CTubules",hr*mcs,CTubules) 
        self.pPBPKconc.addDataPoint("AVen",   hr*mcs,CVen/VVen) 
        self.pPBPKconc.addDataPoint("AArt",   hr*mcs,CArt/VArt) 
        self.pPBPKconc.addDataPoint("ARest",  hr*mcs,CRest/VRest) 
        self.pPBPKconc.addDataPoint("ALung",  hr*mcs,CLung/VLung) 
        self.pPBPKconc.addDataPoint("AKidney",hr*mcs,CKidney/VKidney) 
        #self.pPBPKconc.addDataPoint("ALiver",mcs,CLiver/VLiver) 
#         self.pPBPKconc.addDataPoint("Transit",mcs,LoadInTransit/SinusoidVolume) 
        self.pPBPKconc.showAllPlots() 


        # save the plot as a png
        if not mcs % self.savePlots:
            if self.pPBPKconc:            
                qwtPlotWidget=self.pPBPKconc.getQWTPLotWidget()
                qwtPlotWidgetSize=qwtPlotWidget.size()
                filePath=CompuCellSetup.getScreenshotDirectoryName() + "/plot_PBPKconc/"
                fileName="plot_PBPKconc_" + format(mcs, '07d') + ".png"
                # Does the output dir exist?
                if not os.path.isdir(filePath):
                    os.makedirs(filePath)
#                         print "                nnnnn MADE Dir nnnn   plot path,filename=\n   "+filePath
#                     print "          nnnnnnnnnnnnnnnnnnnnnn   plot path,filename=\n   "+filePath+fileName+"\n"
                # here we specify size of the image saved - default is 400 x 400
                self.pPBPKconc.savePlotAsPNG(filePath+fileName,qwtPlotWidgetSize.width()+50,qwtPlotWidgetSize.height()+50)

        # add to the plot
        self.pPBPKgrams.addDataPoint("AGutlumen",hr*mcs,AGutlumen) # arguments are (name of the data series, x, y)
        self.pPBPKgrams.addDataPoint("AGut",    hr*mcs,CGut)
        self.pPBPKgrams.addDataPoint("CTubules",hr*mcs,CTubules) 
        self.pPBPKgrams.addDataPoint("AVen",    hr*mcs,CVen) 
        self.pPBPKgrams.addDataPoint("ARest",   hr*mcs,CRest) 
        self.pPBPKgrams.addDataPoint("ALiver",  hr*mcs,CLiver) 
        self.pPBPKgrams.addDataPoint("Transit", hr*mcs,LoadInTransit/SinusoidVolume*VLiver*0.074) # *0.074 Drasdo
        self.pPBPKgrams.showAllPlots() 
        # save the plot as a png

        if not mcs % self.savePlots:
            if self.pPBPKgrams:            
                qwtPlotWidget2=self.pPBPKgrams.getQWTPLotWidget()
                qwtPlotWidgetSize2=qwtPlotWidget2.size()
                filePath2=CompuCellSetup.getScreenshotDirectoryName() + "/plot_PBPKgrams/"
                fileName2="plot_PBPKgrams_" + format(mcs, '07d') + ".png"
                # Does the output dir exist?
                if not os.path.isdir(filePath2):
                    os.makedirs(filePath2)
#                         print "                nnnnn MADE Dir nnnn   plot path,filename=\n   "+filePath2
#                     print "          nnnnnnnnnnnnnnnnnnnnnn   plot path,filename=\n   "+filePath2+fileName2+"\n"
                # here we specify size of the image saved - default is 400 x 400
                self.pPBPKgrams.savePlotAsPNG(filePath2+fileName2,qwtPlotWidgetSize2.width()+50,qwtPlotWidgetSize2.height()+50)
#                except ZeroDivisionError:
#                    pass
        
        
        

        # save the plot as a png
        if not mcs % self.savePlots:
            if self.pSBML:
                self.pSBML.showAllPlots()              
                qwtPlotWidget3=self.pSBML.getQWTPLotWidget()
                qwtPlotWidgetSize3=qwtPlotWidget3.size()
                filePath3=CompuCellSetup.getScreenshotDirectoryName() + "/plot_pSBMLgsh/"
                fileName3="plot_pSBMLgsh_" + format(mcs, '07d') + ".png"
                # Does the output dir exist?
                if not os.path.isdir(filePath3):
                    os.makedirs(filePath3)
#                     print "                nnnnn MADE Dir nnnn   plot path3,filename3=\n   "+filePath3
#                 print "          nnnnnnnnnnnnnnnnnnnnnn   plot path3,filename3=\n   "+filePath3+fileName3+"\n"
                # here we specify size of the image saved - default is 400 x 400
                self.pSBML.savePlotAsPNG(filePath3+fileName3,qwtPlotWidgetSize3.width()+50,qwtPlotWidgetSize3.height()+50)  
        
        ######## Plot Plasma concentration of apap and conjugates
        if not mcs % self.savePlots: 
            p_APAP             =       self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='CVen') # value name can be e.g. species name 
            p_APAP_Glucuronide =       self.getSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='CVen') # value name can be e.g. species name 
            p_APAP_Sulfate     =       self.getSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='CVen') # value name can be e.g. species name 
            e_APAP             =       self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='CTubules') # value name can be e.g. species name 
            e_APAP_Glucuronide =       self.getSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='CTubules') # value name can be e.g. species name 
            e_APAP_Sulfate     =       self.getSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='CTubules') # value name can be e.g. species name
            print '\n***'
            print 'plasma_APAP','\t','plasma_Glucuronide','\t','plasma_Sulfate','\n'
            print p_APAP,'\t',p_APAP_Glucuronide,'\t',p_APAP_Sulfate,'\n'
            print '***\n'
            print 'excreted_APAP','\t','excreted_Glucuronide','\t','excreted_Sulfate','\n'
            print e_APAP,'\t',e_APAP_Glucuronide,'\t',e_APAP_Sulfate,'\n'
            print '***\n'
             
            
        ######## Update SBML (hepatocytes) Graph a few heps, also log the rest
        for cell in self.cellListByType(self.HEPATOCYTE):  # A couple selected hepatocytes)
            state=self.getSBMLState(_modelName='ApapGshModel',_cell=cell) # returns dictionary of values
            hep_GSH      = state['GSH']
            hep_APAP     = state['APAP']  
            hep_APAP_Glucuronide = state['APAPconj_Glu']
            hep_APAP_Sulfate = state['APAPconj_Sul']
            hep_NAPQI    = state['NAPQI']  
            hep_NAPQIGSH = state['NAPQIGSH'] 
            
            # [168,169,170,178,179,180]:  # cellId list of the Zone III hep's
            # I choose to also plot 171, 176 
            if cell.id == hepatocyteList[0].id:
                self.pSBML.addDataPoint("Hep_1 GSH", sec*mcs,hep_GSH) # arguments are (name of the data series, x, y)
            if cell.id == hepatocyteList[1].id:
                self.pSBML.addDataPoint("Hep_11 GSH", sec*mcs,hep_GSH)        # ***$*
            if cell.id == hepatocyteList[11].id:
                self.pSBML.addDataPoint("Hep_16 GSH", sec*mcs,hep_GSH)
            if cell.id == hepatocyteList[14].id:
                self.pSBML.addDataPoint("Hep_8 GSH", sec*mcs,hep_GSH)
            if cell.id == hepatocyteList[19].id:
                self.pSBML.addDataPoint("Hep_20 GSH",sec*mcs,hep_GSH)
            self.pSBML.showAllPlots() 
            # write the various conc's for all the heps to the log file
            if not mcs % self.savePlots:  # write to the log file this often
                line2Print += "TissueLevelsFromSBML\t"+str(mcs)+"\t"+str(cell.id)+"\t"+str(hep_GSH)
                line2Print += "\t"+str(hep_APAP)+"\t"+str(hep_NAPQI)+"\t"+str(hep_NAPQIGSH)+"\t"+str(hep_APAP_Glucuronide)+"\t"+str(hep_APAP_Sulfate)+"\n" 
            if not mcs % self.savePlots:            # ***$*
                if cell.id == 178:
                    print '\n***'
                    print 'subcell_APAP','\t','subcell_Glucuronide','\t','subcell_Sulfate','\n'
                    print hep_APAP,'\t',hep_APAP_Glucuronide,'\t',hep_APAP_Sulfate, '\t', 'Hepatocyte ID = 178', '\n'
                    print '***\n'



    def stop(self):
        self.output_filehep.close()
        self.output_filedrug.close()
########################################################################################
###########
########### visualization for the molecule Load field
###########
class LoadFieldVisualizationSteppable(SteppablePy):
    def __init__(self,_simulator,_frequency=10):
        SteppablePy.__init__(self,_frequency)
        self.simulator=_simulator
        self.cellFieldG=self.simulator.getPotts().getCellFieldG()
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.dim=self.cellFieldG.getDim()

    def setScalarField(self,_field):
        self.scalarField=_field

    def start(self):pass
            
    def step(self,mcs):
        for x in xrange(self.dim.x):
            for y in xrange(self.dim.y):
                for z in xrange(self.dim.z):
                    pt=CompuCell.Point3D(x,y,z)
                    cell=self.cellFieldG.get(pt)
                    #get Load from the cell's dictionary
                    dict_1=CompuCell.getPyAttrib(cell)
                    if ("Load" in dict_1):
                        #if  dict_1["deleting"] != 1:  # don't update color if cell in process of being deleted
                        #   fillScalarValue(self.scalarField,x,y,z, dict_1["Load"])
                        fillScalarValue(self.scalarField,x,y,z, dict_1["Load"])
                    else:
                        fillScalarValue(self.scalarField,x,y,z, 0)
                        print "\nLoadVisualization: missing key 'Load' for cell.id, cell.type",cell.id,cell.type,dict_1,"\n"

########################################################################################
###########
########### visualization for the molecule Load field as concentation (Load/cell area)
###########
class ConcentrationFieldVisualizationSteppable(SteppablePy):
    def __init__(self,_simulator,_frequency=10):
        SteppablePy.__init__(self,_frequency)
        self.simulator=_simulator
        self.cellFieldG=self.simulator.getPotts().getCellFieldG()
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.dim=self.cellFieldG.getDim()

    def setScalarField(self,_field):
        self.scalarField=_field

    def start(self):pass
            
    def step(self,mcs):
        for x in xrange(self.dim.x):
            for y in xrange(self.dim.y):
                for z in xrange(self.dim.z):
                    pt=CompuCell.Point3D(x,y,z)
                    cell=self.cellFieldG.get(pt)
                    #get Load from the cell's dictionary
                    dict_1=CompuCell.getPyAttrib(cell)
                    if ("Load" in dict_1):
                        if(cell.targetVolume > 0): 
                            #if(dict_1["deleting"] != 1):  # don't update color if cell in process of being deleted
                            #    # using ultimate targetVolume instead of actual "cell volume"  4 Oct 2012
                            #    fillScalarValue(self.scalarField,x,y,z, dict_1["Load"]/dict_1["ultimateVolume"]*1e15)
                            fillScalarValue(self.scalarField,x,y,z, dict_1["Load"]/dict_1["ultimateVolume"]*1e15)
                        else:
                            fillScalarValue(self.scalarField,x,y,z, 0)
                    else:
                        print "\nConcVisualization: missing key 'Load' for cell.id, cell.type",cell.id,cell.type,dict_1,"\n"

########################################################################################
###########
########### visualization for the GSH concentation (Load/cell area)
########### Note that GSH is stored as a concentration, not a load, so don't need to divide by cell colume
########### only applies to the hepatocytes (type 1)
class GSHConcentrationFieldVisualizationSteppable(SteppablePy):
    def __init__(self,_simulator,_frequency=10):
        SteppablePy.__init__(self,_frequency)
        self.simulator=_simulator
        self.cellFieldG=self.simulator.getPotts().getCellFieldG()
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.dim=self.cellFieldG.getDim()

    def setScalarField(self,_field):
        self.scalarField=_field

    def start(self):pass
            
    def step(self,mcs):
        for x in xrange(self.dim.x):
            for y in xrange(self.dim.y):
                for z in xrange(self.dim.z):
                    pt=CompuCell.Point3D(x,y,z)
                    cell=self.cellFieldG.get(pt)
                    #get GSHconc from the cell's dictionary
                    if cell.type == 1:
                        dict_1=CompuCell.getPyAttrib(cell)
                        if ("GSHconc" in dict_1):
                            fillScalarValue(self.scalarField,x,y,z, dict_1["GSHconc"])
                        else:
                            print "\nGSHConcentrationFieldVisualizationSteppable: missing key 'GSHconc' for cell.id, cell.type",cell.id,cell.type,dict_1,"\n"

########################################################################################
###########
########### visualization for the NAPQI concentation (Load/cell area)
########### Note that NAPQI is stored as a concentration, not a load, so don't need to divide by cell colume
########### only applies to the hepatocytes (type 1)
class NAPQIConcentrationFieldVisualizationSteppable(SteppablePy):
    def __init__(self,_simulator,_frequency=10):
        SteppablePy.__init__(self,_frequency)
        self.simulator=_simulator
        self.cellFieldG=self.simulator.getPotts().getCellFieldG()
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.dim=self.cellFieldG.getDim()

    def setScalarField(self,_field):
        self.scalarField=_field

    def start(self):pass
            
    def step(self,mcs):
        for x in xrange(self.dim.x):
            for y in xrange(self.dim.y):
                for z in xrange(self.dim.z):
                    pt=CompuCell.Point3D(x,y,z)
                    cell=self.cellFieldG.get(pt)
                    #get NAPQIconc from the cell's dictionary
                    if cell.type == 1:
                        dict_1=CompuCell.getPyAttrib(cell)
                        if ("NAPQIconc" in dict_1):
                            fillScalarValue(self.scalarField,x,y,z, dict_1["NAPQIconc"])
                        else:
                            print "\nNAPQIConcentrationFieldVisualizationSteppable: missing key 'NAPQIconc' for cell.id, cell.type",cell.id,cell.type,dict_1,"\n"

########################################################################################
###########
########### visualization for the APAP conjugates (APAPconj) concentation which only exists in the heptocytes
########### Note that APAPconj is stored as a concentration, not a load, so don't need to divide by cell colume
########### only applies to the hepatocytes (type 1)
class APAPconjConcentrationFieldVisualizationSteppable(SteppablePy):
    def __init__(self,_simulator,_frequency=10):
        SteppablePy.__init__(self,_frequency)
        self.simulator=_simulator
        self.cellFieldG=self.simulator.getPotts().getCellFieldG()
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.dim=self.cellFieldG.getDim()

    def setScalarField(self,_field):
        self.scalarField=_field

    def start(self):pass
            
    def step(self,mcs):
        for x in xrange(self.dim.x):
            for y in xrange(self.dim.y):
                for z in xrange(self.dim.z):
                    pt=CompuCell.Point3D(x,y,z)
                    cell=self.cellFieldG.get(pt)
                    #get APAPconj from the cell's dictionary
                    if cell.type == 1:
                        dict_1=CompuCell.getPyAttrib(cell)
                        if ("APAPconj_Glu" in dict_1):
                            fillScalarValue(self.scalarField,x,y,z, dict_1["APAPconj_Glu"])
                        else:
                            print "\nAPAPconjConcentrationFieldVisualizationSteppable: missing key 'APAPconj' for cell.id, cell.type",cell.id,cell.type,dict_1,"\n"

########################################################################################
###########
########### visualization for the NAPQIGSH conjugate concentation which only exists in the heptocytes
########### Note that APAPconj is stored as a concentration, not a load, so don't need to divide by cell colume
########### only applies to the hepatocytes (type 1)
class NAPQIGSHConcentrationFieldVisualizationSteppable(SteppablePy):
    def __init__(self,_simulator,_frequency=10):
        SteppablePy.__init__(self,_frequency)
        self.simulator=_simulator
        self.cellFieldG=self.simulator.getPotts().getCellFieldG()
        self.inventory=self.simulator.getPotts().getCellInventory()
        self.cellList=CellList(self.inventory)
        self.dim=self.cellFieldG.getDim()

    def setScalarField(self,_field):
        self.scalarField=_field

    def start(self):pass
            
    def step(self,mcs):
        for x in xrange(self.dim.x):
            for y in xrange(self.dim.y):
                for z in xrange(self.dim.z):
                    pt=CompuCell.Point3D(x,y,z)
                    cell=self.cellFieldG.get(pt)
                    #get APAPconj from the cell's dictionary
                    if cell.type == 1:
                        dict_1=CompuCell.getPyAttrib(cell)
                        if ("NAPQIGSH" in dict_1):
                            fillScalarValue(self.scalarField,x,y,z, dict_1["NAPQIGSH"])
                        else:
                            print "\nNAPQIGSHConcentrationFieldVisualizationSteppable: missing key 'NAPQIGSH' for cell.id, cell.type",cell.id,cell.type,dict_1,"\n"
                            

from PySteppables import *
import CompuCell
import sys

from PlayerPython import *
import CompuCellSetup
from math import *


class VolumeCheckSteppable(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        
    def start(self):
        print "VolumeCheckSteppable: This function is called once before simulation"
        
    def step(self,mcs):
        print "VolumeCheckSteppable: This function is called every 1 MCS"
        for cell in self.cellList:
            if cell.type==self.HEPATOCYTE:                
                print "CELL ID=",cell.id, " CELL TYPE=",cell.type," volume=",cell.volume
            
    def finish(self):
        # this function may be called at the end of simulation - used very infrequently though
        return
    

# class SizeWatch(SteppableBasePy):
#     def __init__(self,_simulator,_frequency=1):
#         SteppableBasePy.__init__(self,_simulator,_frequency)

#     def start(self):  
#         import CompuCellSetup
#         self.pW=CompuCellSetup.viewManager.plotManager.getNewPlotWindow()
#         self.pW.setTitle("WATCH")
#         self.pW.setXAxisTitle("MCS")
#         self.pW.setXAxisTitle("# of Cells - AvgVolume")
#         self.pW.addPlot("NumOfCells",_style='Dots') #NoCurve,Lines,Sticks,Steps,Dots
#         self.pW.changePlotProperty("NumOfCells","LineWidth",5)
#         self.pW.changePlotProperty("NumOfCells","LineColor","black")
#         self.pW.addPlot("AvgVol",_style='Dots') #NoCurve,Lines,Sticks,Steps,Dots
#         self.pW.changePlotProperty("AvgVol","LineWidth",5)
#         self.pW.changePlotProperty("AvgVol","LineColor","red")
#         self.pW.addGrid()
        
#     def step(self,mcs):
#         nCells=0.0; vol=0
#         for cell in self.cellListByType(self.BLOODPORTION):
#           if (cell.xCOM<self.dim.x-10):
#             nCells+=1
#             vol+=cell.volume
#         self.pW.addDataPoint("NumOfCells",mcs,nCells)
#         self.pW.addDataPoint("AvgVol",mcs,vol/nCells)
#         self.pW.showAllPlots()

class CountDeadCellNumber(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        
    def start(self):
        global ParaName, ParaIniVal, ParaCurVal
        print "CountDeadCellNumber: This function is called once before simulation"
        import CompuCellSetup
        
    def step(self,mcs):
        global ParaDict,hepatocyteList
        if mcs==1000:      
            for cell in hepatocyteList:
              if cell.id==hepatocyteList[14].id:
#                 state=bionetAPI.getBionetworkState(cell.id,'ApapGshModel')
                state=self.getSBMLState(_modelName='ApapGshModel',_cell=cell) # returns dictionary of values
                hep_8=state['GSH']
              elif cell.id == hepatocyteList[19].id:
#                 state=bionetAPI.getBionetworkState(cell.id,'ApapGshModel')
                state=self.getSBMLState(_modelName='ApapGshModel',_cell=cell) # returns dictionary of values
                hep_20=state['GSH']
  
        
    def finish(self): pass

        

class DrugMetab(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        
    def start(self):
        global ParaDict, dirResult, jobID
        print ParaDict, dirSim
        self.MCS2Time = 1./600
        
        screenDir=CompuCellSetup.getScreenshotDirectoryName()
        jobID = screenDir.split('\\')[-1]
#         print screenDir.split('\\'),'\n',screenDir
        
        
#         self.pDrugMetabPlasma0=self.addNewPlotWindow(_title='Apap and Metabolites in Plasma',_xAxisTitle='Time (Hours)',_yAxisTitle='Concentration (ug/mL)')
        self.pDrugMetabPlasma=self.addNewPlotWindow(_title='Apap and Metabolites in Plasma',_xAxisTitle='Time (Hours)',_yAxisTitle='Concentration (ug/mL)')
        # self.pDrugMetabHep=self.addNewPlotWindow(_title='Apap and Metabolites in Hepatocytes',_xAxisTitle='Time (Hours)',_yAxisTitle='Concentration (ug/mL)')
        # self.pDrugMetabTubules=self.addNewPlotWindow(_title='Apap and Metabolites in Tubules',_xAxisTitle='Time (Hours)',_yAxisTitle='Mass (g)')
        
       # # self.pDrugMetabPlasma0.addPlot('plasmaAPAP',_style='Lines',_color='red',_size=2)
        self.pDrugMetabPlasma.addPlot('plasmaAPAP',_style='Lines',_color='red',_size=2)
        self.pDrugMetabPlasma.addPlot('plasmaAPAPS',_style='Lines',_color='green',_size=2)
        self.pDrugMetabPlasma.addPlot('plasmaAPAPG',_style='Lines',_color='blue',_size=2)
        self.pDrugMetabPlasma.addPlot('plasmaAPAPwet',_style='Dots',_color='red',_size=4)
        self.pDrugMetabPlasma.addPlot('plasmaAPAPSwet',_style='Dots',_color='green',_size=4)
        self.pDrugMetabPlasma.addPlot('plasmaAPAPGwet',_style='Dots',_color='blue',_size=4)

        # self.pDrugMetabHep.addPlot('hepAPAP',_style='Lines',_color='red',_size=2)
        # self.pDrugMetabHep.addPlot('hepAPAPS',_style='Lines',_color='yellow',_size=2)
        # self.pDrugMetabHep.addPlot('hepAPAPG',_style='Lines',_color='blue',_size=2)
        
        # self.pDrugMetabTubules.addPlot('tubulesAPAP',_style='Lines',_color='red',_size=2)
        # self.pDrugMetabTubules.addPlot('tubulesAPAPS',_style='Lines',_color='yellow',_size=2)
        # self.pDrugMetabTubules.addPlot('tubulesAPAPG',_style='Lines',_color='blue',_size=2)
        
        # self.pMetabRatio=self.addNewPlotWindow(_title='Ratio of Metabolites in Tubules',_xAxisTitle='Time (Hours)',_yAxisTitle='Ratio')
        # self.pMetabRatio.addPlot('MetabRatio',_style='Lines',_color='red',_size=2)
         
        

        
        # write to files
        # csv
        import csv
#         self.result = csv.writer(open(dirResult+"Results.csv", "a"))
#         self.names = []; self.data = []
        
#         self.names.append('job_NAME')
#         self.data.append(jobID)

#         self.names.append('XXXXXXXX')
#         self.data.append('XXXXXXXX')
        
#         for key in ParaDict.keys():
#             self.names.append(key)
#             self.data.append(ParaDict[key])
        
#         self.names.append('XXXXXXXX')
#         self.data.append('XXXXXXXX')
        
        self.wetlab = csv.reader(open(dirResult+"wetlab.csv","rb"), delimiter="\t")
        self.wetapap = {}; self.wetapapg = {}; self.wetapaps = {}; self.wetmcs = {}
        rownum = 0
        print self.wetlab
        for row in self.wetlab:
            print row
            if rownum == 0:
                self.header = row
            else:
                self.wetmcs[float(row[0])] = int(float(row[0]) * 3600 / self.MCS2Time)
                self.wetapap[float(row[0])] = float(row[1])
                self.wetapapg[float(row[0])] = float(row[2])
                self.wetapaps[float(row[0])] = float(row[3])

            rownum += 1    
        
        # print self.wetapap, '\n',self.wetapapg,'\n', self.wetapaps, '\n', self.wetmcs
#         exit(0)
        for h in self.wetapap.keys():
            self.pDrugMetabPlasma.addDataPoint("plasmaAPAPwet",h,self.wetapap[h]) # arguments are (name of the data series, x, y)
            self.pDrugMetabPlasma.addDataPoint("plasmaAPAPGwet",h,self.wetapapg[h])
            self.pDrugMetabPlasma.addDataPoint("plasmaAPAPSwet",h,self.wetapaps[h])
        
        try:  # create an output file just for this forcing data
#             self.output_gshAOC,outFullFileNamehep=CompuCellSetup.openFileInSimulationOutputDirectory("gshAOC.txt","a")  # average gsh drop
            self.output_drugBLOOD,outFullFileNamehep=CompuCellSetup.openFileInSimulationOutputDirectory("BLOOD.txt","a")  # 
            self.output_drugEX,outFullFileNamehep=CompuCellSetup.openFileInSimulationOutputDirectory("EX.txt","a")      # 
            self.output_drugINFO,outFullFileNamehep=CompuCellSetup.openFileInSimulationOutputDirectory("INFO.txt","a")      # 
            self.output_result,outFullFileNamehep=CompuCellSetup.openFileInSimulationOutputDirectory("result.txt","a")
            self.output_result2=open(dirResult+"result.txt", "a")
        
        except IOError:
            sys.exit("\n\nIOError: Problem opening the 2nd log file.\n >>> IS THE PLAYER OPTION \"SAVE IMAGE EVERY NTH MCS\" NOT CHECKED? <<<\n") # requires import sys
        except:
            sys.exit("\n\n >>> Unkown Error: Problem opening the 2nd log file. <<<\n") # requires import sys
#         self.output_gshAOC.write("mcs"+"\t"+"hep_GSH"+"\t"+"hep_APAP"+"\t"+"hep_NAPQI"+"\t"+"hep_NAPQIGSH"+"\t"+"hep_APAP_Glucuronide"+"\t"+"hep_APAP_Sulfate"+"\n")
        self.output_drugBLOOD.write("hours"+"\t"+"p_APAP"+"\t"+"p_APAP_Glucuronide"+"\t"+"p_APAP_Sulfate"+"\t"+"Unit:ug/mL"+"\n")
        self.output_drugEX.write("hours"+"\t"+"e_APAP"+"\t"+"e_APAP_Glucuronide"+"\t"+"e_APAP_Sulfate"+"\t"+"Unit:g"+"\n")
        self.output_drugINFO.write("This File Records self.Cmax, self.AUC and MetabRatio"+"\n\n")
        
        self.output_result.write("jobID"+'\t'+"rsqrSUM"+'\t'+"rsqrA"+'\t'+"rsqrG"+'\t'+"rsqrS"+'\t'\
                                +"CmaxA"+'\t'+"CmaxG"+'\t'+"CmaxS"+'\t'+"TmaxA"+'\t'\
                                +"TmaxG"+'\t'+"TmaxS"+'\t'+"AUCA"+'\t'+"AUCG"+'\t'\
                                +"AUCS"+'\t'+"metabRatio"+'\t'+"ParaName"+'\n')
        self.output_result2.write("jobID"+'\t'+"rsqrSUM"+'\t'+"rsqrA"+'\t'+"rsqrG"+'\t'+"rsqrS"+'\t'\
                                +"CmaxA"+'\t'+"CmaxG"+'\t'+"CmaxS"+'\t'+"TmaxA"+'\t'\
                                +"TmaxG"+'\t'+"TmaxS"+'\t'+"AUCA"+'\t'+"AUCG"+'\t'\
                                +"AUCS"+'\t'+"metabRatio"+'\t'+"ParaName"+'\n')
                                
        self.Cmax = {'A':0,'G':0,'S':0}; self.Tmax = {'A':0,'G':0,'S':0}
        self.AUC = {'A':0,'G':0,'S':0}
        self.rsqr = {'A':0,'G':0,'S':0,'SUM':0}; self.ndata = 0
       
               
    def step(self,mcs):
        global numHep, LitersPerMicron, totalMCS, ParaDict, jobID
        
        self.savePlots = freqAll / 10
        if not mcs % self.savePlots:
            self.MCS2Time = 1./600
            hours = mcs * self.MCS2Time / 3600
            
            hepAPAP = 0; hepAPAPS = 0; hepAPAPG = 0
            for cell in self.cellListByType(self.HEPATOCYTE):
                if cell.id == hepatocyteList[19].id:
                    hepAPAP = self.getSBMLValue(_modelName='ApapGshModel',_valueName='APAP',_cell=cell) # value name can be e.g. species name 
                    hepAPAPG = self.getSBMLValue(_modelName='ApapGshModel',_valueName='APAPconj_Glu',_cell=cell)
                    hepAPAPS = self.getSBMLValue(_modelName='ApapGshModel',_valueName='APAPconj_Sul',_cell=cell)
 
            hepAPAP *= 151 
            hepAPAPG *= 322
            hepAPAPS *= 231
            
            vPlasma = 0
            plasmaAPAP = 0; plasmaAPAPS = 0; plasmaAPAPG = 0
            vPlasma = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='VVen') 
            
            plasmaAPAP = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='CVen')
            Rb2p = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='Ratioblood2plasma')
            
            plasmaAPAPG = self.getSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='CVen')
            Rb2pG = self.getSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='Ratioblood2plasma')
            
            plasmaAPAPS = self.getSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='CVen') 
            Rb2pS = self.getSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='Ratioblood2plasma') 
            
            fup = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='Fraction_unbound_plasma')
            fupG = self.getSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='Fraction_unbound_plasma')
            fupS = self.getSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='Fraction_unbound_plasma')
            
            plasmaAPAP_conc = plasmaAPAP/vPlasma/Rb2p * 1e3        # ug/ml
            plasmaAPAPS_conc = plasmaAPAPS/vPlasma/Rb2pS * 1e3 
            plasmaAPAPG_conc = plasmaAPAPG/vPlasma/Rb2pG * 1e3 
            
            self.output_drugBLOOD.write(str(hours)+"\t"+str(plasmaAPAP_conc)+"\t"+str(plasmaAPAPG_conc)+"\t"+str(plasmaAPAPS_conc)+"\n")
                
            tubulesAPAP = self.getSBMLValue(_modelName='PBPKWambaugh',_valueName='CTubules') # value name can be e.g. species name 
            tubulesAPAPG = self.getSBMLValue(_modelName='PBPKWambaugh_cG',_valueName='CTubules')
            tubulesAPAPS = self.getSBMLValue(_modelName='PBPKWambaugh_cS',_valueName='CTubules')
            
            self.output_drugEX.write(str(hours)+"\t"+str(tubulesAPAP)+"\t"+str(tubulesAPAPG)+"\t"+str(tubulesAPAPS)+"\n")
            
##             self.pDrugMetabPlasma0.addDataPoint("plasmaAPAP",hours,plasmaAPAP_conc) # arguments are (name of the data series, x, y)
            self.pDrugMetabPlasma.addDataPoint("plasmaAPAP",hours,plasmaAPAP_conc) # arguments are (name of the data series, x, y)
            self.pDrugMetabPlasma.addDataPoint("plasmaAPAPG",hours,plasmaAPAPG_conc)
            self.pDrugMetabPlasma.addDataPoint("plasmaAPAPS",hours,plasmaAPAPS_conc)
            # self.pDrugMetabHep.addDataPoint("hepAPAP",hours,hepAPAP) # arguments are (name of the data series, x, y)
            # self.pDrugMetabHep.addDataPoint("hepAPAPG",hours,hepAPAPG)
            # self.pDrugMetabHep.addDataPoint("hepAPAPS",hours,hepAPAPS)
            # self.pDrugMetabTubules.addDataPoint("tubulesAPAP",hours,tubulesAPAP)
            # self.pDrugMetabTubules.addDataPoint("tubulesAPAPG",hours,tubulesAPAPG)
            # self.pDrugMetabTubules.addDataPoint("tubulesAPAPS",hours,tubulesAPAPS)
            
#             self.pDrugMetabPlasma0.showAllPlots() 
            self.pDrugMetabPlasma.showAllPlots() 

            # self.pDrugMetabHep.showAllPlots() 
            # self.pDrugMetabTubules.showAllPlots()
            
            molarAPAP = tubulesAPAP / 151
            molarAPAPG = tubulesAPAPG / 322
            molarAPAPS = tubulesAPAPS / 231
            
            # calculate self.AUC
            self.AUC['A'] += plasmaAPAP_conc* self.savePlots * self.MCS2Time / 3600
            self.AUC['G'] += plasmaAPAPG_conc* self.savePlots* self.MCS2Time / 3600
            self.AUC['S'] += plasmaAPAPS_conc* self.savePlots* self.MCS2Time / 3600
            
            # calculate self.Cmax
            if plasmaAPAP_conc > self.Cmax['A']: 
                self.Cmax['A'] = plasmaAPAP_conc
                self.Tmax['A'] = hours
            if plasmaAPAPS_conc > self.Cmax['S']: 
                self.Cmax['S'] = plasmaAPAPS_conc
                self.Tmax['S'] = hours    
            if plasmaAPAPG_conc > self.Cmax['G']: 
                self.Cmax['G'] = plasmaAPAPG_conc
                self.Tmax['G'] = hours    
                
            # calculate ratioMetab           
            if mcs:
                ratioMetab = 1 - molarAPAP/(molarAPAP + molarAPAPG + molarAPAPS)
                # self.pMetabRatio.addDataPoint("MetabRatio",hours,ratioMetab)
            # self.pMetabRatio.showAllPlots()
            
            
            #''# RMS is calculated here 
            
            # calculate rsqr
               
            for h in self.wetapap.keys():
                if h == hours:
                    self.rsqr["A"] += (self.wetapap[h] - plasmaAPAP_conc)**2
                    self.rsqr["G"] += (self.wetapapg[h] - plasmaAPAPG_conc)**2
                    self.rsqr["S"] += (self.wetapaps[h] - plasmaAPAPS_conc)**2
                    self.ndata += 1
                    print "\n$$$$$$$$$$$$$$$$\n"
                    print "matched a data point!\n"
                    print "mcs = ",mcs," hours = ", hours, "\n"
                    print "$$$$$$$$$$$$$$$$\n"
            
            # save to files    
            if mcs/1000 == totalMCS/1000:
                ## put other results and jobID into output file as well LATER!!!!!
                tempA = self.rsqr["A"] / self.ndata; self.rsqr["A"] = sqrt(tempA)
#                 self.names.append('rsqrA'); self.data.append(self.rsqr["A"])
                tempG = self.rsqr["G"] / self.ndata; self.rsqr["G"] = sqrt(tempG)
#                 self.names.append('rsqrG'); self.data.append(self.rsqr["G"])
                tempS = self.rsqr["S"] / self.ndata; self.rsqr["S"] = sqrt(tempS)
#                 self.names.append('rsqrS'); self.data.append(self.rsqr["S"])
                self.rsqr['SUM'] = self.rsqr["A"]+self.rsqr["G"]+self.rsqr["S"]
#                 self.names.append('CmaxA'); self.data.append(self.Cmax['A'])
#                 self.names.append('CmaxG'); self.data.append(self.Cmax['G'])
#                 self.names.append('CmaxS'); self.data.append(self.Cmax['S'])
                
#                 self.names.append('AUCA'); self.data.append(self.AUC['A'])
#                 self.names.append('AUCG'); self.data.append(self.AUC['G'])
#                 self.names.append('AUCS'); self.data.append(self.AUC['S'])
                
#                 self.names.append('TmaxA'); self.data.append(self.Tmax['A'])
#                 self.names.append('TmaxG'); self.data.append(self.Tmax['G'])
#                 self.names.append('TmaxS'); self.data.append(self.Tmax['S'])
                                
                self.output_drugINFO.write("MetabRatio is "+str(ratioMetab*100)+" %\n\n")
                self.output_drugINFO.write("self.Cmax (A, G, S) are "+str(self.Cmax['A'])+'\t'+str(self.Cmax['G'])+'\t'+str(self.Cmax['S'])+"\n\n")
                self.output_drugINFO.write("self.Tmax (A, G, S) are "+str(self.Tmax['A'])+'\t'+str(self.Tmax['G'])+'\t'+str(self.Tmax['S'])+"\n\n")
                self.output_drugINFO.write("self.AUC (A, G, S) are "+str(self.AUC['A'])+'\t'+str(self.AUC['G'])+'\t'+str(self.AUC['S'])+"\n")
                self.output_drugINFO.write("self.rsqr (A, G, S) are "+str(self.rsqr['A'])+'\t'+str(self.rsqr['G'])+'\t'+str(self.rsqr['S'])+"\n")
                
                paraName = ParaDict["parameter"]
                self.output_result.write(jobID+'\t'+str(self.rsqr['SUM'])+'\t'+str(self.rsqr['A'])+'\t'+str(self.rsqr['G'])+'\t'+str(self.rsqr['S'])+'\t'+str(self.Cmax['A'])+'\t'+str(self.Cmax['G'])+'\t'+\
                                            str(self.Cmax['S'])+'\t'+str(self.Tmax['A'])+'\t'+str(self.Tmax['G'])+'\t'+str(self.Tmax['S'])+'\t'+str(self.AUC['A'])+'\t'+\
                                            str(self.AUC['G'])+'\t'+str(self.AUC['S'])+'\t'+str(ratioMetab*100)+'\t'+paraName+'\n')
                self.output_result2.write(jobID+'\t'+str(self.rsqr['SUM'])+'\t'+str(self.rsqr['A'])+'\t'+str(self.rsqr['G'])+'\t'+str(self.rsqr['S'])+'\t'+str(self.Cmax['A'])+'\t'+str(self.Cmax['G'])+'\t'+\
                                            str(self.Cmax['S'])+'\t'+str(self.Tmax['A'])+'\t'+str(self.Tmax['G'])+'\t'+str(self.Tmax['S'])+'\t'+str(self.AUC['A'])+'\t'+\
                                            str(self.AUC['G'])+'\t'+str(self.AUC['S'])+'\t'+str(ratioMetab*100)+'\t'+paraName+'\n')
                
                self.output_drugINFO.write("\n ParaDict -> \n"+str(ParaDict))
                

#                 self.result.writerow(self.names)
#                 self.result.writerow(self.data)
                
    def finish(self):
        
        self.output_drugINFO.close()
        self.output_drugBLOOD.close()
        self.output_drugEX.close()
        
        self.output_result.close()
        self.output_result2.close()

class MetabVisualization(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        self.Load_A=CompuCellSetup.createScalarFieldPy(self.dim,"Load") 
        self.Load_Glu=CompuCellSetup.createScalarFieldPy(self.dim,"Load_Glu")  
        self.Load_Sul=CompuCellSetup.createScalarFieldPy(self.dim,"Load_Sul")  

    def start(self):
        pass        
    
    def step(self,mcs):
        global LitersPerMicron, freqAll
        if not mcs%freqAll:
#         if not mcs%100:
            print "*******"
            for cell in self.cellListByType(self.HEPATOCYTE):
                dict=CompuCell.getPyAttrib(cell)
                print "cell ID -> ",cell.id, "; Load -> ", dict["Load"]
            print "*******"    
            for x in xrange(self.dim.x):
                for y in xrange(self.dim.y):
                    for z in xrange(self.dim.z):
                        cell=self.cellField[x,y,z]
                        #get Load from the cell's dictionary
                        dict_1=CompuCell.getPyAttrib(cell)
                        if ("Load" in dict_1):
                            if cell and not ((cell.type == 2 and x >= (self.dim.x-4)) \
                                or (cell.type == 4 and x >= (self.dim.x-10))):
                                    vol = cell.targetVolume * 20 * LitersPerMicron / 1000
                                    if cell.type != self.HEPATOCYTE:
                                        vol /= 5
                                    if vol > 0:
                                        fillScalarValue(self.Load_A,x,y,z, dict_1["Load"]/vol)      # ug/mL  
                                        fillScalarValue(self.Load_Glu,x,y,z, dict_1["Load_Glu"]/vol)
                                        fillScalarValue(self.Load_Sul,x,y,z, dict_1["Load_Sul"]/vol)

                        else:
                            fillScalarValue(self.Load_Glu,x,y,z, 0)
                            fillScalarValue(self.Load_A,x,y,z, 0)
                            fillScalarValue(self.Load_Sul,x,y,z, 0)
                            print "\nConcVisualization: missing key 'Load' for cell.id, cell.type",cell.id,cell.type,dict_1,"\n"
            
    def finish(self):
        # this function may be called at the end of simulation - used very infrequently though
        return
    
