#!/bin/bash

# syntax: python scan.py [node id] [processe id] [ppn]
rm jobs_Set*
rm submit_jobsOnSet*

python scan.py > dir_info_111814.txt

chmod +x *.sh
chmod +x *.bash
