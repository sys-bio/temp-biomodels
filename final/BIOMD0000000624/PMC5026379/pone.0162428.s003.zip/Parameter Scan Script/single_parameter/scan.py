## Functionality of this file
# 1. change parameters' values, generate new steppable files and write it under dir /Simulation
# 2. copy .cc3d and main .py files to proper location
# 3. generate joblist.bash in proper format
## NOTE: MUST be used together with scan.bash

import re	# regular expression
from random import *
from math import *
import sys
import os
import shutil

wt="59:59:59"
#wt="00:00:50"

# jobType = "LN"  # log-normal
jobType = "SP"  # single-parameter
# jobType = "PP"  # pair-parameter
# jobType = "PV"  # population-variability


path0 = os.getcwd()+'/'
path0 = os.path.dirname(os.path.realpath(__file__))+"/"
path = path0.replace('/hd03/','/u/')

pathToW = "${HOME}/scan1_SP_100714/scanfiles_60h/"

xmlFiles=["Wambaugh_vLiver_PBPK_based_v4_APAPconj_Glu.xml","Wambaugh_vLiver_PBPK_based_v4_APAPconj_Sul.xml","Wambaugh_vLiver_PBPK_based_v4.xml","APAP_GSH_Liver_Metab_Sul_Glu.xml"]
pyFile=jobType+"_PBPK_SBML_MULTI.py"
cc3dFile=jobType+"_PBPK_SBML_MULTI.cc3d"
inFileName=jobType+"_PBPK_SBML_MULTISteppablesMaster.py"
outFileName=jobType+"_PBPK_SBML_MULTISteppables.py"
# print "*****\ninFileName",path+inFileName,"\noutFileName",path+outFileName

#inFile=open(path+inFileName, 'r')
#theText=inFile.read()	# the entire file


paradict = {}
# 13 cc3d parameters (actually 12 without PD_k_S2R); 8 sc parameters; 17 pbpk parameters 

'''
OLD before 100714

paradict_aREF = {'cc3d_Vmax_AT_APAP_REP':0.01,'cc3d_Km_AT_APAP_REP':0.03,'cc3d_k_AT_APAPG_REP':4.5E-4 ,'cc3d_k_AT_APAPS_REP':1.9E-3,'cc3d_k_PD_R2R_REP':0.005,'cc3d_k_PD_R2S_REP':0.005,'cc3d_k_PD_R2H_REP':0.005,'cc3d_k_PD_S2R_REP':0.005,'cc3d_k_PD_S2S_REP':0.005,'cc3d_k_PD_S2H_REP':0.005,'cc3d_k_PD_H2R_REP':0.005,'cc3d_k_PD_H2S_REP':0.005,'cc3d_k_PD_H2H_REP':0.005,'sc_Vmax_GLUC_REP':1e-3,'sc_Km_GLUC_REP':3,'sc_Vmax_SULF_REP':8e-5,'sc_Km_SULF_REP':0.1,'sc_Km_2E1_APAP_REP':1.29,'sc_Vmax_2E1_APAP_REP':1.67e-5,'sc_kNapqiGsh_REP':0.1,'sc_kGsh_REP':0.0001,'pbpk_kGutabs_REP':1,'pbpk_Fup_REP':0.75,'pbpk_FupG_REP':1,'pbpk_FupS_REP':1,'pbpk_Kr2p_REP':0.75,'pbpk_Kk2p_REP':1,'pbpk_Kr2pG_REP':1,'pbpk_Kk2pG_REP':1,'pbpk_Kr2pS_REP':1,'pbpk_Kk2pS_REP':1,'pbpk_Qgfr_REP':7.5,'pbpk_QgfrG_REP':7.5,'pbpk_QgfrS_REP':7.5,'pbpk_Rb2p_REP':1,'pbpk_Rb2pG_REP':1,'pbpk_Rb2pS_REP':1,'pbpk_dose_REP':1.4,'paraName_REP':'aREF'}

paradict_sim163 = {'cc3d_Vmax_AT_APAP_REP':0.0094793704 ,'cc3d_Km_AT_APAP_REP':0.0463508408,'cc3d_k_AT_APAPG_REP':0.0001660799,'cc3d_k_AT_APAPS_REP':0.001490508,'cc3d_k_PD_R2R_REP':0.0028980024,'cc3d_k_PD_R2S_REP':0.00095325,'cc3d_k_PD_R2H_REP':0.0025467,'cc3d_k_PD_S2R_REP':0.0006954,'cc3d_k_PD_S2S_REP':0.0037442,'cc3d_k_PD_S2H_REP':0.0018197,'cc3d_k_PD_H2R_REP':0.0003681,'cc3d_k_PD_H2S_REP':0.006744,'cc3d_k_PD_H2H_REP':0.0020436,'sc_Vmax_GLUC_REP':5.194e-3,'sc_Km_GLUC_REP':2.712,'sc_Vmax_SULF_REP':6.28e-5,'sc_Km_SULF_REP':0.07123,'sc_Km_2E1_APAP_REP':0.1341,'sc_Vmax_2E1_APAP_REP':1.56e-5,'sc_kNapqiGsh_REP':0.78371,'sc_kGsh_REP':0.00012829,'pbpk_kGutabs_REP':0.28202,'pbpk_Fup_REP':0.15889,'pbpk_FupG_REP':0.48773,'pbpk_FupS_REP':0.39206,'pbpk_Kr2p_REP':1.0062,'pbpk_Kk2p_REP':0.91625,'pbpk_Kr2pG_REP':0.04385,'pbpk_Kk2pG_REP':2.1246,'pbpk_Kr2pS_REP':0.14538,'pbpk_Kk2pS_REP':0.64495,'pbpk_Qgfr_REP':1.84236,'pbpk_QgfrG_REP':11.21381,'pbpk_QgfrS_REP':4.018,'pbpk_Rb2p_REP':1.2,'pbpk_Rb2pG_REP':0.31186,'pbpk_Rb2pS_REP':0.62019,'pbpk_dose_REP':1.4,'paraName_REP':'sim163'}

paradict_sim1022 = {'cc3d_Vmax_AT_APAP_REP':0.0053261462,'cc3d_Km_AT_APAP_REP':0.0341145701,'cc3d_k_AT_APAPG_REP':0.000742932 ,'cc3d_k_AT_APAPS_REP':0.0009455849,'cc3d_k_PD_R2R_REP':0.0033837,'cc3d_k_PD_R2S_REP':0.019484,'cc3d_k_PD_R2H_REP':0.0084614,'cc3d_k_PD_S2R_REP':0.0048424,'cc3d_k_PD_S2S_REP':0.0020688,'cc3d_k_PD_S2H_REP':0.0095132,'cc3d_k_PD_H2R_REP':0.0021937,'cc3d_k_PD_H2S_REP':0.0008643,'cc3d_k_PD_H2H_REP':0.0061664,'sc_Vmax_GLUC_REP':5.9604e-4,'sc_Km_GLUC_REP':1.9778,'sc_Vmax_SULF_REP':1.11e-4,'sc_Km_SULF_REP':0.11232,'sc_Km_2E1_APAP_REP':7.8099,'sc_Vmax_2E1_APAP_REP':1.13e-5,'sc_kNapqiGsh_REP':0.61368,'sc_kGsh_REP':0.00010663,'pbpk_kGutabs_REP':0.26238,'pbpk_Fup_REP':0.28419,'pbpk_FupG_REP':0.74957,'pbpk_FupS_REP':0.63313,'pbpk_Kr2p_REP':0.4577,'pbpk_Kk2p_REP':0.9443,'pbpk_Kr2pG_REP':0.7983,'pbpk_Kk2pG_REP':28.594,'pbpk_Kr2pS_REP':1.1101,'pbpk_Kk2pS_REP':0.45754,'pbpk_Qgfr_REP':1.8277,'pbpk_QgfrG_REP':21.92419,'pbpk_QgfrS_REP':2.29635,'pbpk_Rb2p_REP':0.75454,'pbpk_Rb2pG_REP':35.8797,'pbpk_Rb2pS_REP':0.17357,'pbpk_dose_REP':1.4,'paraName_REP':'sim1022'}

paradict_sim72 = {'cc3d_Vmax_AT_APAP_REP':0.009976285,'cc3d_Km_AT_APAP_REP':0.0630434978,'cc3d_k_AT_APAPG_REP':0.0004248725 ,'cc3d_k_AT_APAPS_REP':0.0027741962,'cc3d_k_PD_R2R_REP':0.014077,'cc3d_k_PD_R2S_REP':0.010429,'cc3d_k_PD_R2H_REP':0.020521,'cc3d_k_PD_S2R_REP':0.0063176,'cc3d_k_PD_S2S_REP':0.0049215,'cc3d_k_PD_S2H_REP':0.0009825,'cc3d_k_PD_H2R_REP':0.0083331,'cc3d_k_PD_H2S_REP':0.0022334,'cc3d_k_PD_H2H_REP':0.012069,'sc_Vmax_GLUC_REP':4.0538e-4,'sc_Km_GLUC_REP':1.0542,'sc_Vmax_SULF_REP':2.46e-5,'sc_Km_SULF_REP':0.17269,'sc_Km_2E1_APAP_REP':0.8885,'sc_Vmax_2E1_APAP_REP':8.04e-5,'sc_kNapqiGsh_REP':0.0062837,'sc_kGsh_REP':0.00029454,'pbpk_kGutabs_REP':0.323,'pbpk_Fup_REP':0.07526,'pbpk_FupG_REP':0.62204,'pbpk_FupS_REP':0.60616,'pbpk_Kr2p_REP':0.4239,'pbpk_Kk2p_REP':0.3567,'pbpk_Kr2pG_REP':0.608,'pbpk_Kk2pG_REP':1.1448,'pbpk_Kr2pS_REP':0.52948,'pbpk_Kk2pS_REP':0.29818,'pbpk_Qgfr_REP':28.7468,'pbpk_QgfrG_REP':4.8249,'pbpk_QgfrS_REP':7.71746,'pbpk_Rb2p_REP':2.76374,'pbpk_Rb2pG_REP':0.60282,'pbpk_Rb2pS_REP':1.67956,'pbpk_dose_REP':1.4,'paraName_REP':'sim72'}

paradict_sim850 = {'cc3d_Vmax_AT_APAP_REP':0.0095188941,'cc3d_Km_AT_APAP_REP':0.0355374938,'cc3d_k_AT_APAPG_REP':3.05E-05 ,'cc3d_k_AT_APAPS_REP':0.0089630001,'cc3d_k_PD_R2R_REP':0.0060455,'cc3d_k_PD_R2S_REP':0.02382,'cc3d_k_PD_R2H_REP':0.0036575,'cc3d_k_PD_S2R_REP':0.0038865,'cc3d_k_PD_S2S_REP':0.028168,'cc3d_k_PD_S2H_REP':0.0012123,'cc3d_k_PD_H2R_REP':0.0015728,'cc3d_k_PD_H2S_REP':0.0076434,'cc3d_k_PD_H2H_REP':0.0074769,'sc_Vmax_GLUC_REP':1.4451e-3,'sc_Km_GLUC_REP':10.765,'sc_Vmax_SULF_REP':7.36e-5,'sc_Km_SULF_REP':0.57876,'sc_Km_2E1_APAP_REP':0.3342,'sc_Vmax_2E1_APAP_REP':7.29e-5,'sc_kNapqiGsh_REP':0.028226,'sc_kGsh_REP':0.0000657,'pbpk_kGutabs_REP':0.50452,'pbpk_Fup_REP':0.50744,'pbpk_FupG_REP':0.96521,'pbpk_FupS_REP':0.1835,'pbpk_Kr2p_REP':0.2799,'pbpk_Kk2p_REP':2.1538,'pbpk_Kr2pG_REP':0.4818,'pbpk_Kk2pG_REP':1.0204,'pbpk_Kr2pS_REP':0.1364,'pbpk_Kk2pS_REP':1.67423,'pbpk_Qgfr_REP':0.47752,'pbpk_QgfrG_REP':4.77982,'pbpk_QgfrS_REP':11.34926,'pbpk_Rb2p_REP':0.56368,'pbpk_Rb2pG_REP':1.73113,'pbpk_Rb2pS_REP':0.10936,'pbpk_dose_REP':1.4,'paraName_REP':'sim850'}

paradict_sim657 = {'cc3d_Vmax_AT_APAP_REP':0.0273516733,'cc3d_Km_AT_APAP_REP':0.0853683035,'cc3d_k_AT_APAPG_REP':0.0058790534 ,'cc3d_k_AT_APAPS_REP':0.0018770514,'cc3d_k_PD_R2R_REP':0.0020256,'cc3d_k_PD_R2S_REP':0.0080715,'cc3d_k_PD_R2H_REP':0.0032904,'cc3d_k_PD_S2R_REP':0.0082823,'cc3d_k_PD_S2S_REP':0.00064292,'cc3d_k_PD_S2H_REP':0.0019738,'cc3d_k_PD_H2R_REP':0.0071248,'cc3d_k_PD_H2S_REP':0.003143,'cc3d_k_PD_H2H_REP':0.0015296,'sc_Vmax_GLUC_REP':1.1558e-3,'sc_Km_GLUC_REP':1.0131,'sc_Vmax_SULF_REP':7.02e-5,'sc_Km_SULF_REP':0.06358,'sc_Km_2E1_APAP_REP':0.9961,'sc_Vmax_2E1_APAP_REP':1.093e-4,'sc_kNapqiGsh_REP':0.06019,'sc_kGsh_REP':0.00037068,'pbpk_kGutabs_REP':0.23878,'pbpk_Fup_REP':0.646,'pbpk_FupG_REP':0.34651,'pbpk_FupS_REP':0.16365,'pbpk_Kr2p_REP':0.28907,'pbpk_Kk2p_REP':6.97,'pbpk_Kr2pG_REP':0.04464,'pbpk_Kk2pG_REP':0.17211,'pbpk_Kr2pS_REP':1.20124,'pbpk_Kk2pS_REP':4.89819,'pbpk_Qgfr_REP':13.91856,'pbpk_QgfrG_REP':20.4324,'pbpk_QgfrS_REP':14.00852,'pbpk_Rb2p_REP':3.70593,'pbpk_Rb2pG_REP':5.9294,'pbpk_Rb2pS_REP':1.65647,'pbpk_dose_REP':1.4,'paraName_REP':'sim657'}

paradict_sim615 ={'cc3d_Vmax_AT_APAP_REP':0.0261658557,'cc3d_Km_AT_APAP_REP':0.0301601287,'cc3d_k_AT_APAPG_REP':0.0040903557 ,'cc3d_k_AT_APAPS_REP':0.0022174918,'cc3d_k_PD_R2R_REP':0.0062304,'cc3d_k_PD_R2S_REP':0.0029824,'cc3d_k_PD_R2H_REP':0.0041431,'cc3d_k_PD_S2R_REP':0.0032295,'cc3d_k_PD_S2S_REP':0.0062047,'cc3d_k_PD_S2H_REP':0.00034603,'cc3d_k_PD_H2R_REP':0.024836,'cc3d_k_PD_H2S_REP':0.0029297,'cc3d_k_PD_H2H_REP':0.25741,'sc_Vmax_GLUC_REP':2.59e-3,'sc_Km_GLUC_REP':1.0135,'sc_Vmax_SULF_REP':3.77e-4,'sc_Km_SULF_REP':1.4114,'sc_Km_2E1_APAP_REP':1.1025,'sc_Vmax_2E1_APAP_REP':3.43e-5,'sc_kNapqiGsh_REP':0.02774,'sc_kGsh_REP':0.0000464,'pbpk_kGutabs_REP':1.1987,'pbpk_Fup_REP':0.42353,'pbpk_FupG_REP':0.16742,'pbpk_FupS_REP':0.61371,'pbpk_Kr2p_REP':0.23295,'pbpk_Kk2p_REP':3.8347,'pbpk_Kr2pG_REP':2.3967,'pbpk_Kk2pG_REP':2.7675,'pbpk_Kr2pS_REP':1.01,'pbpk_Kk2pS_REP':0.83595,'pbpk_Qgfr_REP':14.13024,'pbpk_QgfrG_REP':29.006,'pbpk_QgfrS_REP':11.83405,'pbpk_Rb2p_REP':0.4358,'pbpk_Rb2pG_REP':3.0428,'pbpk_Rb2pS_REP':0.09715,'pbpk_dose_REP':1.4,'paraName_REP':'sim615'}

'''

# NEW from 10/07/14

paradict_aREF={'cc3d_Vmax_AT_APAP_REP':1e-2,'cc3d_Km_AT_APAP_REP':1e-2,'cc3d_k_AT_APAPG_REP':4.5E-4 ,'cc3d_k_AT_APAPS_REP':1.9E-3,\
		  'cc3d_k_PD_R2R_REP':1e-3,'cc3d_k_PD_R2S_REP':1e-3,'cc3d_k_PD_R2H_REP':1e-3,'cc3d_k_PD_S2R_REP':1e-3,'cc3d_k_PD_S2S_REP':1e-2,\
		  'cc3d_k_PD_S2H_REP':1e-3,'cc3d_k_PD_H2R_REP':1e-3,'cc3d_k_PD_H2S_REP':1e-3,'cc3d_k_PD_H2H_REP':1e-3,\
          'sc_Vmax_GLUC_REP':1e-3,'sc_Km_GLUC_REP':1,'sc_Vmax_SULF_REP':1.75e-4,'sc_Km_SULF_REP':0.2,\
          'sc_Km_2E1_APAP_REP':1.29,'sc_Vmax_2E1_APAP_REP':2e-5,'sc_kNapqiGsh_REP':0.1,'sc_kGsh_REP':0.0001,\
          'pbpk_kGutabs_REP':1.5,'pbpk_Fup_REP':0.8,'pbpk_FupG_REP':1,'pbpk_FupS_REP':1,'pbpk_Kr2p_REP':1.6,'pbpk_Kk2p_REP':1,'pbpk_Kr2pG_REP':0.4,'pbpk_Kk2pG_REP':1,\
          'pbpk_Kr2pS_REP':0.2,'pbpk_Kk2pS_REP':1,'pbpk_Qgfr_REP':0.714,'pbpk_QgfrG_REP':7.86,'pbpk_QgfrS_REP':9.96,'pbpk_Rb2p_REP':1.09,'pbpk_Rb2pG_REP':0.55,'pbpk_Rb2pS_REP':0.55,\
          'pbpk_dose_REP':1.4,'pbpk_bw_REP':70,'pbpk_hemat_REP':0.45,'paraName_REP':'aREF_100714','simName_REP':''}

keylist_all=['pbpk_hemat_REP','pbpk_bw_REP','cc3d_Vmax_AT_APAP_REP','cc3d_Km_AT_APAP_REP','cc3d_k_AT_APAPG_REP','cc3d_k_AT_APAPS_REP',	
		 'cc3d_k_PD_R2R_REP','cc3d_k_PD_R2S_REP','cc3d_k_PD_R2H_REP','cc3d_k_PD_S2R_REP','cc3d_k_PD_S2S_REP',
		 'cc3d_k_PD_S2H_REP','cc3d_k_PD_H2R_REP','cc3d_k_PD_H2S_REP','cc3d_k_PD_H2H_REP',
          'sc_Vmax_GLUC_REP','sc_Km_GLUC_REP','sc_Vmax_SULF_REP','sc_Km_SULF_REP',
          'sc_Km_2E1_APAP_REP','sc_Vmax_2E1_APAP_REP','sc_kNapqiGsh_REP','sc_kGsh_REP',
          'pbpk_kGutabs_REP','pbpk_Fup_REP','pbpk_FupG_REP','pbpk_FupS_REP','pbpk_Kr2p_REP','pbpk_Kk2p_REP','pbpk_Kr2pG_REP','pbpk_Kk2pG_REP',
          'pbpk_Kr2pS_REP','pbpk_Kk2pS_REP','pbpk_Qgfr_REP','pbpk_QgfrG_REP','pbpk_QgfrS_REP','pbpk_Rb2p_REP','pbpk_Rb2pG_REP','pbpk_Rb2pS_REP',
          'pbpk_dose_REP','paraName_REP','simName_REP']

# delete keys not to be scanned from keylist
keylist=[]
for items in keylist_all:
	if items not in ['pbpk_dose_REP','paraName_REP','simName_REP']:
		keylist.append(items)

keylist=sorted(keylist)
print keylist
print 'in total, it has # of parameters:', len(keylist), '\n'

keylist1 = keylist[:12]
keylist2 = keylist[12:25]
keylist3 = keylist[25:]
print 'keylist1',keylist1,'\n'
print 'keylist2',keylist2,'\n'
print 'keylist3',keylist3,'\n'

keydict={}
keydict.update({0:keylist1,1:keylist2,2:keylist3})
#paradict.update({0:paradict_aREF,1:paradict_sim163,2:paradict_sim1022,3:paradict_sim72,4:paradict_sim850,5:paradict_sim657,6:paradict_sim615})
# generate duplicate simulations
paradict.update({0:paradict_aREF})	

## num of nodes required: 7 dicts X 3 nodes
setNum = 1
nodeNum = 3	# # node per set
ppn = 32

def replaceText(cc3dpath, outpath, pDict):	
	inFile=open(path+inFileName, 'r')
	theText=inFile.read()
	for key in keylist:
		theText=re.sub(key,str(pDict[key]),theText)

	if not os.path.exists(outpath):
   		os.makedirs(outpath)	
	outFile=open(outpath+outFileName, 'w')
	outFile.write(theText)
	shutil.copy2(path+cc3dFile, cc3dpath+cc3dFile)
	shutil.copy2(path+pyFile, outpath+pyFile)
	for xmlFile in xmlFiles:
		shutil.copy2(path+xmlFile, outpath+xmlFile)


	inFile.close()
	outFile.close()

# generate joblist file
def jobList(part2, setID, nodeID, flag):
	part1 = "time ${HOME}/3.7.2/runScript.sh -i "
	#part2 = pathToW + "node" + str(node_id) + "proc" + str(proc_id)+"/"
	part3 = jobType+"_PBPK_SBML_MULTI.cc3d -f 100000 &"
	jobFileName="jobs_Set"+str(setID)+'_Node'+str(nodeID)+".bash"
	jobFile=open(path+jobFileName, 'a')
	if 'NoChange' in part2:
		jobFile.write("#!/bin/bash"+"\n"+"ccmrun "+part1+part2+part3+"\n")
	jobFile.write(part1+part2+part3+"\n")
	if flag:
		jobFile.write("wait"+"\n")
	jobFile.close()



# generate submission file
for setID in range(setNum):
	for nodeID in range(nodeNum):
		submitFileName="submit_jobsOnSet"+str(setID)+'_Node'+str(nodeID)+".sh"
		jobFileName="jobs_Set"+str(setID)+'_Node'+str(nodeID)+".bash"
		submitFile=open(path +submitFileName, 'a')
		submitFile.write("#!/bin/bash"+"\n")
		submitFile.write("#PBS -l nodes=1:ppn="+str(ppn)+"\n")
		submitFile.write("#PBS -l walltime="+wt+"\n")
		submitFile.write("#PBS -N jobs_Set"+str(setID)+'_Node'+str(nodeID)+"\n")
		submitFile.write("#PBS -q cpu"+"\n")
		submitFile.write("#PBS -V"+"\n")
		submitFile.write("#PBS -l gres=ccm"+"\n")
		submitFile.write("module load ccm"+"\n")
		submitFile.write("ccmrun -n 1 "+pathToW+jobFileName+"\n")


for kSet in range(setNum):
	
	setName = ""
	pDict = {}
	select = paradict[kSet]
	for key in select:
		pDict[key] = select[key]
	setName = select['paraName_REP']
	print '\n\n************\n',setName,'\n************\n'
	print select

	for jNode in range(nodeNum):

		kList = keydict[jNode]
		cc3dpath = path + "Set" + str(kSet) + "_" + setName + "_Node" + str(jNode) + '_' + 'NoChange'  +"/"
		outpath = path + "Set" + str(kSet) + "_" + setName + "_Node" + str(jNode) + '_' + 'NoChange'  +"/Simulation/"
		replaceText(cc3dpath, outpath, pDict)
		jobpath = pathToW + "Set" + str(kSet) + "_" + setName + "_Node" + str(jNode) + '_' + 'NoChange'  +"/"
		jobList(jobpath, kSet, jNode,0)
		
		
		used_key = 0
		num_key = len(kList)
		for key in sorted(kList):
			used_key += 1
			procName = key
			for flag in [0.75,1.25]:
				print "\nflag is ... ", flag

				pDict = {}			## this part is very important as it avoids "varying nominal points"
				for kk in select:
					pDict[kk] = select[kk]
							


				if pDict != select: print "error!"


				oldval = pDict[key]
				if key in ['pbpk_dose_REP','paraName_REP']:
					pDict[key] = oldval
				else:

					pDict[key] = flag*oldval
					print key+'_'+str(flag),':', oldval,'-->',pDict[key]
					cc3dpath = path + "Set" + str(kSet) + "_" + setName + "_Node" + str(jNode) + '_' + procName + '_' + str(flag) +"/"
					outpath = path + "Set" + str(kSet) + "_" + setName + "_Node" + str(jNode) + '_' + procName + '_' + str(flag) +"/Simulation/"
					jobpath = pathToW + "Set" + str(kSet) + "_" + setName + "_Node" + str(jNode) + '_' + procName + '_' + str(flag) +"/"
					replaceText(cc3dpath, outpath, pDict)
					if (used_key == num_key) and flag == 1.25:
						jobList(jobpath, kSet, jNode, 1)
					else:
						jobList(jobpath, kSet, jNode, 0)
		
		for key in sorted(pDict):
			print key, pDict[key]	

		



