## Functionality of this file
# 1. change parameters' values, generate new steppable files and write it under dir /Simulation
# 2. copy .cc3d and main .py files to proper location
# 3. generate joblist.bash in proper format
## NOTE: MUST be used together with scan.bash

import re	# regular expression
from random import *
from math import *
import sys
import os
import shutil

wt="59:59:00"
#wt="00:00:50"

# jobType = "LN"  # log-normal
# jobType = "SP"  # single-parameter
# jobType = "PP"  # pair-parameter
jobType = "PV"  # population-variability


rand_list = []
rand_list_fup = []
for i in range(10000):
        n = gauss(1,0.25)
	if 0.75<n<1.25:
        	rand_list.append(n)
	if 0.75<n<1:
        	rand_list_fup.append(n)


# path="C:\Users\xfu\Documents\00BR2\SCAN\ParameterScan\Simulation\"
# path="X:/Projects/br2/scan3_br2/scan/"
path0 = os.getcwd()+'/'
path0 = os.path.dirname(os.path.realpath(__file__))+"/"
path = path0.replace('/hd03/','/u/')

#path = "/N/u/fuxiao/BigRed2/TEST/Create_scan3_Files/scan3_files/"
pathToW = "${HOME}/scan3_PV_100714/scanfiles/"

xmlFiles=["Wambaugh_vLiver_PBPK_based_v4_APAPconj_Glu.xml","Wambaugh_vLiver_PBPK_based_v4_APAPconj_Sul.xml","Wambaugh_vLiver_PBPK_based_v4.xml","APAP_GSH_Liver_Metab_Sul_Glu.xml"]
pyFile=jobType+"_PBPK_SBML_MULTI.py"
cc3dFile=jobType+"_PBPK_SBML_MULTI.cc3d"
inFileName=jobType+"_PBPK_SBML_MULTISteppablesMaster.py"
outFileName=jobType+"_PBPK_SBML_MULTISteppables.py"

inFile=open(path+inFileName, 'r')
theText=inFile.read()	# the entire file

'''
# this is REF updated 100714

ParaDict.update({'cc3d_k_PD_R2R':1e-3,'cc3d_k_PD_R2S':1e-3,'cc3d_k_PD_R2H':1e-3,\
                 'cc3d_k_PD_S2R':1e-3,'cc3d_k_PD_S2S':1e-2,'cc3d_k_PD_S2H':1e-3,\
                 'cc3d_k_PD_H2R':1e-3,'cc3d_k_PD_H2S':1e-3,'cc3d_k_PD_H2H':1e-3,\
                 'cc3d_Vmax_AT_APAP':1e-2,'cc3d_Km_AT_APAP':1e-2,'cc3d_k_AT_APAPG':4.5e-4,'cc3d_k_AT_APAPS':1.9e-3})

## PBPK Parameters
ParaDict.update({'pbpk_bw':70,'pbpk_kGutabs':1.5,'pbpk_Fup':0.8,'pbpk_FupG':1,'pbpk_FupS':1,\
                 'pbpk_Kr2p':1.6 ,'pbpk_Kk2p':1,'pbpk_Kr2pG':0.4,'pbpk_Kk2pG':1,'pbpk_Kr2pS':0.2,'pbpk_Kk2pS':1,\
                 'pbpk_Qgfr':0.714,'pbpk_QgfrG':7.86,'pbpk_QgfrS':9.96,'pbpk_Rb2p':1.09,'pbpk_Rb2pG':0.55,'pbpk_Rb2pS':0.55})

## SUBCELL Parameters
ParaDict.update({'sc_Vmax_GLUC':1e-3,'sc_Km_GLUC':1,'sc_Vmax_SULF':1.75e-4,'sc_Km_SULF':0.2,\
                 'sc_Km_2E1_APAP':1.29,'sc_Vmax_2E1_APAP':2e-5,\
                 'sc_kNapqiGsh':0.1,'sc_kGsh':0.0001})


'''

paradict={'cc3d_Vmax_AT_APAP_REP':1e-2,'cc3d_Km_AT_APAP_REP':1e-2,'cc3d_k_AT_APAPG_REP':4.5E-4 ,'cc3d_k_AT_APAPS_REP':1.9E-3,\
		  'cc3d_k_PD_R2R_REP':1e-3,'cc3d_k_PD_R2S_REP':1e-3,'cc3d_k_PD_R2H_REP':1e-3,'cc3d_k_PD_S2R_REP':1e-3,'cc3d_k_PD_S2S_REP':1e-2,\
		  'cc3d_k_PD_S2H_REP':1e-3,'cc3d_k_PD_H2R_REP':1e-3,'cc3d_k_PD_H2S_REP':1e-3,'cc3d_k_PD_H2H_REP':1e-3,\
          'sc_Vmax_GLUC_REP':1e-3,'sc_Km_GLUC_REP':1,'sc_Vmax_SULF_REP':1.75e-4,'sc_Km_SULF_REP':0.2,\
          'sc_Km_2E1_APAP_REP':1.29,'sc_Vmax_2E1_APAP_REP':2e-5,'sc_kNapqiGsh_REP':0.1,'sc_kGsh_REP':0.0001,\
          'pbpk_kGutabs_REP':1.5,'pbpk_Fup_REP':0.8,'pbpk_FupG_REP':1,'pbpk_FupS_REP':1,'pbpk_Kr2p_REP':1.6,'pbpk_Kk2p_REP':1,'pbpk_Kr2pG_REP':0.4,'pbpk_Kk2pG_REP':1,\
          'pbpk_Kr2pS_REP':0.2,'pbpk_Kk2pS_REP':1,'pbpk_Qgfr_REP':0.714,'pbpk_QgfrG_REP':7.86,'pbpk_QgfrS_REP':9.96,'pbpk_Rb2p_REP':1.09,'pbpk_Rb2pG_REP':0.55,'pbpk_Rb2pS_REP':0.55,\
          'pbpk_dose_REP':1.4,'pbpk_bw_REP':70,'pbpk_hemat_REP':0.45,'paraName_REP':'aREF_100714','simName_REP':''}

keylist=['pbpk_hemat_REP','pbpk_bw_REP','cc3d_Vmax_AT_APAP_REP','cc3d_Km_AT_APAP_REP','cc3d_k_AT_APAPG_REP','cc3d_k_AT_APAPS_REP',	
		 'cc3d_k_PD_R2R_REP','cc3d_k_PD_R2S_REP','cc3d_k_PD_R2H_REP','cc3d_k_PD_S2R_REP','cc3d_k_PD_S2S_REP',
		 'cc3d_k_PD_S2H_REP','cc3d_k_PD_H2R_REP','cc3d_k_PD_H2S_REP','cc3d_k_PD_H2H_REP',
          'sc_Vmax_GLUC_REP','sc_Km_GLUC_REP','sc_Vmax_SULF_REP','sc_Km_SULF_REP',
          'sc_Km_2E1_APAP_REP','sc_Vmax_2E1_APAP_REP','sc_kNapqiGsh_REP','sc_kGsh_REP',
          'pbpk_kGutabs_REP','pbpk_Fup_REP','pbpk_FupG_REP','pbpk_FupS_REP','pbpk_Kr2p_REP','pbpk_Kk2p_REP','pbpk_Kr2pG_REP','pbpk_Kk2pG_REP',
          'pbpk_Kr2pS_REP','pbpk_Kk2pS_REP','pbpk_Qgfr_REP','pbpk_QgfrG_REP','pbpk_QgfrS_REP','pbpk_Rb2p_REP','pbpk_Rb2pG_REP','pbpk_Rb2pS_REP',
          'pbpk_dose_REP','paraName_REP','simName_REP']
## in total 38 keys
		  
# OLD: change every parameter in each simulation; 95% percent of variations should lie within 10^-2 to 10^2 times original value

# NEW: change every parameter in each simulation; the change "dx" has the constraint: -0.5x < dx < 0.5x; and normal distribution is used

node_id = int(sys.argv[1])
proc_id = int(sys.argv[2])
ppn = int(sys.argv[3])
print "nid : ", node_id, "pid : ", proc_id
	
cc3dpath = path + "node" + str(node_id) + "proc" + str(proc_id)+"/"
outpath = path + "node" + str(node_id) + "proc" + str(proc_id) + "/Simulation/"
paradict['simName_REP'] = cc3dpath
paradict['paraName_REP'] = "ref_PopuVar_100814"

keylist.sort()

nochangeFlag = 0
if random()>0.98:
	nochangeFlag = 1
for key in keylist:
	oldval = 0
	if key in ['paraName_REP', 'simName_REP','pbpk_dose_REP'] and nochangeFlag==0:
		oldval = paradict[key]
		paradict[key] = oldval
	elif key in ['pbpk_FupG_REP','pbpk_FupS_REP']:
		num = randrange(len(rand_list_fup))
		oldval = paradict[key]
		paradict[key] = rand_list_fup[num] * oldval
	#elif key in ['pbpk_Rb2p_REP','pbpk_Rb2pG_REP','pbpk_Rb2pS_REP','pbpk_hemat_REP','pbpk_bw_REP','pbpk_Fup_REP'] and nochangeFlag==0:
	#	num = randrange(len(rand_list_small))
	#	oldval = paradict[key]
	#	paradict[key] = 10**rand_list_small[num] * oldval
	elif nochangeFlag==0:
		num = randrange(len(rand_list))
		oldval = paradict[key]
		paradict[key] = rand_list[num] * oldval

	print "paraName : ", key, "values : ", oldval, " -> ", paradict[key]
	if type(oldval) == (float or int):
		print "\t\tthe ratio of new/old -> ", paradict[key]/float(oldval)
	theText=re.sub(key,str(paradict[key]),theText)


# generate joblist file
part1 = "time ${HOME}/3.7.2/runScript.sh -i "
part2 = pathToW + "node" + str(node_id) + "proc" + str(proc_id)+"/"
part3 = jobType+"_PBPK_SBML_MULTI.cc3d -f 100000 &"
jobFileName="jobsOnNode"+str(node_id)+".bash"
jobFile=open(path+jobFileName, 'a')
if proc_id == 0:
	jobFile.write("#!/bin/bash"+"\n"+"ccmrun "+part1+part2+part3+"\n")
jobFile.write(part1+part2+part3+"\n")
if proc_id == ppn-1:
	jobFile.write("wait"+"\n")
jobFile.close()

# generate submission file
if proc_id == 0:
	submitFileName="submit_jobsOnNode"+str(node_id)+".sh"
	submitFile=open(path +submitFileName, 'a')
	submitFile.write("#!/bin/bash"+"\n")
	submitFile.write("#PBS -l nodes=1:ppn="+str(ppn)+"\n")
	submitFile.write("#PBS -l walltime="+wt+"\n")
	submitFile.write("#PBS -N jobsOnNode"+str(node_id)+"\n")
	submitFile.write("#PBS -q cpu"+"\n")
	submitFile.write("#PBS -V"+"\n")
	submitFile.write("#PBS -l gres=ccm"+"\n")
	submitFile.write("module load ccm"+"\n")
	submitFile.write("ccmrun -n 1 "+pathToW+jobFileName+"\n")


##replace with numerical value for every parameter in the code		  
#for key in keylist:
#	theText=re.sub(key,str(paradict[key]),theText)

	
# print theText
if not os.path.exists(outpath):
   	os.makedirs(outpath)	
outFile=open(outpath+outFileName, 'w')
outFile.write(theText)
shutil.copy2(path+cc3dFile, cc3dpath+cc3dFile)
shutil.copy2(path+pyFile, outpath+pyFile)
for xmlFile in xmlFiles:
	shutil.copy2(path+xmlFile, outpath+xmlFile)


inFile.close()
outFile.close()
