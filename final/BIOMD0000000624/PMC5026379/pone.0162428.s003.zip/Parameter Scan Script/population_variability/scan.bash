#!/bin/bash

# syntax: python scan.py [node id] [processe id] [ppn]
rm *jobsOnNode*

i=0
numNode=40
ppn=30

while [ $i -lt $numNode ];do
j=0
while [ $j -lt $ppn ];do
python scan.py $i $j $ppn
j=$[$j+1]
done
i=$[$i+1]
done

chmod +x *.sh
chmod +x *.bash
