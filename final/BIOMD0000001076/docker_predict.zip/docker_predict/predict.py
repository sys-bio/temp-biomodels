import numpy as np
import pandas as pd
import onnxruntime as rt

sFilep = './prediction_data.csv'
dfp = pd.read_csv(sFilep)

Xdatap = dfp.iloc[:,:-1].values

# Loading the ONNX model
sess = rt.InferenceSession("MLP_model3.onnx")
input_name = sess.get_inputs()[0].name
label_name = sess.get_outputs()[0].name

# Making predictions
pred_onx = sess.run([label_name], {input_name: Xdatap.astype(np.float32)})[0]

# Saving the predictions in a text file named 'MLP_predictions.txt'
np.savetxt('MLP_predictions.txt', pred_onx, fmt='%s')