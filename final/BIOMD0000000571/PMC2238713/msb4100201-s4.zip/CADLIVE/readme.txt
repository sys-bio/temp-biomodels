Computer-aided rational design of the phosphotransferase system for enhanced glucose uptake in Escherichia coli.

Yousuke Nishio, Yoshihiro Usuda, Kazuhiko Matsui, Hiroyuki Kurata


InstructionforCADLIVE.doc : 
 The insturuction manual for the CADLIVE dynamic simulator

glucosePTS.XML : 
 The XML file for describing a biochemical network of the glucose PTS model
 It is constructed by the CADLIVE GUI network constructor.

Mathmodel_glucosePTS.txt : 
 The Mathematical equations of the glucose PTS model 
 It is employed in the CADLIVE dynamic simulator.

Parameter_glucosePTS.txt : 
 The parameter file that is necessary for mathematical simulation of the glucose PTS model
 It is employed in the CADLIVE dynamic simulator.

UserFunction.txt : 
 The C program function that describes the mathematical equations of the glucose PTS model. 
 It is compiled by the CADLIVE dynamic simulator to simulate the model.

sanac.dtd : 
 A file for XML document type definitions.
 It is necessary for displaying glucosePTS.XML by Internet Explorer or other browsers.