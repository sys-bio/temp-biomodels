%Glucose PTS model
%In Molecular Systems Biology:
%Computer-aided rational design of the
%phosphotransferase system for enhanced glucose uptake in Escherichia coli. 
%By Yousuke Nishio, Yoshihiro Usuda, Kazuhiko Matsui, Hiroyuki Kurata 
%This matlab program makes Figure 3 in the above paper.
function GlucosePTS
clear all

global constantPlayer Kb km kmd kp kpd kx Q Kmich

%Mass Matrix definition
M=eye(63); for i=1:1:44 M(i,i)=0; end

options = odeset('Mass',M,'RelTol',1e-12,'AbsTol',1e-12,'OutputFcn','odeplot');

%Parameter setting
Tevent = 500;
Tfinal = 1000;

Y_START(    1)=5.4207e-06; %CRP.cyt	
Y_START(    2)=7.4368e-11; %CRPsiteI(crp).cyt	
Y_START(    3)=1.9047e-10; %CRPsiteII(crp).cyt	
Y_START(    4)=3.1103e-11; %CRPsite(cyaA).cyt	
Y_START(	 5)=3.6756e-09; %CRPsite(genome).cyt	
Y_START(	 6)=1.2021e-10; %CRPsite(ptsGp1).cyt	
Y_START(	 7)=1.2021e-10; %CRPsite(ptsGp2).cyt	
Y_START(	 8)=1.2021e-10; %CRPsite(ptsHp0).cyt	
Y_START(	 9)=1.2021e-10; %CRPsite(ptsHp1).cyt	
Y_START(	10)=1.2021e-10; %CRPsite(ptsIp0).cyt	
Y_START(	11)=1.2021e-10; %CRPsite(ptsIp1).cyt	
Y_START(	12)=1.2021e-10; %CRPsite(mlcp1).cyt	
Y_START(	13)=1.2021e-10; %CRPsite(mlcp2).cyt	
Y_START(	14)=5.5172e-10; %Mlc.cyt	
Y_START(	15)=2.4267e-10; %Mlcsite(mlcp1).cyt	
Y_START(	16)=2.4282e-10; %Mlcsite(mlcp2).cyt	
Y_START(	17)=2.1885e-10; %Mlcsite(ptsGp1).cyt	
Y_START(	18)=2.1885e-10; %Mlcsite(ptsGp2).cyt	
Y_START(	19)=2.1885e-10; %Mlcsite(ptsHp0).cyt	
Y_START(	20)=2.1885e-10; %Mlcsite(ptsIp0).cyt	
Y_START(	21)=1.0214e-07; %CRP:cAMP.cyt	
Y_START(	22)=1.6863e-10; %CRP:cAMP:CRPsiteI(crp).cyt	
Y_START(	23)=5.2529e-11; %CRP:cAMP:CRPsiteII(crp).cyt	
Y_START(	24)=2.1190e-10; %CRP:cAMP:CRPsite(cyaA).cyt	
Y_START(	25)=3.7544e-09; %CRP:cAMP:CRPsite(genome).cyt	
Y_START(	26)=1.2279e-10; %CRP:cAMP:CRPsite(ptsGp1).cyt	
Y_START(	27)=1.2279e-10; %CRP:cAMP:CRPsite(ptsGp2).cyt	
Y_START(	28)=1.2279e-10; %CRP:cAMP:CRPsite(ptsHp0).cyt	
Y_START(	29)=1.2279e-10; %CRP:cAMP:CRPsite(ptsHp1).cyt	
Y_START(	30)=1.2279e-10; %CRP:cAMP:CRPsite(ptsIp0).cyt	
Y_START(	31)=1.2279e-10; %CRP:cAMP:CRPsite(ptsIp1).cyt	
Y_START(	32)=1.2279e-10; %CRP:cAMP:CRPsite(mlcp1).cyt	
Y_START(	33)=1.2279e-10; %CRP:cAMP:CRPsite(mlcp2).cyt	
Y_START(	34)=2.4149e-11; %Mlc:Mlcsite(ptsGp1).cyt	
Y_START(	35)=2.4149e-11; %Mlc:Mlcsite(ptsGp2).cyt	
Y_START(	36)=2.4149e-11; %Mlc:Mlcsite(ptsIp0).cyt	
Y_START(	37)=2.4149e-11; %Mlc:Mlcsite(ptsHp0).cyt	
Y_START(	38)=3.2535e-13; %Mlc:Mlcsite(mlcp1).cyt	
Y_START(	39)=1.8086e-13; %Mlc:Mlcsite(mlcp2).cyt	
Y_START(	40)=4.2844e-05; %IICB.cyt	
Y_START(	41)=1.6546e-07; %IICB:Mlc.cyt	
Y_START(	42)=1.4934e-06; %CYA.cyt	
Y_START(	43)=7.0094e-06; %IIA-P.cyt	
Y_START(	44)=7.3371e-09; %IIA-P:CYA.cyt	
Y_START(	45)=1.3643e-08; %mRNA(cyaA).cyt	
Y_START(	46)=5.0254e-08; %mRNA(crp).cyt	
Y_START(	47)=4.5559e-07; %mRNA(ptsG).cyt	
Y_START(	48)=1.1411e-07; %mRNA(ptsH).cyt	
Y_START(	49)=1.0038e-08; %mRNA(ptsI).cyt	
Y_START(	50)=9.3861e-07; %mRNA(crr).cyt	
Y_START(	51)=1.5101e-09; %mRNA(mlc).cyt	
Y_START(	52)=1.5007e-06; %TCYA.cyt	
Y_START(	53)=5.5280e-06; %TCRP.cyt	
Y_START(	54)=7.1055e-06; %IICB-P.cyt	
Y_START(	55)=4.3009e-05; %TIICB.cyt	
Y_START(	56)=7.0167e-06; %TIIA-P.cyt	
Y_START(	57)=9.6230e-05; %IIA.cyt	
Y_START(	58)=7.5867e-07; %HPr-P.cyt	
Y_START(	59)=1.1793e-05; %HPr.cyt	
Y_START(	60)=2.4319e-07; %EI-P.cyt	
Y_START(	61)=8.6098e-07; %EI.cyt	
Y_START(	62)=1.6611e-07; %TMlc.cyt	
Y_START(	63)=4.7107e-07; %cAMP.cyt	

constantPlayer( 1)=  2.43e-10; % cyaA.cyt	
constantPlayer( 2)=  2.43e-10; % cyaA_basal.cyt	
constantPlayer( 3)=  2.43e-10; % crp.cyt	
constantPlayer( 4)=  2.43e-10; % crp_basal.cyt	
constantPlayer( 5)=  2.43e-10; % ptsGp1.cyt	
constantPlayer( 6)=  2.43e-10; % ptsGp2.cyt	
constantPlayer( 7)=  2.43e-10; % ptsHp0.cyt	
constantPlayer( 8)=  2.43e-10; % ptsHp1.cyt	
constantPlayer( 9)=  2.43e-10; % ptsIp0.cyt	
constantPlayer(10)=  2.43e-10; % ptsIp1.cyt	
constantPlayer(11)=  2.43e-10; % crr.cyt	
constantPlayer(12)=  2.43e-10; % mlcp1.cyt	
constantPlayer(13)=  2.43e-10; % mlcp2.cyt	
constantPlayer(14)=  2.43e-10; % TCRPsiteI(crp).cyt	
constantPlayer(15)=  2.43e-10; % TCRPsiteII(crp).cyt	
constantPlayer(16)=  2.43e-10; % TCRPsite(cyaA).cyt	
constantPlayer(17)=  7.43e-09; % TCRPsite(genome).cyt	
constantPlayer(18)=  2.43e-10; % TCRPsite(ptsGp1).cyt	
constantPlayer(19)=  2.43e-10; % TCRPsite(ptsGp2).cyt	
constantPlayer(20)=  2.43e-10; % TCRPsite(ptsHp0).cyt	
constantPlayer(21)=  2.43e-10; % TCRPsite(ptsHp1).cyt	
constantPlayer(22)=  2.43e-10; % TCRPsite(ptsIp0).cyt	
constantPlayer(23)=  2.43e-10; % TCRPsite(ptsIp1).cyt	
constantPlayer(24)=  2.43e-10; % TCRPsite(mlcp1).cyt	
constantPlayer(25)=  2.43e-10; % TCRPsite(mlcp2).cyt	
constantPlayer(26)=  2.43e-10; % TMlcsite(mlcp1).cyt	
constantPlayer(27)=  2.43e-10; % TMlcsite(mlcp2).cyt	
constantPlayer(28)=  2.43e-10; % TMlcsite(ptsGp1).cyt	
constantPlayer(29)=  2.43e-10; % TMlcsite(ptsGp2).cyt	
constantPlayer(30)=  2.43e-10; % TMlcsite(ptsHp0).cyt	
constantPlayer(31)=  2.43e-10; % TMlcsite(ptsIp0).cyt	
constantPlayer(32)=  2.67e-03; % Pyr.cyt	
constantPlayer(33)=  2.67e-03; % PEP.cyt	
constantPlayer(34)=  1.48e-03; % Glc6P.cyt	
constantPlayer(35)=  2.0000e-01; % Glucose.env	
constantPlayer(36)=  6.9942e-03; % ATP.env	
constantPlayer(37)=  5.00e-00; % RelativeactivityatTCRPsiteII(crp).cyt	

Kb( 1)=  4.0e+04; % binding_constant_CRP.cyt_cAMP.cyt	
Kb( 2)=  6.67e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(cyaA).cyt	
Kb( 3)=  2.22e+07; % binding_constant_CRP:cAMP.cyt_CRPsiteI(crp).cyt	
Kb( 4)=  2.7e+06; % binding_constant_CRP:cAMP.cyt_CRPsiteII(crp).cyt	
Kb( 5)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(ptsGp1).cyt	
Kb( 6)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(ptsGp2).cyt	
Kb( 7)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(ptsHp0).cyt	
Kb( 8)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(ptsHp1).cyt	
Kb( 9)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(ptsIp0).cyt	
Kb(10)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(ptsIp1).cyt	
Kb(11)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(mlcp1).cyt	
Kb(12)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(mlcp2).cyt	
Kb(13)=  1.00e+07; % binding_constant_CRP:cAMP.cyt_CRPsite(genome).cyt	
Kb(14)=  2.00e+08; % binding_constant_Mlc.cyt_Mlcsite(ptsGp1).cyt	
Kb(15)=  2.00e+08; % binding_constant_Mlc.cyt_Mlcsite(ptsGp2).cyt	
Kb(16)=  2.00e+08; % binding_constant_Mlc.cyt_Mlcsite(ptsHp0).cyt	
Kb(17)=  2.00e+08; % binding_constant_Mlc.cyt_Mlcsite(ptsIp0).cyt	
Kb(18)=  2.43e+06; % binding_constant_Mlc.cyt_Mlcsite(mlcp1).cyt	
Kb(19)=  1.35e+06; % binding_constant_Mlc.cyt_Mlcsite(mlcp2).cyt	
Kb(20)=  7.00e+06; % binding_constant_IICB.cyt_Mlc.cyt	
Kb(21)=  1.0e+08; % binding_constant_IIA-P.cyt_CYA.cyt	
kx( 1)=  1.20e+10; % reaction_rate_constant_EI-P.cyt_HPr.cyt (PTS2for)	
kx( 2)=  4.80e+08; % reaction_rate_constant_EI.cyt_HPr-P.cyt (PTS2rev)	
kx( 3)=  3.66e+09; % reaction_rate_constant_HPr-P.cyt_IIA.cyt (PTS3for)	
kx( 4)=  2.82e+09; % reaction_rate_constant_HPr.cyt_IIA-P.cyt (PTS3rev)	
kx( 5)=  6.60e+08; % reaction_rate_constant_IIA-P.cyt_IICB.cyt (PTS4for)	
kx( 6)=  2.40e+08; % reaction_rate_constant_IIA.cyt_IICB-P.cyt (PTS4for)	
kp( 1)=   1.10e+01; % translation_rate_constant_mRNA(cyaA).cyt	
kp( 2)=   1.10e+01; % translation_rate_constant_mRNA(crp).cyt	
kp( 3)=   1.10e+01; % translation_rate_constant_mRNA(ptsG).cyt	
kp( 4)=   1.10e+01; % translation_rate_constant_mRNA(ptsH).cyt	
kp( 5)=   1.10e+01; % translation_rate_constant_mRNA(ptsI).cyt	
kp( 6)=   1.10e+01; % translation_rate_constant_mRNA(crr).cyt	
kp( 7)=   1.10e+01; % translation_rate_constant_mlc.cyt	
kpd( 1)=   0.1; % decomposition_rate_constant_CYA.cyt	
kpd( 2)=   0.1; % decomposition_rate_constant_CRP.cyt	
kpd( 3)=   0.1; % decomposition_rate_constant_Mlc.cyt	
kpd( 4)=   400; % decomposition_rate_constant_cAMP.cyt	
kpd( 5)=   0.1; % decomposition_rate_constant_CRP:cAMP.cyt	
kpd( 6)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(cyaA).cyt	
kpd( 7)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsiteI(crp).cyt	
kpd( 8)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsiteII(crp).cyt	
kpd( 9)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(ptsGp1).cyt	
kpd(10)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(ptsGp2).cyt	
kpd(11)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(ptsHp0).cyt	
kpd(12)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(ptsHp1).cyt	
kpd(13)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(ptsIp0).cyt	
kpd(14)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(ptsIp1).cyt	
kpd(15)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(mlcp1).cyt	
kpd(16)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(mlcp2).cyt	
kpd(17)=   0.1; % decomposition_rate_constant_CRP:cAMP:CRPsite(genome).cyt	
kpd(18)=   0.1; % decomposition_rate_constant_Mlc:Mlcsite(ptsGp1).cyt	
kpd(19)=   0.1; % decomposition_rate_constant_Mlc:Mlcsite(ptsGp2).cyt	
kpd(20)=   0.1; % decomposition_rate_constant_Mlc:Mlcsite(ptsHp0).cyt	
kpd(21)=   0.1; % decomposition_rate_constant_Mlc:Mlcsite(ptsIp0).cyt	
kpd(22)=   0.1; % decomposition_rate_constant_Mlc:Mlcsite(mlcp1).cyt	
kpd(23)=   0.1; % decomposition_rate_constant_Mlc:Mlcsite(mlcp2).cyt	
kpd(24)=   0.1; % decomposition_rate_constant_IICB:Mlc.cyt	
kpd(25)=   0.1; % decomposition_rate_constant_EI.cyt	
kpd(26)=   0.1; % decomposition_rate_constant_HPr.cyt	
kpd(27)=   0.1; % decomposition_rate_constant_IIA.cyt	
kpd(28)=   0.1; % decomposition_rate_constant_IICB.cyt	
km( 1)=  45.26; % transcription_rate_constant_CRP:cAMP:CRPsite(cyaA).cyt_cyaA.cyt	
km( 2)=  1.281; % transcription_rate_constant_cyaA_basal.cyt	
km( 3)=  20.0; % transcription_rate_constant_CRP:cAMP:CRPsiteI(crp).cyt_CRP:cAMP:CRPsiteII(crp).cyt_crp.cyt	
km( 4)=  1.00886; % transcription_rate_constant_crp_basal.cyt	
km( 5)=  8.92e+02; % transcription_rate_constant_CRP:cAMP:CRPsite(ptsGp1).cyt_Mlc:Mlcsite(ptsGp1).cyt_ptsGp1.cyt	
km( 6)=  2.00; % transcription_rate_constant_CRP:cAMP:CRPsite(ptsGp2).cyt_Mlc:Mlcsite(ptsGp2).cyt_ptsGp2.cyt	
km( 7)=  7.18e+01; % transcription_rate_constant_CRP:cAMP:CRPsite(ptsHp0).cyt_Mlc:Mlcsite(ptsHp0).cyt_ptsHp0.cyt	
km( 8)=  1.795e+01; % transcription_rate_constant_CRP:cAMP:CRPsite(ptsHp1).cyt_ptsHp1.cyt	
km( 9)=  6.244e+00; % transcription_rate_constant_CRP:cAMP:CRPsite(ptsIp0).cyt_Mlc:Mlcsite(ptsIp0).cyt_ptsIp0.cyt	
km(10)=  0.892e+00; % transcription_rate_constant_CRP:cAMP:CRPsite(ptsIp1).cyt_ptsIp1.cyt	
km(11)=  3.345e+02; % transcription_rate_constant_crr.cyt	
km(12)=  1.875; % transcription_rate_constant_CRP:cAMP:CRPsite(mlcp1).cyt_Mlc:Mlcsite(mlcp1).cyt_mlcp1.cyt	
km(13)=  1.875; % transcription_rate_constant_CRP:cAMP:CRPsite(mlcp2).cyt_Mlc:Mlcsite(mlcp2).cyt_mlcp2.cyt	
kmd( 1)=  0.126; % decomposition_rate_constant_mRNA(cyaA).cyt	
kmd( 2)=  0.139; % decomposition_rate_constant_mRNA(crp).cyt	
kmd( 3)=  0.217; % decomposition_rate_constant_mRNA(ptsG).cyt	
kmd( 4)=  0.0889; % decomposition_rate_constant_mRNA(ptsH).cyt	
kmd( 5)=  0.0797; % decomposition_rate_constant_mRNA(ptsI).cyt	
kmd( 6)=  0.0866; % decomposition_rate_constant_mRNA(crr).cyt	
kmd( 7)=  0.3014; % decomposition_rate_constant_mRNA(mlc).cyt	
Q( 1)=  1.0e+02; % reaction_rate_constant_CYA.cyt_ATP.cyt_MM	
Q( 2)=  9.00e+03; % reaction_rate_constant_IIA-P:CYA.cyt_ATP.cyt_MM	
Q( 3)=  1.08e+05; % reaction_rate_constant_EI.cyt_PEP.cyt_MM	
Q( 4)=  4.80e+05; % reaction_rate_constant_EIP.cyt_Pyr.cyt_MM	
Q( 5)=  4.80e+03; % reaction_rate_constant_IICB-P.cyt_Glucose.cyt_MM	
Q( 6)=  3.89e+02; % reaction_rate_constant_IICB.cyt_Glc6P.cyt_MM	
Kmich( 1)=  1.0e-03; % Michaelis_constant(ATP.cyt)_CYA.cyt_ATP.cyt_MM	
Kmich( 2)=  1.0e-03; % Michaelis_constant(ATP.cyt)_IIA-P:CYA.cyt_ATP.cyt_MM	
Kmich( 3)=  3.00e-04; % Michaelis_constant(PEP.cyt)_EI.cyt_PEP.cyt_MM	
Kmich( 4)=  2.00e-03; % Michaelis_constant(Pyr.cyt)_EIP.cyt_Pyr.cyt_MM	
Kmich( 5)=  2.00e-05; % Michaelis_constant(Glucose.cyt)_IICB-P.cyt_Glucose.cyt_MM	
Kmich( 6)=  9.61; % Michaelis_constant(Glc6P.cyt)_IICB.cyt_Glc6P.cyt_MM	

%Simulation
[T,Y] = ode15s(@mathmodel,[0 Tevent],Y_START,options);
          [n, m]= size(Y); Y_middle=Y(n,:);
%Time event
constantPlayer(35)=  2.0000e-9; % Glucose.env	
%Simulation
[T2,Y2] = ode15s(@mathmodel,[Tevent Tfinal],Y_middle,options);
          [n2, m2]= size(Y2);      
T(n+1:1:n+n2-1,:) = T2(2:1:n2,:); Y(n+1:1:n+n2-1,:) = Y2(2:1:n2,:);

%Visualization
figure(1);
plot(T,Y(:,57),'r-',T,Y(:,56),'b--','LineWidth',2);
    set(gca,'fontname','arial','fontsize',14,'linewidth',2,'XLim',[0 Tfinal],'Xtick',[0 200 400 600 800 1000],'Ylim', [0, 1e-4], 'Ytick',[0 0.2e-4 0.4e-4 0.6e-4 0.8e-4 1e-4]);
    xlabel('Time (min)','fontname','arial','fontweight','bold','fontsize',14);
    ylabel('Protein concentration (M)','fontname','arial','fontweight','bold','fontsize',14);
    title('A','fontname','arial','fontweight','bold','fontsize',14);
    box on;
    axis square;
figure(2);
plot(T,Y(:,63),'k-','LineWidth',2);
    set(gca,'fontname','arial','fontsize',14,'linewidth',2,'XLim',[0 Tfinal],'Xtick',[0 200 400 600 800 1000],'Ylim', [0, 2e-5], 'Ytick',[0 0.4e-5 0.8e-5 1.2e-5 1.6e-5 2e-5]);
    xlabel('Time (min)','fontname','arial','fontweight','bold','fontsize',14);
    ylabel('cAMP concentration (M)','fontname','arial','fontweight','bold','fontsize',14);
    title('B','fontname','arial','fontweight','bold','fontsize',14);
    box on;
    axis square;
figure(3);
plot(T,Y(:,34),'k--','LineWidth',2);
    set(gca,'fontname','arial','fontsize',14,'linewidth',2,'XLim',[0 Tfinal],'Xtick',[0 200 400 600 800 1000],'Ylim', [0, 3e-10], 'Ytick',[0 0.5e-10 1e-10 1.5e-10 2e-10 2.5e-10 3e-10]);
    xlabel('Time (min)','fontname','arial','fontweight','bold','fontsize',14);
    ylabel('Mlc:ptsGp1 concentration (M)','fontname','arial','fontweight','bold','fontsize',14);
    title('C','fontname','arial','fontweight','bold','fontsize',14);
    box on;
    axis square;
figure(4);
plot(T,Y(:,47),'b-',T,Y(:,48),'r-',T,Y(:,49),'k-','LineWidth',2);
    set(gca,'fontname','arial','fontsize',14,'linewidth',2,'XLim',[0 Tfinal],'Xtick',[0 200 400 600 800 1000],'Ylim', [0, 5e-7], 'Ytick',[0 1e-7 2e-7 3e-7 4e-7 5e-7]);
    xlabel('Time (min)','fontname','arial','fontweight','bold','fontsize',14);
    ylabel('mRNA concentration (M)','fontname','arial','fontweight','bold','fontsize',14);
    title('D','fontname','arial','fontweight','bold','fontsize',14);
    box on;
    axis square;
   
function fvec = mathmodel(t,y)

    global constantPlayer Kb km kmd kp kpd kx Q Kmich
    fvec=zeros(63,1);
 
	fvec(1) = y(53) - (y(1) + y(21) + y(24) + y(22) + y(23) + y(25) + y(26) + y(27) + y(28) + y(29) + y(30) + y(31) + y(32) + y(33));
	fvec(2) = constantPlayer(16) - (y(4) + y(24));
	fvec(3) = constantPlayer(14) - (y(2) + y(22));
	fvec(4) = constantPlayer(15) - (y(3) + y(23));
	fvec(5) = constantPlayer(17) - (y(5) + y(25));
	fvec(6) = constantPlayer(18) - (y(6) + y(26));
	fvec(7) = constantPlayer(19) - (y(7) + y(27));
	fvec(8) = constantPlayer(20) - (y(8) + y(28));
	fvec(9) = constantPlayer(21) - (y(9) + y(29));
	fvec(10) = constantPlayer(22) - (y(10) + y(30));
	fvec(11) = constantPlayer(23) - (y(11) + y(31));
	fvec(12) = constantPlayer(24) - (y(12) + y(32));
	fvec(13) = constantPlayer(25) - (y(13) + y(33));
	fvec(14) = y(55) - (y(40) + y(41));
	fvec(15) = y(62) - (y(14) + y(41) + y(34) + y(35) + y(37) + y(36) + y(38) + y(39));
	fvec(16) = constantPlayer(28) - (y(17) + y(34));
	fvec(17) = constantPlayer(29) - (y(18) + y(35));
	fvec(18) = constantPlayer(30) - (y(19) + y(37));
	fvec(19) = constantPlayer(31) - (y(20) + y(36));
	fvec(20) = constantPlayer(26) - (y(15) + y(38));
	fvec(21) = constantPlayer(27) - (y(16) + y(39));
	fvec(22) = Kb(1)^2*(y(1)*y(63))^2 - y(21)^2;
	fvec(23) = Kb(2)*y(21)*y(4) - y(24);
	fvec(24) = Kb(3)*y(21)*y(2) - y(22);
	fvec(25) = Kb(4)*y(21)*y(3) - y(23);
	fvec(26) = Kb(5)*y(21)*y(6) - y(26);
	fvec(27) = Kb(6)*y(21)*y(7) - y(27);
	fvec(28) = Kb(7)*y(21)*y(8) - y(28);
	fvec(29) = Kb(8)*y(21)*y(9) - y(29);
	fvec(30) = Kb(9)*y(21)*y(10) - y(30);
	fvec(31) = Kb(10)*y(21)*y(11) - y(31);
	fvec(32) = Kb(11)*y(21)*y(12) - y(32);
	fvec(33) = Kb(12)*y(21)*y(13) - y(33);
	fvec(34) = Kb(13)*y(21)*y(5) - y(25);
	fvec(35) = Kb(14)*y(14)*y(17) - y(34);
	fvec(36) = Kb(15)*y(14)*y(18) - y(35);
	fvec(37) = Kb(16)*y(14)*y(19) - y(37);
	fvec(38) = Kb(17)*y(14)*y(20) - y(36);
	fvec(39) = Kb(18)*y(14)*y(15) - y(38);
	fvec(40) = Kb(19)*y(14)*y(16) - y(39);
	fvec(41) = Kb(20)*y(40)*y(14) - y(41);
	fvec(42) = y(52) - (y(42) + y(44));
	fvec(43) = y(56) - (y(43) + y(44));
	fvec(44) = Kb(21)*y(42)*y(43)^2 - y(44);
	fvec(45) = km(1)*(1 - y(24)/constantPlayer(16))*constantPlayer(1) + km(2)*constantPlayer(2) - kmd(1)*y(45);
	fvec(46) = km(3)*(1 + constantPlayer(37)*y(23)/constantPlayer(15) - y(22)/constantPlayer(14))*constantPlayer(3) + km(4)*constantPlayer(4) - kmd(2)*y(46);
	fvec(47) = km(5)*(y(26)/constantPlayer(18))*(1 - y(34)/constantPlayer(28))*constantPlayer(5) + km(6)*(y(27)/constantPlayer(19))*(1 - y(35)/constantPlayer(29))*constantPlayer(6) - kmd(3)*y(47);
	fvec(48) = km(7)*(y(28)/constantPlayer(20))*(1 - y(37)/constantPlayer(30))*constantPlayer(7) + km(8)*(y(29)/constantPlayer(21))*constantPlayer(8) - kmd(4)*y(48);
	fvec(49) = km(9)*(y(30)/constantPlayer(22))*(1 - y(36)/constantPlayer(31))*constantPlayer(9) + km(10)*(y(31)/constantPlayer(23))*constantPlayer(10) - kmd(5)*y(49);
	fvec(50) = km(11)*constantPlayer(11) - kmd(6)*y(50);
	fvec(51) = km(12)*(1 - y(32)/constantPlayer(24))*(1 - y(38)/constantPlayer(26))*constantPlayer(12) + km(13)*(y(33)/constantPlayer(25))*(1 - y(39)/constantPlayer(27))*constantPlayer(13) - kmd(7)*y(51);
	fvec(52) = kp(1)*y(45) - kpd(1)*y(52);
	fvec(53) = kp(2)*y(46) - kpd(2)*y(1) - kpd(5)*y(21) - kpd(6)*y(24) - kpd(7)*y(22) - kpd(8)*y(23) - kpd(9)*y(26) - kpd(10)*y(27) - kpd(11)*y(28) - kpd(12)*y(29) - kpd(13)*y(30) - kpd(14)*y(31) - kpd(15)*y(32) - kpd(16)*y(33) - kpd(17)*y(25);
	fvec(54) = kx(5)*y(40)*y(43) - kx(6)*y(57)*y(54) + Q(6)*y(40)*constantPlayer(34)/(Kmich(6) + constantPlayer(34)) - Q(5)*y(54)*constantPlayer(35)/(Kmich(5) + constantPlayer(35)) - kpd(28)*y(54);
	fvec(55) = kp(3)*y(47) - kx(5)*y(40)*y(43) + kx(6)*y(57)*y(54) - Q(6)*y(40)*constantPlayer(34)/(Kmich(6) + constantPlayer(34)) + Q(5)*y(54)*constantPlayer(35)/(Kmich(5) + constantPlayer(35)) - kpd(28)*y(55);
	fvec(56) = kx(3)*y(57)*y(58) - kx(4)*y(59)*y(43) - kx(5)*y(40)*y(43) + kx(6)*y(57)*y(54) - kpd(27)*y(56);
	fvec(57) = kp(6)*y(50) - kx(3)*y(57)*y(58) + kx(4)*y(59)*y(43) + kx(5)*y(40)*y(43) - kx(6)*y(57)*y(54) - kpd(27)*y(57);
	fvec(58) = kx(1)*y(59)*y(60) - kx(2)*y(61)*y(58) - kx(3)*y(57)*y(58) + kx(4)*y(59)*y(43) - kpd(26)*y(58);
	fvec(59) = kp(4)*y(48) - kx(1)*y(59)*y(60) + kx(2)*y(61)*y(58) + kx(3)*y(57)*y(58) - kx(4)*y(59)*y(43) - kpd(26)*y(59);
	fvec(60) = -2*Q(4)*y(60)*constantPlayer(32)^2/(Kmich(4)^2 + constantPlayer(32)^2) + 2*Q(3)*y(61)*constantPlayer(33)^2/(Kmich(3)^2 + constantPlayer(33)^2) - kx(1)*y(59)*y(60) + kx(2)*y(61)*y(58) - kpd(25)*y(60);
	fvec(61) = kp(5)*y(49) + 2*Q(4)*y(60)*constantPlayer(32)^2/(Kmich(4)^2 + constantPlayer(32)^2) - 2*Q(3)*y(61)*constantPlayer(33)^2/(Kmich(3)^2 + constantPlayer(33)^2) + kx(1)*y(59)*y(60) - kx(2)*y(61)*y(58) - kpd(25)*y(61);
	fvec(62) = kp(7)*y(51) - kpd(3)*y(14) - kpd(22)*y(38) - kpd(23)*y(39) - kpd(20)*y(37) - kpd(21)*y(36) - kpd(19)*y(35) - kpd(18)*y(34) - kpd(24)*y(41);
	fvec(63) = -kpd(4)*y(63) + Q(1)*y(42)*constantPlayer(36)/(Kmich(1) + constantPlayer(36)) + Q(2)*y(44)*constantPlayer(36)/(Kmich(2) + constantPlayer(36));

 
   
