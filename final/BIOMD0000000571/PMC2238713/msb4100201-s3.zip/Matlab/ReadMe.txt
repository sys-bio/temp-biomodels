Computer-aided rational design of the phosphotransferase system for enhanced glucose uptake in Escherichia coli.

Yousuke Nishio, Yoshihiro Usuda, Kazuhiko Matsui, Hiroyuki Kurata


InstructionforMatlab.doc : The instruction for glucose PTS simulation using MATLAB

GlucosePTS.m : Matlab script file

