function err=ActInh_oscillator_main(lparam)

% Main function for the two-node oscillator (Design I) 
% and the two-node oscillator with a positive feedback (Design II)

% Declare global variables

global data bestparam besterr model_leaveout drawplots 
global OptAmp OptFre     % optimization results for Figure S7

ExpAmp=zeros(45,12);
SimAmp=zeros(45,12);
MaxExpAmp=zeros(45,1);
MaxSimAmp=zeros(45,1);
ExpFre=zeros(45,1);
SimFre=zeros(45,1);
ExpLambda=zeros(45,1);
SimLambda=zeros(45,1);
DT=30*ones(45,1);    % default spacing for detecting peaks and troughs
DT(4:5)=20;          % smaller spacing for faster experimental oscillations
DT(6)=25; DT(10)=25; DT(13)=15; DT(14)=10;
DT(17:18)=15; DT(20)=12; DT(23)=12; DT(24)=20;
DT(31)=20; DT(33)=15; DT(36)=20; DT(42)=12;
param=exp(lparam);
N=size(data,1);

hold off; err=0; 

% Get gel data

gelexp=[2111/0.8 7247 9407 5727 2988 4317 10912 11703 6750 4916 9500 13016 15992 13211 9278 9182 16484 23576 30401 29090 26565 20361 20242 25163 30064 31690 30960 39987 37012 30244 26655 24752 30503 26768 34820 36344 35850 35958 34397 31257 28057 25312]./[5148 5712 5711 5490 5936 5952 6697 5870 6140 6315 6632 6072 6181 6560 6554 5967 6553 6316 6481 6377 6391 6840 6406 6686 6329 5477 5009 6461 6351 6000 5488 5608 6620 5401 6297 6523 6526 6834 6937 6933 6701 6948]/1.1;
wasteexp=[0 985 1843 2208 2688 5159 4897 5377 6530 7069 8465 7000 5891 10328 9273 9176 13419 15135 17024 18163 18782 19667 17215 19895 22138 19753 18047 25860 26136 24580 23645 22726 25857 20022 28347 31267 32726 34859 35414 35442 35805 36828]./[5148 5712 5711 5490 5936 5952 6697 5870 6140 6315 6632 6072 6181 6560 6554 5967 6553 6316 6481 6377 6391 6840 6406 6686 6329 5477 5009 6461 6351 6000 5488 5608 6620 5401 6297 6523 6526 6834 6937 6933 6701 6948];
NDgelexp=[1000 1294 1273 1961 2745 1851 1671 1730 2356 1902 1366 698 911 1325 1467 1217 1188 785 1052 1264 1430 1498]./[ones(1,11)*2700*1.05 ones(1,11)*1500*1.1];
geltime=[0 15 30 45 60 90 120 150 180 210 240 270 300 330 360 390 420 450 480 510 540 570 600 630 660 690 720 750 780 810 840 870 900 930 960 990 1020 1050 1080 1110 1140 1170]+1;

% Main function for plots 
 
for n=1:N
if model_leaveout(n)==0,

% Load data

TX=data{n,1}';
TAM=data{n,2}'; 
Volratio=data{n,14};
T21tot=data{n,3}/Volratio;
A1tot=data{n,4}/Volratio;
dI1tot=data{n,5}/Volratio;
T12tot=data{n,6}/Volratio;
A2tot=data{n,7}/Volratio;
R=data{n,8}/Volratio;
H=data{n,9}/Volratio;
FFTregion=data{n,10};
rA1=data{n,11}/Volratio;
rI2=data{n,12}/Volratio;
T11tot=data{n,13}/Volratio;

% setup parameters

% for switch Sw21
KM21=param(1); kpc21=param(2); KMF21=param(3); kpFc21=param(4); KMh1=param(5); khc1=param(6); kTA21=param(7); krAI1=param(8); krAAI1=param(9); kAI1=param(10); kTAI21=param(11); 
% for switch Sw12
KM12=param(12); kpc12=param(13); KMF12=param(14); kpFc12=param(15); KMh2=param(16); khc2=param(17); kTA12=param(18); kAI2=param(19); kTAI12=param(20);
% for switch Sw11
KM11=param(33); kpc11=param(34); KMF11=param(35); kpFc11=param(36); kTA11=param(21); kTAI11=param(22);
% for short RNA product
kdisso=param(23); kasso=param(24);

if n>37 & n<46, % parameters for positive feedback switch Sw11 (Design II)

KM21=param(25); kpc21=param(26); KMF21=param(27); kpFc21=param(28); KM12=param(29); kpc12=param(30); KMF12=param(31); kpFc12=param(32); KM11=param(33); kpc11=param(34); KMF11=param(35); kpFc11=param(36);

end

if n<25,  % parameters for enzyme batch one

KM21=param(37); kpc21=param(38); KMF21=param(39); kpFc21=param(40); KMh1=param(41); khc1=param(42); kTA21=param(43); krAI1=param(44); krAAI1=param(45); kAI1=param(46); kTAI21=param(47); 
KM12=param(48); kpc12=param(49); KMF12=param(50); kpFc12=param(51); KMh2=param(52); khc2=param(53); kTA12=param(54); kAI2=param(55); kTAI12=param(56);
kdisso=param(57); kasso=param(58);
    
end

L=length(TX); 
dt=60; 
x0=[T21tot A1tot dI1tot rA1 0 0 0 T12tot A2tot rI2 0 0 0 0 0 T11tot 0]'; 

% equilibrate for 30 min without enzymes'

tspan=[0:dt:1800]; y1tspan=[0:20:60];
options=odeset('AbsTol',1e-9);  % set tolerances
[t,y0]=ode23s('ActInh_oscillator_define', tspan, x0, options, KM21, kpc21, KMF21, kpFc21, KMh1, khc1, 10^5, 10^5, 10^5, 10^5, 10^5, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, 10^5, 10^5, 10^5, 10^5, 10^5, 0, 0, kdisso, kasso, KM11, kpc11, KMF11, kpFc11);

% 1 min burst (RNAP only)

[t,y1]=ode23s('ActInh_oscillator_define', y1tspan, y0(30,:), options, KM21, kpc21, KMF21, kpFc21, KMh1, khc1, kTA21, krAI1, krAAI1, kAI1, kTAI21, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, kTA11, kTAI11, R, 0, kdisso, kasso, KM11, kpc11, KMF11, kpFc11);

% actual run

tspan=[0:dt:dt*(L-1)];

[t,y]=ode23s('ActInh_oscillator_define', tspan, y1(4,:), options, KM21, kpc21, KMF21, kpFc21, KMh1, khc1, kTA21, krAI1, krAAI1, kAI1, kTAI21, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, kTA11, kTAI11, R, H, kdisso, kasso, KM11, kpc11, KMF11, kpFc11);

TXsim = y(:,1)/T21tot;
TAMsim = y(:,8)/T12tot;
sI2sim = y(:,13) + y(:,14) + y(:,15); 
T12A2sim = y(:,11)/T12tot;
T12A2sI2sim = y(:,15)/T12tot;

% error measure in time domain

TxE=sum((TXsim-TX).^2)/L;
TamE=sum((TAMsim-TAM).^2)/L;  

% calculate amplitude, frequency, and damping coefficient within FFTregion
% ignore the initial transient and final NTP-depleted state 

ExpTX=TX(find(FFTregion>1)); 
Start=find(FFTregion>1);
LTX=length(ExpTX); 
SmTX=smooth(ExpTX,7);
delSmTX=SmTX(2:end)-SmTX(1:end-1); delshiftTX=[delSmTX(2:end); delSmTX(1)];
FindMinMax=find(delSmTX>0 & delshiftTX<0 | delSmTX<0 & delshiftTX>0);
TrimMinMax=FindMinMax(find((FindMinMax(2:end)-FindMinMax(1:end-1))>DT(n)));
LFind=length(TrimMinMax);
if LFind>1,
ExpAmp(n,1:LFind-1)=[abs(ExpTX(TrimMinMax(2:end))-ExpTX(TrimMinMax(1:end-1)))];
ExpFre(n)=30/(TrimMinMax(end)-TrimMinMax(1))*(LFind-1);
if LFind>2,
pLambda=polyfit(TrimMinMax(2:LFind)'/60,log(ExpAmp(n,1:LFind-1)),1);
ExpLambda(n)=min(1,-pLambda(1));
else
    ExpLambda(n)=1;
end
else ExpFre(n)=0; ExpLambda(n)=1;
end

SimTX=TXsim(find(FFTregion>1));
delSimTX=SimTX(2:end)-SimTX(1:end-1); delshiftSimTX=[delSimTX(2:end); delSimTX(1)];
FindSimMinMax=find(delSimTX>0 & delshiftSimTX<0 | delSimTX<0 & delshiftSimTX>0);
TrimSimMinMax=FindSimMinMax(find((FindSimMinMax(2:end)-FindSimMinMax(1:end-1))>DT(n)));
SimLFind=length(TrimSimMinMax);
if SimLFind>1,
SimAmp(n,1:SimLFind-1)=[abs(SimTX(TrimSimMinMax(2:end))-SimTX(TrimSimMinMax(1:end-1)))];
SimFre(n)=30/(TrimSimMinMax(end)-TrimSimMinMax(1))*(SimLFind-1);
if SimLFind>2,
pLambdaS=polyfit(TrimSimMinMax(2:SimLFind)'/60,log(SimAmp(n,1:SimLFind-1)),1);
SimLambda(n)=min(1,-pLambdaS(1));
else
    SimLambda(n)=1;
end
else   SimFre(n)=0; SimLambda(n)=1;
end

% error measure in amplitude, frequency, and damping

AmpE=(max(ExpAmp(n,:))-max(SimAmp(n,:)))^2;
FreE=(ExpFre(n)-SimFre(n))^2;
DampE=(ExpLambda(n)-SimLambda(n))^2;

% main plots for the two-node oscillator (Figure 3)

if n==37,
  gelsim=(y(geltime(1:end),10)+y(geltime(1:end),12))*10^6;  % put in uM scale'
  GelE=sum(((gelsim(1:end)'-gelexp(1:end))./max(gelexp(1:end),gelsim(1:end)')).^2)/42;  
  err=err+GelE;

if drawplots 
figure(5) 
     plot(tspan/dt/60,TX,'.','Color',[0.7 0 0],'Markersize',7); hold on
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on 
     plot(tspan/dt/60,TXsim,'-','Color',[1 0.6 0.6],'Linewidth',1.5); hold on
     plot(tspan/dt/60,TAMsim,'-','Color',[0.6 1 0.6],'Linewidth',1.5); hold on
     plot(geltime(1:22)/60, NDgelexp,'ks','Linewidth',1.5); hold on
     plot(tspan/dt/60,TX,'.','Color',[0.7 0 0],'Markersize',7); hold on
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on 
     plot(geltime(1:22)/60, NDgelexp,'ks','Linewidth',1.5);
     legend('T21','T12','T21 sim','T12 sim','T21 gel','Location','Northoutside');
     axis([0 20 -0.1 1.1])
     xlabel('Time (hr)','Fontsize',20);
     ylabel('Normalized Fluorescence','Fontsize',20);
     set(gca,'Fontsize',20);

figure(6)
     plot(geltime/60, gelexp,'o-','Color',[0 0 0.7],'Linewidth',1); hold on
     plot(tspan/dt/60,(y(:,10)+y(:,12))*10^6,'-','Color',[0.6 0.6 1],'Linewidth',1); hold on
     plot(geltime/60, wasteexp,'o-','Color',[1 0.5 1],'Linewidth',1); hold on
     plot(geltime/60, gelexp,'o-','Color',[0 0 0.7],'Linewidth',1); hold on
     legend('[rI2]','[rI2] sim','w','Location','Northoutside');
     axis([0 1200/60 -0.5 6.5])
     xlabel('Time (hr)','Fontsize',20);
     ylabel('[RNA] (\muM)','Fontsize',20);
     set(gca,'Fontsize',20);     
     
end
end

% update and print errors

err=err+TxE+TamE+AmpE+FreE+DampE;
if drawplots,
      [n TxE TamE AmpE FreE DampE],
end

% plots for the two-node oscillator with enzyme batch one (Figure S6)

if n<13 & drawplots,
figure(1)
     subplot(3,4,n)
     plot(tspan/dt/60,TXsim,'-','Color',[1 0.6 0.6],'Linewidth',1.5); hold on
     plot(tspan/dt/60,TAMsim,'-','Color',[0.6 1 0.6],'Linewidth',1.5); hold on
     quiver(3,0.1,max(SimAmp(n,:))*4,0,'Color','b','Linewidth',1.5); quiver(7.5,0.1,SimFre(n)*2.5,0,'Color','b','Linewidth',1.5); quiver(12,0.1,SimLambda(n)*2.5,0,'Color','b','Linewidth',1.5); hold on
     text(1.8,0.15,'A'); hold on
     plot(tspan/dt/60,TX,'.','Color',[0.7 0 0],'Markersize',7); hold on
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on 
     quiver(3,0.2,max(ExpAmp(n,:))*4,0,'Color','k','Linewidth',1.5); quiver(7.5,0.2,ExpFre(n)*2.5,0,'Color','k','Linewidth',1.5); quiver(12,0.2,ExpLambda(n)*2.5,0,'Color','k','Linewidth',1.5); hold on
     text (6.5,0.15,'F'); hold on
     text (10.8,0.15,'D'); hold on
  %   plot((TrimMinMax+Start(1))/60,ExpTX(TrimMinMax),'ks'); hold on
  %   plot((TrimSimMinMax+Start(1))/60,SimTX(TrimSimMinMax),'bs'); hold on
     axis([0 15 -0.1 1.1])
     title(int2str(n),'Fontsize',15);
     drawnow
end 

if n>12 & n<25 & drawplots,
figure(2)
     subplot(3,4,n-12)
     plot(tspan/dt/60,TXsim,'-','Color',[1 0.6 0.6],'Linewidth',1.5); hold on
     plot(tspan/dt/60,TAMsim,'-','Color',[0.6 1 0.6],'Linewidth',1.5); hold on
     quiver(3,0.1,max(SimAmp(n,:))*4,0,'Color','b','Linewidth',1.5); quiver(7.5,0.1,SimFre(n)*2.5,0,'Color','b','Linewidth',1.5); quiver(12,0.1,SimLambda(n)*2.5,0,'Color','b','Linewidth',1.5); hold on
     text(1.8,0.15,'A'); hold on
     plot(tspan/dt/60,TX,'.','Color',[0.7 0 0],'Markersize',7); hold on
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on 
     quiver(3,0.2,max(ExpAmp(n,:))*4,0,'Color','k','Linewidth',1.5); quiver(7.5,0.2,ExpFre(n)*2.5,0,'Color','k','Linewidth',1.5); quiver(12,0.2,ExpLambda(n)*2.5,0,'Color','k','Linewidth',1.5); hold on
     text (6.5,0.15,'F'); hold on
     text (10.8,0.15,'D'); hold on
  %   plot((TrimMinMax+Start(1))/60,ExpTX(TrimMinMax),'ks'); hold on
  %   plot((TrimSimMinMax+Start(1))/60,SimTX(TrimSimMinMax),'bs'); hold on
     axis([0 15 -0.1 1.1])
     title(int2str(n),'Fontsize',15);
     drawnow
end 

% plots for the two-node oscillator with enzyme batch two (Figure S6)

if n>24 & n<38 & drawplots,
     if n==37, fignum=4;  mark=36;  
          else fignum=3;  mark=24;
     end    
figure(fignum)
     subplot(3,4,n-mark)
     plot(tspan/dt/60,TXsim,'-','Color',[1 0.6 0.6],'Linewidth',1.5); hold on
     plot(tspan/dt/60,TAMsim,'-','Color',[0.6 1 0.6],'Linewidth',1.5); hold on
     plot(tspan/dt/60,TX,'.','Color',[0.7 0 0],'Markersize',7); hold on
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on 
     quiver(4,0.1,max(SimAmp(n,:))*4,0,'Color','b','Linewidth',1.5); quiver(10,0.1,SimFre(n)*5,0,'Color','b','Linewidth',1.5); quiver(16,0.1,SimLambda(n)*5,0,'Color','b','Linewidth',1.5); hold on
     text(2.4,0.15,'A'); hold on
  %   plot((TrimMinMax+Start(1))/60,ExpTX(TrimMinMax),'ks'); hold on
     quiver(4,0.2,max(ExpAmp(n,:))*4,0,'Color','k','Linewidth',1.5); quiver(10,0.2,ExpFre(n)*5,0,'Color','k','Linewidth',1.5); quiver(16,0.2,ExpLambda(n)*5,0,'Color','k','Linewidth',1.5); hold on
     text (8.6,0.15,'F'); hold on
     text (14.3,0.15,'D'); hold on
  %   plot(tspan/dt/60,T12A2sI2sim,'k-','Linewidth',1.5); hold on
  %   plot(tspan/dt/60,T12A2sim,'b-','Linewidth',1.5); hold on
  %   plot(tspan/dt/60,sI2sim,'k-','Linewidth',1.5); hold on
  %   plot((TrimSimMinMax+Start(1))/60,SimTX(TrimSimMinMax),'bs'); hold on
     axis([0 20 -0.1 1.1])
     title(int2str(n),'Fontsize',15);
     drawnow
end 

% Phaseplane plots for the two-node oscillator reactions 33~36
% (Figure S8)

if n>32 & n<37 & drawplots,
    G=[1 0 0; 0 1 0; 0 0 1; 0 1 1; 0 0 0];
    Dia=[0.974 0.6; 0.9625 0.6; 0.9645 0.6; 0.932 0.718];
    alpha = 1/(24.5*10^(-6)); % scaling factor for waste product crowding near T12A2 and decrease quenching efficiency
    smooTAM=smooth(TAM(1:1000),25); smooTAM_cor=smooth((TAM(1:1000)-alpha.*sI2sim(1:1000))./(1-alpha.*sI2sim(1:1000)),25); smooTX=smooth(TX(1:1000),20); 
    smooTAMsim=smooth(TAMsim(1:1000),10); smooTXsim=smooth(TXsim(1:1000),10); 
figure(13)
    plot(smooTAM(1:900),smooTX(1:900),'-','Color',G(n-32,:),'Linewidth',2.5); hold on
    plot(TAM(1),TX(1),'d','Color',G(n-32,:),'Linewidth',4); hold on
    xlabel('TAMRA Fluorescence','Fontsize',20);
    ylabel('Texas Red Fluorescence','Fontsize',20);
    set(gca,'Fontsize',20);
    
figure(14)
    plot(smooTAM(1:600),smooTX(1:600),'-','Color',G(n-32,:),'Linewidth',2.5); hold on
    plot(0.9625,0.6,'gd',0.9645,0.6,'bd',0.974,0.6,'rd',0.932,0.718,'cd','Linewidth',4); hold on
    axis([0.9 1 0.6 1])
    xlabel('TAMRA Fluorescence','Fontsize',20);
    ylabel('Texas Red Fluorescence','Fontsize',20);
    set(gca,'Fontsize',20);
    
figure(24)
    plot(smooTAM_cor(1:500),smooTX(1:500),'-','Color',G(n-32,:),'Linewidth',2.5); hold on
    plot(0.9625,0.6,'gd',0.9645,0.6,'bd',0.974,0.6,'rd',0.932,0.718,'cd','Linewidth',4); hold on
    axis([0.9 1 0.6 1])
    xlabel('TAMRA Fluorescence','Fontsize',20);
    ylabel('Texas Red Fluorescence','Fontsize',20);
    set(gca,'Fontsize',20);
     
figure(25+n-32)
         plot(smooTAM(1:600),smooTX(1:600),'-','Color',G(n-32,:),'Linewidth',2.5); hold on
         plot(smooTAM_cor(1:600),smooTX(1:600),'k-','Linewidth',2.5); hold on
         plot(Dia(n-32,1),Dia(n-32,2),'d','Color',G(n-32,:),'Linewidth',4);
         axis([0.9 1 0.6 1])
         xlabel('TAMRA Fluorescence, [T12]/[T12^{tot}]','Fontsize',20);
         ylabel('Texas Red Fluorescence','Fontsize',20);
         set(gca,'Fontsize',20);

end

% plots for two-node oscillator+positive feedback switch Sw11 (Figure 4 and S9)

if n>37 & drawplots,

figure(8)
     subplot(3,4,n-37)
     plot(tspan/dt/60,TXsim,'-','Color',[1 0.6 0.6],'Linewidth',1.5); hold on
     plot(tspan/dt/60,TAMsim,'-','Color',[0.6 1 0.6],'Linewidth',1.5); hold on
     plot(tspan/dt/60,TX,'.','Color',[0.7 0 0],'Markersize',7); hold on
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on 
  %  plot((TrimMinMax+Start(1))/60,ExpTX(TrimMinMax),'ks'); hold on
  %  plot((TrimSimMinMax+Start(1))/60,SimTX(TrimSimMinMax),'bs'); hold on
     axis([0 15 -0.1 1.1])
     title(int2str(n-37),'Fontsize',15);

end 

end

end

fprintf('.')

% update error and parameters if total error is reduced

if err<besterr
     bestparam=lparam;
     besterr=err,
end

% Amplitude vs. frequency plots and fits (Figure S7)
       
if drawplots,

x=0:0.02:0.8; xl=0:0.02:1.3; xd=-0.1:0.1:1;
MaxExpAmp=max(ExpAmp,[],2);
MaxSimAmp=max(SimAmp,[],2);
p1=polyfit(MaxExpAmp([1:21 23:37]),MaxSimAmp([1:21 23:37]),1),
[r,p]=corrcoef(MaxExpAmp([1:21 23:37]),MaxSimAmp([1:21 23:37])),  

figure(17)
     plot(MaxExpAmp(1:37), MaxSimAmp(1:37),'bd',MaxExpAmp(22),MaxSimAmp(22),'rd','Linewidth',2); hold on
     plot(x,p1(1)*x+p1(2),'k-',x,x,'k--','Linewidth',1)
     axis([0 0.8 0 0.8]);
     xlabel('Experimental Amplitude','Fontsize',20)
     ylabel('Simulation Amplitude','Fontsize',20)
     set(gca,'Fontsize',20)
     
p2=polyfit(ExpFre([1:21 23:37]),SimFre([1:21 23:37]),1),
[r,p]=corrcoef(ExpFre([1:21 23:37]),SimFre([1:21 23:37])),

figure(18)
     plot(ExpFre(1:37), SimFre(1:37),'bd',ExpFre([22]),SimFre([22]),'rd','Linewidth',2); hold on
     plot(xl,p2(1)*xl+p2(2),'k-',xl,xl,'k--','Linewidth',1)
     axis([0 1.2 0 1.2]);
     xlabel('Experimental Frequency (/hr)','Fontsize',20)
     ylabel('Simulation Frequency (/hr)','Fontsize',20)
     set(gca,'Fontsize',20)

p5=polyfit(ExpLambda([1:37]),SimLambda([1:37]),1),
[r,p]=corrcoef(ExpLambda([1:37]),SimLambda([1:37])),     
     
figure(19)
     plot(ExpLambda(1:37), SimLambda(1:37),'bd','Linewidth',2); hold on
     plot(xd,p5(1)*xd+p5(2),'k-',xd,xd,'k--','Linewidth',1)      
     axis([-0.1 1.1 -0.1 1.1]);
     xlabel('Experimental Damping','Fontsize',20)
     ylabel('Simulation Damping','Fontsize',20)
     set(gca,'Fontsize',20)          
     
figure(20)
     plot(MaxExpAmp(1:37), ExpFre(1:37),'bd',MaxExpAmp(22), ExpFre(22),'rd','Linewidth',2); hold on    
     axis([0 0.8 0 1.2]);
     xlabel('Experimental Amplitude','Fontsize',20)
     ylabel('Experimental Frequency (/hr)','Fontsize',20)
     set(gca,'Fontsize',20)

figure(21)
     plot(MaxSimAmp(1:37), SimFre(1:37),'bd',MaxSimAmp(22),SimFre(22),'rd','Linewidth',2); hold on
     plot(OptAmp(1:37), OptFre(1:37),'gd','Linewidth',2); hold on
     plot(xl,-1.12*xl+1.36,'k-','Linewidth',1)   
     axis([0 1 0 1]);
     xlabel('Simulation Amplitude','Fontsize',20)
     ylabel('Simulation Frequency (/hr)','Fontsize',20)
     set(gca,'Fontsize',20)
     
end

