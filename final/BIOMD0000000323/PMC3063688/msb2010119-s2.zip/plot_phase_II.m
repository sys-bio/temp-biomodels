
% Design II

figure(4); hold off
step=0.005; a=step:step:3; d=step:step:3;  clear G;
vals=union(GII(:),[]); for i=1:length(a), for j=1:length(d), G(i,j)=find(vals==GII(i,j)); end, end
imagesc(d,a,G); axis xy;  axis square; ylabel('\alpha'); xlabel('\delta')
colormap([1 1 1; .8 .8 .8; .6 .6 .6; .4 .4 .4; 0.2 0.2 0.2; 0 0 0 ]); 
%%G=(G~=[G(1,:); G(1:end-1,:)]) | (G~=[G(:,1) G(:,1:end-1)]);
%%imagesc(d,a,G); axis xy;  axis square; colormap([1 1 1; 0 0 0]); 
%%%contour(d,a,G,1,'k'); axis xy; axis square; 
set(gca,'FontSize',20); 
ylabel('\alpha','FontSize',20); xlabel('\delta','FontSize',20)
title('\beta=2, n=m=5, \gamma=1', 'FontSize',20)
h=text(.2,2,'oscillating'); set(h,'FontSize',15);
h=text(.2,.2,'monostable low'); set(h,'FontSize',15);
h=text(1.5,2,'monostable high'); set(h,'FontSize',15);
h=text(2,.2,'bistable'); set(h,'FontSize',15);

%h=text(1.05,0.8,'oscillating'); set(h,'FontSize',15);   % for the blow-up image in SI 1.2
%h=text(1.05,.2,'monostable low'); set(h,'FontSize',15);
%h=text(1.5,0.8,'monostable high'); set(h,'FontSize',15);
%h=text(1.7,.2,'bistable'); set(h,'FontSize',15);
hold on
T21=3; A1=4; dI1=5; T12=6; A2=7; RNAP=8; RNaseH=9; T11=13;

a=1.7; b=1.7; c=1; d=0; n=5; m=5; i=37; %% default parameters correspond to trajectory 13 for batch 1
for j=38:45 % reactions 1:8 in manuscript
 aa = a * data{j,RNAP} / data{i,RNAP} * data{i,RNaseH} / data{j,RNaseH} * data{j,T12} / data{i,T12} * ...
      (data{i,dI1} - data{i,A1} + .5 * data{i,T21}) / (data{j,dI1} - data{j,A1} + .5 * data{j,T21});
 bb = b * data{j,RNAP} / data{i,RNAP} * data{i,RNaseH} / data{j,RNaseH} * data{j,T21} / data{i,T21} * ...
      (data{i,A2} - .5 * data{i,T12}) / (data{j,A2} - .5 * data{j,T12});
 dd = aa * data{j,T11} / data{j,T12};
 cc = c * data{i,RNaseH} / data{j,RNaseH};
 nn = n * (data{j,A2}-.5*data{j,T12})/data{j,T12} / (data{i,A2}-.5*data{i,T12})*data{i,T12};
 mm = m * (data{j,dI1}-data{j,A1}+.5*data{j,T21})/data{j,T21} / ...
          (data{i,dI1}-data{i,A1}+.5*data{i,T21})*data{i,T21} ;
 % if Damp(j)<.15, tick='ko'; ms=5+100*(.15-Damp(j))/3; else tick='kx'; ms=5+5*Damp(j); end
 % if Damp(j)<.15, tick='ko'; ms=10; else tick='kx'; ms=10; end
 if Damp(j)<.15, tick='ko'; elseif Damp(j)<.5, tick='k.'; else tick='kx'; end; ms=10;
 disp([j-37 aa bb cc dd nn mm Damp(j)])
 figure(4); plot(dd+.01,aa,tick, 'MarkerSize', ms, 'LineWidth', 1.5); 
 if 0
     oscIIsnm_plot(aa,bb,cc,dd,nn,mm); drawnow;  % pause
 end
end

hold off

%% annotations for figure
figure(4)
h=text(0,1,'(a)'); set(h,'FontSize',15)
h=text(.8,1,'(b)'); set(h,'FontSize',15)
h=text(1.75,.95,'(c)'); set(h,'FontSize',15)
h=text(.8,.5,'(d)'); set(h,'FontSize',15)
h=text(1.4,.55,'(e)'); set(h,'FontSize',15)
h=text(1.75,.25,'(f)'); set(h,'FontSize',15)
h=text(0,1.25,'#5'); set(h,'FontSize',15)
h=text(.65,1.25,'#6'); set(h,'FontSize',15)
h=text(1.75,1.25,'#8'); set(h,'FontSize',15)
%axis([1 2 0 1])   % for the blow-up image in SI 1.2
%axis([1.1 1.7 0.3 0.6])  