function Y=oscIIIs_ss(a,b,n) 
% Design III oscillator, simple model, essential parameters -- steady state
%
% a = kp [T_{i,i-1}^tot] / kd
% b = Kd / KI
% n = n
%
% x1 = [rI1] / KI
% x2 = [rI2] / KI
% x3 = [rI3] / KI
% s = t * KI / kd
% 
% dx_i/ds = a / (1 + x_{i-1}^n) - (1 - 1/(1+x_i/b))

% a/(1+x^n) = 1 - 1/(1+x/b)  %% assume ss has x=x1=x2=x3
 
 x=0:.001:4;  %% find places where the sign changed
 dy=a./(1+x.^n)-(1-1./(1+x/b));
 sy=sign(dy); zi=find(sy==0);
 if ~isempty(zi)
  if length(zi)>1
    zi; keyboard
  end
  sy(zi)=sign(rand(1,length(zi))-.5);
 end
 xi=find(sy(1:end-1)==-sy(2:end));
 xss=(x(xi)+x(xi+1))/2; 

if length(xss)==0  % could be "off screen"
 xss=fzero(@(x) a/(1+abs(x)^n)-(1-1/(1+abs(x)/b)), 1.0);  % take abs for root-finder avoiding complex #s
 xss=abs(xss);
end

if length(xss)~=1 || isnan(xss) % trouble!
  xss; keyboard
end

Y=[xss; xss; xss];
