function err=Repressilator_main(lparam)

% Main function for the three-node ring oscillator (Design III) 
% 
% Declare global variables

global data bestparam besterr model_leaveout drawplots 

ExpAmp=zeros(27,10);
SimAmp=zeros(27,12);
MaxExpAmp=zeros(27,1);
MaxSimAmp=zeros(27,1);
ExpFre=zeros(27,1);
SimFre=zeros(27,1);
ExpLambda=zeros(27,1);
SimLambda=zeros(27,1);
DT=30*ones(27,1);     % default spacing for detecting peaks and troughs
DT(1:6,1)=15;         % smaller spacing for faster experimental oscillations

param=exp(lparam);

% setup parameters

% for switch Sw31
KM31=param(1); kpc31=param(2); KMF31=param(3); kpFc31=param(4); KMh1=param(5); khc1=param(6); kTA31=param(7); kAI1=param(8); kTAI31=param(9);
% for switch Sw12
KM12=param(10); kpc12=param(11); KMF12=param(12); kpFc12=param(13); KMh2=param(14); khc2=param(15); kTA12=param(16); kAI2=param(17); kTAI12=param(18); 
% for switch Sw23
KM23=param(19); kpc23=param(20); KMF23=param(21); kpFc23=param(22); KMh3=param(23); khc3=param(24); kTA23=param(25); kAI3=param(26); kTAI23=param(27); 
% for short RNA products
kasso1=param(28); kdisso1=param(29); kasso2=param(30); kdisso2=param(31); kasso3=param(32); kdisso3=param(33);

dt=60; 

N=size(data,1);

hold off; err=0; 

% gel data quantified by Gaussian fit (automatic)

geltimelong=[15 30 45 60 75 90 120 150 180 210 240 270 300 330 360 390 420 450 480 510 540 570 600 630];
I1gelGaussA=[106 125 265 260 135 187 114 42  195 335  622  624 608 606 478 336 324 349  562  569 674 757 716 742]./[ones(1,8) * 961 ones(1,8) * 969 ones(1,8) * 955];
I3gelGaussA=[435 560 456 187 84  53  230 322 815 1159 1034 415 273 378 502 556 783 1084 1576 931 534 409 287 428]./[ones(1,8) * 840 ones(1,8) * 880 ones(1,8) * 840];
I2gelGaussA=[133 78  18  27  107 423 874 587 268 354  234  100 286 833 988 760 579 406  342  331 263 308 491 670]./[ones(1,8) * 735 ones(1,8) * 803 ones(1,8) * 703];

% due to the spiky and irregular oscillations observed experimentally, the
% peaks and troughs for experimental oscillations are calculated once and
% defined here

FindMinMax(1,1:3)=[40 150 360];
FindMinMax(2,1:3)=[60 180 320];
FindMinMax(3,1:3)=[35 180 390];
FindMinMax(4,1:3)=[60 180 390];
FindMinMax(5,1:3)=[30 150 240];
FindMinMax(6,1:4)=[40 140 360 600];
FindMinMax(7,1:2)=[40 150];
FindMinMax(8,1:2)=[40 120];
FindMinMax(9,1:3)=[40 180 400];
FindMinMax(10,1:3)=[50 180 460];
FindMinMax(11,1:3)=[45 180 420];
FindMinMax(12,1:3)=[40 180 480];
FindMinMax(13,1:4)=[45 150 300 450];
FindMinMax(14,1:3)=[55 240 570];
FindMinMax(15,1:3)=[55 240 450]; 
FindMinMax(16,1)=[120];
FindMinMax(17,1:5)=[78 180 440 550 690];
FindMinMax(18,1:3)=[75 300 620];
FindMinMax(19,1:5)=[70 180 420 540 660];
FindMinMax(20,1:5)=[60 120 240 300 390];
FindMinMax(21,1:5)=[60 180 360 450 550];
FindMinMax(22,1:5)=[50 150 300 390 490];
FindMinMax(23,1:7)=[10 45 120 230 330 450 540]; 
FindMinMax(24,1:6)=[10 50 120 290 360 490];
FindMinMax(25,1:8)=[10 45 120 250 400 570 720 850];
FindMinMax(26,1:6)=[10 60 120 300 480 840];
FindMinMax(27,1:8)=[15 54 100 260 360 540 660 840];

for n=1:N
if model_leaveout(n)==0,
    
TAM=data{n,1}';  % Load data'
T31tot=data{n,2};
A1tot=data{n,3};
T12tot=data{n,4};
A2tot=data{n,5};
T23tot=data{n,6};
A3tot=data{n,7};
R=data{n,8};  
H=data{n,9};
rI1=data{n,10};  
rI2=data{n,11};
rI3=data{n,12}; 
FFTregion=data{n,13};

L=length(TAM);

x0=[T31tot A1tot rI1 0 0 0 0 0 T12tot A2tot rI2 0 0 0 0 0 T23tot A3tot rI3 0 0 0 0 0]'; 

% equilibrate for 30 min without enzymes'

tspan=[0:dt:1800]; y1tspan=[0:20:60];
options=odeset('AbsTol',1e-9); % set tolerances
[t,y0]=ode23s('Repressilator_define',tspan,x0, options, KM31, kpc31, KMF31, kpFc31, KMh1, khc1, 10^5, 10^5, 10^5, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, 10^5, 10^5, 10^5, KM23, kpc23, KMF23, kpFc23, KMh3, khc3, 10^5, 10^5, 10^5, 0, 0, kasso1, kdisso1, kasso2, kdisso2, kasso3, kdisso3);

% 1 min burst (RNAP only)

[t,y1]=ode23s('Repressilator_define',y1tspan,y0(30,:), options, KM31, kpc31, KMF31, kpFc31, KMh1, khc1, kTA31, kAI1, kTAI31, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, KM23, kpc23, KMF23, kpFc23, KMh3, khc3, kTA23, kAI3, kTAI23, R, 0, kasso1, kdisso1, kasso2, kdisso2, kasso3, kdisso3);

% actual run

tspan=[0:dt:dt*(L-1)];

[t,y]=ode23s('Repressilator_define',tspan,y1(4,:), options, KM31, kpc31, KMF31, kpFc31, KMh1, khc1, kTA31, kAI1, kTAI31, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, KM23, kpc23, KMF23, kpFc23, KMh3, khc3, kTA23, kAI3, kTAI23, R, H, kasso1, kdisso1, kasso2, kdisso2, kasso3, kdisso3);

TAMsim = y(:,9)/T12tot;

% error measure in time domain

TamE=sum((TAMsim-TAM).^2)/L;  

% calculate amplitude, frequency, and damping coefficient within FFTregion
% ignore the initial transient and final NTP-depleted state 

ExpTAM=TAM(find(FFTregion>1)); 
Start=find(FFTregion>1);
LTAM=length(ExpTAM); 
SmTAM=smooth(ExpTAM,10);
TrimMinMax=FindMinMax(n,(find(FindMinMax(n,:)>0)));
LFind=length(TrimMinMax);
if LFind>1,
ExpAmp(n,1:LFind-1)=[abs(ExpTAM(TrimMinMax(2:end))-ExpTAM(TrimMinMax(1:end-1)))];
ExpFre(n)=30/(TrimMinMax(end)-TrimMinMax(1))*(LFind-1);
if LFind>2,
pLambda=polyfit(TrimMinMax(2:LFind)/60,log(ExpAmp(n,1:LFind-1)),1);
ExpLambda(n)=min(1,-pLambda(1));
else
    ExpLambda(n)=1;
end
else ExpFre(n)=0; ExpLambda(n)=1;
end

SimTAM=TAMsim(find(FFTregion>1));
delSimTAM=SimTAM(2:end)-SimTAM(1:end-1); delshiftSimTAM=[delSimTAM(2:end); delSimTAM(1)];
FindSimMinMax=find(delSimTAM>0 & delshiftSimTAM<0 | delSimTAM<0 & delshiftSimTAM>0);
TrimSimMinMax=FindSimMinMax(find(([FindSimMinMax(2:end); L]-FindSimMinMax(1:end))>DT(n)));
SimLFind=length(TrimSimMinMax);
if SimLFind>1,
SimAmp(n,1:SimLFind-1)=[abs(SimTAM(TrimSimMinMax(2:end))-SimTAM(TrimSimMinMax(1:end-1)))];
SimFre(n)=30/(TrimSimMinMax(end)-TrimSimMinMax(1))*(SimLFind-1);
if SimLFind>2,
pLambdaS=polyfit(TrimSimMinMax(2:SimLFind)'/60,log(SimAmp(n,1:SimLFind-1)),1);
SimLambda(n)=min(1,-pLambdaS(1));
else
    SimLambda(n)=1;
end
else   SimFre(n)=0; SimLambda(n)=1;
end

% error measure in amplitude, frequency, and damping

AmpE=(max(ExpAmp(n,:))-max(SimAmp(n,:)))^2;
FreE=(ExpFre(n)-SimFre(n))^2;
DampE=(ExpLambda(n)-SimLambda(n))^2;

% gel error 

if n==27,
  I1sim=(y(geltimelong,3)+y(geltimelong,5))*10^6;  
  I2sim=(y(geltimelong,11)+y(geltimelong,13))*10^6;  
  I3sim=(y(geltimelong,19)+y(geltimelong,21))*10^6;  

I1E=sum(((I1sim'-I1gelGaussA)./max(I1sim',I1gelGaussA)).^2)/24;
I2E=sum(((I2sim'-I2gelGaussA)./max(I2sim',I2gelGaussA)).^2)/24;
I3E=sum(((I3sim'-I3gelGaussA)./max(I3sim',I3gelGaussA)).^2)/24;  
GelE=I1E+I2E+I3E;
err=err+GelE;

if drawplots 

% gel measurement (Figure 5)    
    
figure(4)
  plot(geltimelong/60,I1gelGaussA,'mo',geltimelong/60,I2gelGaussA,'bo','Markersize',6,'Linewidth',3); hold on
  plot(geltimelong/60,I3gelGaussA,'o','Color',[0.5 0 0],'Markersize',6,'Linewidth',3);  hold on
  plot(tspan/dt/60,(y(:,3)+y(:,5))*10^6,'m-',tspan/dt/60,(y(:,11)+y(:,13))*10^6,'b-','Linewidth',1.5); hold on
  plot(tspan/dt/60,(y(:,19)+y(:,21))*10^6,'-','Color',[0.5 0 0],'Linewidth',1.5);
  plot(geltimelong/60,I1gelGaussA,'mo',geltimelong/60,I2gelGaussA,'bo','Markersize',6,'Linewidth',3); hold on
  plot(geltimelong/60,I3gelGaussA,'o','Color',[0.5 0 0],'Markersize',6,'Linewidth',3);  hold on
  legend('rI1','rI2','rI3','Location','NorthOutside'); 
  axis([-0.1 16 -0.1 2.5])
  xlabel('Time (hr)','Fontsize',20);
  ylabel('[RNA] (\muM)','Fontsize',20);
  set(gca,'Fontsize',20)

end

end

err=err+TamE+AmpE+FreE+DampE;

if drawplots, 
[n TamE AmpE FreE DampE],

% plots for the three-node ring oscillator (Figure S12)

if n<13,
figure(1)
     subplot(3,4,n)
     plot(tspan/dt/60,TAMsim,'.','Color',[0.6 1 0.6],'Markersize',7); hold on 
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on
  %   plot((TrimMinMax+Start(1))/60,ExpTAM(TrimMinMax),'ks'); hold on     
  %   plot((TrimSimMinMax+Start(1))/60,SimTAM(TrimSimMinMax),'bs'); hold on
	 axis([0 15 -0.1 1.1])
     title(int2str(n),'Fontsize',15)
drawnow
end

if n>12 & n<25,
figure(2)
     subplot(3,4,n-12)
     plot(tspan/dt/60,TAMsim,'.','Color',[0.6 1 0.6],'Markersize',7); hold on 
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on
   %  plot((TrimMinMax+Start(1))/60,ExpTAM(TrimMinMax),'ks'); hold on     
   %  plot((TrimSimMinMax+Start(1))/60,SimTAM(TrimSimMinMax),'bs'); hold on
	 axis([0 15 -0.1 1.1])
     title(int2str(n),'Fontsize',15)
drawnow
end

if n>24,
figure(3)
     subplot(3,4,n-24)
     plot(tspan/dt/60,TAMsim,'.','Color',[0.6 1 0.6],'Markersize',7); hold on 
     plot(tspan/dt/60,TAM,'.','Color',[0 0.7 0],'Markersize',7); hold on
   %  plot((TrimMinMax+Start(1))/60,ExpTAM(TrimMinMax),'ks'); hold on     
   %  plot((TrimSimMinMax+Start(1))/60,SimTAM(TrimSimMinMax),'bs'); hold on
	 axis([0 15 -0.1 1.1])
     title(int2str(n),'Fontsize',15)
drawnow
end

end 

end  
end

if drawplots,   
    
% fluorescence measurement (Figure 5)
    
figure(5)
  plot(tspan/dt/60,TAM,'g.','Markersize',10,'Linewidth',3); hold on 
  plot(tspan/dt/60,TAMsim,'-','Color',[0.6 1 0.6],'Linewidth',1.5,'Markersize',7); hold on 
  plot(tspan/dt/60,TAM,'g.','Markersize',10,'Linewidth',3); hold on 
  axis([-0.1 16 -0.1 1.1])
  legend('T12','T12 sim','Location','NorthOutside');
  xlabel('Time (hr)','Fontsize',20);
  ylabel('Normalized fluorescence','Fontsize',20);
  set(gca,'Fontsize',20)
end

if err<besterr
     bestparam=lparam;
besterr=err,
end

fprintf ('.');
