function Repressilator_fit(lparam)

global data
global bestparam
global besterr
global model_leaveout

if length(who('data'))==0
 fprintf(1,'runModel is not running \n');
 return
end
 
besterr=Inf;

bestparam=lparam;

lb=[ -8   -2 -7   -3   -8   -2   3.5 3.5 3.5  -8   -2 -7   -3   -8   -2   3.5 3.5 3.5 -8   -2 -7   -3   -8   -2   3.5 3.5 3.5 3.5 -2 3.5 -2 3.5 -2]*log(10);
ub=[ -6.5 -1 -5.5 -1.5 -6.5 -0.5 5.5 5.5 5.5  -6.5 -1 -5.5 -1.5 -6.5 -0.5 5.5 5.5 5.5 -6.5 -1 -5.5 -1.5 -6.5 -0.5 5.5 5.5 5.5 5.5 0  5.5 0  5.5 0 ]*log(10);
options=optimset('LargeScale','off','MaxFunEvals',inf,'MaxIter',inf);
[nparam,fval,exitflag,output]=fmincon(@Repressilator_main,bestparam,[],[],[],[],lb,ub,[],options);

