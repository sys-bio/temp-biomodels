function G=oscIIIs_plotfig(a,b,n,   a2,b2,n2) 
% Design III oscillator, simple model, essential parameters -- plot nullclines & sample trajectories
%
% a = kp [T_{i,i-1}^tot] / kd
% b = Kd / KI
% n = n
%
% x1 = [rI1] / KI
% x2 = [rI2] / KI
% x3 = [rI3] / KI
% s = t * KI / kd
% 
% dx_i/ds = a / (1 + x_{i-1}^n) - (1 - 1/(1+x_i/b))

figure(1); hold off
x=0:.001:3;

for i=1:2

 if i==2, a=a2; b=b2; n=n2; end

 prod = a./(1+x.^n); deg = 1-1./(1+x/b);
 if i==1, plot(x, prod, 'g-', x, deg, 'r-', 'LineWidth', 3);  end
 if i==2, plot(x, prod, 'g--', x, deg, 'r--', 'LineWidth', 3); end 
 axis([0 3 0 3]); axis square; hold on; 
 if i==1
  title(sprintf('\\alpha=%5.3f or %5.3f,  n=%5.2f',a,a2,n), 'FontName', 'Arial', 'FontSize', 20);
  legend('production of xi', 'degradation of xj'); xlabel('xj','FontName', 'Arial', 'FontSize', 20); ylabel('d/ds','FontName', 'Arial', 'FontSize', 20); 
  set(gca,'Fontsize',20);
  h=text(0.5,1.1,'(a)');  set(h,'FontSize',15)
  h=text(0.5,2.1,'(b)');  set(h,'FontSize',15)
 end

 [M,SS]=oscIIIs_M(a,b,n); xss=SS(1);
 Growth = max(real(eig(M))); 
 G=sign(Growth); 
 Period = max(imag(eig(M))); 

 if Growth>0, tick='ro'; elseif Growth<0, tick='r*'; else tick='rs'; end
 plot(xss,a/(1+xss^n),tick, 'MarkerSize', 10, 'LineWidth', 3); 

end
hold off; 

