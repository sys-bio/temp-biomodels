function mv=hillmodel3(tmax,Rleak,Ract,Ka,na,Rdeg,Kd,nd,scale)

% hillmodel3(6, 0, 1e-9, 3*1e-7, 5, 1e-9, 1e-7,1, 0.5);  % fast oscillation
% hillmodel3(20, 0, 1e-9, 3*1e-7, 5, 0.5*1e-9, 1e-7,1, 8); % slow-down

p=[Rleak,Ract,Ka,na,Rdeg,Kd,nd]; fprintf(1,'%g ',p); fprintf(1,'\n');

if 0
 fminsearch( @(p) -hillmodel3(0,10^p(1),10^p(2),10^p(3),10^p(4),10^p(5),10^p(6),10^p(7)),...
   [-11,-9,-7,log10(6),-9,-7,log10(1)]);
end

tmax=tmax*3600;  %% given in hours, simulated in seconds

figure(1)  % plot functions, solve for steady-state

 rI=0:(max(Ka,Kd)/200):(5*max(Ka,Kd));

 subplot(1,1,1); plot(rI*1e9,P(rI)*1e9,'g-',  rI*1e9,D(rI)*1e9,'r-'); 
 legend('P','D'); ylabel('nM/sec'); xlabel('rI / nM')

 if Rleak+Ract > Rdeg & Rleak < Rdeg
   xss=fzero(@(x)  P(x)-D(x), max(Ka,Kd));  
   if isfinite(xss) & isreal(xss)
    rIss = xss; 
    hold on; plot(rIss*1e9, P(rIss)*1e9, 'go'); hold off

    %% compute linearized matrix around steady state
    M = [ -(D(rIss)-D(.999*rIss))/(.001*rIss) 0 (P(rIss)-P(.999*rIss))/(.001*rIss); ...
        (P(rIss)-P(.999*rIss))/(.001*rIss)  -(D(rIss)-D(.999*rIss))/(.001*rIss) 0; ...  ];
        0 (P(rIss)-P(.999*rIss))/(.001*rIss)  -(D(rIss)-D(.999*rIss))/(.001*rIss) ];
    v = eig(M);
    title(sprintf('%f+%fi    %f+%fi    %f+%fi',real(v(1)),imag(v(1)), real(v(2)), imag(v(2)), real(v(3)), imag(v(3)) ));
    mv= max(real(v));
   else
    mv=-100; disp('Steady state was not found'); 
   end
 else
  mv=-100; disp('No steady state'); 
 end

if tmax>0
 figure(3)  % plot simulation

 x0  = [0 0 10e-9];
 options = odeset('MaxStep',10, 'InitialStep',.1);
 [t,x]=ode23s(@rates, 0:tmax, x0, options); 
 plot(t(:)/3600,x(:,1)*1e6,'m-', t(:)/3600,x(:,2)*1e6,'b-', 'LineWidth', 2); hold on
 plot(t(:)/3600,x(:,3)*1e6,'-', 'Color',[0.5 0 0],'LineWidth', 2); 
 legend('rI1', 'rI2', 'rI3'); xlabel('Time (hrs)','Fontsize',20); ylabel('[RNA] (\muM)','Fontsize',20); 
 set(gca,'Fontsize',20);
 
 figure(4)
 plot3(x(:,1)*1e6,x(:,2)*1e6,x(:,3)*1e6,'k-', 'LineWidth', 2); 
 xlabel('[rI1] (\muM)','Fontsize',20); ylabel('[rI2] (\muM)','Fontsize',20);  zlabel('[rI3] (\muM)','Fontsize',20);
 set(gca,'Fontsize',20);
 axis([0 scale 0 scale 0 scale]);
 %axis([0 0.5 0 0.5 0 0.5]);  % for fast oscillation
 %axis([0 8 0 8 0 8]);   % for slow oscillation
 view(135,45)
end

function dxdt=rates(t,x)
 rI1=x(1); rI2=x(2); rI3=x(3);
 dxdt(1) = P(rI2)-D(rI1);
 dxdt(2) = P(rI3)-D(rI2);
 dxdt(3) = P(rI1)-D(rI3);
 dxdt=dxdt';
end  %% of subfunction rates()

function x=P(y)
 x=Rleak+Ract./(1+(y/Ka).^na);
end

function x=D(y)
 x=Rdeg*(1-1./(1+(y/Kd).^nd));
end

function y=Dinv(x)
 x=min(x,.999*Rdeg);
 y=Kd*(1./(1-x/Rdeg)-1).^(1/nd);
 y=max(0,min(5*max(Kd,Ka),y));
end

end %% of function


