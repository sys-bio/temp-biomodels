function G=oscIIIs_plot(a,b,n, tmult, xmult) 
% Design III oscillator, simple model, essential parameters -- plot nullclines & sample trajectories
%
% a = kp [T_{i,i-1}^tot] / kd
% b = Kd / KI
% n = n
%
% x1 = [rI1] / KI
% x2 = [rI2] / KI
% x3 = [rI3] / KI
% s = t * KI / kd
% 
% dx_i/ds = a / (1 + x_{i-1}^n) - (1 - 1/(1+x_i/b))

if nargin<=3, tmult=50; end
if nargin<=4, xmult=10; end
global showit

x=0:.001:4;

prod = a./(1+x.^n); deg = 1-1./(1+x/b);
if showit, figure(1); plot(x, prod, 'g.', x, deg, 'r.' ); axis([0 4 0 4]); hold on; end

[M,SS]=oscIIIs_M(a,b,n); xss=SS(1);
Growth = max(real(eig(M))); 
G=sign(Growth); 
Period = max(imag(eig(M))); 

%% double checking if hump for n near zero is real.  it is.
% if a>2 && b<1 && n < 1, if b*(1+xss/b)^2*n*(a-1) > 2*xss*a, G=1; else G=-1; end; end

if a>2, G=[G 2]; end 
%%% should spiral out to infinity for large enough initial conditions (possibly in addition to a limit cycle or stable state)
if 0 %% confirms that for all n, for oscillatory parameters the amplitude exceeds 10, or spiralling out is initiated by then.
 Y0=[10, 0, 0];     % start at 10x production threshold
 tmax=3*10*(1+1/a); % give enough time for two full cycles if there is no amplitude decrease
 [T,Y]=ode23s('oscIIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,n);
 Ti=find(T>10); % wait for first signal to decay
 top=max([max(Y(Ti,1)) max(Y(Ti,2)) max(Y(Ti,3))]);
 if (top>10), G=[G 2]; end
end 
%% having established that a>2 ==> spiraling out can happen, when is there also an attracting limit cycle?
%% we can test this by ODE simulations starting at the steady state and 
%% stopping when either we repeat a state to within 0.1%, or when some concentration hits 0... hmm, not definitive?  
%% then let's not distinguish those cases.

if showit
 if Growth>0, tick='ro'; elseif Growth<0, tick='r*'; else tick='rs'; end
 plot(xss,a/(1+xss^n),tick, 'MarkerSize', 10, 'LineWidth', 3); hold off; 

 title(sprintf('Design III: \\alpha=%5.3f, \\beta=%5.3f, n=%5.2f',a,b,n));
 legend('production of x2', 'degradation of x1'); xlabel('x1'); ylabel('d/ds'); tmax=tmult;
 Y0=[rand(1)*4, rand(1)*4, rand(1)*4];  
 [T1,Y1]=ode23s('oscIIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,n);
 Y0=[rand(1)*4, rand(1)*4, rand(1)*4];  
 [T2,Y2]=ode23s('oscIIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,n);
 Y0=[rand(1)*4, rand(1)*4, rand(1)*4];  
 [T3,Y3]=ode23s('oscIIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,n);
 Y0=[rand(1)*4*xmult, rand(1)*4*xmult, rand(1)*4*xmult];  
 [T4,Y4]=ode23s('oscIIIs', [0 tmax*xmult], Y0, odeset('MaxStep',4), a,b,n);
 hold on; plot(Y1(:,1),a./(1+Y1(:,2).^n),'r',Y2(:,1),a./(1+Y2(:,2).^n),'c', ...
               Y3(:,1),a./(1+Y3(:,2).^n),'m',Y4(:,1),a./(1+Y4(:,2).^n),'g'); hold off;

 figure(2); ymax=max(4,max(union(union(Y1(:),Y2(:)),union(Y3(:),Y4(:)))));
 subplot(2,2,1); plot(T1,Y1(:,1),'r-',T1,Y1(:,2),'g-',T1,Y1(:,3),'b-'); axis([0 tmax 0 ymax]);
 legend('x1','x2','x3'); xlabel('t'); ylabel('red')
 subplot(2,2,2); plot(T2,Y2(:,1),'r-',T2,Y2(:,2),'g-',T2,Y2(:,3),'b-'); axis([0 tmax 0 ymax]);
 legend('x1','x2','x3'); xlabel('t'); ylabel('cyan')
 subplot(2,2,3); plot(T3,Y3(:,1),'r-',T3,Y3(:,2),'g-',T3,Y3(:,3),'b-'); axis([0 tmax 0 ymax]);
 legend('x1','x2','x3'); xlabel('t'); ylabel('magenta')
 subplot(2,2,4); plot(T4,Y4(:,1),'r-',T4,Y4(:,2),'g-',T4,Y4(:,3),'b-'); axis([0 tmax*xmult 0 ymax]);
 legend('x1','x2','x3'); xlabel('t'); ylabel('green')
end
