function [Amp,Fre]= ActInhDetailed(param,tmax,drawplots,initA,initI)

% default parameter
% param=[248*10^(-9) 0.08 2.67*10^(-6) 0.02 76*10^(-9) 0.05 7.4*10^4 2.4*10^4 5.3*10^4 2.8*10^4 2.8*10^4 250*10^(-9) 250*10^(-9) 1000*10^(-9) 69*10^(-9) 0.05 2.62*10^(-6) 0.002 18*10^(-9) 0.24 1.4*10^4 3.1*10^4 1.4*10^5 120*10^(-9) 500*10^(-9) 125*10^(-9) 15*10^(-9)]

KM21=param(1); kpc21=param(2); KMF21=param(3); kpFc21=param(4); KMh1=param(5); khc1=param(6); kTA21=param(7); krAI1=param(8); kAI1=param(9); kTAI21=param(10); 
krAAI1=param(11);

KM12=param(15); kpc12=param(16); KMF12=param(17); kpFc12=param(18); KMh2=param(19); khc2=param(20); kTA12=param(21); kAI2=param(22); kTAI12=param(23);

dt=60;

T21tot=param(12); A1tot=param(13); dI1tot=param(14); 
T12tot=param(24); A2tot=param(25);

R=param(26); Rh=param(27);
C=zeros(1,12);

C(1,1)=T21tot; C(1,2)=A1tot; C(1,3)=dI1tot;
C(1,8)=T12tot; C(1,9)=A2tot; 

if nargin>4,  C(1,4)=initA; C(1,10)=initI; 
end

% Inital condition vector 

tspan=[0:dt:60*dt];
options=odeset('AbsTol',1e-9); % set tolerances

% equilibrate first without enzymes

[t,y0]=ode23s('ActInhDetaileddefine',tspan,C, options, KM21, kpc21, KMF21, kpFc21, KMh1, khc1, kTA21, krAI1, kAI1, kTAI21, krAAI1, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, 0, 0);

tspan=[0:dt:tmax*dt];             

% actual run

[t,y]=ode23s('ActInhDetaileddefine',tspan,y0(60,:), options, KM21, kpc21, KMF21, kpFc21, KMh1, khc1, kTA21, krAI1, kAI1, kTAI21, krAAI1, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, R, Rh);

itot1 = y(:,4) + y(:,7);
itot2 = y(:,10) + y(:,12);

T21A1 = y(:,5); 
T12A2 = y(:,11);

% determine amplitude and frequency

Tend=T12A2(420:tmax); Tmaxe=max(Tend); Tmine=min(Tend);
iend=itot1(420:tmax); maxe=max(iend); mine=min(iend);
icrop=itot1(300:tmax); maxi=max(icrop); mini=min(icrop);
Amp=(Tmaxe-Tmine)*100/T12tot;
if Amp>5 & Tmaxe>1.3*Tmine,
Tdomain=find(Tend>0.8*Tmaxe);
t=Tdomain(find((Tdomain(2:end)-Tdomain(1:end-1))>1));
if length(t)>1,
Fre=60/(t(2)-t(1));
else Fre=0;
end
else Fre=0;
end
	   
fprintf('.');
if drawplots,
figure(2)

subplot(2,1,1)
x=1:tmax;
ITOT=[itot1(x),itot2(x)];
plot(x,ITOT);
xlabel('time (min)')
ylabel('RNA conc.')
legend('rA1tot','rI2tot');

subplot(2,1,2)
TA=[T21A1(x),T12A2(x)];
plot(x,TA);
xlabel('time (min)')
ylabel('ON-state switch conc.')
legend('T21A1','T12A2');

end

