function ydot=ActInhDetaileddefine (t,y,flags, KM21, kpc21, KMF21, kpFc21, KMh1, khc1, kTA21, krAI1, kAI1, kTAI21, krAAI1, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, R, Rh)

% define ODEs for Design I oscillator (detailed model)

T21 = y(1); A1 = y(2); dI1 = y(3); rA1 = y(4); T21A1 = y(5);  
A1dI1 = y(6); rA1dI1 = y(7);
T12 = y(8); A2 = y(9); rI2 = y(10); T12A2 = y(11); A2rI2 = y(12); 

% calculate available enzyme concentrations

L = T21A1/KM21 + T21/KMF21 + T12A2/KM12 + T12/KMF12;
Rfree = R/(1 + L);
Lh = rA1dI1/KMh1 + A2rI2/KMh2;
Rhfree = Rh/(1 + Lh);

% ODEs

T21dot =  - kTA21*T21*A1 + kTAI21*T21A1*dI1; 
A1dot = - kTA21*T21*A1 - kAI1*A1*dI1 + krAAI1*A1dI1*rA1;
dI1dot = khc1/KMh1*Rhfree*rA1dI1 - kAI1*A1*dI1  - krAI1*rA1*dI1 - kTAI21*T21A1*dI1; 
rA1dot = kpc12/KM12*Rfree*T12A2 + kpFc12/KMF12*Rfree*T12 - krAI1*rA1*dI1 - krAAI1*A1dI1*rA1;
T21A1dot = -T21dot;
A1dI1dot = - A1dot - T21A1dot; 
rA1dI1dot = - dI1dot - A1dI1dot;

T12dot = - kTA12*T12*A2 + kTAI12*T12A2*rI2;
A2dot = - kAI2*A2*rI2 - kTA12*T12*A2 + khc2/KMh2*Rhfree*A2rI2;
rI2dot = kpc21/KM21*Rfree*T21A1 + kpFc21/KMF21*Rfree*T21 - kAI2*A2*rI2 - kTAI12*T12A2*rI2;
T12A2dot = - T12dot;
A2rI2dot = - A2dot - T12A2dot;


ydot=[T21dot;A1dot;dI1dot;rA1dot;T21A1dot;A1dI1dot;rA1dI1dot;T12dot;A2dot;rI2dot;T12A2dot;A2rI2dot];



