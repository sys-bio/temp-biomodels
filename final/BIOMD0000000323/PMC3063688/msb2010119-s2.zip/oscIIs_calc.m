global showit
showit=0;

% step=0.02
step=.005; 
clear G
for a=step:step:3
 for d=step:step:3
  i=round(a/step); j=round(d/step);
  Gvector=oscIIs_plot(a,2,1,d,5); 
  G(i,j) = eval(char(Gvector+2+'0'));
  if showit, figure(1); title(sprintf('\\alpha=%5.3f   \\delta=%5.3f   G=%d',a,d,G(i,j)));  drawnow; end
 end
 if ~showit, disp([4 a]); end
end
GII=G; 
a=step:step:3; d=step:step:3;  clear G;
vals=union(GII(:),[]); for i=1:length(a), for j=1:length(d), G(i,j)=find(vals==GII(i,j)); end, end
figure(4); imagesc(a,d,G); axis xy;  axis square; ylabel('\alpha'); xlabel('\delta')
colorbar; cm=rand(length(vals),3); colormap(cm); vals

showit=1;
