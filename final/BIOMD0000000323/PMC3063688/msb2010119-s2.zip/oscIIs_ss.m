function Y=oscIIs_ss(a,b,c,d,n) 
% Design II oscillator, simple model, essential parameters -- steady state
%
% a = kp [T12tot] / KA / kd
% b = kp [T21tot] / KI / kd
% c = 1 / tau / kd
% d = kp [T11tot] / KA / kd
% n = n
%
% x = [rA1] / KA
% y = [rI2] / KI
% u = [T12A2] / [T12tot]
% v = [T21A1] / [T21tot]
% w = [T11A1] / [T11tot] = v
% s = t / tau
% 
% c dx/ds = a u - x + d w
% c dy/ds = b v - y
%   du/ds = 1/(1+y^n) - u
%   dv/ds = 1/(1+x^-n) - v

% x = a*u +d*v
% y = b*v
% u = 1/(1+y^n) 
% v = 1-1/(1+x^n) 
 


if 0
 x=0.01:.01:4; 
 rt=zeros(length(x)-1,1);  % find root nearest to each value in x, take the union
 for i=1:length(x)-1
  rt(i) = fzero(@(x) min(4,max(0,a./(x-d*(1-1./(1+x.^n)))-1).^(1/n))-b*(1-1./(1+x.^n)), x(i));
  rt(i) = round(rt(i)*1000)/1000;
 end

 xss=union(rt,[]); xss=xss(find(xss>0)); 
 x=xss; diff=min(4,max(0,a./(x-d*(1-1./(1+x.^n)))-1).^(1/n))-b*(1-1./(1+x.^n));
 xss=xss(find(diff.^2<0.05));
else
 x=0.001:.001:4;  %% find places where the sign changed
 dy=min(4,max(0,a./max(0.0001,x-d*(1-1./(1+x.^n)))-1).^(1/n))-b*(1-1./(1+x.^n));
 sy=sign(dy); zi=find(sy==0);
 if ~isempty(zi)
  if length(zi)>1
    zi; %keyboard
  end
  sy(zi)=sign(rand(1,length(zi))-.5);
 end
 xi=find(sy(1:end-1)==-sy(2:end));
 xss=(x(xi)+x(xi+1))/2; 
end

yss=b*(1-1./(1+xss.^n)); 
uss=1./(1+yss.^n);
vss=1-1./(1+xss.^n);

Y=[xss(:)'; yss(:)'; uss(:)'; vss(:)'];
