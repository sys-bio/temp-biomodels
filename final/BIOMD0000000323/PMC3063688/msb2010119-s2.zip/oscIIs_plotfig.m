function G=oscIIs_plotfig(a,b,c,d,n,tmult,dx) 
% Design II oscillator, simple model, essential parameters -- plot nullclines for paper version figure
%
% a = kp [T12tot] / KA / kd
% b = kp [T21tot] / KI / kd
% c = 1 / tau / kd
% d = kp [T11tot] / KA / kd
% n = n
%
% x = [rA1] / KA
% y = [rI2] / KI
% u = [T12A2] / [T12tot]
% v = [T21A1] / [T21tot]
% w = [T11A1] / [T11tot] = v
% s = t / tau
% 
% c dx/ds = a u - x + d w
% c dy/ds = b v - y
%   du/ds = 1/(1+y^n) - u
%   dv/ds = 1/(1+x^-n) - v

figure(1)

if nargin==4, n=d; d=0; end
if nargin<6, tmult=20; end
if nargin<7, dx=0.3; end
%tmult=20*4;  % for (-,+,-,+,-) case

x=0:.001:3;


  y=min(3,max(0,a./(x-d*(1-1./(1+x.^n)))-1).^(1/n)); 

  h=plot(x, b*(1-1./(1+x.^n)), 'k-', 'LineWidth', 3 ); axis([0 3 0 3]); axis square; hold on; 
  y0 = [0 y 0]; 
  ybegin = find( y0(2:end-1)>0 & y0(1:end-2)==0 );  % these index into y
  yend   = find( y0(2:end-1)>0 & y0(3:end)==0 );
  %assert(length(ybegin)==length(yend));
  for i=1:length(ybegin)
    yi = ybegin(i):yend(i); 
    if ybegin(i)>1 && y(ybegin(i))<3 && y(ybegin(i))>0, yi=[ybegin(i)-1 yi]; if y(ybegin(i))>2 && y(ybegin(i))<3, y(ybegin(i)-1)=3; end; end
    if yend(i)<length(y) && y(yend(i))<3 && y(yend(i))>0, yi=[yi yend(i)+1]; if y(yend(i))>2, y(yend(i)+1)=3; end; end
    plot(x(yi), y(yi), '-', 'Color',[0.5 0 0.5],'LineWidth',3); 
  end

[Ms,SS]=oscIIs_M(a,b,c,d,n); G=zeros(1,size(Ms,3)); if ~isempty(SS), xss=SS(1,:); yss=SS(2,:); end
for i=1:size(Ms,3)
   Growth = max(real(eig(Ms(:,:,i)))); G(i)=sign(Growth);
   Period = max(imag(eig(Ms(:,:,i)))); 
   if Growth>0, tick='ro'; elseif Growth<0, tick='go'; else tick='rs'; end
   plot(xss(i),yss(i),tick, 'MarkerSize', 10, 'LineWidth', 2);
end

 hold off

 odeopt = odeset('MaxStep',1, 'RelTol',1e-5 );

 if nargin==4,  
   title(sprintf('\\alpha=\\beta=%5.3f, n=m=%5.2f',a,n), 'FontName', 'Arial', 'FontSize', 25); %assert(a==b);
 else
   title(sprintf('\\alpha=%5.3f, \\delta=%5.3f',a,d), 'FontName', 'Arial', 'FontSize', 25);
 end
 legend('y nullcline', 'x nullcline'); xlabel('x','FontName', 'Arial', 'FontSize', 25); ylabel('y','FontName', 'Arial', 'FontSize', 25); 
 set(gca,'Fontsize',25);
 tmax=tmult*(c+1/c);
 for xx=.3:dx:2.7   % default spacing is dx=0.3, can use fine-grid search 
   % use steady-state values for u and v: u = 1/(1+y^n)    v = (1-1/(1+x^n))
   % from bottom
   Y0=[xx, 0, 1, 1-1/(1+xx^n)]; [T1,Y1]=ode23s('oscIIs', [0 tmax], Y0, odeopt, a,b,c,d,n);
   % from top
   Y0=[xx, 3, 1/(1+3^n), 1-1/(1+xx^n)]; [T2,Y2]=ode23s('oscIIs', [0 tmax], Y0, odeopt, a,b,c,d,n);
   hold on; plot(Y1(:,1),Y1(:,2),'c',Y2(:,1),Y2(:,2),'c'); hold off;
 end

 for yy=.3:.3:2.7
   % from left
   Y0=[0, yy, 1/(1+yy^n), 0]; [T1,Y1]=ode23s('oscIIs', [0 tmax], Y0, odeopt, a,b,c,d,n);
   % from right
   Y0=[3, yy, 1/(1+yy^n), 1-1/(1+3^n)]; [T2,Y2]=ode23s('oscIIs', [0 tmax], Y0, odeopt, a,b,c,d,n);
   hold on; plot(Y1(:,1),Y1(:,2),'c',Y2(:,1),Y2(:,2),'c'); hold off;
 end

if 0
 for i=1:length(G)
   if G(i)==1 %% unstable : close circle
     eps=.1;
   else       %% stable (or zero) : far circle
     eps=.5;
   end
   for t=(2*pi/8):(2*pi/8):(2*pi)
     xx=xss(i)+eps*cos(t); yy=yss(i)+eps*sin(t);
     if xx>0 && xx<3 && yy>0 && yy<3
      Y0=[xx, yy, 1/(1+yy^n), 1-1/(1+xx^n)]; [T1,Y1]=ode23s('oscIIs', [0 tmax], Y0, odeopt, a,b,c,d,n);
      hold on; plot(Y1(:,1),Y1(:,2),'c'); hold off;
     end
   end
 end
end
