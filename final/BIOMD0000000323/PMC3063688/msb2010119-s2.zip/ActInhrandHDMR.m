function [Ampr,frer,sucr,varf,varAf]=ActInhrandHDMR (reftrial,trial,mesh,Ampref,freref)

% This function explores the parameters of ActInhDetailed and decompose variance to each variable.

% declare variables

Ampr=zeros(15,mesh); frer=zeros(15,mesh); success=zeros(15,mesh);

% K_M, k_cat are fixed
% [K_M,ON k_cat,ON K_M,OFF k_cat,OFF K_M,H k_cat,H]

p=[10^(-7) 0.05 4*10^(-7) 0.01 10^(-7) 0.1];

title_name = ['kTA21 ';'krAI1 ';'kAI1  ';'kTAI21';'kAIrA1';'T21tot';'A1tot ';'dI1tot'; 'kTA12 '; 'kAI2  '; 'kTAI12'; 'T12tot'; 'A2tot '; 'Rtot  '; 'Rhtot '];

lb=[10^3 10^3 10^3 10^3 10^3 20*10^(-9) 50*10^(-9) 50*10^(-9) 10^3 10^3 10^3 20*10^(-9) 50*10^(-9) 5*10^(-9) 1*10^(-9)]; 
ub=[10^5 10^5 10^5 10^5 10^5 200*10^(-9) 1000*10^(-9) 1000*10^(-9) 10^5 10^5 10^5 200*10^(-9) 1000*10^(-9) 100*10^(-9) 20*10^(-9)];
%ref=[10^4 10^4 10^4 10^4 10^4 100*10^(-9) 200*10^(-9) 500*10^(-9) 10^4 10^4 10^4 100*10^(-9) 500*10^(-9) 40*10^(-9) 8*10^(-9)];

if nargin<4,
  freref=0; Ampref=0; sucref=0;  

for i=1:reftrial

rv=rand(1,15);        % rescaled to 0~1
vp=exp(rv.*(log(ub)-log(lb))+log(lb));     % uniform sampling in log space
param=[p vp(1:8) p vp(9:15)];

[Amp,fre]=ActInhDetailed(param,1100,0);
freref=freref+fre; sucref=sucref+(fre>0);
Ampref=Ampref+Amp*(fre>0);              % Count Amplitude only when oscillating
end
 
Ampref=Ampref/sucref, freref=freref/sucref, sucref=sucref/reftrial,

end


for i=1:15,
    fprintf('variable=%2.0f\n',i)
	for j=1:mesh,
		for k=1:trial,
rv=rand(1,15);        % rescaled to 0~1
vp=exp(rv.*(log(ub)-log(lb))+log(lb));     % uniform sampling in log space
vp(i)=exp((log(ub(i))-log(lb(i)))*(j-1)/(mesh-1)+log(lb(i)));     

param=[p vp(1:8) p vp(9:15)];
 
[Amp,fre]=ActInhDetailed(param,1100,0);
Ampr(i,j)=Ampr(i,j)+Amp*(fre>0); frer(i,j)=frer(i,j)+fre; success(i,j)=success(i,j)+(fre>0);

end
if success(i,j)==0, Ampr(i,j)==0; frer(i,j)==0; else
Ampr(i,j)=Ampr(i,j)/success(i,j)-Ampref; frer(i,j)=frer(i,j)/success(i,j)-freref;
end
end
end

% plot relative changes in amplitude, frequency, and success rates
sucr=success/trial-sucref;
figure(1)
for i=1:15,
	subplot(4,4,i)
     x=exp((log(ub(i))-log(lb(i)))*linspace(0,1,mesh)+log(lb(i)));
     semilogx(x,[Ampr(i,:)+Ampref;frer(i,:)+freref;sucr(i,:)+sucref]) 
     varf(i)=mean(frer(i,:).*frer(i,:));
     varAf(i)=mean(Ampr(i,:).*Ampr(i,:).*frer(i,:).*frer(i,:));
end

% plot success rates

figure(2)
for i=1:15,
	subplot(4,4,i)
     x=exp((log(ub(i))-log(lb(i)))*linspace(0,1,mesh)+log(lb(i)));
     semilogx(x,[sucr(i,:)+sucref]) 
     axis([lb(i) ub(i) 0 0.04]);
     title(title_name(i,:));
end


