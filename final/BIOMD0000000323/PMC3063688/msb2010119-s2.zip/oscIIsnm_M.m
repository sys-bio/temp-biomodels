function [M,Y]=oscIIs_M(a,b,c,d,n,m) 
% Design II oscillator, simple model, essential parameters -- linear matrix near steady state
%
% a = kp [T12tot] / KA / kd
% b = kp [T21tot] / KI / kd
% c = 1 / tau / kd
% d = kp [T11tot] / KA / kd
%
% x = [rA1] / KA
% y = [rI2] / KI
% u = [T12A2] / [T12tot]
% v = [T21A1] / [T21tot]
% w = [T11A1] / [T11tot] = v
% s = t / tau
% 
% c dx/ds = a u - x + d w
% c dy/ds = b v - y
%   du/ds = 1/(1+y^n) - u
%   dv/ds = 1/(1+x^-m) - v

Y = oscIIsnm_ss(a,b,c,d,n,m); k=size(Y,2);  % could be zero or multiple steady states

M=zeros(4,4,k);
for i=1:k
 x=Y(1,i); y=Y(2,i); u=Y(3,i); v=Y(4,i); w=v;
 M(1,1,i) = -1/c;  M(1,3,i) = a/c;   M(1,4,i) = d/c;
 M(2,2,i) = -1/c;  M(2,4,i) = b/c;
 M(3,3,i) = -1;    M(4,4,i) = -1;
 M(3,2,i) = -n*y^(n-1)/((1+y^n)^2);
 M(4,1,i) =  m*x^(m-1)/((1+x^m)^2);
end

