function Y=oscIs_ss(a,b,c,n) 
% Design I oscillator, simple model, essential parameters -- steady state
%
% a = kp [T12tot] / KA / kd
% b = kp [T21tot] / KI / kd
% c = 1 / tau / kd
% n = n
%
% x = [rA1] / KA
% y = [rI2] / KI
% u = [T12A2] / [T12tot]
% v = [T21A1] / [T21tot]
% s = t / tau
% 
% c dx/ds = a u - x
% c dy/ds = b v - y
%   du/ds = 1/(1+y^n) - u
%   dv/ds = 1/(1+x^-n) - v

% x = a*u 
% y = b*v
% u = 1/(1+y^n) = 1/(1+(b*v)^n)
% v = 1-1/(1+x^n) = 1 - 1/(1+(a*u)^n)
% 
% v = 1 - 1/(1+(a/(1+(b*v)^n))^n);

v = fzero(@(v) 1 - 1/(1+(a/(1+(b*v)^n))^n) - v, .5  );
u = 1/(1+(b*v)^n);
y = b*v;
x = a*u;

Y=[x, y, u, v];


