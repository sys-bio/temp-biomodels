function [M,Y]=oscIIIs_M(a,b,n) 
% Design III oscillator, simple model, essential parameters -- linear matrix near steady state
%
% a = kp [T_{i,i-1}^tot] / kd
% b = Kd / KI
% n = n
%
% x1 = [rI1] / KI
% x2 = [rI2] / KI
% x3 = [rI3] / KI
% s = t * KI / kd
% 
% dx_i/ds = a / (1 + x_{i-1}^n) - (1 - 1/(1+x_i/b))

Y = oscIIIs_ss(a,b,n); 

M=zeros(3,3);
 x1=Y(1); x2=Y(2); x3=Y(3);
 M(1,1) = -1/(b*(1+x1/b)^2);  M(1,3) = -a*n*x3^(n-1)/((1+x3^n)^2);
 M(2,2) = -1/(b*(1+x2/b)^2);  M(2,1) = -a*n*x1^(n-1)/((1+x1^n)^2);
 M(3,3) = -1/(b*(1+x3/b)^2);  M(3,2) = -a*n*x2^(n-1)/((1+x2^n)^2);
end

