function ydot=ActInh_oscillator_define (t,y,flags, KM21, kpc21, KMF21, kpFc21, KMh1, khc1, kTA21, krAI1, krAAI1, kAI1, kTAI21, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, kTA11, kTAI11, R, Rh, kdisso, kasso, KM11, kpc11, KMF11, kpFc11)

% define ODEs for two-node oscillator

T21 = y(1); A1 = y(2); dI1 = y(3); rA1 = y(4); T21A1 = y(5); 
A1dI1 = y(6); rA1dI1 = y(7); 
T12 = y(8); A2 = y(9); rI2 = y(10); T12A2 = y(11); A2rI2 = y(12); 
sI2 = y(13);  
% sI2 is the subsequence of rI2 produced by RNase H that spans the toehold-binding region of A2.
A2sI2 = y(14); T12A2sI2 = y(15);
T11 = y(16);  T11A1 = y(17);

L= T21A1/KM21 + T21/KMF21 + T12A2/KM12 + T12A2sI2/KM12 + T12/KMF12 + T11A1/KM11 + T11/KMF11;
Rfree= R/(1+L);

% Repeated estimation of free RNAP concentration using *Newton's Method'*

for k=1:6,
f_R=Rfree*(1+T21A1/(Rfree+KM21)+T11A1/(Rfree+KM11)+T21/(Rfree+KMF21)+T11/(Rfree+KMF11)+(T12A2+T12A2sI2)/(Rfree+KM12)+T12/(Rfree+KMF12))-R;
f_R_prime=1+KM21*T21A1/(KM21+Rfree)^2+KM11*T11A1/(KM11+Rfree)^2+KMF21*T21/(KMF21+Rfree)^2+KMF11*T11/(KMF11+Rfree)^2+KM12*(T12A2+T12A2sI2)/(KM12+Rfree)^2+KMF12*T12/(KMF12+Rfree)^2;
Rfree=Rfree-f_R/f_R_prime; 
end

% Calculate the fraction of enzyme-bound species for RNase H 

Lh = rA1dI1/KMh1 + A2rI2/KMh2;
Rhfree = Rh/(1 + Lh);

% ODEs

T21dot =  - kTA21*T21*A1 + kTAI21*T21A1*dI1; 
A1dot = - kTA21*T21*A1 - kTA11*T11*A1 - kAI1*A1*dI1 + krAAI1*A1dI1*rA1;
dI1dot = khc1/KMh1*Rhfree*rA1dI1 - kAI1*A1*dI1  - krAI1*rA1*dI1 - kTAI21*T21A1*dI1 - kTAI11*T11A1*dI1; 
rA1dot = kpc12/(KM12+Rfree)*Rfree*T12A2 + kpFc12/(KMF12+Rfree)*Rfree*T12 + kpc12/(KM12+Rfree)*Rfree*T12A2sI2 + kpc11/(KM11+Rfree)*Rfree*T11A1 + kpFc11/(KMF11+Rfree)*Rfree*T11 - krAI1*rA1*dI1 - krAAI1*A1dI1*rA1;
T21A1dot = - T21dot;

T11dot = - kTA11*T11*A1 + kTAI11*T11A1*dI1;
T11A1dot = - T11dot;
A1dI1dot = - A1dot - T21A1dot - T11A1dot; 
rA1dI1dot = - dI1dot - A1dI1dot;

T12dot = - kTA12*T12*A2 + kTAI12*T12A2*rI2 - kTA12*T12*A2sI2;
A2dot = - kAI2*A2*rI2 - kTA12*T12*A2 - kasso*A2*sI2 + kdisso*A2sI2;
rI2dot = kpc21/(KM21+Rfree)*Rfree*T21A1 + kpFc21/(KMF21+Rfree)*Rfree*T21 - kAI2*A2*rI2 - kTAI12*T12A2*rI2 - kAI2*A2sI2*rI2;

sI2dot = - kasso*A2*sI2 + kdisso*A2sI2 + kAI2*A2sI2*rI2 - kasso*T12A2*sI2 + kdisso*T12A2sI2; 
A2sI2dot = khc2/KMh2*Rhfree*A2rI2 + kasso*A2*sI2 - kdisso*A2sI2 - kAI2*A2sI2*rI2 - kTA12*T12*A2sI2;
T12A2sI2dot = kasso*T12A2*sI2 - kdisso*T12A2sI2 + kTA12*T12*A2sI2;

T12A2dot = - T12dot - T12A2sI2dot;
A2rI2dot = - A2dot - T12A2dot - A2sI2dot - T12A2sI2dot;

ydot=[T21dot;A1dot;dI1dot;rA1dot;T21A1dot;A1dI1dot;rA1dI1dot;T12dot;A2dot;rI2dot;T12A2dot;A2rI2dot;sI2dot;A2sI2dot;T12A2sI2dot;T11dot;T11A1dot];

