global showit
showit=0;

% step=.1;
% step=.02;
step=.005;
clear G
for a=step:step:3
 for b=step:step:3
  i=round(a/step); j=round(b/step);
  Gvector=oscIIIs_plot(a,b,5); 
  G(i,j) = eval(char(Gvector+2+'0'));
  if showit, figure(1); title(sprintf('\\alpha=%5.3f   \\beta=%5.3f   G=%d',a,b,G(i,j))); drawnow; end
 end
 if ~showit, disp([5 a]); end
end 
GIII=G;
a=step:step:3; b=step:step:3;  clear G;
vals=union(GIII(:),[]); for i=1:length(a), for j=1:length(b), G(i,j)=find(vals==GIII(i,j)); end, end
figure(5); imagesc(b,a,G); axis xy;  axis square; ylabel('\alpha'); xlabel('\beta')
colorbar; cm=rand(length(vals),3); colormap(cm); vals

% stepa=.02; stepn=.05; 
stepa=.005; stepn=.02; 
clear G
for a=stepa:stepa:3
 for n=stepn:stepn:10
  i=round(a/stepa); j=round(n/stepn);
  Gvector=oscIIIs_plot(a,.3,n); 
  G(i,j) = eval(char(Gvector+2+'0'));
  if showit, figure(1); title(sprintf('\\alpha=%5.3f   \\beta=%5.3f   G=%d',a,b,G(i,j)));  drawnow; end
 end
 if ~showit, disp([9 a]); end
end 
GIIIn=G;
a=stepa:stepa:3; n=stepn:stepn:10;  clear G;
vals=union(GIIIn(:),[]); for i=1:length(a), for j=1:length(n), G(i,j)=find(vals==GIIIn(i,j)); end, end
figure(9); imagesc(n,a,G); axis xy;  axis square; ylabel('\alpha'); xlabel('n')
colorbar; cm=rand(length(vals),3); colormap(cm); vals

showit=1;
