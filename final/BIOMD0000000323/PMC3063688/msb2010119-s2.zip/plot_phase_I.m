% Design I 

ids=0;

figure(3); hold off
step=0.005; a=step:step:3; b=step:step:3;  clear G;
vals=union(GI(:),[]); for i=1:length(a), for j=1:length(b), G(i,j)=find(vals==GI(i,j)); end, end
imagesc(b,a,G); axis xy; axis square; colormap([1 1 1;.8 .8 .8]); 
%%%contour(b,a,G,1); axis xy; axis square;
%%G=(G~=[G(1,:); G(1:end-1,:)]) | (G~=[G(:,1) G(:,1:end-1)]);
%%imagesc(b,a,G); axis xy;  axis square; colormap([1 1 1; 0 0 0]); 
set(gca,'FontSize',20);
ylabel('\alpha','FontSize',20); xlabel('\beta','FontSize',20)
title('n=m=5, \gamma=1', 'FontSize',20)
h=text(1.7,2.7,'oscillating'); set(h,'FontSize',15);
h=text(.2,.2,'monostable'); set(h,'FontSize',15);
hold on

figure(6); hold off
stepa=0.005; a=stepa:stepa:3; stepn=0.02; n=stepn:stepn:10;  clear G;
vals=union(GIn(:),[]); for i=1:length(a), for j=1:length(n), G(i,j)=find(vals==GIn(i,j)); end, end
imagesc(n,a,G); axis xy; axis square; colormap([1 1 1;.8 .8 .8]); 
%%%contour(n,a,G,1); axis xy; axis square; 
%%G=(G~=[G(1,:); G(1:end-1,:)]) | (G~=[G(:,1) G(:,1:end-1)]);
%%imagesc(n,a,G); axis xy;  axis square; colormap([1 1 1; 0 0 0]); 
set(gca,'FontSize',20);
ylabel('\alpha=\beta','FontSize',20); xlabel('n=m','FontSize',20)
title('\gamma=1', 'FontSize',20)
h=text(7.5,2.7,'oscillating'); set(h,'FontSize',15);
h=text(.5,.2,'monostable'); set(h,'FontSize',15);
hold on

figure(7); hold off
stepm=.02; stepn=.02; m=stepm:stepm:10; n=stepn:stepn:10;  clear G;
vals=union(GInm(:),[]); for i=1:length(m), for j=1:length(n), G(i,j)=find(vals==GInm(i,j)); end, end
imagesc(n,m,G); axis xy; axis square; colormap([1 1 1;.8 .8 .8]); 
%%%contour(n,m,G,1); axis xy; axis square; 
%%G=(G~=[G(1,:); G(1:end-1,:)]) | (G~=[G(:,1) G(:,1:end-1)]);
%%imagesc(n,m,G); axis xy;  axis square; colormap([1 1 1; 0 0 0]); 
set(gca,'FontSize',20);
ylabel('m','FontSize',20); xlabel('n','FontSize',20)
title('\alpha=\beta=2, \gamma=1', 'FontSize',20)
h=text(5,9,'oscillating'); set(h,'FontSize',15);
h=text(.5,.5,'monostable'); set(h,'FontSize',15);
hold on

T21=3; A1=4; dI1=5; T12=6; A2=7; RNAP=8; RNaseH=9;  % indices into data{}
a0 = 20; % ratio of kcat/KM for RNAP vs RNaseH in literature
b0 = 20; % ratio of kcat/KM for RNAP vs RNaseH in literature
c0 = 0.02; % 0.02 ~ min k_assoc / (kcat/KM) RNaseH
m0 = 1;
n0 = 1;

a0 = 1.3;  % empirically a bit better for batch 2, and twice this for batch 1.
b0 = .5;
c0 = .4;
m0 = .4;
n0 = .4;
%%% none of the constants a0...n0 matters for the relative parameter scoring with geometric-mean placement

clear aa bb cc nn mm
for j=1:37  %% compute ostensible simple model params from experimental params
 if j>=25 && j<=37, a0=2.6; b0=1.0; end % batch 1
 if j>=1 && j<=24, a0=1.3; b0=0.5; end % batch 2
 mm(j) = m0 * 4 * (data{j,dI1} - data{j,A1} + .5 * data{j,T21}) / data{j,T21};
 nn(j) = n0 * 4 * (data{j,A2} - .5 * data{j,T12}) / data{j,T12};
 aa(j) = a0 * data{j,RNAP} / data{j,RNaseH} * data{j,T12} / (data{j,dI1} - data{j,A1} + .5 * data{j,T21}); 
 bb(j) = b0 * data{j,RNAP} / data{j,RNaseH} * data{j,T21} / (data{j,A2} - .5 * data{j,T12});
 cc(j) = c0 * 2/(1/data{j,T12}+1/data{j,T21}) / data{j,RNaseH};  
end
figure(8); hold off; clf; axis([0 max(max(mm),max(nn)) 0 max(max(aa),max(bb))]); hold on

for j=1:37 
 %% j=1:24 are reactions 14:37 in manuscript: default parameters correspond to trajectory 21 for batch 2
 %% j=25:37 are reactions 1:13 in manuscript: default parameters correspond to trajectory 13 for batch 1
 if j>=25 && j<=37, a=1.7; b=1.7; c=1; d=0; n=5; m=5; i=37; dj=-24;  end % #13 is ref trajectory for batch 1
 if j>=1 && j<=24, a=1.7; b=1.7; c=1; d=0; n=5; m=5; i=20; dj=13; end  % #33 is ref trajectory for batch 2
 ar = a * aa(j)/aa(i);
 br = b * bb(j)/bb(i);
 abr = sqrt(ar*br);
 cr = c * cc(j)/cc(i);
 nr = n * nn(j)/nn(i);
 mr = m * mm(j)/mm(i);
 % nmr = max(nr,mr);  %% for some reason, this works better, but is not justifiable.
 nmr = sqrt(nr*mr);
 if 0
 Gv=oscIIsnm_plot(ar,br,cr,0,nr,mr);  drawnow; % pause
 end
  % tick='ko'; ms=max(1,15*(.8-abs(Damp(j))));
  % if Damp(j)<.15, tick='ko'; ms=5+100*(.15-Damp(j))/3; else tick='kx'; ms=5+5*Damp(j); end
  %%%%%if Damp(j)<.15, tick='ko'; ms=10; else tick='kx'; ms=10; end
  if Damp(j)<.15, tick='ko'; elseif Damp(j)<.5, tick='k.'; else tick='kx'; end; ms=10;
  % if Gv<0
  %  if Damp(j)<.15, tick='ko'; ms=10; else tick='kx'; ms=10; end
  % else
  %  if Damp(j)<.15, tick='ro'; ms=10; else tick='rx'; ms=10; end
  % end
 fprintf(1,'%d: %4.1f %4.1f %4.1f %4.1f %4.1f = %5.2f = %4.1f %4.1f %4.1f %4.1f %4.1f\n',...
        j, aa(j),bb(j),cc(j),nn(j),mm(j),  Damp(j),  ar,br,cr,nr,mr);
 figure(3); plot(min(3,br),min(3,ar),tick, 'MarkerSize', ms, 'LineWidth', 1.5); 
 if ids, h=text(min(3,br),min(3,ar),sprintf('%d',j+dj)); set(h,'Color','r'); end

 figure(6); plot(min(10,nmr),min(3,abr),tick, 'MarkerSize', ms, 'LineWidth', 1.5);
 % figure(6); plot(min(10,nmr),min(3,abr),tick, 'MarkerSize', ms, 'LineWidth', 3, 'Color', abs(Damp(j))*[1 1 1]);
 if ids, h=text(min(10,nmr),min(3,abr),sprintf('%d',j+dj)); set(h,'Color','r'); end

 figure(7); plot(min(10,nr),min(10,mr),tick, 'MarkerSize', ms, 'LineWidth', 1.5);
 if ids, h=text(min(10,nr),min(10,mr),sprintf('%d',j+dj)); set(h,'Color','r'); end

 if 0
  Gv=oscIIsnm_plot(aa(j),bb(j),cc(j),0,nn(j),mm(j), 20);
  if Gv<0, 
   if Damp(j)<.15, tick='ko'; ms=10; else tick='kx'; ms=10; end
  else
   if Damp(j)<.15, tick='ro'; ms=10; else tick='rx'; ms=10; end
  end
  figure(8); plot( sqrt(nn(j)*mm(j)), sqrt(aa(j)*bb(j)), tick, 'MarkerSize', 10);
  h=text(sqrt(nn(j)*mm(j)), sqrt(aa(j)*bb(j)), ...
     sprintf('%d: abr=%3.1f, mnr=%3.2f, c=%3.1f', j, aa(j)/bb(j), mm(j)/nn(j), cc(j))); 
  clrs='rgcbk'; set(h,'Color',clrs(ceil(rand(1)*5)));
 end
 % pause
end

hold off

%% annotations for figure
figure(6)
h=text(5.2,2,'(a)'); set(h,'FontSize',15)
h=text(5.2,1.25,'(b)'); set(h,'FontSize',15)
h=text(4.2,2.75,'#8'); set(h,'FontSize',15)
h=text(7.8,1,'#13'); set(h,'FontSize',15)

