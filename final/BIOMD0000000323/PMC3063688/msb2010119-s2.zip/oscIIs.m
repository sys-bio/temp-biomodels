function dYdT=oscIIs(T,Y,Y0,a,b,c,d,n) 
% Design II oscillator, simple model, essential parameters
%
% a = kp [T12tot] / KA / kd
% b = kp [T21tot] / KI / kd
% c = 1 / tau / kd
% d = kp [T11tot] / KA / kd
% n = n
%
% x = [rA1] / KA
% y = [rI2] / KI
% u = [T12A2] / [T12tot]
% v = [T21A1] / [T21tot]
% w = [T11A1] / [T11tot] = v
% s = t / tau
% 
% c dx/ds = a u - x + d w
% c dy/ds = b v - y
%   du/ds = 1/(1+y^n) - u
%   dv/ds = 1/(1+x^-n) - v


x = Y(1); y = Y(2); u = Y(3); v = Y(4); w = v;

dx = (a*u - x + d*w)/c;
dy = (b*v - y)/c;
du = 1/(1+y^n) - u;
dv = (1-1/(1+x^n)) - v;

dYdT = [dx dy du dv]'; 



