global showit
showit=0;


% step=.1;
% step=.02;
step=.005;
clear G
for a=step:step:3
 for b=step:step:3
  i=round(a/step); j=round(b/step);
  Gvector=oscIIs_plot(a,b,1,0,5); 
  G(i,j) = eval(char(Gvector+2+'0'));
  if showit, figure(1); title(sprintf('\\alpha=%5.3f   \\beta=%5.3f   G=%d',a,b,G(i,j))); drawnow; end
 end
 if ~showit, disp([3 a]); end
end 
GI=G;
a=step:step:3; b=step:step:3; clear G;
vals=union(GI(:),[]); for i=1:length(a), for j=1:length(b), G(i,j)=find(vals==GI(i,j)); end, end
figure(3); imagesc(b,a,G); axis xy; axis square; ylabel('\alpha'); xlabel('\beta')
colorbar; cm=rand(length(vals),3); colormap(cm); vals


% stepa=.02; stepn=.05;
stepa=.005; stepn=.02;
clear G
for a=stepa:stepa:3
 for n=stepn:stepn:10
  i=round(a/stepa); j=round(n/stepn);
  Gvector=oscIIs_plot(a,a,1,0,n); 
  G(i,j) = eval(char(Gvector+2+'0'));
  if showit, figure(1); title(sprintf('\\alpha=\\beta=%5.3f   n=%5.3f   G=%d',a,n,G(i,j)));  drawnow; end
 end
 if ~showit, disp([6 a]); end
end 
GIn=G; 
% there is some consistent glitch; but when run by hand, the results are as expected
GIn=GIn.*(GIn<=3) + (GIn>3); 
a=stepa:stepa:3; n=stepn:stepn:10;  clear G;
vals=union(GIn(:),[]); for i=1:length(a), for j=1:length(n), G(i,j)=find(vals==GIn(i,j)); end, end
figure(6); imagesc(n,a,G); axis xy; axis square; ylabel('\alpha=\beta'); xlabel('n')
colorbar; cm=rand(length(vals),3); colormap(cm); vals


%stepm=.1; stepn=.1;
stepm=.02; stepn=.02;
clear G
for m=stepm:stepm:10
 for n=stepn:stepn:10
  i=round(m/stepm); j=round(n/stepn);
  Gvector=oscIIsnm_plot(2,2,1,0,n,m); 
  G(i,j) = eval(char(Gvector+2+'0'));
  if showit, figure(1); title(sprintf('n=%5.3f m=%5.3f  G=%d',n,m,G(i,j)));  drawnow; end
 end
 if ~showit, disp([7 m]); end
end 
GInm=G; 
m=stepm:stepm:10; n=stepn:stepn:10;  clear G;
vals=union(GInm(:),[]); for i=1:length(m), for j=1:length(n), G(i,j)=find(vals==GInm(i,j)); end, end
figure(7); imagesc(n,m,G); axis xy; axis square; ylabel('m'); xlabel('n')
colorbar; cm=rand(length(vals),3); colormap(cm); vals

showit=1;
