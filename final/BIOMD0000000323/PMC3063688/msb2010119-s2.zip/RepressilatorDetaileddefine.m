function ydot=RepressilatorDetaileddefine (t,y,flags, KM31, kpc31, KMF31, kpFc31, KMh1, khc1, kTA31, kAI1, kTAI31, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, KM23, kpc23, KMF23, kpFc23, KMh3, khc3, kTA23, kAI3, kTAI23, R, Rh)


% define ODEs for Design III oscillator (Detailed model)

T31 = y(1); A1 = y(2); rI1 = y(3); T31A1 = y(4); A1rI1 = y(5);
T12 = y(6); A2 = y(7); rI2 = y(8); T12A2 = y(9); A2rI2 = y(10);
T23 = y(11); A3 = y(12); rI3 = y(13); T23A3 = y(14); A3rI3 = y(15);

% calculate available enzyme concentrations

L = T31A1/KM31 + T31/KMF31 + T12A2/KM12 + T12/KMF12 + T23A3/KM23 + T23/KMF23;
Rfree = R/(1 + L);

Lh = A1rI1/KMh1 + A2rI2/KMh2 + A3rI3/KMh3;
Rhfree = Rh/(1 + Lh);

% ODEs

T31dot = - kTA31*T31*A1 + kTAI31*T31A1*rI1;
A1dot = - kAI1*A1*rI1 - kTA31*T31*A1 + khc1/KMh1*Rhfree*A1rI1;
rI1dot = kpc12/(KM12+Rfree)*Rfree*T12A2 + kpFc12/(KMF12+Rfree)*Rfree*T12 - kAI1*A1*rI1 - kTAI31*T31A1*rI1;
T31A1dot = - T31dot;
A1rI1dot = - A1dot - T31A1dot;

T12dot = - kTA12*T12*A2 + kTAI12*T12A2*rI2;
A2dot = - kAI2*A2*rI2 - kTA12*T12*A2 + khc2/KMh2*Rhfree*A2rI2;
rI2dot = kpc23/(KM23+Rfree)*Rfree*T23A3 + kpFc23/(KMF23+Rfree)*Rfree*T23 - kAI2*A2*rI2 - kTAI12*T12A2*rI2;
T12A2dot = - T12dot;
A2rI2dot = - A2dot - T12A2dot;

T23dot = - kTA23*T23*A3 + kTAI23*T23A3*rI3;
A3dot = - kAI3*A3*rI3 - kTA23*T23*A3 + khc3/KMh3*Rhfree*A3rI3;
rI3dot = kpc31/(KM31+Rfree)*Rfree*T31A1 + kpFc31/(KMF31+Rfree)*Rfree*T31 - kAI3*A3*rI3 - kTAI23*T23A3*rI3;
T23A3dot = - T23dot;
A3rI3dot = - A3dot - T23A3dot;


ydot=[T31dot;A1dot;rI1dot;T31A1dot;A1rI1dot;T12dot;A2dot;rI2dot;T12A2dot;A2rI2dot;T23dot;A3dot;rI3dot;T23A3dot;A3rI3dot];
