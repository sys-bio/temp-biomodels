
% Design III

% (occasionally crashes on sims.... bad initial conditions... run it again and it will be OK)

figure(5); hold off
step=.005; a=step:step:3; b=step:step:3;  clear G;
vals=union(GIII(:),[]); for i=1:length(a), for j=1:length(b), G(i,j)=find(vals==GIII(i,j)); end, end
imagesc(b,a,G); axis xy;  axis square; colormap([1 1 1; .8 .8 .8; .6 .6 .6]); 
%%G=(G~=[G(1,:); G(1:end-1,:)]) | (G~=[G(:,1) G(:,1:end-1)]);
%%imagesc(b,a,G); axis xy;  axis square; colormap([1 1 1; 0 0 0]); 
%%%contour(b,a,G,1,'k'); axis xy; axis square; 
set(gca,'FontSize',20); 
ylabel('\alpha','FontSize',20); xlabel('\beta','FontSize',20)
title('n=5', 'FontSize',20)
h=text(.2,.2,'monostable'); set(h,'FontSize',15);
h=text(.2,1.2,'oscillating'); set(h,'FontSize',15);
h=text(.2,2.5,'spiraling out'); set(h,'FontSize',15);
hold on

figure(9); hold off
stepa=0.005; a=stepa:stepa:3; stepn=0.02; n=stepn:stepn:10;  clear G;
vals=union(GIIIn(:),[]); for i=1:length(a), for j=1:length(n), G(i,j)=find(vals==GIIIn(i,j)); end, end
imagesc(n,a,G); axis xy; axis square; colormap([1 1 1;.8 .8 .8; .9 .9 .9; .6 .6 .6]); 
%%%contour(n,a,G,1); axis xy; axis square; 
%%G=(G~=[G(1,:); G(1:end-1,:)]) | (G~=[G(:,1) G(:,1:end-1)]);
%%imagesc(n,a,G); axis xy;  axis square; colormap([1 1 1; 0 0 0]); 
set(gca,'FontSize',20);
ylabel('\alpha','FontSize',20); xlabel('n','FontSize',20)
title('\beta=0.3', 'FontSize',20)
h=text(6,1,'oscillating'); set(h,'FontSize',15);
h=text(6,.2,'monostable'); set(h,'FontSize',15);
h=text(6,2.5,'spiraling out'); set(h,'FontSize',15);
hold on

T31=2; A1=3; T12=4; A2=5; T23=6; A3=7; RNAP=8; RNaseH=9; 

a0=4e8;  % in /Molar, based on typical literature values
a0=a0/20;     % adjustment comparable to that suggested for Design I
b0=1e-7; % in Molar, based on typical literature values
n0=.4;   % if Hill coefficient is about half that expected for perfect hybridization

a=1.7; b=.3; n=3.5; i=27; %% default parameters correspond to trajectory 27 
ai = a0 * (data{i,T12} * data{i,T23} * data{i,T31})^(1/3) * data{i,RNAP} / data{i,RNaseH};
bi = b0 / ( (data{i,A1}-data{i,T31}/2) * (data{i,A2}-data{i,T12}/2) * (data{i,A3}-data{i,T23}/2) )^(1/3); 
ni = n0 * 4 * ( (data{i,A1}-data{i,T31}/2)/data{i,T31} *... 
                (data{i,A2}-data{i,T12}/2)/data{i,T12} *... 
                (data{i,A3}-data{i,T23}/2)/data{i,T23} )^(1/3);
for j=1:27 % 16 exploratory reactions (1:16) and subsequent trajectories (17:27) in manuscript
 aj = a0 * (data{j,T12} * data{j,T23} * data{j,T31})^(1/3) * data{j,RNAP} / data{j,RNaseH};
 bj = b0 / ( (data{j,A1}-data{j,T31}/2) * (data{j,A2}-data{j,T12}/2) * (data{j,A3}-data{j,T23}/2) )^(1/3); 
 nj = n0 * 4 * ( (data{j,A1}-data{j,T31}/2)/data{j,T31} *... 
                 (data{j,A2}-data{j,T12}/2)/data{j,T12} *... 
                 (data{j,A3}-data{j,T23}/2)/data{j,T23} )^(1/3);
 ar = a * aj / ai;
 br = b * bj / bi; 
 nr = n * nj / ni;
 % if Damp(j)<.15, tick='ko'; ms=10; else tick='kx'; ms=10; end
 if Damp(j)<.15, tick='ko'; elseif Damp(j)<.5, tick='k.'; else tick='kx'; end; ms=10;
 fprintf(1,'%d: %4.1f %4.1f %4.1f = %5.2f = %4.1f %4.1f %4.1f \n',...
        j, aj,bj,nj,  Damp(j),  ar,br,nr);
 figure(5); plot(min(3,br),min(3,ar),tick, 'MarkerSize', ms, 'LineWidth', 1.5); 
 % figure(5); h=text(min(3,br),min(3,ar),sprintf('%d: n=%3.1f',j-16,nr)); set(h,'Color','c');
 figure(9); plot(min(10,nr),min(3,ar),tick, 'MarkerSize', ms, 'LineWidth', 1.5); 
 % figure(9); h=text(min(10,nr),min(3,ar),sprintf('%d: b=%3.1f',j-16,br)); set(h,'Color','c');
 if 0
     oscIIIs_plot(ar,br,nr, 20); drawnow; % pause
 end
end

hold off


%% annotations for figure
figure(9)
h=text(4.9,1,'(a)'); set(h,'FontSize',15)
h=text(4.9,2.5,'(b)'); set(h,'FontSize',15)
h=text(2.45,1.85,'#27'); set(h,'FontSize',15)
