function G=oscIIs_plot(a,b,c,d,n, tmult) 
% Design II oscillator, simple model, essential parameters -- plot nullclines & sample trajectories
%
% a = kp [T12tot] / KA / kd
% b = kp [T21tot] / KI / kd
% c = 1 / tau / kd
% d = kp [T11tot] / KA / kd
% n = n
%
% x = [rA1] / KA
% y = [rI2] / KI
% u = [T12A2] / [T12tot]
% v = [T21A1] / [T21tot]
% w = [T11A1] / [T11tot] = v
% s = t / tau
% 
% c dx/ds = a u - x + d w
% c dy/ds = b v - y
%   du/ds = 1/(1+y^n) - u
%   dv/ds = 1/(1+x^-n) - v

global showit

if nargin==5, tmult=20; end

x=0:.001:4;


y=min(4,max(0,a./(x-d*(1-1./(1+x.^n)))-1).^(1/n)); 
if showit, 
  figure(1); 
  % yi=find(y>0); plot(x(yi), y(yi), 'b.', x, b*(1-1./(1+x.^n)), 'k.' ); axis([0 4 0 4]); hold on; 
  h=plot(x, b*(1-1./(1+x.^n)), 'k-', 'LineWidth', 5 ); axis([0 4 0 4]); hold on; 
  y0 = [0 y 0]; 
  ybegin = find( y0(2:end-1)>0 & y0(1:end-2)==0 );  % these index into y
  yend   = find( y0(2:end-1)>0 & y0(3:end)==0 );
 % assert(length(ybegin)==length(yend));
  for i=1:length(ybegin)
    yi = ybegin(i):yend(i); 
    if ybegin(i)>1 && y(ybegin(i))<4 && y(ybegin(i))>0, yi=[ybegin(i)-1 yi]; if y(ybegin(i))>2 && y(ybegin(i))<4, y(ybegin(i)-1)=4; end; end
    if yend(i)<length(y) && y(yend(i))<4 && y(yend(i))>0, yi=[yi yend(i)+1]; if y(yend(i))>2, y(yend(i)+1)=4; end; end
    plot(x(yi), y(yi), 'b-', 'LineWidth',5); 
  end
end

[Ms,SS]=oscIIs_M(a,b,c,d,n); G=zeros(1,size(Ms,3)); if ~isempty(SS), xss=SS(1,:); yss=SS(2,:); end
for i=1:size(Ms,3)
   Growth = max(real(eig(Ms(:,:,i)))); G(i)=sign(Growth);
   Period = max(imag(eig(Ms(:,:,i)))); 
   if showit
     if Growth>0, tick='ro'; elseif Growth<0, tick='r*'; else tick='rs'; end
     plot(xss(i),yss(i),tick, 'MarkerSize', 10, 'LineWidth', 3);
   end
end

if showit
 hold off

 title(sprintf('Design II: \\alpha=%5.3f, \\beta=%5.3f, \\gamma=%5.3f, \\delta=%5.3f, n=%5.2f',a,b,c,d,n));
 legend('x nullcline', 'y nullcline'); xlabel('x'); ylabel('y'); tmax=tmult*(c+1/c);
 Y0=[rand(1)*4, rand(1)*4, rand(1), rand(1)];  
 [T1,Y1]=ode23s('oscIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,c,d,n);
 Y0=[rand(1)*4, rand(1)*4, rand(1), rand(1)];  
 [T2,Y2]=ode23s('oscIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,c,d,n);
 Y0=[rand(1)*4, rand(1)*4, rand(1), rand(1)];  
 [T3,Y3]=ode23s('oscIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,c,d,n);
 Y0=[rand(1)*4, rand(1)*4, rand(1), rand(1)];  
 [T4,Y4]=ode23s('oscIIs', [0 tmax], Y0, odeset('MaxStep',4), a,b,c,d,n);
 hold on; plot(Y1(:,1),Y1(:,2),'r',Y2(:,1),Y2(:,2),'c',Y3(:,1),Y3(:,2),'m',Y4(:,1),Y4(:,2),'g'); hold off;

 figure(2); 
 subplot(2,2,1); plot(T1,Y1(:,1),'r-',T1,Y1(:,2),'g-',T1,Y1(:,3),'b-', T1,Y1(:,4), 'c-'); axis([0 tmax 0 4]);
 legend('x','y','u','v'); xlabel('t'); ylabel('red')
 subplot(2,2,2); plot(T2,Y2(:,1),'r-',T2,Y2(:,2),'g-',T2,Y2(:,3),'b-', T2,Y2(:,4), 'c-'); axis([0 tmax 0 4]);
 legend('x','y','u','v'); xlabel('t'); ylabel('cyan')
 subplot(2,2,3); plot(T3,Y3(:,1),'r-',T3,Y3(:,2),'g-',T3,Y3(:,3),'b-', T3,Y3(:,4), 'c-'); axis([0 tmax 0 4]);
 legend('x','y','u','v'); xlabel('t'); ylabel('magenta')
 subplot(2,2,4); plot(T4,Y4(:,1),'r-',T4,Y4(:,2),'g-',T4,Y4(:,3),'b-', T4,Y4(:,4), 'c-'); axis([0 tmax 0 4]);
 legend('x','y','u','v'); xlabel('t'); ylabel('green')
 
 figure(3)
 plot(T1,Y1(:,1),'r-',T1,Y1(:,2),'g-',T1,Y1(:,3),'b-', T1,Y1(:,4), 'c-','Linewidth',2); axis([0 tmax 0 2]);
 legend('x','y','u','v'); xlabel('s','Fontsize',25); ylabel('a.u.','Fontsize',25);
 set(gca,'Fontsize',25)
end

if isempty(G)
 G=0; keyboard
end
