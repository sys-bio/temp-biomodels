function dYdT=oscIIIs(T,Y,Y0,a,b,n) 
% Design III oscillator, simple model, essential parameters
%
% a = kp [T_{i,i-1}^tot] / kd
% b = Kd / KI
% n = n
%
% x1 = [rI1] / KI
% x2 = [rI2] / KI
% x3 = [rI3] / KI
% s = t * KI / kd
% 
% dx_i/ds = a / (1 + x_{i-1}^n) - (1 - 1/(1+x_i/b))

x1 = Y(1); x2 = Y(2); x3 = Y(3);

dx1 = a / (1 + x3^n) - (1 - 1/(1+x1/b));
dx2 = a / (1 + x1^n) - (1 - 1/(1+x2/b));
dx3 = a / (1 + x2^n) - (1 - 1/(1+x3/b));

dYdT = [dx1 dx2 dx3]'; 



