function M=oscIs_M(a,b,c,n) 
% Design I oscillator, simple model, essential parameters -- linear matrix near steady state
%
% a = kp [T12tot] / KA / kd
% b = kp [T21tot] / KI / kd
% c = 1 / tau / kd
% n = n
%
% x = [rA1] / KA
% y = [rI2] / KI
% u = [T12A2] / [T12tot]
% v = [T21A1] / [T21tot]
% s = t / tau
% 
% c dx/ds = a u - x
% c dy/ds = b v - y
%   du/ds = 1/(1+y^n) - u
%   dv/ds = 1/(1+x^-n) - v

Y = oscIs_ss(a,b,c,n); x=Y(1); y=Y(2); u=Y(3); v=Y(4);

M=zeros(4);
M(1,1) = -1/c;  M(1,3) = a/c;
M(2,2) = -1/c;  M(2,4) = b/c;
M(3,3) = -1; M(4,4) = -1;
M(3,2) = -n*y^(n-1)/((1+y^n)^2);
M(4,1) =  n*x^(n-1)/((1+x^n)^2);


