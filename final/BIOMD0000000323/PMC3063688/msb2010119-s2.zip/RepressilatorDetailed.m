function [Amp,Fre]= RepressilatorDetailed(param,tmax,drawplots)

% default parameter
% param=[248*10^(-9) 0.08 2.67*10^(-6) 0.02 76*10^(-9) 0.05 7.4*10^4 2.4*10^4 5.3*10^4  100*10^(-9) 500*10^(-9) 248*10^(-9) 0.08 2.67*10^(-6) 0.02 76*10^(-9) 0.05 7.4*10^4 2.4*10^4 5.3*10^4  100*10^(-9) 500*10^(-9) 248*10^(-9) 0.08 2.67*10^(-6) 0.02 76*10^(-9) 0.05 7.4*10^4 2.4*10^4 5.3*10^4  100*10^(-9) 500*10^(-9) 75*10^(-9) 30*10^(-9)]

KM31=param(1); kpc31=param(2); KMF31=param(3); kpFc31=param(4); KMh1=param(5); khc1=param(6); kTA31=param(7); kAI1=param(8); kTAI31=param(9);

KM12=param(12); kpc12=param(13); KMF12=param(14); kpFc12=param(15); KMh2=param(16); khc2=param(17); kTA12=param(18); kAI2=param(19); kTAI12=param(20);

KM23=param(23); kpc23=param(24); KMF23=param(25); kpFc23=param(26); KMh3=param(27); khc3=param(28); kTA23=param(29); kAI3=param(30); kTAI23=param(31);

dt=60;

T31tot=param(10); A1tot=param(11); 
T12tot=param(21); A2tot=param(22);
T23tot=param(32); A3tot=param(33);


R=param(34); Rh=param(35);
C=zeros(1,15);

%Inital condition vector 

C(1,1)=T31tot; C(1,2)=A1tot; C(1,3)=A1tot*1.5; 
C(1,6)=T12tot; C(1,7)=A2tot;
C(1,11)=T23tot; C(1,12)=A3tot;

% equilibrate first without enzymes

tspan=[0:dt:1800];                            

options=odeset('AbsTol',1e-10); % set tolerances

[t,y0]=ode23s('RepressilatorDetaileddefine',tspan,C, options, KM31, kpc31, KMF31, kpFc31, KMh1, khc1, kTA31, kAI1, kTAI31, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, KM23, kpc23, KMF23, kpFc23, KMh3, khc3, kTA23, kAI3, kTAI23, 0, 0);

% actual run

tspan=[0:dt:tmax*dt];
[t,y]=ode23s('RepressilatorDetaileddefine',tspan,y0(31,:), options, KM31, kpc31, KMF31, kpFc31, KMh1, khc1, kTA31, kAI1, kTAI31, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, KM23, kpc23, KMF23, kpFc23, KMh3, khc3, kTA23, kAI3, kTAI23, R, Rh);

itot1 = y(:,3) + y(:,5);
itot2 = y(:,8) + y(:,10);
itot3 = y(:,13) + y(:,15);

T31A1 = y(:,4); 
T12A2 = y(:,9);
T23A3 = y(:,14);

% determine amplitude and frequency

iend=itot1(420/dt:tmax); maxe=max(iend); mine=min(iend);
T31A1end=T31A1(420/dt:tmax); Tmaxe=max(T31A1end); Tmine=min(T31A1end);
Amp=(Tmaxe-Tmine)*100/T31tot;
if Amp>5 & Tmaxe>1.3*Tmine,
T31A1domain=find(T31A1end>0.8*Tmaxe);
t=T31A1domain(find((T31A1domain(2:end)-T31A1domain(1:end-1))>1));
if length(t)>1,
Fre=60/(t(2)-t(1));
else Fre=0;
end
else Fre=0;
end
	   
fprintf('.');
if drawplots,
figure(2)

subplot(2,1,1)
x=1:tmax;
ITOT=[itot1(x),itot2(x),itot3(x)];
plot(x,ITOT);
legend('rI1tot','rI2tot','rI3tot');

subplot(2,1,2)
TA=[T31A1(x),T12A2(x),T23A3(x)];
plot(x,TA);
legend('T31A1','T12A2','T23A3');

end
