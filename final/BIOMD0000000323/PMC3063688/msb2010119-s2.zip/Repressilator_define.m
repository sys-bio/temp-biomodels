function ydot=Repressilator_define (t,y,flags, KM31, kpc31, KMF31, kpFc31, KMh1, khc1, kTA31, kAI1, kTAI31, KM12, kpc12, KMF12, kpFc12, KMh2, khc2, kTA12, kAI2, kTAI12, KM23, kpc23, KMF23, kpFc23, KMh3, khc3, kTA23, kAI3, kTAI23, R, Rh, kasso1, kdisso1, kasso2, kdisso2, kasso3, kdisso3)

% define ODEs for three-node ring oscillator

T31 = y(1); A1 = y(2); rI1 = y(3); T31A1 = y(4); A1rI1 = y(5); sI1 = y(6); A1sI1 = y(7); T31A1sI1 = y(8);
T12 = y(9); A2 = y(10); rI2 = y(11); T12A2 = y(12); A2rI2 = y(13); sI2 = y(14); A2sI2 = y(15); T12A2sI2 = y(16);
T23 = y(17); A3 = y(18); rI3 = y(19); T23A3 = y(20); A3rI3 = y(21); sI3 = y(22); A3sI3 = y(23); T23A3sI3 = y(24);

% sI's are the subsequence of rI's produced by RNase H that span the
% toehold-binding region of A's.

L = (T31A1+T31A1sI1)/KM31 + T31/KMF31 + (T12A2+T12A2sI2)/KM12 + T12/KMF12 + (T23A3+T23A3sI3)/KM23 + T23/KMF23;
Rfree = R/(1 + L);

% Repeated estimation of free RNAP concentration using *Newton's Method'*

for k=1:6,
f_R=Rfree*(1+(T31A1+T31A1sI1)/(Rfree+KM31)+T31/(Rfree+KMF31)+(T12A2+T12A2sI2)/(Rfree+KM12)+T12/(Rfree+KMF12)+(T23A3+T23A3sI3)/(Rfree+KM23)+T23/(Rfree+KMF23))-R;
f_R_prime=1+KM31*(T31A1+T31A1sI1)/(Rfree+KM31)^2+KMF31*T31/(Rfree+KMF31)^2+KM12*(T12A2+T12A2sI2)/(Rfree+KM12)^2+KMF12*T12/(Rfree+KMF12)^2+KM23*(T23A3+T23A3sI3)/(Rfree+KM23)^2+KMF23*T23/(Rfree+KMF23)^2;
Rfree=Rfree-f_R/f_R_prime; 
end

% Calculate the fraction of enzyme-bound species for RNase H 

Lh = A1rI1/KMh1 + A2rI2/KMh2 + A3rI3/KMh3;
Rhfree = Rh/(1 + Lh);

% ODEs

T31dot = - kTA31*T31*A1 + kTAI31*T31A1*rI1 - kTA31*T31*A1sI1;
A1dot = - kAI1*A1*rI1 - kTA31*T31*A1 - kasso1*A1*sI1 + kdisso1*A1sI1;
rI1dot = kpc12/(KM12+Rfree)*Rfree*(T12A2+T12A2sI2) + kpFc12/(KMF12+Rfree)*Rfree*T12 - kAI1*A1*rI1 - kTAI31*T31A1*rI1;
sI1dot = - kasso1*A1*sI1 + kdisso1*A1sI1 + kAI1*A1sI1*rI1 - kasso1*T31A1*sI1 + kdisso1*T31A1sI1; 
A1sI1dot = khc1/KMh1*Rhfree*A1rI1 + kasso1*A1*sI1 - kdisso1*A1sI1 - kAI1*A1sI1*rI1 - kTA31*T31*A1sI1;
T31A1sI1dot = kasso1*T31A1*sI1 - kdisso1*T31A1sI1 + kTA31*T31*A1sI1;

T31A1dot = - T31dot - T31A1sI1dot;
A1rI1dot = - A1dot - T31A1dot - A1sI1dot - T31A1sI1dot;

T12dot = - kTA12*T12*A2 + kTAI12*T12A2*rI2 - kTA12*T12*A2sI2;
A2dot = - kAI2*A2*rI2 - kTA12*T12*A2 - kasso2*A2*sI2 + kdisso2*A2sI2;
rI2dot = kpc23/(KM23+Rfree)*Rfree*(T23A3+T23A3sI3) + kpFc23/(KMF23+Rfree)*Rfree*T23 - kAI2*A2*rI2 - kTAI12*T12A2*rI2;
sI2dot = - kasso2*A2*sI2 + kdisso2*A2sI2 + kAI2*A2sI2*rI2 - kasso2*T12A2*sI2 + kdisso2*T12A2sI2; 
A2sI2dot = khc2/KMh2*Rhfree*A2rI2 + kasso2*A2*sI2 - kdisso2*A2sI2 - kAI2*A2sI2*rI2 - kTA12*T12*A2sI2;
T12A2sI2dot = kasso2*T12A2*sI2 - kdisso2*T12A2sI2 + kTA12*T12*A2sI2;

T12A2dot = - T12dot - T12A2sI2dot;
A2rI2dot = - A2dot - T12A2dot - A2sI2dot - T12A2sI2dot;

T23dot = - kTA23*T23*A3 + kTAI23*T23A3*rI3 - kTA23*T23*A3sI3;
A3dot = - kAI3*A3*rI3 - kTA23*T23*A3 - kasso3*A3*sI3 + kdisso3*A3sI3;
rI3dot = kpc31/(KM31+Rfree)*Rfree*(T31A1+T31A1sI1) + kpFc31/(KMF31+Rfree)*Rfree*T31 - kAI3*A3*rI3 - kTAI23*T23A3*rI3;
sI3dot = - kasso3*A3*sI3 + kdisso3*A3sI3 + kAI3*A3sI3*rI3 - kasso3*T23A3*sI3 + kdisso3*T23A3sI3; 
A3sI3dot = khc3/KMh3*Rhfree*A3rI3 + kasso3*A3*sI3 - kdisso3*A3sI3 - kAI3*A3sI3*rI3 - kTA23*T23*A3sI3;
T23A3sI3dot = kasso3*T23A3*sI3 - kdisso3*T23A3sI3 + kTA23*T23*A3sI3;

T23A3dot = - T23dot - T23A3sI3dot;
A3rI3dot = - A3dot - T23A3dot - A3sI3dot - T23A3sI3dot;


ydot=[T31dot;A1dot;rI1dot;T31A1dot;A1rI1dot;sI1dot;A1sI1dot;T31A1sI1dot;T12dot;A2dot;rI2dot;T12A2dot;A2rI2dot;sI2dot;A2sI2dot;T12A2sI2dot;T23dot;A3dot;rI3dot;T23A3dot;A3rI3dot;sI3dot;A3sI3dot;T23A3sI3dot];

