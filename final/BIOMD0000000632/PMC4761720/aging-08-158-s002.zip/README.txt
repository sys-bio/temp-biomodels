This archive contains the parameterized model for 
DNA-damage induced G1-S transition for primary human MRC5 fibroblasts in COPASI-format
as published in the paper Kollarovic et al. 2015

To run the model and display the fits corresponding to the paper do the following:
1. Extract cps-file and *.txt files into the SAME folder.
2. Open the cps-file with COPASI version 4.13 or higher.
3. Go to Tasks->Parameter Estimation
4. Click run.

Displays with simulations and fits should open automatically.

This model was deposited in BioModels Database [1] and assigned the identifier MODEL1505080000.

[1] Li C et al. BioModels Database: An enhanced, curated and annotated resource for published quantitative kinetic models. BMC Systems Biology 2010, 4:92
