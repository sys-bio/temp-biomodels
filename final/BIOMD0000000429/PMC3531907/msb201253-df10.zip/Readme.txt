Readme for single cell volume measurements data files.

MV01.txt: single cell volume measurements 0.1 M NaCl
MV01REP.txt: single cell volume measurements 0.1 M NaCl repitition

MV02.txt: single cell volume measurements 0.2 M NaCl
MV01REP2.txt: single cell volume measurements 0.2 M NaCl repitition
MV01RE32.txt: single cell volume measurements 0.2 M NaCl repitition

In the above data files the columns are :
"min.time.e", "z.scan", "pos", "cellID", 100 "norm.med.sphere.vol2"

where 

min.time.e: time in minutes relative to osmotic shock induction
z.scan: order number of measurement per cell
pos: mutant identification, 1= wt, 2= delta - ssk1 (Sho1 branch only), 3 = delta sho1 (Sln1 branch only) 
cellID: cell identifier
norm.med.sphere.vol2: single cell volume, normed by median of three measurements before osmotic shock induction

MV01-02REPv4.txt: single cell volume measurements for 0.1 and 0.2 M NaCl

In the above data file the columns are :
"time.s0", "z.scan", "pos", "cellID", 100 "norm.med.sphere.vol2"

where 
time.s0: time in minutes relative to osmotic shock induction
z.scan: order number of measurement per cell
pos: the position number indicates repetitio (series) strain and osmotic shock:
pos serie strain shock  
11 1 WT 0
12 1 Dssk1 0
13 1 Dsho1 0
14 1 Dsho1 0.1
15 1 Dssk1 0.1
16 1 WT 0.1
21 2 WT 0.1
22 2 Dssk1 0.1
23 2 Dsho1 0.1
24 2 Dsho1 0.2
25 2 Dssk1 0.2
26 2 WT 0.2
31 3 WT 0.2
32 3 Dssk1 0.2
33 3 Dsho1 0.2
34 3 Dsho1 0
35 3 Dssk1 0
36 3 WT 0

cellID: cell identifier
norm.med.sphere.vol2: single cell volume, normed by median of three measurements before osmotic shock induction
