function [t,c]=ie(i0,b,T,plotToggle)

%%--------------------------------
%This function simulates the time series using Eq. 1 in the main text
%    dc/dt = alpha + c/(kappa + c) - (1 + phi/(delta + gamma*c))*c
%
%Input: i0 = initial condition of c
%       b = parameters [delta, gamma]. Refer to Eq. 1 for definition 
%       T = total simulation time
%       plotToggle = 1 (plot results) or 0 (does not plot results)
%
%Output: t = simulated time
%        c = simulated c
%%---------------------------------

%define global parameters
global k;k=b;

%call function solveie to solve for dc/dt
[t, c] = ode23s('solveie', 0:T, i0);

%plot results
if plotToggle==1
    figure;
    plot(t,c);xlabel('t');ylabel('c');
end
 