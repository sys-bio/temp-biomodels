clear all;

%%------------------------------------------------------------------
%This is a Matlab script that generates Fig. 1D
%The script can be executed by using "script1D" in the command folder
%    dc/dt = alpha + c/(kappa + c) - (1 + phi/(delta + gamma*c))*c
%%---------------------------------------

%define simulation parameters
i0=1; %i0=initial condition of c
T=1000; %total simulation time
phi=logspace(-7,-3,100); %range of phi

%%--Execute routine to find values of c for one delta value-------
delta=1e-4;
for j=1:size(phi,2)
    k=[phi(j) delta 1e-4]; %define system parameters for a high initial density
    [t,c]=ie(i0,k,T,0); %simulate ode
    data1(j)=c(end); %record the final value of x     
    
    k=[phi(j) delta 1e-5]; %define system parameters for a low initial density
    [t,c]=ie(i0,k,T,0); %simulate ode
    data2(j)=c(end); %record the final value of x
end
figure;
line1=loglog(phi,data1);hold all
set(line1,'LineWidth',4,'LineStyle','.','Color',[0 1 0]);
line2=loglog(phi,data2);hold all
set(line2,'LineWidth',4,'LineStyle','.','Color',[1 0 0]);
%%--------------------------------------------

%%--Execute routine to find values of c for one delta value-------
delta=1e-5;
for j=1:size(phi,2)
    k=[phi(j) delta 1e-4]; %define system parameters for a high initial density
    [t,c]=ie(i0,k,T,0); %simulate ode
    data1(j)=c(end); %record the final value of x 
    
    k=[phi(j) delta 1e-5]; %define system parameters for a low initial density
    [t,c]=ie(i0,k,T,0); %simulate ode
    data2(j)=c(end); %record the final value of x
end
line1=loglog(phi,data1);hold all
set(line1,'LineWidth',4,'LineStyle','--','Color',[0 1 0]);
line2=loglog(phi,data2);hold all
set(line2,'LineWidth',4,'LineStyle','--','Color',[1 0 0]);
%%--------------------------------------------

%%--Execute routine to find values of c for one delta value-------
delta=1e-6;
for j=1:size(phi,2)
    k=[phi(j) delta 1e-4]; %define system parameters for a high initial density
    [t,c]=ie(i0,k,T,0); %simulate ode
    data1(j)=c(end); %record the final value of x 
    
    k=[phi(j) delta 1e-5]; %define system parameters for a low initial density
    [t,c]=ie(i0,k,T,0); %simulate ode
    data2(j)=c(end); %record the final value of x
end
line1=loglog(phi,data1);hold all
set(line1,'LineWidth',4,'LineStyle','-','Color',[0 1 0]);
line2=loglog(phi,data2);hold all
set(line2,'LineWidth',4,'LineStyle','-','Color',[1 0 0]);
%%--------------------------------------------

axis([1e-7 1e-3 1e-4 1]);
set(gca,'FontSize',20,'FontName','Arial');
xlabel('\phi');ylabel('Css');