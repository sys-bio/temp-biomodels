function dcdt = solveie(t, c)

%%--------------------------------
%This function calculates values of dc/dt
%    dc/dt = alpha + c/(kappa + c) - (1 + phi/(delta + gamma*c))*c
%
%Input: t = current time
%       x = current variable values
%
%Output: dcdt = values of dc/dt
%
%%---------------------------------

global k;

%define parameters
alpha=1e-3;
kappa=0.5;
phi=k(1);
delta=k(2);
gamma=k(3);

%solve for dcdt
dcdt=zeros(1,1);
dcdt(1)=alpha + c(1)/(kappa+c(1)) - (1+phi/(delta+gamma*c(1)))*c(1);
