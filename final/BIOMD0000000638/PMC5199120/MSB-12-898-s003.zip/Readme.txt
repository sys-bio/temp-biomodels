=======================================
Carrousel model of G-protein activation 
from Bush, Vasen et al 2016.
=======================================

* Bush2016-Simplified-Carrousel-model-of-GPCR:

This model corresponds to scheme shown in Figure 3A and the simulations of Figure 3B-E. We implemented the model in COPASI and exported it as SBML. In the COPASI version of the model the "Parameter Scan" of k_off_R.G used to generate Figures 3B-D is implemented. Note that all the rates are defined as "Global Quantities". The assigment of these global quantities correspond to the parameter values of Table 1 and the assumptions detailed in the Appendix. We uploaded this model to Biomodels, MODEL1610220000.

Parameter for each panel of Figure 3.
Figure 3B: Parameters from Table 1.
Figure 3C: Same as 3B except for k_off_R.G -> 0.0001 s^-1
Figure 3D: Same as 3B except for k_off_R.G -> 10 s^-1
Figure 3E: Same as 3B except for k_Hf_Gt -> 0.11 s^-1


* Bush2016-Extended-Carrousel-model-of-GPCR-RGS: 

This model corresponds to the scheme shown in Figure EV3A and the simulations of Figure EV3B-D. We implemented this model in the same way as the previous. We uploaded this model to Biomodels, MODEL1610220001.

Parameter for each panel of Figure EV3
Figure EV3B: Parameters from Table 1 and RGStot=6000 #/cell, Vcyt=36.4fL, K_d_R.rgs=383nM, k_Hf_xRrgsGt=0.002 s^-1
Figure EV3C: Same as EV3B except for k_off_R.G -> 0.0001 s^-1
Figure EV3D: Same as EV3B except for  k_off_R.G -> 10 s^-1

