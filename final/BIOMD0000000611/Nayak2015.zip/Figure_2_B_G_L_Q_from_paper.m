%% Generating plots for Figure 2B, G, L, Q from the paper

m = sbioloadproject('./Nayak2015 - Blood Coagulation Network - Predicting the Effects of Various Therapies on Biomarkers.sbproj');
modelObj = m.m1;

% Change the simulation time from 21600 (6 hr) to 3600 (1 hr)
simulation_config = getconfigset(modelObj);
set(simulation_config,'StopTime', 3600);                                   % units are defined in the simbiology file as seconds
set(simulation_config.SolverOptions,'RelativeTolerance',1e-4);
set(simulation_config.SolverOptions,'AbsoluteTolerance',1e-6);
set(simulation_config.SolverOptions,'SensitivityAnalysis',0);
set(simulation_config.CompileOptions,'DimensionalAnalysis',0);
set(simulation_config,'SolverType','ode15s');


%% 01. TGA NHP - FVIIa different concentrations
modelObj1 = copyobj(modelObj);
sim_data = [];

% Conc of VIIa reagant in nM
% the concentrations are multiplied by 120/70 as 70 uL plasma is diluted to
% 120 uL as described in the methods section of the paper
VIIa_reagant_conc = (120/70) * [4000; 2000; 1000; 500; 250; 125; 0.1;];                % Experimental level of zero VIIa means only endogenous VIIa (0.1 nM) is there



for index = 1:length(VIIa_reagant_conc) 
    
    % In the model, VIIa Initial Concentration is set by a rule -
    % VIIa = VIIa_ss/Dilution, so I have to vary the VIIa_ss value.
    
    SET_TO_CHANGE = sbioselect(modelObj1,'Type','parameter','Name','VIIa_ss');          % Choose the parameter to be changed - VIIa_ss is a parameter and not a species
    if (strcmp(SET_TO_CHANGE.Name,'VIIa_ss'))
        SET_TO_CHANGE.Value = VIIa_reagant_conc(index,1);
    else
        disp('Setting something other that VIIa_ss -- exiting');
        keyboard;
    end
    
    configsetObj = getconfigset(modelObj1);    
    
    try
        [SOLN_OBJ] = sbiosimulate(modelObj1,configsetObj);
        disp(strcat('solved the system - FVIIa_NHP index->',num2str(index)));
        
    catch
        
        disp('Could not perform experiment - FVIIa in NHP');
        break;
        
    end
    
    % % Now simulate and interpolate so that each output is same length
    [sim_t,sim_thrombin,~] = selectbyname(SOLN_OBJ,'IIa_12mIIa');
    
    sim_thrombin = transpose(interp1(sim_t,sim_thrombin,0:1:3600,'linear','extrap'));
    
    sim_data = [sim_data sim_thrombin];
        
        
end

time_vec = 0:3600;
figure(1); plot(time_vec/60,sim_data(:,1:7)); xlabel('Time (min)'), ylabel('Thrombin (nM'); title ('FVIIa-NHP');
legend('0 nM','125 nM','250 nM','500 nM', '1000 nM', '2000 nM', '4000 nM');

clear sim_data modelObj1;

%% 02. TGA 8DP - FVIIa different concentrations
modelObj2 = copyobj(modelObj);
sim_data = [];

% Conc of VIIa reagant in nM
% the concentrations are multiplied by 120/70 as 70 uL plasma is diluted to
% 120 uL as described in the methods section of the paper
VIIa_reagant_conc = (120/70) * [4000; 2000; 1000; 500; 250; 125; 0.1;];               % Experimental level of zero VIIa means only endogenous VIIa (0.1 nM) is present

for index = 1:length(VIIa_reagant_conc) 
    
    % Set VIII to zero for factor VIII deficient plasma, again VIII is set by a rule ->
    % VIII = VIII_ss/Dilution, so set parameter VIII_ss to zero
    
    SET_TO_ZERO = sbioselect(modelObj2,'Type','parameter','Name','VIII_ss');       % Choose the parameter to be set to zero - VIII_ss is a parameter and not a species
    if (strcmp(SET_TO_ZERO.Name,'VIII_ss'))
        SET_TO_ZERO.Value = 0.0;                                           % set to zero inside the loop, value outside should not be affected
    else
        disp('Setting something other that VIII_ss to zero -- exiting');
        keyboard;
    end
    
      
    % In the model, VIIa Initial Concentration is set by a rule -
    % VIIa = VIIa_ss/Dilution, so I have to vary the VIIa_ss value.
    
    SET_TO_CHANGE = sbioselect(modelObj2,'Type','parameter','Name','VIIa_ss');     % Choose the parameter to be changed - VIIa_ss is a parameter and not a species
    if (strcmp(SET_TO_CHANGE.Name,'VIIa_ss'))
        SET_TO_CHANGE.Value = VIIa_reagant_conc(index,1);
    else
        disp('Setting something other that VIIa_ss -- exiting');
        keyboard;
    end
    
    configsetObj = getconfigset(modelObj2);
   
    
    try
        [SOLN_OBJ] = sbiosimulate(modelObj2,configsetObj);
        disp(strcat('solved the system - FVIIa_8DP index->',num2str(index)));
        
    catch
        
        disp('Could not perform experiment - FVIIa in 8DP');
        break;
        
    end
    
    % Now simulate and interpolate so that each output is same length
    [sim_t,sim_thrombin,~] = selectbyname(SOLN_OBJ,'IIa_12mIIa');
    
    sim_thrombin = transpose(interp1(sim_t,sim_thrombin,0:1:3600,'linear','extrap'));
    
    sim_data = [sim_data sim_thrombin];
    
          
end 
time_vec = 0:3600;
figure(2); plot(time_vec/60,sim_data(:,1:7)); xlabel('Time (min)'), ylabel('Thrombin (nM'); title ('FVIIa-8DP');
legend('0 nM','125 nM','250 nM','500 nM', '1000 nM', '2000 nM', '4000 nM');
clear sim_data modelObj2;

%% 03. - TGA NHP - FXa different concentrations
modelObj3 = copyobj(modelObj);
sim_data = [];

% Conc of VIIa reagant in nM
% the concentrations are multiplied by 120/70 as 70 uL plasma is diluted to
% 120 uL as described in the methods section of the paper
pdXa_reagant_conc = (120/70) * [1; 0.5; 0.25; 0.125; 0.0625; 0.03125; 0.0;];        % in nM

for index = 1:length(pdXa_reagant_conc)          
    
    % In the model, Xa Initial Concentration is set by a rule -
    % Xa = Xa_ss/Dilution, so I have to vary the Xa_ss value. 
    
    SET_TO_CHANGE = sbioselect(modelObj3,'Type','parameter','Name','Xa_ss');       % Xa_ss is set as a parameter, not as a species
    if (strcmp(SET_TO_CHANGE.Name,'Xa_ss'))
        SET_TO_CHANGE.Value = pdXa_reagant_conc(index,1);
    else
        disp('Setting something other that Xa_ss -- exiting');
        keyboard;
    end 

    configsetObj = getconfigset(modelObj3);
   
    try
        [SOLN_OBJ] = sbiosimulate(modelObj3,configsetObj);
        disp(strcat('solved the system - FXa_NHP index->',num2str(index)));
        
    catch
        
        disp('Could not perform experiment - FXa in NHP');
        break;
        
    end
    
    % Now check that the simulation was completed properly
    [sim_t,sim_thrombin,~] = selectbyname(SOLN_OBJ,'IIa_12mIIa');
    
    % Now simulate and interpolate so that each output is same length
    [sim_t,sim_thrombin,~] = selectbyname(SOLN_OBJ,'IIa_12mIIa');
    
    sim_thrombin = transpose(interp1(sim_t,sim_thrombin,0:1:3600,'linear','extrap'));
    
    sim_data = [sim_data sim_thrombin];
    
end 

time_vec = 0:3600;
figure(3); plot(time_vec/60,sim_data(:,1:7)); xlabel('Time (min)'), ylabel('Thrombin (nM'); title ('FXa-NHP');
legend('0 nM','0.03 nM','0.06 nM','0.13 nM', '0.25 nM', '0.5 nM', '1 nM');
clear sim_data modelObj3;

%% 04. TGA 8DP - FXa different concentrations
modelObj4 = copyobj(modelObj);
sim_data = [];

% Conc of VIIa reagant in nM
% the concentrations are multiplied by 120/70 as 70 uL plasma is diluted to
% 120 uL as described in the methods section of the paper
pdXa_reagant_conc = (120/70) * [1; 0.5; 0.25; 0.125; 0.0625; 0.03125; 0.0;];        % in nM

for index = 1:length(pdXa_reagant_conc)        
    
    % Set VIII to zero, again VIII is set by a rule -> 
    % VIII = VIII_ss/Dilution, so set parameter VIII_ss to zero
    
    SET_TO_ZERO = sbioselect(modelObj4,'Type','parameter','Name','VIII_ss');       % Choose the parameter to be set to zero - VIII_ss is a parameter and not a species
    if (strcmp(SET_TO_ZERO.Name,'VIII_ss'))
        SET_TO_ZERO.Value = 0.0;                                           % set to zero inside the loop, value outside should not be affected
    else
        disp('Setting something other that VIII_ss to zero -- exiting');
        keyboard;
    end
    
    
    SET_TO_CHANGE = sbioselect(modelObj4,'Type','parameter','Name','Xa_ss');       % Xa_ss is set as a parameter, not as a species
    if (strcmp(SET_TO_CHANGE.Name,'Xa_ss'))
        SET_TO_CHANGE.Value = pdXa_reagant_conc(index,1);
    else
        disp('Setting something other that Xa_ss -- exiting');
        keyboard;
    end
    
    %%%%%%%%%%%%%%%
    % set the others (which are changed in other experiments) to their default values
    VIIa_ss = sbioselect(modelObj4,'Type','parameter','Name','VIIa_ss');
    VIIa_ss.Value = 0.1;                                                      % The default value in the model
    %%%%%%%%%%%%%%%
    
    configsetObj = getconfigset(modelObj4);
   
    try
        [SOLN_OBJ] = sbiosimulate(modelObj4);
        disp(strcat('solved the system - FXa_8DP index->',num2str(index)));
        
    catch
        
        disp('Could not perform experiment - FXa in 8DP');
        break;
        
    end
    
    % Now simulate and interpolate so that each output is same length
    [sim_t,sim_thrombin,~] = selectbyname(SOLN_OBJ,'IIa_12mIIa');
    
    sim_thrombin = transpose(interp1(sim_t,sim_thrombin,0:1:3600,'linear','extrap'));
    
    sim_data = [sim_data sim_thrombin];
    
    
end 

time_vec = 0:3600;
figure(4); plot(time_vec/60,sim_data(:,1:7)); xlabel('Time (min)'), ylabel('Thrombin (nM'); title ('FXa-8DP');
legend('0 nM','0.03 nM','0.06 nM','0.13 nM', '0.25 nM', '0.5 nM', '1 nM');
clear sim_data modelObj4;
