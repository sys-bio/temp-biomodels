This package contains executable model files featuring the article:

 "Feedbacks, Bifurcations, and Cell Fate Decision-Making in the p53 System"
          by  Hat B, Kochanczyk M, Bogdal MN, and Lipniacki T
                   (PLOS Computational Biology 2016)

The code allows for deterministic simulations of model dynamics in Matlab 
and is provided both for the complete model and for its subordinated 
modules (in isolation): the core regulatory module, cell cycle arrest 
module, and apoptotic module.  In each case, the main executable script
is called 'run_simulation.m'.

When executed, the code for the

  * complete model -- reproduces Fig. 7A from the main text of the article. 

Simulations of isolated modules present selected aspects of their behavior:

 * core module -- behavior in the case of irreparable DNA damage;

 * cell cycle arrest module -- "reversible bistability" which allows for
       arresting cell cycle at a high level of p53_arrester and for 
       returning to normal cell cycle progression when the level of
       p53_arrester decreases;

 * apoptotic module -- the AND logic gate requires the presence of both 
       pro-apoptotic inputs (high level of p53_killer and low level of
       phosphorylated Akt) for inducing apoptosis; the module exhibits
       also an "irreversible bistability" which allows for commitment to 
       apoptosis even when the pro-apoptotic stimuli are withdrawn.

Summary of modules' complexity:

                 Table: Number of equations in modules.
                 ======================================
                   Module           ODEs  algebraic_eqs
                 --------------------------------------
                   core              19         4
                   arrest             6         2
                   apoptotic          8         3
                 --------------------------------------
                   sum (complete)    33    +    9      = 42 molecular species
                 ======================================

-- Fri Sep 18 12:14:29 CEST 2015

