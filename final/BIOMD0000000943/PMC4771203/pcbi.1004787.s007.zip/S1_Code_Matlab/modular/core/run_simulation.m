% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%              The p53 network model by Hat et al. (2016).                %
%                                                                         %
%  This is the *main script* ("driver") for simulating dynamics of the    %
%  regulatory core of the model.                                          %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


%% Simulation protocol settings

sec_ = 1;  min_= 60*sec_;  hour_ = 60*min_;  day_ = 24*hour_;
%
tp1 = 30*day_;      % duration of the pre-damage (equilibration) phase
tp2 =  3*day_;      % duration of the post-damage (relaxation) phase
%
dt = 10*sec_;       % trajectory: timepoints interval
tspan1 = 0:dt:tp1;  % trajectory: timepoints of the equilibration phase
tspan2 = 0:dt:tp2;  % trajectory: timepoints of the relaxation phase


%% Initial conditions

global Rb_tot;  global SIAH1_tot;  global Bad_tot;  global BclXL_tot;
Rb_tot    = 3e5;
SIAH1_tot = 1e5;
Bad_tot   = 6e4;    % [BMC Syst.Biol.2013:: gate AND: 6e4, gate OR: 2e5] 
BclXL_tot = 1e5;    % [BMC Syst.Biol.2013: 1e5]

%------------------------------------------------
y0 = zeros(1,33);
y0( 1) =  0;        % DNA_DSB (DNA damage)
y0( 2) =  0;        % ATM_p
y0( 3) = SIAH1_tot; % SIAH1_0
y0( 4) =  0;        % HIPK2
y0( 5) =  0;        % p53_0p
y0( 6) =  0;        % p53_arrester
y0( 7) =  0;        % p53_S46p
y0( 8) =  0;        % p53_killer
y0( 9) =  0;        % Mdm2 mRNA
y0(10) =  0;        % Mdm2_cyt_0p
y0(11) =  0;        % Mdm2_cyt_S166S186p
y0(12) =  0;        % Mdm2_nuc_S166S186p
y0(13) =  0;        % Mdm2_nuc_S166S186p_S395p
y0(14) =  0;        % Wip1 mRNA
y0(15) =  0;        % Wip1
y0(16) =  0;        % PTEN mRNA
y0(17) =  0;        % PTEN
y0(18) =  0;        % PIP3
y0(19) =  0;        % AKT_p
%------------------------------------------------
%
% (Values above are only initial molecule abundancies.
%  Proper protein levels are obtained in equilibrium.)


%% Simulation

% Phase of equilibration:
[t1,Y1] = ode23tb(@p53_network_core_module,tspan1,y0);

% Phase in which (irrepairable) DNA damage is introduced:
Y1(end,1) = 100;
[t2,Y2] = ode23tb(@p53_network_core_module,tspan2,Y1(end,:));


%% Plotting
%
T = [ t1 - t1(end);  t2 ]; % shift timepoints so that IR phase 
T = T / hour_;             % begins at t = 0; set unit to hour
Y = [ Y1; Y2 ];
%
make_plots(T,Y);

