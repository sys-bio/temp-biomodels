% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%              The p53 network model by Hat et al. (2016).                %
%                                                                         %
%  This file contains the definition of the apoptotic module. Most of     %
%  parameters and ODEs are defined here. This file is intended to be      %
%  used by the main simulation script.                                    %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


% The system of ODEs is autonomous => 1st parameter (time) has been omitted.
function dy = p53_network_apoptotic_module(~,y)
%% --------------------------===[ PARAMETERS ]===--------------------------


% Total amounts of molecules per cell --
%
global Bad_tot;         % (Global variables are defined in run_simulation.m 
global BclXL_tot;       %  and used for defining initial conditions.)
Fourteen33_tot = 2e5;   % [BMC Syst.Biol.2013: 2e5]


% Reaction rates --

% protein activation 
%
a1 = 3e-10;      % activation of (pro)caspases by Bax [BMC Syst.Biol.2013: 2e-10]
a2 = 1e-12;      % Caspases autoactivation            [BMC Syst.Biol.2013: 1e-12]

% gene activation
%
q0_bax  = 1e-5;  % spontaneous Bax gene activation 
%
q1_bax  = 3e-13; % Bax gene activation induced by p53 killer
 
% gene inactivation
%
q2 = 3e-3;       % for gene of Bax
    
% transcription
%
s4 = 0.03;       % Bax  mRNA synthesis [BMC Syst.Biol.2013: 0.03]
    
% translation
%
t4 = 0.1;        % Bax  translation [BMC Syst.Biol.2013: 0.2]
    
% protein synthesis    
%
s7 =  30;        % proCaspases sythesis [BMC Syst.Biol.2013: 20]
    
% phosphorylation 
%
p7  = 3e-9;      % Bad phosphorylation by AKT_p [BMC Syst.Biol.2013: 3e-10]
  
% dephosphorylation 
%
d9  = 3e-5;      % spontaneous Bad_p dephosphorylation [BMC Syst.Biol.2013: 3e-5]
    
% proteins binding    
%
b1 = 3e-5;       % Bax and BclXL  [BMC Syst.Biol.2013: 3e-5]
b2 = 3e-3;       % BclXL and Bad_0 [BMC Syst.Biol.2013: 3e-3]
b3 = 3e-3;       % Bad_p and 14-3-3 [BMC Syst.Biol.2013: 3e-3]

% unbinding 
%
u1 = 1e-3;       % Bax:BclXL complex  [BMC Syst.Biol.2013: 1e-4]       
u2 = 1e-3;       % Bad:BclXL complex   [BMC Syst.Biol.2013: 1e-4] 
u3 = 1e-3;       % Bad_p:14-3-3 complex [BMC Syst.Biol.2013: 1e-4] 
      
% mRNA degradation
%
g4 = 3e-4;       % Bax [BMC Syst.Biol.2013: 1e-3]
    
% protein degradation
%  
g9  = 1e-4;      % Bax (delay of apoptosis)  [BMC Syst.Biol.2013: 1e-4] 
g16 = 1e-4;      % Mdm2_nuc_S166S186p_395p degradatoin Ser395p-dependent
g17 = 3e-4;      % proCaspase [BMC Syst.Biol.2013: 2e-4]
g18 = g17;       % Caspase
    

% Hill coefficient
h = 2;           % used in multiple places

% Reusable expressions for genes' activity

AS_BAX  = (q0_bax  + q1_bax *y(8)^h)/(q2+q0_bax  + q1_bax *y(8)^h);  % gene state Bax


%% ----------------------------===[ DYNAMICS ]===--------------------------

dy = zeros(33,1);

% ------- APOPTOTIC MODULE ------------------------------------------------

BclXL_Bad_complex = BclXL_tot - (y(28) + y(29));
Bad_p_Fourteen33_complex = Bad_tot - (BclXL_Bad_complex + y(30) + y(31));
Fourteen33_free = Fourteen33_tot - Bad_p_Fourteen33_complex;

% Bax mRNA
dy(26)= ... 
  +s4*AS_BAX...              % Bax gene transcription
  -g4*y(26);                 % Bax mRNA degradation
  
% Bax (protein, free)
dy(27)=...
  +t4*y(26)...               % Bax mRNA translation 
  +u1*y(29)...               % Bax:BclXL complex dissociation
  -b1*y(28)*y(27)...         % Bax and BclXL binding
  -g9*y(27);                 % Bax degradation

% BclXL (free)
dy(28)=...
  +u2*BclXL_Bad_complex...   % BclXL:Bad complex dissociation
  +u1*y(29)...               % Bax:BclXL complex dissociation
  +g16*y(29)...              % Bax degradation in Bax:BclXL complex
  +p7*y(19)*BclXL_Bad_complex...  % Bad phosphorylation in BclXL:Bad complex
  -b2*y(28)*y(30)...         % BclXL and Bad binding
  -b1*y(28)*y(27);           % Bax and BclXL binding

% Bax:BclXL complex
dy(29)=...
  +b1*y(28)*y(27)...         % Bax and BclXL binding
  -u1*y(29)...               % Bax:BclXL complex dissociation
  -g16*y(29);                % Bax degradation in Bax:BclXL complex 

% Bad_0 (free)
dy(30)=...
  +d9*y(31)...               % Bad_p dephosphorylation 
  +u2*BclXL_Bad_complex...   % BclXL:Bad complex dissociation
  -p7*y(19)*y(30)...         % Bad_0 phosphorylation by AKT_p
  +d9*Bad_p_Fourteen33_complex... % Bad_p dephosphorylation and dissociation in Bad:14_3_3 complex
  -b2*y(30)*y(28);           % BclXL and Bad_0 binding

% Bad_p (free)
dy(31)=...
  +p7*y(19)*y(30)...         % Bad_0 phosphorylation by AKT_p
  +u3*Bad_p_Fourteen33_complex... % Bad:14-3-3 complex dissociation 
  +p7*y(19)*BclXL_Bad_complex...  % Bad phosphorylation in BclXL:Bad complex and complex dissociationn
  -d9*y(31)...               % Bad_p dephosphorylation 
  -b3*y(31)*Fourteen33_free; % Bad_p and 14-3-3 binding

% proCaspases (inactive caspases)
dy(32)=...
  +s7...                     % proCaspase synthesis
  -g17*y(32)...              % proCaspase degradation 
  -a1*y(27)*y(32)...         % caspases activation by active (i.e., free) Bax
  -a2*((y(33))^2)*y(32);     % caspases autoactivation

% Caspases (active caspases)
dy(33)=...
  -g18*y(33)...              % caspases degradation
  +a1*y(27)*y(32) ...        % caspases activation by active (i.e., free) Bax
  +a2*((y(33))^2)*y(32);     % caspases autoactivation

% Note: There are no equations for the core and the cell cycle arrest module.

