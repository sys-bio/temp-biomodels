% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%              The p53 network model by Hat et al. (2016).                %
%                                                                         %
%  This file contains only plotting commands and is intended to be used   %
%  by the main simulation script using the apoptotic module.              %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

function make_plots(T,Y)

figure

t_before_p53_killer = 20; % [h]
time_range = [-t_before_p53_killer  max(T)]; % horizontal axis range
time_label = 'Time [h]';

plot_vars = {{'p53_{killer}',8} ; ...
             {'AKT_p',      19} ; ...
             {'Caspase',    33}};
        
for i = 1:length(plot_vars)
  subplot(1,3,i)
  plot(T,sum(Y(:,plot_vars{i}{2}),2), 'r', 'LineWidth',2);
  xlim(time_range);
  title(plot_vars{i}{1})
  xlabel(time_label);
  ylim([0 1.1e5])
end

end
