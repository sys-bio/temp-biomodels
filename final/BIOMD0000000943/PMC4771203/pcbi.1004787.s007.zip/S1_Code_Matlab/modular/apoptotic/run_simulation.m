% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%              The p53 network model by Hat et al. (2016).                %
%                                                                         %
%  This is the *main script* ("driver") for simulating dynamics of the    %
%  apoptotic module.                                                      %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


%% Simulation protocol settings

sec_ = 1;  min_= 60*sec_;  hour_ = 60*min_;  day_ = 24*hour_;
%
tp1 = 30*day_;      % duration of phase 1 (equlibration with Akt_u only)
tp2 = 50*hour_;     % duration of phase 2 (Akt_u & p53_killer)
tp3 = 40*hour_;     % duration of phase 3 (p53_killer only)
tp4 =  1*day_;      % duration of phase 4 (no stimulation)
%
dt = 10*sec_;       % trajectory: timepoints interval
tspan1 = 0:dt:tp1;  % trajectory: timepoints of phase 1
tspan2 = 0:dt:tp2;  % trajectory: timepoints of phase 2
tspan3 = 0:dt:tp3;  % trajectory: timepoints of phase 3
tspan4 = 0:dt:tp4;  % trajectory: timepoints of phase 4


%% Initial conditions

global Bad_tot;  global BclXL_tot;
Bad_tot   = 6e4;   % [BMC Syst.Biol.2013:: gate AND: 6e4, gate OR: 2e5] 
BclXL_tot = 1e5;   % [BMC Syst.Biol.2013: 1e5]

%------------------------------------------------
y0 = zeros(1,33);
%------------------------------------------------
y0(26) =  0;       % Bax mRNA
y0(27) =  0;       % Bax (free)
y0(28) = BclXL_tot;% BclXL (free)
y0(29) =  0;       % Bax:BclXL complex
y0(30) = Bad_tot;  % Bad_0 (free)
y0(31) =  0;       % Bad_p (free)
y0(32) =  0;       % proCaspase
y0(33) =  0;       % Caspase (active)
%------------------------------------------------
%
% (Values above are only initial molecule abundancies.
%  Proper protein levels are obtained in equilibrium.)


%% Simulation

% Phase 1 (equilibration with Akt_u):
%
y0( 8) = 0;        % p53_killer
y0(19) = 5e4;      % AKT_p := 5e4  =>  AKT_u == AKT_tot-5e4 > 0
[t1,Y1] = ode23tb(@p53_network_apoptotic_module,tspan1,y0);

% Phase 2 (pro-apoptotic stimulation by both Akt_u and p53_killer):
%
Y1(end, 8) = 1e5;  % p53_killer
Y1(end,19) = 5e4;  % AKT_p := 5e4  =>  AKT_u == AKT_tot-5e4 > 0
[t2,Y2] = ode23tb(@p53_network_apoptotic_module,tspan2,Y1(end,:));

% Phase 3 (pro-apoptotic stimulation by p53_killer):
%
Y2(end, 8) = 1e5;  % p53_killer
Y2(end,19) = 0;    % AKT_p := 0  =>  AKT_u == AKT_tot
[t3,Y3] = ode23tb(@p53_network_apoptotic_module,tspan3,Y2(end,:));

% Phase 4 (no pro-apoptotic stimulation):
%
Y3(end, 8) = 0;    % p53_killer
Y3(end,19) = 0;    % AKT_p := 0  =>  AKT_u == AKT_tot
[t4,Y4] = ode23tb(@p53_network_apoptotic_module,tspan4,Y3(end,:));



%% Plotting
%
% shift timepoints so that the rise of p53_killer begins at t = 0
T = [ t1 - t1(end);  t2;  t2(end) + t3;  t2(end) + t3(end) + t4 ]; 
T = T / hour_;   % set unit to hour
Y = [ Y1; Y2; Y3; Y4 ];
%
make_plots(T,Y);

