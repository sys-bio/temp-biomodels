% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%              The p53 network model by Hat et al. (2016).                %
%                                                                         %
%  This is the *main script* ("driver") for simulating dynamics of the    %
%  cell cycle arrest module.                                              %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


%% Simulation protocol settings

sec_ = 1;  min_= 60*sec_;  hour_ = 60*min_;  day_ = 24*hour_;
%
tp1 = 30*day_;      % duration of the pre-arrest (equlibration) phase
tp2 =  1*day_;      % duration of the cell cycle arrest (p53_arrester present) phase
tp3 =  2*day_;      % duration of the post-arrest (p53_arrester no longer present) phase
%
dt = 10*sec_;       % trajectory: timepoints interval
tspan1 = 0:dt:tp1;  % trajectory: timepoints of the pre-arrest phase
tspan2 = 0:dt:tp2;  % trajectory: timepoints of the arrest phase
tspan3 = 0:dt:tp3;  % trajectory: timepoints of the post-arrest phase


%% Initial conditions

global Rb_tot;
Rb_tot    = 3e5;

%------------------------------------------------
y0 = zeros(1,33);
%------------------------------------------------
y0(20) =  0;        % p21 mRNA
y0(21) =  0;        % p21 (free)
y0(22) = Rb_tot;    % Rb1_0 (free)
y0(23) =  0;        % Rb1_0:E2F1 complex
y0(24) =  0;        % Cyclin_E (free)
y0(25) =  0;        % Cyclin_E:p21 complex
%------------------------------------------------
%
% (Values above are only initial molecule abundancies.
%  Proper protein levels are obtained in equilibrium.)


%% Simulation

% Phase of equilibration:
%
[t1,Y1] = ode23tb(@p53_network_arrest_module,tspan1,y0);

% Phase of cell cycle arrest:
%  
Y1(end,6) =  1e5;  % p53_arrester 
[t2,Y2] = ode23tb(@p53_network_arrest_module,tspan2,Y1(end,:));

% Phase of cell cycle de-arrest:
%  
Y2(end,6) =    0;  % p53_arrester 
[t3,Y3] = ode23tb(@p53_network_arrest_module,tspan3,Y2(end,:));


%% Plotting
%
T = [ t1 - t1(end);  t2;  t2(end) + t3 ]; % shift timepoints so that IR phase 
T = T / hour_;                            % begins at t = 0; set unit to hour
Y = [ Y1; Y2; Y3 ];
%
make_plots(T,Y);
