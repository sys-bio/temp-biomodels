% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%              The p53 network model by Hat et al. (2016).                %
%                                                                         %
%  This file contains the definition of the cell cycle arrest module.     %
%  Most of parameters and ODEs are defined here. This file is intended    %
%  to be used by the main simulation script.                              %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


% The system of ODEs is autonomous => 1st parameter (time) has been omitted.
function dy = p53_network_arrest_module(~,y)  
%% --------------------------===[ PARAMETERS ]===--------------------------

% Total amounts of molecules per cell --
%                       % (Global variables are defined in run_simulation.m 
global Rb_tot;          %  and used for defining initial conditions.)
E2F1_tot = 2e5;


% Reaction rates --
 
% gene activation
%
q0_p21 = 1e-5;  % spontaneous p21 gene activation 
%
q1_p21 = 3e-13; % p21 gene activation induced by p53 arrester 
 
% gene inactivation
%
q2 = 3e-3;       % for gene of p21
    
% transcription
%
s5 = 0.1;        % p21 mRNA synthesis
    
% translation
%
t5 = 0.1;        % p21  translation
    
% protein synthesis    
%
s9  = 30;        % Cyclin_E synthesis, induced by E2F1
s10 =  3;        % Cyclin_E synthesis, spontaneous 
    
% phosphorylation 
%
p9  = 3e-6;      % Rb1 phosphorylation by Cyclin_E
p10 =  p9;       % Rb1 phosphorylation by Cyclin_E in Rb1:E2F1 complex 
  
% dephosphorylation 
%
d12 = 1e4;       % Rb1 dephosphorylation  
    
% proteins binding    
%
b4 = 1e-5;       % Rb1 and E2F1 
b5 = 1e-5;       % p21 and Cyclin_E  

% unbinding 
%
u5 = 1e-4;       % Rb1:E2F1 complex
u6 = 1e-4;       % p21:Cyclin_E complex 
        
% mRNA degradation
%
g5 = 3e-4;       % p21
    
% protein degradation
g19 = 3e-4;      % p21
g20 = 1e-4;      % Cyclin_E
    
% Hill coefficient
h = 2;           % used in multiple places
   
% Michaelis--Menten constants:
M2 = 1e5;        % M--M const. in Rb1 dephosphorylation at Ser567 
M3 = 2e5;        % M--M const. in Cyclin_E synthesis by E2F1


% Reusable expressions for genes' activity

AS_p21  = (q0_p21  + q1_p21 *y(6)^h)/(q2+q0_p21  + q1_p21 *y(6)^h);  % gene state p21


%% ----------------------------===[ DYNAMICS ]===--------------------------

dy = zeros(33,1);


%-------- CELL CYCLE ARREST MODULE ----------------------------------------

Rb_p = Rb_tot - (y(22) + y(23));
E2F1 = E2F1_tot - y(23);

% p21 mRNA
dy(20)=...
  +s5*AS_p21...              % p21 gene transcription
  -g5*y(20);                 % p21 mRNA degradation  

% p21 (protein, free)
dy(21)=...
  +t5*y(20)...               % p21 mRNA translation
  +u6*y(25)...               % Cyclin_E:p21 complex dissociation
  -b5*y(24)*y(21)...         % Cyclin_E and p21 binding
  -g19*y(21);                % p21 degradation

% Rb1_0 (free)
dy(22)=...
  +(d12*Rb_p/(M2+Rb_p))...   % Rb1 dephosphorylation at S567
  -b4*y(22)*E2F1...          % Rb1 and E2F1 binding
  -p9*y(24)*y(22)...         % Rb1 phosphorylation by Cyclin_E 
  +u5*y(23);                 % Rb1:E2F1 complex dissociation

% Rb1_0:E2F1 complex
dy(23)=...
  +b4*y(22)*E2F1...          % Rb1 and E2F1 binding
  -u5*y(23)...               % Rb1:E2F1 complex dissociation
  -p10*y(24)*y(23);          % Rb1 phosphorylation in Rb1:E2F1 complex by Cyclin_E

% Cyclin_E (free)
dy(24)=...
  +s10...                    % Cyclin_E synthesis
  +s9*E2F1^2/(M3^2+E2F1^2)...% Cyclin_E synthesis induced by E2F1
  -b5*y(24)*y(21)...         % Cyclin_E and p21 binding
  +u6*y(25)...               % Cyclin_E:p21 complex dissociation
  -g20*y(24);                % Cyclin_E degradation

% Cyclin_E:p21 complex
dy(25)=...
  +b5*y(24)*y(21)...         % Cyclin_E and p21 binding
  -u6*y(25)...               % Cyclin_E:p21 complex dissociation
  -g20*y(25);                % Cyclin_E:p21 complex degradation

% Note: There are no equations for the core and the apoptotic module.
