
This package contains files for performing automated bifurcation analysis 
of isolated modules of the system described in the article:

 "Feedbacks, Bifurcations, and Cell Fate Decision-Making in the p53 System"
          by  Hat B, Kochanczyk M, Bogdal MN, and Lipniacki T
                   (PLOS Computational Biology 2016)


Running instructions
--------------------

In order to execute the continuation and obtain bifurcation diagrams,
please:

1) download the MATCONT package (the command-line flavour named 
cl_matcont...).

Our code was tested with cl_matcont5p4 but we hope that it will be
compatible with later software releases. After downloading, please

2) unarchive the MATCONT package and place files:

   run_matcont_on_core_module.m
   run_matcont_on_arrest_module.m
   run_matcont_on_apoptotic_module.m

in the MATCONT's main directory (i.e., next to MATCONT's init.m) and out

   p53_network_core_module.m
   p53_network_arrest_module.m
   p53_network_apoptotic_module.m

in MATCONT's Systems subdirectory. Then 

3) add the MATCONT's main directory and all its subdirectories to the
MATLAB's path, 

4) enter the MATCONT's main directory and execute the command 

    init

in order to precompile several compute-intensive MATCONT's subroutines.
If files compile fluently, possible warnings about C compiler version
mismatch can be disregarded; under linux, possible error upon unresolved
libstdc++.so dependencies may be tamed by resetting path to dynamic
libraries:

   setenv('LD_LIBRARY_PATH', '')

(Possible errors during script execution, such as e.g.:

   Error using feval
   Undefined function 'BVP_LC_jac' for input arguments of type 
   'function_handle'.

may result from forgetting to compile these C sources or from a compilation
failure.)

5) Now, you can finally execute the commands

   run_matcont_on_core_module
   run_matcont_on_arrest_module
   run_matcont_on_apoptotic_module
    
to obtain bifurcation diagrams shown in the main text of the article:
Fig. 5A, Fig. 2B, Fig. 3C.


System definitions
------------------

MATCONT-readable definitions of system modules were obtained using a
GUI-equipped MATCONT from lists of equations, "coordinates", and parameters
provided for reference as textual files in the modules_definitions directory.

Note: in the core module the trivial equation for DNA DSB (DNA_DSB' = 0) 
was turned into a constant parameter (DNA_DSB).


-- Fri Sep 18 12:32:24 CEST 2015

