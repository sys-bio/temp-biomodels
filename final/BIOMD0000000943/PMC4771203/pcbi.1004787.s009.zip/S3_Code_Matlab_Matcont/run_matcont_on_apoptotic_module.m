% This script, when launched within cl_matcont, reproduces Fig. 3C from the main text.

init  % initialize cl_matcont; triggers compilation if run for the first time


%% Initial conditions

% setting initial conditions
Bax_mRNA=0;      Bax=0;         BclXL=0; 
Bax_BclXL_cx=0;  Bad_0=0;       Bad_p=0; 
proCasp=0;       Casp=0; 

% packing initial conditions into a vector
x0 = [ Bax_mRNA, Bax, BclXL, Bax_BclXL_cx, Bad_0, Bad_p, proCasp, Casp ]; % 1..8
n_eqs = length(x0);


%% Parameters

% setting parameters' values:
p53_killer=0;  % input to the model, bifurcation parameter for the following analysis
AKT_p=0;       % input to the model, kept constant for the following analysis
Bad_tot=6e4;        BclXL_tot=1e5;       Fourteen33_tot=2e5;
a1=3e-10;           a2=1e-12;
q0_bax=1e-5;        q1_bax=3e-13;        q2=3e-3;
s4=0.03;            t4=0.1;              s7=30;
p7=3e-9;            d9=3e-5;
b1=3e-5;            b2=3e-3;             b3=3e-3;
u1=1e-3;            u2=1e-3;             u3=1e-3;
g4=3e-4;            g9=1e-4;             g16=1e-4;
g17=3e-4;           g18=g17;
h=2;

% packing parameter's values into a vector:
params = [ p53_killer,AKT_p,Bad_tot,BclXL_tot,Fourteen33_tot,... %  1.. 5
           a1,a2,q0_bax,q1_bax,q2,s4,t4,s7,p7,d9,...             %  6..15
           b1,b2,b3,u1,u2,u3,g4,g9,g16,g17,g18,h ];              % 16..27
n_params = length(params);


%% Indices

% bifurcation parameter index in the vector of parameters:
bif_par_params_idx = 1;  % p53_killer
%
% bifurcation parameter index in the extended vector of protein levels:
bif_par_traj_idx = n_eqs + 1;

% observables
protein_traj_idx = 8;  % Casp


%% Numerical algorithms settings

% -- ODE solver (used for initial equlibration)

eq_step = 1e4;
eq_duration = 1e7;

ode_opts = odeset;
ode_opts = odeset(ode_opts, 'RelTol',1e-6);

% -- Continuer (used as a base, subject to further changes)

cont_opts_base = contset;
cont_opts_base = contset(cont_opts_base,'MaxCorrIters',  40);
cont_opts_base = contset(cont_opts_base,'MaxNewtonIters',30);
cont_opts_base = contset(cont_opts_base,'Backward',       0);
%
cont_opts_base = contset(cont_opts_base,'Eigenvalues',    1);
cont_opts_base = contset(cont_opts_base,'Multipliers',    0);
cont_opts_base = contset(cont_opts_base,'Singularities',  1);
cont_opts_base = contset(cont_opts_base,'Adapt',          1);
cont_opts_base = contset(cont_opts_base,'TestTolerance',1e-9);


%% Model set-up

S = @p53_network_apoptotic_module;
SFuns = feval(S);


%% Equlibration 1

SFunDydt = SFuns{2};

SFunDydtParams = @(t,x)SFunDydt(t,x, ...
          p53_killer,AKT_p,Bad_tot,BclXL_tot,Fourteen33_tot,a1,a2,...
          q0_bax,q1_bax,q2,s4,t4,s7,p7,d9,b1,b2,b3,u1,u2,u3,...
          g4,g9,g16,g17,g18,h);

[t_eq1,x_eq1] = ode23tb(SFunDydtParams, 0:eq_step:eq_duration, x0, ode_opts);

% figure   % equilibration preview
% plot(t_eq1/3600,x_eq1(:,protein_traj_idx))


%% Continuation 1: lower steady state

[x1_,v1_] = init_EP_EP(S,x_eq1(end,:)',params,bif_par_params_idx); % bif_par is p53_killer

opts = cont_opts_base;
opts = contset(opts,'MinStepsize',    1);
opts = contset(opts,'InitStepsize',  25);
opts = contset(opts,'MaxStepsize',  250);
opts = contset(opts,'MaxNumPoints',1000);
[x1,v1,S1,h1,f1] = cont(@equilibrium,x1_,[],opts);

% figure  % preview of steady state continuation
% cpl(x1,v1,S1, [bif_par_traj_idx, protein_traj_idx]);


%% Equlibration 2

p53_killer = 2e5;
params(1) = p53_killer;
SFunDydtParams = @(t,x)SFunDydt(t,x, ...
          p53_killer,AKT_p,Bad_tot,BclXL_tot,Fourteen33_tot,a1,a2,...
          q0_bax,q1_bax,q2,s4,t4,s7,p7,d9,b1,b2,b3,u1,u2,u3,...
          g4,g9,g16,g17,g18,h);

[t_eq2,x_eq2] = ode23tb(SFunDydtParams, 0:eq_step:eq_duration, x0, ode_opts);

% figure   % equilibration preview
% plot(t_eq2/3600,x_eq2(:,protein_traj_idx))


%% Continuation 2: higher steady state

[x2_,v2_] = init_EP_EP(S,x_eq2(end,:)',params,bif_par_params_idx); % bif_par is p53_killer

opts = cont_opts_base;
opts = contset(opts,'MinStepsize',    1);
opts = contset(opts,'InitStepsize',  25);
opts = contset(opts,'MaxStepsize',  250);
opts = contset(opts,'MaxNumPoints',1000);
opts = contset(opts,'Backward', 1);
[x2,v2,S2,h2,f2] = cont(@equilibrium,x2_,[],opts);

% figure  % preview of steady state continuation
% cpl(x2,v2,S2, [bif_par_traj_idx, protein_traj_idx]);


%% Bifurcation diagram (Fig. 3C)

stb_idcs1 = find(all(f1<=0));
uns_idcs1 = find(any(f1> 0));
stb_idcs2 = find(all(f2<=0));
x1_ss_stb = x1(:,stb_idcs1);   % stable part
x1_ss_uns = x1(:,uns_idcs1);   % unstable part
x2_ss_stb = x2(:,stb_idcs2);   % upper stable steady state

figure
plot(x1_ss_stb(end,:), x1_ss_stb(protein_traj_idx,:), 'b-', 'LineWidth',3);  hold on
plot(x1_ss_uns(end,:), x1_ss_uns(protein_traj_idx,:), 'c--','LineWidth',2); 
plot(x2_ss_stb(end,:), x2_ss_stb(protein_traj_idx,:), 'b-', 'LineWidth',3);  hold on
xlim([0 2e5]);   xlabel('p53_{killer}');
ylim([3e-2 2e5]);   ylabel('Caspase');
set(gca, 'yscale','log');
title(sprintf('Akt_p = %.0f', AKT_p));

