% This script, when launched within cl_matcont, reproduces Fig. 2B from the main text.

init   % initialize cl_matcont; triggers compilation if run for the first time


%% Initial conditions

% setting initial conditions
p21_mRNA=0;     p21=0;
Rb_0=0;         Rb_0_E2F1_cx=0;
CyclinE=0;      CyclinE_p21_cx=0;

% packing initial conditions into a vector
x0 = [ p21_mRNA, p21, Rb_0, Rb_0_E2F1_cx, CyclinE, CyclinE_p21_cx ]; % 1..6
n_eqs = length(x0);


%% Parameters

% setting parameters' values:
p53_arrester=0; % input to the module
Rb_tot=3e5;     E2F1_tot=2e5;
q0_p21=1e-5;    q1_p21=3e-13;    q2=3e-3;
s5=0.1;         t5=0.1;          s9=30;           s10=3;
p9=3e-6;        p10=p9;          d12=1e4;
b4=1e-5;        b5=1e-5;         u5=1e-4;         u6=1e-4;
g5=3e-4;        g19=3e-4;        g20=1e-4;
h=2;            M2=1e5;          M3=2e5;

% packing parameter's values into a vector:
params = [ p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,... %  1.. 6
           s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,...           %  7..17
           g5,g19,g20,h,M2,M3 ];                             % 18..23
n_params = length(params);


%% Indices

% bifurcation parameter index in the vector of parameters:
bif_par_params_idx = 1;  % p53_arrester
%
% bifurcation parameter index in the extended vector of protein levels:
bif_par_traj_idx = n_eqs + 1;

% observables
protein_traj_idx = 5;  % CyclinE


%% Numerical algorithms settings

% -- ODE solver (used for initial equlibration)

eq_step = 1e4;
eq_duration = 1e7;

ode_opts = odeset;
ode_opts = odeset(ode_opts, 'RelTol',1e-6);

% -- Continuer (used as a base, subject to further changes)

cont_opts_base = contset;
cont_opts_base = contset(cont_opts_base,'MaxCorrIters',  40);
cont_opts_base = contset(cont_opts_base,'MaxNewtonIters',30);
cont_opts_base = contset(cont_opts_base,'Backward',       0);
%
cont_opts_base = contset(cont_opts_base,'Eigenvalues',    1);
cont_opts_base = contset(cont_opts_base,'Multipliers',    0);
cont_opts_base = contset(cont_opts_base,'Singularities',  1);
cont_opts_base = contset(cont_opts_base,'Adapt',          1);
cont_opts_base = contset(cont_opts_base,'TestTolerance',1e-9);


%% Model set-up

S = @p53_network_arrest_module;
SFuns = feval(S);


%% Equlibration

SFunDydt = SFuns{2};

SFunDydtParams = @(t,x)SFunDydt(t,x, ...
          p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,...
          s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3);

[t_eq,x_eq] = ode23tb(SFunDydtParams, 0:eq_step:eq_duration, x0, ode_opts);

% figure   % equilibration preview
% plot(t_eq/3600,x_eq(:,protein_traj_idx))


%% Continuation: steady state

[x1_,v1_] = init_EP_EP(S,x_eq(end,:)',params,bif_par_params_idx); % bif_par is p53_arrester

opts = cont_opts_base;
opts = contset(opts,'MinStepsize',    1);
opts = contset(opts,'InitStepsize',  25);
opts = contset(opts,'MaxStepsize',  500);
opts = contset(opts,'MaxNumPoints',1040);
[x1,v1,S1,h1,f1] = cont(@equilibrium,x1_,[],opts);

% figure  % preview of steady state continuation
% cpl(x1,v1,S1, [bif_par_traj_idx, protein_traj_idx]);
% xlim([0 1e5]);   xlabel('p53_{arrester} E');
% ylim([0 2e5]);   ylabel('CyclinE');


%% Bifurcation diagram (Fig. 2B)

uns_idcs = find(any(f1> 0));
x_ss_uns = x1(:,uns_idcs);            % unstable linker
x_ss_stb1 = x1(:,1:uns_idcs(1));      % first  stable branch
x_ss_stb2 = x1(:,uns_idcs(end):end);  % second stable branch

figure
plot(x_ss_stb1(end,:), x_ss_stb1(protein_traj_idx,:), 'b-', 'LineWidth',3);  hold on
plot(x_ss_stb2(end,:), x_ss_stb2(protein_traj_idx,:), 'b-', 'LineWidth',3);  hold on
plot(x_ss_uns(end,:), x_ss_uns(protein_traj_idx,:), 'c--','LineWidth',2); 
xlim([0 1e5]);   xlabel('p53_{arrester}');
ylim([0 2e5]);   ylabel('Cyclin E');

