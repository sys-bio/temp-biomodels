% This script, when launched within cl_matcont, reproduces Fig. 5A from the main text.


init         % initialize cl_matcont; triggers compilation if run for the first time
global lds;  % necessary for drawing limit cycles


%% Initial conditions

% setting initial conditions
ATM_p=0;      SIAH1_0=0;       HIPK2=0; 
p53_0p=0;     p53_arrester=0;  p53_S46p=0;
p53_killer=0; Mdm2_mRNA=0;     Mdm2_cyt_0p=0;
Mdm2_cyt_S166S186p=0;  Mdm2_nuc_S166S186p=0;  Mdm2_nuc_S166S186p_S395p=0;
Wip1_mRNA=0;  Wip1=0;          PTEN_mRNA=0;
PTEN=0;       PIP3=0;          AKT_p=0;

% packing initial conditions into a vector
x0 = [ ATM_p,SIAH1_0,HIPK2,p53_0p,p53_arrester,p53_S46p,...    %  1.. 6
       p53_killer,Mdm2_mRNA,Mdm2_cyt_0p,Mdm2_cyt_S166S186p,... %  7..10
       Mdm2_nuc_S166S186p,Mdm2_nuc_S166S186p_S395p,...         % 11.12
       Wip1_mRNA,Wip1,PTEN_mRNA,PTEN,PIP3,AKT_p ];             % 13..18
n_eqs = length(x0);


%% Parameters

% setting parameters' values:
DNA_DSB=100;
SIAH1_tot=1e5; ATM_tot=1e5;   AKT_tot=1e5;   PIP_tot=1e5;   PI3K_tot=1e5;
q0_pten=1e-5;  q0_wip1=1e-5;  q0_mdm2=1e-4;
q1_pten=3e-13; q1_mdm2=3e-13; q1_wip1=3e-13; q2=3e-3;
s1=0.2;        s2=0.035;      s3=0.1;
t1=0.1;        t2=0.1;        t3=0.1;        s6=300;        s8=30;
p1=3e-4;       p2=1e-8;       p3=3e-8;       p4=1e-10;      p5=1e-8;       
 p6=1e-8;      p8=3e-9;       p11=p4;        p12=1e-9;
d1=1e-8;       d2=3e-5;       d3=1e-4;       d4=1e-10;      d5=1e-4;        
d6=1e-10;      d7=3e-7;       d8=1e-4;       d10=d3;        d11=d4;
i1=1e-3;       g1=3e-4;       g2=3e-4;       g3=3e-4;       g6=3e-5;       
g7=1e-13;      g8=3e-4;       g10=1e-5;      g101=1e-5;     g11=1e-11;     
g12=1e-13;     g13=g12;       g14=1e-4;      g15=3e-5;      g16=1e-4;
h=2;           M1=5;

% packing parameter's values into a vector:
params = [ DNA_DSB,SIAH1_tot,ATM_tot,AKT_tot,PIP_tot,PI3K_tot,... %  1.. 6
           q0_pten,q0_wip1,q0_mdm2,q1_pten,q1_mdm2,q1_wip1,...    %  7..12
           q2,s1,s2,s3,t1,t2,t3,s6,s8,...                         % 13..21
           p1,p2,p3,p4,p5,p6,p8,p11,p12,...                       % 22..30
           d1,d2,d3,d4,d5,d6,d7,d8,d10,d11,i1,...                 % 31..41
           g1,g2,g3,g6,g7,g8,g10,g101,g11,g12,g13,g14,g15,g16,... % 42..55
           h,M1 ];                                                % 56..57
n_params = length(params);


%% Indices

% bifurcation parameter index in the vector of parameters:
bif_par_params_idx = 15;  % s2, PTEN mRNA synthesis rate
%
% bifurcation parameter index in the extended vector of protein levels:
bif_par_traj_idx = n_eqs + 1;

% observables
protein_traj_idx = 7;  % p53_killer


%% Numerical algorithms settings

% -- ODE solver (used for initial equlibration)

eq_step = 1e4;
eq_duration = 1e7;

ode_opts = odeset;
ode_opts = odeset(ode_opts, 'RelTol',1e-6);

% -- Continuer (used as a base, subject to further changes)

cont_opts_base = contset;
cont_opts_base = contset(cont_opts_base,'MaxCorrIters',  40);
cont_opts_base = contset(cont_opts_base,'MaxNewtonIters',30);
cont_opts_base = contset(cont_opts_base,'Backward',       0);
%
cont_opts_base = contset(cont_opts_base,'Eigenvalues',    1);
cont_opts_base = contset(cont_opts_base,'Multipliers',    1);
cont_opts_base = contset(cont_opts_base,'Singularities',  1);
cont_opts_base = contset(cont_opts_base,'Adapt',          1);
cont_opts_base = contset(cont_opts_base,'TestTolerance',1e-9);


%% Model set-up

S = @p53_network_core_module;
SFuns = feval(S);

      
%% Equlibration

SFunDydt = SFuns{2};

SFunDydtParams = @(t,x)SFunDydt(t,x, ...
          DNA_DSB,SIAH1_tot,ATM_tot,AKT_tot,PIP_tot,PI3K_tot,q0_pten, ...
          q0_wip1,q0_mdm2,q1_pten,q1_mdm2,q1_wip1,q2,s1,s2,s3,t1,t2,t3, ...
          s6,s8,p1,p2,p3,p4,p5,p6,p8,p11,p12, ...
          d1,d2,d3,d4,d5,d6,d7,d8,d10,d11,i1, ...
          g1,g2,g3,g6,g7,g8,g10,g101,g11,g12,g13,g14,g15,g16,h,M1);

[t_eq,x_eq] = ode23tb(SFunDydtParams, 0:eq_step:eq_duration, x0, ode_opts);

% figure   % equilibration preview
% plot(t_eq/3600,x_eq(:,protein_traj_idx))


%% Continuation 1/2: steady state

[x1_,v1_] = init_EP_EP(S,x_eq(end,:)',params,bif_par_params_idx); % bif_par is s2

opts = cont_opts_base;
opts = contset(opts,'MinStepsize',     3);
opts = contset(opts,'InitStepsize',   30);
opts = contset(opts,'MaxStepsize',  3000);
opts = contset(opts,'MaxNumPoints', 1270);
opts = contset(opts,'Multipliers',     0);
[x1,v1,S1,h1,f1] = cont(@equilibrium,x1_,[],opts);

% figure  % preview of steady state continuation
% cpl(x1,v1,S1, [bif_par_traj_idx, protein_traj_idx]);
% xlim([0 0.035]);          xlabel('s_2');
% set(gca, 'yscale','log'); ylabel('p53_{killer}');

       
%% Continuation 2/2: limit cycle

assert(length(S1) == 3);
hopf_idx = S1(2).index;
hopf_bif_param = x1(bif_par_traj_idx,hopf_idx);
params(bif_par_params_idx) = hopf_bif_param;
[x2_,v2_] = init_H_LC(S,x1(1:end-1,hopf_idx),params,bif_par_params_idx, ...
                      0.1, 25, 4);

opts = cont_opts_base;
opts = contset(opts,'MinStepsize',  1000);
opts = contset(opts,'InitStepsize',10000);
opts = contset(opts,'MaxStepsize',100000);
opts = contset(opts,'MaxNumPoints',   42);
[x2,v2,S2,h2,f2] = cont(@limitcycle,x2_,v2_,opts);

% figure  % preview of limit cycle continuation
% protein2_traj_idx = 5;  % p53_arrester 
% plotcycle1(x2,v2,S2,[protein_traj_idx,protein2_traj_idx,bif_par_traj_idx])
% xlabel('s_2')
% zlabel('p53_{killer}')
% ylabel('p53_{arrester}')


%% Bifurcation diagram (Fig. 5A)

% steady states
uns_idcs = find(any(f1> 0));
stb_idcs = find(all(f1<=0));
x_ss_stb = x1(:,stb_idcs);
x_ss_uns = x1(:,horzcat(stb_idcs(end,end),uns_idcs));

% limit cycle
floquet_mus = f2(end-n_eqs+1:end,:);
uns_idcs3 = find(sum(abs(floquet_mus(end-1:end,:))) > 2);
stb_idcs3 = find(sum(abs(floquet_mus(end-1:end,:)))<= 2);
x_lc_stb = x2(:,stb_idcs3);
x_lc_uns = x2(:,stb_idcs3);

figure
readout_idx = protein_traj_idx; 
semilogy(x_ss_stb(end,:), x_ss_stb(readout_idx,:), 'b-', 'LineWidth',3);  hold on
semilogy(x_ss_uns(end,:), x_ss_uns(readout_idx,:), 'c--','LineWidth',2);  hold on
%
for j=1:size(x2,2)
  if isempty(find([S2(end-1).index]==j,1))
    mi=min( x2((0:lds.tps-1)*lds.nphase+readout_idx,j) );
    ma=max( x2((0:lds.tps-1)*lds.nphase+readout_idx,j) );
    if ~isempty(find(stb_idcs3==j,1))
      line([x2(end,j) x2(end,j)],[mi ma], ...
          'Color','b', 'Marker', '.', 'MarkerSize', 18)
    else
      line([x2(end,j) x2(end,j)],[mi ma], ...
          'Color','c', 'Marker', 'o', 'MarkerSize', 6)
    end
  else
    % special point
    if j > 2 && j < size(x2,2)-1
      mi=min( x2((0:lds.tps-1)*lds.nphase+readout_idx,j) );
      ma=max( x2((0:lds.tps-1)*lds.nphase+readout_idx,j) );
      line([x2(end,j) x2(end,j)],[mi ma], 'Color','r')
    end
  end
end
semilogy(hopf_bif_param, x1(readout_idx,hopf_idx), 'r.');
%
title(sprintf('s_1 = %.1f;  Hopf and Neimark-Sacker bifurcations are marked in red.',s1));
xlim([0 0.035]);  xlabel('s_2')
ylim([0 2e7]);    ylabel('p53_{killer}');

