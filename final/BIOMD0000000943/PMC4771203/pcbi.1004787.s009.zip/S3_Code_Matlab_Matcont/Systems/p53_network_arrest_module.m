function out = p53_network_arrest_module
out{1} = @init;
out{2} = @fun_eval;
out{3} = @jacobian;
out{4} = @jacobianp;
out{5} = @hessians;
out{6} = @hessiansp;
out{7} = [];
out{8} = [];
out{9} = [];

% --------------------------------------------------------------------------
function dydt = fun_eval(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
dydt=[+s5*((q0_p21+q1_p21*p53_arrester^h)/(q2+q0_p21+q1_p21*p53_arrester^h))-g5*kmrgd(1);;
+t5*kmrgd(1)+u6*kmrgd(6)-b5*kmrgd(5)*kmrgd(2)-g19*kmrgd(2);;
+(d12*(Rb_tot-(kmrgd(3)+kmrgd(4)))/(M2+(Rb_tot-(kmrgd(3)+kmrgd(4)))))-b4*kmrgd(3)*(E2F1_tot-kmrgd(4))-p9*kmrgd(5)*kmrgd(3)+u5*kmrgd(4);;
+b4*kmrgd(3)*(E2F1_tot-kmrgd(4))-u5*kmrgd(4)-p10*kmrgd(5)*kmrgd(4);;
+s10+s9*(E2F1_tot-kmrgd(4))^2/(M3^2+(E2F1_tot-kmrgd(4))^2)-b5*kmrgd(5)*kmrgd(2)+u6*kmrgd(6)-g20*kmrgd(5);;
+b5*kmrgd(5)*kmrgd(2)-u6*kmrgd(6)-g20*kmrgd(6);;];

% --------------------------------------------------------------------------
function [tspan,y0,options] = init
handles = feval(p53_network_arrest_module);
y0=[0,0,0,0,0,0];
options = odeset('Jacobian',handles(3),'JacobianP',handles(4),'Hessians',handles(5),'HessiansP',handles(6));
tspan = [0 10];

% --------------------------------------------------------------------------
function jac = jacobian(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
jac=[ -g5 , 0 , 0 , 0 , 0 , 0 ; t5 , - g19 - kmrgd(5)*b5 , 0 , 0 , -b5*kmrgd(2) , u6 ; 0 , 0 , - kmrgd(5)*p9 - b4*(E2F1_tot - kmrgd(4)) - d12/(M2 - kmrgd(3) + Rb_tot - kmrgd(4)) - (d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 , u5 + kmrgd(3)*b4 - d12/(M2 - kmrgd(3) + Rb_tot - kmrgd(4)) - (d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 , -kmrgd(3)*p9 , 0 ; 0 , 0 , b4*(E2F1_tot - kmrgd(4)) , - u5 - kmrgd(5)*p10 - kmrgd(3)*b4 , -kmrgd(4)*p10 , 0 ; 0 , -kmrgd(5)*b5 , 0 , (s9*(E2F1_tot - kmrgd(4))^2*(2*E2F1_tot - 2*kmrgd(4)))/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 - (s9*(2*E2F1_tot - 2*kmrgd(4)))/(M3^2 + (E2F1_tot - kmrgd(4))^2) , - g20 - b5*kmrgd(2) , u6 ; 0 , kmrgd(5)*b5 , 0 , 0 , b5*kmrgd(2) , - g20 - u6 ];
% --------------------------------------------------------------------------
function jacp = jacobianp(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
jacp=[ (h*p53_arrester^(h - 1)*q1_p21*s5)/(q2 + q0_p21 + p53_arrester^h*q1_p21) - (h*p53_arrester^(h - 1)*q1_p21*s5*(q0_p21 + p53_arrester^h*q1_p21))/(q2 + q0_p21 + p53_arrester^h*q1_p21)^2 , 0 , 0 , s5/(q2 + q0_p21 + p53_arrester^h*q1_p21) - (s5*(q0_p21 + p53_arrester^h*q1_p21))/(q2 + q0_p21 + p53_arrester^h*q1_p21)^2 , (p53_arrester^h*s5)/(q2 + q0_p21 + p53_arrester^h*q1_p21) - (p53_arrester^h*s5*(q0_p21 + p53_arrester^h*q1_p21))/(q2 + q0_p21 + p53_arrester^h*q1_p21)^2 , -(s5*(q0_p21 + p53_arrester^h*q1_p21))/(q2 + q0_p21 + p53_arrester^h*q1_p21)^2 , (q0_p21 + p53_arrester^h*q1_p21)/(q2 + q0_p21 + p53_arrester^h*q1_p21) , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , -kmrgd(1) , 0 , 0 , (p53_arrester^h*q1_p21*s5*log(p53_arrester))/(q2 + q0_p21 + p53_arrester^h*q1_p21) - (p53_arrester^h*q1_p21*s5*log(p53_arrester)*(q0_p21 + p53_arrester^h*q1_p21))/(q2 + q0_p21 + p53_arrester^h*q1_p21)^2 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 , 0 , kmrgd(1) , 0 , 0 , 0 , 0 , 0 , 0 , -kmrgd(5)*kmrgd(2) , 0 , kmrgd(6) , 0 , -kmrgd(2) , 0 , 0 , 0 , 0 ; 0 , d12/(M2 - kmrgd(3) + Rb_tot - kmrgd(4)) + (d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 , -kmrgd(3)*b4 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , -kmrgd(5)*kmrgd(3) , 0 , -(kmrgd(3) - Rb_tot + kmrgd(4))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4)) , -kmrgd(3)*(E2F1_tot - kmrgd(4)) , 0 , kmrgd(4) , 0 , 0 , 0 , 0 , 0 , (d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 , 0 ; 0 , 0 , kmrgd(3)*b4 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , -kmrgd(5)*kmrgd(4) , 0 , kmrgd(3)*(E2F1_tot - kmrgd(4)) , 0 , -kmrgd(4) , 0 , 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , (s9*(2*E2F1_tot - 2*kmrgd(4)))/(M3^2 + (E2F1_tot - kmrgd(4))^2) - (s9*(E2F1_tot - kmrgd(4))^2*(2*E2F1_tot - 2*kmrgd(4)))/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 , 0 , 0 , 0 , 0 , 0 , (E2F1_tot - kmrgd(4))^2/(M3^2 + (E2F1_tot - kmrgd(4))^2) , 1 , 0 , 0 , 0 , 0 , -kmrgd(5)*kmrgd(2) , 0 , kmrgd(6) , 0 , 0 , -kmrgd(5) , 0 , 0 , -(2*M3*s9*(E2F1_tot - kmrgd(4))^2)/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 ; 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , kmrgd(5)*kmrgd(2) , 0 , -kmrgd(6) , 0 , 0 , -kmrgd(6) , 0 , 0 , 0 ];
% --------------------------------------------------------------------------
function hess = hessians(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
hess1=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hess2=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , -b5 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , -b5 , 0 ; 0 , 0 , 0 , 0 , b5 , 0 ];
hess3=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , - (2*d12)/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 - (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , b4 - (2*d12)/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 - (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , -p9 , 0 ; 0 , 0 , 0 , -b4 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hess4=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , b4 - (2*d12)/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 - (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , - (2*d12)/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 - (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , 0 , 0 ; 0 , 0 , -b4 , 0 , -p10 , 0 ; 0 , 0 , 0 , (2*s9)/(M3^2 + (E2F1_tot - kmrgd(4))^2) - (2*s9*(2*E2F1_tot - 2*kmrgd(4))^2)/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 - (2*s9*(E2F1_tot - kmrgd(4))^2)/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 + (2*s9*(E2F1_tot - kmrgd(4))^2*(2*E2F1_tot - 2*kmrgd(4))^2)/(M3^2 + (E2F1_tot - kmrgd(4))^2)^3 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hess5=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , -b5 , 0 , 0 , 0 , 0 ; 0 , 0 , -p9 , 0 , 0 , 0 ; 0 , 0 , 0 , -p10 , 0 , 0 ; 0 , -b5 , 0 , 0 , 0 , 0 ; 0 , b5 , 0 , 0 , 0 , 0 ];
hess6=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hess(:,:,1) =hess1;
hess(:,:,2) =hess2;
hess(:,:,3) =hess3;
hess(:,:,4) =hess4;
hess(:,:,5) =hess5;
hess(:,:,6) =hess6;
% --------------------------------------------------------------------------
function hessp = hessiansp(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
hessp1=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp2=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , (2*d12)/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 + (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , (2*d12)/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 + (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp3=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , -b4 , 0 , 0 , 0 ; 0 , 0 , b4 , 0 , 0 , 0 ; 0 , 0 , 0 , (2*s9*(2*E2F1_tot - 2*kmrgd(4))^2)/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 - (2*s9)/(M3^2 + (E2F1_tot - kmrgd(4))^2) + (2*s9*(E2F1_tot - kmrgd(4))^2)/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 - (2*s9*(E2F1_tot - kmrgd(4))^2*(2*E2F1_tot - 2*kmrgd(4))^2)/(M3^2 + (E2F1_tot - kmrgd(4))^2)^3 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp4=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp5=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp6=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp7=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp8=[ 0 , 0 , 0 , 0 , 0 , 0 ; 1 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp9=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , ((E2F1_tot - kmrgd(4))^2*(2*E2F1_tot - 2*kmrgd(4)))/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 - (2*E2F1_tot - 2*kmrgd(4))/(M3^2 + (E2F1_tot - kmrgd(4))^2) , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp10=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp11=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , -kmrgd(5) , 0 , -kmrgd(3) , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp12=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , -kmrgd(5) , -kmrgd(4) , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp13=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , - 1/(M2 - kmrgd(3) + Rb_tot - kmrgd(4)) - (kmrgd(3) - Rb_tot + kmrgd(4))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 , - 1/(M2 - kmrgd(3) + Rb_tot - kmrgd(4)) - (kmrgd(3) - Rb_tot + kmrgd(4))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp14=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , kmrgd(4) - E2F1_tot , kmrgd(3) , 0 , 0 ; 0 , 0 , E2F1_tot - kmrgd(4) , -kmrgd(3) , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp15=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , -kmrgd(5) , 0 , 0 , -kmrgd(2) , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , -kmrgd(5) , 0 , 0 , -kmrgd(2) , 0 ; 0 , kmrgd(5) , 0 , 0 , kmrgd(2) , 0 ];
hessp16=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 1 , 0 , 0 ; 0 , 0 , 0 , -1 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp17=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 1 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 1 ; 0 , 0 , 0 , 0 , 0 , -1 ];
hessp18=[ -1 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp19=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , -1 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp20=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , -1 , 0 ; 0 , 0 , 0 , 0 , 0 , -1 ];
hessp21=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp22=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , d12/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 + (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , d12/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^2 + (2*d12*(kmrgd(3) - Rb_tot + kmrgd(4)))/(M2 - kmrgd(3) + Rb_tot - kmrgd(4))^3 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp23=[ 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ; 0 , 0 , 0 , (2*M3*s9*(2*E2F1_tot - 2*kmrgd(4)))/(M3^2 + (E2F1_tot - kmrgd(4))^2)^2 - (4*M3*s9*(E2F1_tot - kmrgd(4))^2*(2*E2F1_tot - 2*kmrgd(4)))/(M3^2 + (E2F1_tot - kmrgd(4))^2)^3 , 0 , 0 ; 0 , 0 , 0 , 0 , 0 , 0 ];
hessp(:,:,1) =hessp1;
hessp(:,:,2) =hessp2;
hessp(:,:,3) =hessp3;
hessp(:,:,4) =hessp4;
hessp(:,:,5) =hessp5;
hessp(:,:,6) =hessp6;
hessp(:,:,7) =hessp7;
hessp(:,:,8) =hessp8;
hessp(:,:,9) =hessp9;
hessp(:,:,10) =hessp10;
hessp(:,:,11) =hessp11;
hessp(:,:,12) =hessp12;
hessp(:,:,13) =hessp13;
hessp(:,:,14) =hessp14;
hessp(:,:,15) =hessp15;
hessp(:,:,16) =hessp16;
hessp(:,:,17) =hessp17;
hessp(:,:,18) =hessp18;
hessp(:,:,19) =hessp19;
hessp(:,:,20) =hessp20;
hessp(:,:,21) =hessp21;
hessp(:,:,22) =hessp22;
hessp(:,:,23) =hessp23;
%---------------------------------------------------------------------------
function tens3  = der3(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
%---------------------------------------------------------------------------
function tens4  = der4(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
%---------------------------------------------------------------------------
function tens5  = der5(t,kmrgd,p53_arrester,Rb_tot,E2F1_tot,q0_p21,q1_p21,q2,s5,t5,s9,s10,p9,p10,d12,b4,b5,u5,u6,g5,g19,g20,h,M2,M3)
