
The file p53.bngl is a BioNetGen model file which accompanies the paper:

 "Feedbacks, Bifurcations, and Cell Fate Decision-Making in the p53 System"
          by  Hat B, Kochanczyk M, Bogdal MN, and Lipniacki T
                   (PLOS Computational Biology 2016)

and allows for performing both deterministic (cvODE solver) and stochastic
(Gillespie SSA) simulations of dynamics of the p53 network model.

In export directory an equivalent model definition in SBML can be found.


BNGL model execution instructions
---------------------------------

1)  Download BioNetGen from http://www.bionetgen.org and install the 
software following the step-by-step instructions provided in the tutorial.
(This may require the installation of Perl and, optionally, Java.)

The model has been developed and tested under BioNetGen 2.2.5, in hope that
it will be compatible with later BioNetGen releases.

2)  Place the file 'p53.bngl' into 'Models2' folder in the BioNetGen directory.

3)  In the command window under Windows: change the current working 
directory to 'Models2' in your installed BioNetGen directory hierarchy
by issuing e.g.

  cd "C:\Program Files\BioNetGen-2.2.5-stable\Models2"

and run BioNetGen engine with the following command:

  perl ..\BNG2.pl p53.bngl

(Proceed analogously under Linux/Mac OS X.)

Output will be written in Models2 directory in files:

  p53_TTT_1_equil.gdat 
  p53_TTT_2_irrad.gdat 
  p53_TTT_3_relax.gdat 
 
where actual TTT depends on simulation type: TTT=ode in case of deterministic,
and TTT=ssa in case of stochastic simulation.

Type of simulation (deterministic vs. stochastic) can be chosen by commenting 
or uncommenting respective lines at the end of the code. By default, only the
deterministic simulation is performed, which takes a few seconds. Execution 
of the code should produce trajectory identical to that in Fig. 9, IR = 4 Gy 
(middle panel, bold red line). To calculate stochastic trajectories please 
uncomment respective lines at the end of the code; please note that stochastic
simulation can take more than an hour, depending on the computer speed. 

You can visualize individual trajectories with, e.g., PhiBPlot, which is 
contained in the BioNetGen installation directory (Java required). Under
Windows, double-click the application jar file and select GDAT-file;
under Linux/Mac OS X type in the command line:

  java -jar BIONETGET_DIR/PhiBPlot/PhiBPlot.jar p53_ode_3_relax.gdat 

where BIONETGET_DIR is the BioNetGen main directory.



Optional use of RuleBender
--------------------------

To facilitate model analysis, you can also consider using BioNetGen
within RuleBender, which is an integrated environment with a convenient
trajectory visualization tool (please see http://www.rulebender.org).



-- Fri Sep 18 12:26:53 CEST 2015

