### Script for making all ensemble trajectories for all predictions
##  under the conditions described in the paper
import sys
import os
import scipy
from SloppyCell.ReactionNetworks import *
import SloppyCell.ReactionNetworks.RunInParallel 
Network.full_speed()

print "Starting predictions"

##Get pickled objects from ensemble calculation
pickle_dir = "pickled/"
nets = Utility.load(pickle_dir + "nets.bp")
pruned_ens = Utility.load(pickle_dir + "pruned_ens.bp")

#Method to get either pulsatile or nonpulsatile nets!
def setup(pulsatile=True):
    if pulsatile:
        for n in nets:
            n.setInitialVariableValue("pulsatility",1)
            n.set_var_val("pulsatility",1)
            n.setInitialVariableValue("Jhyd", 0)
            n.set_var_val("Jhyd", 0)
            n.setInitialVariableValue("time_Jhyd_step", 40)
            n.set_var_val("time_Jhyd_step", 40)
    else:
        for n in nets:
            n.setInitialVariableValue("pulsatility",0)
            n.set_var_val("pulsatility",0)
            n.setInitialVariableValue("Jhyd", n.get_var_val("Jhyd_basis"))
            n.set_var_val("Jhyd", n.get_var_val("Jhyd_basis"))
            n.setInitialVariableValue("time_Jhyd_step", 40)
            n.set_var_val("time_Jhyd_step", 40)
    return nets


starttime = 0
endtime = 100
time_slice = [99,100]

### Simple pulsatile simulation of all trajectories in the pruned ensemble for each condition
print "Performing simple pulsatile prediction for all conditions!"
nets  = setup(True)
for n in nets:
    if n == nets[4] or n == nets[0]: ##Hannes change this later!
        print "Doing pulsatile prediction for net ", n.id
        stepsize = n.get_var_val("stepsize")
        times = scipy.arange(starttime, endtime+stepsize, stepsize)
        #times = scipy.arange(0, 100.01, 0.01)
        traj_set = Ensembles.ensemble_trajs(n, times, pruned_ens, slice=time_slice)
        Utility.save(traj_set, pickle_dir + "TRAJ_SET_" + n.id + ".bp")
print "Done performing simple pulsatile prediction for all conditions!"
###

### Simple nonpulsatile simulation of all trajectories in the pruned ensemble for each condition
print "Performing simple nonpulsatile prediction for all conditions!"
nets  = setup(False)
for n in nets:
    print "Doing nonpulsatile prediction for net ", n.id
    stepsize = n.get_var_val("stepsize")
    times = scipy.arange(starttime, endtime+stepsize, stepsize)
    traj_set = Ensembles.ensemble_trajs(n, times, pruned_ens, slice=time_slice)
    Utility.save(traj_set, pickle_dir + "TRAJ_SET_NONPULS_" + n.id + ".bp")
print "Done performing simple nonpulsatile prediction for all conditions!"
###

### Parameter range prediction for heartrate: Heartrate is varied from 60 to 300 bpm,
##   for each heart rate, an ensemble prediction with the pruned ensemble is done 
##   We do this for a nonpulstile net due to running time
print "Performing nonpulsatile range prediction over different heart rates"
nets  = setup(False)
net = nets[4] ##we get reference jhyd values from 220 bpm net
hrbasis = net.get_var_val("heartrate_basis")
hrtest = net.get_var_val("heartrate_test")
jhydbasis = net.get_var_val("Jhyd_basis")
jhydtest = net.get_var_val("Jhyd_test")
heartrates = range(60,301,1)
#hr_pred_traj_sets = [] ##we store all trajectory sets for each heart rate here!
counter = 0.0
for hr in heartrates:
    counter = counter + 1
    print (counter / len(heartrates)) * 100, " % finished" 
    new_jhydtest = jhydbasis + (hr - hrbasis) * ((jhydtest - jhydbasis)/(hrtest - hrbasis))
    if new_jhydtest == 486.5: ##add an epsilon so base hr != test hr
        new_jhydtest = 486.501
    n = net.copy()
    n.set_var_val("Jhyd_test", new_jhydtest)
    net.setInitialVariableValue("Jhyd_test", new_jhydtest)
    ##The step size should not be too important since we have a nonpulsatile simulation
    stepsize = n.get_var_val("stepsize")
    times = scipy.arange(starttime, endtime+stepsize, stepsize)
    traj_set = Ensembles.ensemble_trajs(n, times, pruned_ens, slice=time_slice)
    Utility.save(traj_set, pickle_dir + "heartrate_alter_trajs_hr_" + str(hr) + ".bp")
    del traj_set

print "Done performing nonpulsatile range prediction over different heart rates"
###



### Parameter range prediction (220bpm net) for PSmomATP (=PSmomAdN) values. The same as above, but we vary
##   PSmomATP from 0 to 50. We do it for nonpulsatile nets
print "Performing nonpulsatile range predictions for different PSmomAdN values."
nets  = setup(False)
net = nets[4] ##we take a net for 220 bpm
psmomatps = scipy.arange(0.1, 80.1, 0.5)
#psmom_preds_traj_sets = []
counter = 0.0
for ps in psmomatps:
    counter = counter + 1
    print (counter / len(psmomatps)) * 100, " % finished" 
    n = net.copy()
    n.set_var_val("PSmomATP", ps)
    n.setInitialVariableValue("PSmomATP", ps)
    ##Make altered ensemble: find PSmomATP parameter in pruned ensemble and change it to ps!
    altered_ens = pruned_ens.copy()
    idx = n.GetParameters().keys().index("PSmomATP")
    for pset in altered_ens:
        pset[idx] = ps
    ##The step size should not be so important since we have a nonpulsatile simulation
    stepsize = n.get_var_val("stepsize")
    times = scipy.arange(starttime, endtime+stepsize, stepsize)
    traj_set = Ensembles.ensemble_trajs(n, times, altered_ens, slice=time_slice)
    Utility.save(traj_set, pickle_dir + "psmom_alter_trajs_psmom_" + str(ps) + ".bp")
    #psmom_preds_traj_sets.append(traj_set)
#Utility.save(psmom_preds_traj_sets, pickle_dir + "psmom_preds.bp")
print "Done performing nonpulsatile range predictions for different PSmomAdN values."
###



### Predict pulsatile trajectories for 220 bpm with 0, 0.02, 3 fold
##   CK activity.
print "Performing pulsatile predictions for altered CK activity"
nets  = setup(True)
net = nets[4] ##we take a net for 220 bpm
#ck_factors = [0.1, 0.5, 0.8, 1.5]
ck_factors = [10000]
for f in ck_factors:
    n = net.copy()
    n.set_var_val("VmaxMif_full_activity", n.get_var_val("VmaxMif_full_activity") * f)
    n.setInitialVariableValue("VmaxMif_full_activity", n.get_var_val("VmaxMif_full_activity") * f)
    n.set_var_val("VmaxMMf_full_activity", n.get_var_val("VmaxMif_full_activity") * f)
    n.setInitialVariableValue("VmaxMMf_full_activity", n.get_var_val("VmaxMif_full_activity") * f)
    ##Make altered ensemble: find parameters for CK velocities in pruned ensemble and change it according to f!
    altered_ens = pruned_ens.copy()
    idx_mif = n.GetParameters().keys().index("VmaxMif_full_activity")
    idx_mmf = n.GetParameters().keys().index("VmaxMMf_full_activity")
    for pset in altered_ens:
        pset[idx_mif] = f * pset[idx_mif]
        pset[idx_mmf] = f * pset[idx_mmf]
    stepsize = n.get_var_val("stepsize")
    times = scipy.arange(starttime, endtime+stepsize, stepsize)
    traj_set = Ensembles.ensemble_trajs(n, times, altered_ens, slice=time_slice)
    for t in traj_set:
        t = t.time_slice(99,100)
    Utility.save(traj_set, pickle_dir + "ck_alter_trajs_factor_" + str(f) + ".bp")
print "Done performing pulsatile predictions for altered CK activity"
###


###Predict pulsatile network with 220 bpm for three cases:
##  1)Mi-CK knowckout, 2)MM-CK knockout, 3)both CKs knocked out
print "Performing pulsatile CK knockout predictions"
nets  = setup(True)
factor = 0.02 #We inhibit CK by 98%, like in the experiment
net = nets[4] ##we take a net for 220 bpm

## 1) Mi-CK knockout
n = net.copy()
n.set_var_val("VmaxMif_full_activity", n.get_var_val("VmaxMif_full_activity")* factor)
n.setInitialVariableValue("VmaxMif_full_activity", n.get_var_val("VmaxMif_full_activity")* factor)
altered_ens = pruned_ens.copy()
idx_mif = n.GetParameters().keys().index("VmaxMif_full_activity")
for pset in altered_ens:
    pset[idx_mif] = factor * pset[idx_mif]
stepsize = n.get_var_val("stepsize")
times = scipy.arange(starttime, endtime+stepsize, stepsize)
traj_set = Ensembles.ensemble_trajs(n, times, altered_ens, slice=time_slice)
Utility.save(traj_set, pickle_dir + "ck_knockout_trajs_MiCK.bp")

## 2) MM-CK knockout
n = net.copy()
n.set_var_val("VmaxMMf_full_activity", n.get_var_val("VmaxMMf_full_activity")* factor)
n.setInitialVariableValue("VmaxMMf_full_activity", n.get_var_val("VmaxMMf_full_activity")* factor)
altered_ens = pruned_ens.copy()
idx_mmf = n.GetParameters().keys().index("VmaxMMf_full_activity")
for pset in altered_ens:
    pset[idx_mmf] = factor * pset[idx_mmf]
stepsize = n.get_var_val("stepsize")
times = scipy.arange(starttime, endtime+stepsize, stepsize)
traj_set = Ensembles.ensemble_trajs(n, times, altered_ens, slice=time_slice)
Utility.save(traj_set, pickle_dir + "ck_knockout_trajs_MMCK.bp")

###Do the same knockout predictions as above, but with 100% knockout, not only 98%
print "Performing pulsatile CK knockout predictions with full CK knockout"
nets  = setup(True)
factor = 0.0 #We inhibit CK by 100%
net = nets[4] ##we take a net for 220 bpm

## 1) Mi-CK knockout
n = net.copy()
n.set_var_val("VmaxMif_full_activity", n.get_var_val("VmaxMif_full_activity")* factor)
n.setInitialVariableValue("VmaxMif_full_activity", n.get_var_val("VmaxMif_full_activity")* factor)
altered_ens = pruned_ens.copy()
idx_mif = n.GetParameters().keys().index("VmaxMif_full_activity")
for pset in altered_ens:
    pset[idx_mif] = factor * pset[idx_mif]
stepsize = n.get_var_val("stepsize")
times = scipy.arange(starttime, endtime+stepsize, stepsize)
traj_set = Ensembles.ensemble_trajs(n, times, altered_ens, slice=time_slice)
Utility.save(traj_set, pickle_dir + "ck_full_knockout_trajs_MiCK.bp")

## 2) MM-CK knockout
n = net.copy()
n.set_var_val("VmaxMMf_full_activity", n.get_var_val("VmaxMMf_full_activity")* factor)
n.setInitialVariableValue("VmaxMMf_full_activity", n.get_var_val("VmaxMMf_full_activity")* factor)
altered_ens = pruned_ens.copy()
idx_mmf = n.GetParameters().keys().index("VmaxMMf_full_activity")
for pset in altered_ens:
    pset[idx_mmf] = factor * pset[idx_mmf]
stepsize = n.get_var_val("stepsize")
times = scipy.arange(starttime, endtime+stepsize, stepsize)
traj_set = Ensembles.ensemble_trajs(n, times, altered_ens, slice=time_slice)
Utility.save(traj_set, pickle_dir + "ck_full_knockout_trajs_MMCK.bp")

print "Done performing pulsatile CK knockout predictions with full CK knockout"
###

