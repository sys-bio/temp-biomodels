This supplemental material includes the model in SBML format and
all python scripts necessary to reproduce the results of the 
publication "Analyzing the Functional Properties of the Creatine 
Kinase' System with Multiscale 'Sloppy' Modeling" by
Hannes Hettling and Johannes HGM van Beek. Questions
concerning this supplemental material can be posed to
Hannes Hettling (hettling@few.vu.nl). 

--------------------IMPORTANT-----------------------------------------------
Please note that the calculations performed in this study are 
computationally expensive regarding CPU and memory.
In order to reproduce results 
in reasonable running time, one of the provided scripts (make_predictions.py)
should be executed on a parallel machine (see below). In case you do not
have acces to a high-performance cluster, the authors can provide
pickled python object files containing the simulation results on
request. 
---
Depending on the versions python and scipy installed on your machine,
parameter optimization results can differ, which can slightly affect the
results of the predictions. To make sure to reproduce all values reported
in the paper exactly, you can comment in line 50 in the script 'make_ensemble.py',
which reads in the parameter set optimized on my machine.
----------------------------------------------------------------------------

In order to run the provided python
scripts without errors, the following requirements must be met:
(i)   Python and the packages scipy (http://www.scipy.org) and 
      matplotlib (http://matplotlib.sourceforge.net) must be
      installed on your machine.
(ii)  A modified version of the SloppyCell package, which can be
      found in the supporting information Dataset S1 of the
      article must be installed.
(iii) The directory in which the scipts are executed must be writable
      in order to save simulation results as pickled python object files.
(iv)  About 50 GB of disc memory must be available to store all simulation 
      results.

The filename of the model stored in SBML format Level 2, 
Version 3 is 'ajp_net.xml'.

The provided code consists of the following python scripts which have 
to be executed consecutively in order to reproduce the analysis:

make_ensemble.py :      In this script, model parameters are fit to experiment
		        data and generates a parameter ensemble using 
		        Metropolis-Hastings. The resulting parameter ensemble
		        is saved into the directory 'pickled'.
make_predictions.py :	Here, all predictions under varying conditions
			as described in the manuscript are performed for 
			the whole parameter ensemble by simulating the model
			with each parameter set under each condition. In order
			to obtain results in reasonable
			running time, this script must be executed on a 
			cluster machine with sufficient computing power.
			To enable parallel computing, the python package 
			pypar (http://sourceforge.net/projects/pypar/) must
			be installed on the machine.
get_predict_values.py : Executing this script will print all predicted 
			fluxes and metabolite levels as reported in the paper
			to the screen.
make_plots.py :		Execute this script to reproduce figures 2 to 8
			of the manuscript. All generated figures will be
			saved in postscript format.

The file 'Nets_Expts_Model.py' does not have to be directly executed, it is
used by the other scripts. In this file, all used data is hard coded and
integrated with the model into a SloppyCell model object. Also, in this
file, priors on model parameters are set according to equation 6 in the paper.


		
		   


