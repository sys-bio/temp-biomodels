##This script reproduces the figures 2-8 in the paper.
import sys
import os
import scipy
import numpy
import matplotlib
from matplotlib.font_manager import FontProperties
from SloppyCell.ReactionNetworks import *
import SloppyCell.ReactionNetworks.RunInParallel
from Nets_Expts_Model import *

Network.pretty_plotting()
##Get pickled objects from ensemble calculation
pickle_dir = "pickled/"
nets = Utility.load(pickle_dir + "nets.bp")
ens = Utility.load(pickle_dir + "ens.bp")
pruned_ens = Utility.load(pickle_dir + "pruned_ens.bp")
trajs_after_fit = Utility.load(pickle_dir + "trajs_after_fit.bp")


def get_last_cycles(net, n=1):
    endtime = 100
    return [(endtime)-n*(60./net.get_var_val("heartrate_test")), endtime+net.get_var_val("stepsize")]

def get_peak_timepoints(traj):
    peak_timepoints = []
    max_jhyd = max(traj.get_var_traj('Jhyd'))
    for t, jh in zip(traj.timepoints, traj.get_var_traj('Jhyd')):
        if jh > (max_jhyd - 1): 
            peak_timepoints.append(t)
    return peak_timepoints

matplotlib.rcParams['legend.fancybox'] = True
matplotlib.rcParams['legend.fontsize'] = 8
matplotlib.rcParams['font.size']=8
matplotlib.rcParams['axes.labelsize']=8
matplotlib.rcParams['text.fontsize']=8
matplotlib.rcParams['ytick.labelsize']=8
matplotlib.rcParams['xtick.labelsize']=8       
matplotlib.rcParams['font.sans-serif']=["Arial"]
matplotlib.rcParams['figure.facecolor']='w'


###MAPPINGS FROM "COMPUTER-CODE" STYLE PARAMETER NAMES TO BETTER LOOKING NAMES
param_name_mapping = {
    "K_CK_eq": "$K_{eq,CK}$",
    "VmaxMif_full_activity": "$V_{max,Mi,f}$",
    "VmaxMib": "$V_{max,Mi,b}$",
    "KiaMi": "$K_{ia,Mi}$",
    "KibMi": "$K_{ib,Mi}$",
    "KicMi": "$K_{ic,Mi}$",
    "KidMi": "$K_{id,Mi}$",
    "KbMi": "$K_{b,Mi}$",
    "KdMi": "$K_{d,Mi}$",
    "KcMi": "$K_{c,Mi}$",
    
    "VmaxMMf_full_activity": "$V_{max,MM,f}$",
    "VmaxMMb": "$V_{max,MM,b}$",
    "KiaMM": "$K_{ia,MM}$",
    "KibMM": "$K_{ib,MM}$",
    "KicMM": "$K_{ic,MM}$",
    "KidMM": "$K_{id,MM}$",
    "KbMM": "$K_{b,MM}$",
    "KdMM": "$K_{d,MM}$",
    "KcMM": "$K_{c,MM}$",
    
    "PSmomATP": "$PS_{mom,AdN}$",
    "PSmomPCr": "$PS_{mom,PCr}$",
    "PSmomCr": "$PS_{mom,Cr}$",
    "PSmomPi": "$PS_{mom,Pi}$",
    
    "Vmaxsyn": "$V_{max,syn}$",
    "Kadp": "$K_{ADP}$",
    "Kpi": "$K_{Pi}$"
    }
param_name_mapping = KeyedList(param_name_mapping)

species_name_mapping = {"flux_ratio": "$R_{diff,PCr}$",
                        "ATP": "$[ATP]$",
                        "ADP": "$[ADP]$",
                        "jsyn": "$J_{ATPsyn}$",
                        "Jhyd": "$J_{ATPhyd}$",
                        "tmito": "$t_{mito}$",
                        "P_i": "$[P_i]$",
                        "PCr": "$[PCr]$"
                        }
species_name_mapping = KeyedList(species_name_mapping)

species_unit_mapping = {"flux_ratio":" ",
                        "ATP": "$\mu M$",
                        "ADP": "$\mu M$",
                        "P_i": "$\mu M$",
                        "PCr": "$\mu M$",
                        "jsyn": "$\mu M*s^{-1}$",
                        "Jhyd": "$\mu M*s^{-1}$"
                        }
species_unit_mapping = KeyedList(species_unit_mapping)

###MAPPING OF UNITS TO PARAMETERS
param_unit_mapping = {
    "K_CK_eq": "",
    "VmaxMif_full_activity": "$\mu M * s^{-1}$",
    "VmaxMib": "$mu M * s^{-1}$",
    "KiaMi": "$\mu M$",
    "KibMi": "$\mu M$",
    "KicMi": "$\mu M$",
    "KidMi": "$\mu M$",
    "KbMi": "$\mu M$",
    "KdMi": "$\mu M$",
    "KcMi": "$\mu M$",
    
    "VmaxMMf_full_activity": "$\mu M * s^{-1}$",
    "VmaxMMb": "$\mu M * s^{-1}$",
    "KiaMM": "$\mu M$",
    "KibMM": "$\mu M$",
    "KicMM": "$\mu M$",
    "KidMM": "$\mu M$",
    "KbMM": "$\mu M$",
    "KdMM": "$\mu M$",
    "KcMM": "$\mu M$",
    
    "PSmomATP": "$s^{-1}$",
    "PSmomPCr": "$s^{-1}$",
    "PSmomCr": "$s^{-1}$",
    "PSmomPi": "$s^{-1}$",
    
    "Vmaxsyn": "$\mu M * s^{-1}$",
    "Kadp": "$\mu M$",
    "Kpi": "$\mu M$"
    }
param_unit_mapping = KeyedList(param_unit_mapping)
FILE_FORMAT = "eps"


###Figure 2: Plot fit results
##PloS single column figure, width has to be 3.27 inches or 8.3 centimenters 
fig = Plotting.figure(figsize=(3.27, 3.27))
ck_activity_percentage = ('100%\n160', '2%\n160', '100%\n190', '2%\n190', '100%\n220', '2%\n220')
#barplot
tmitosafter = [t.get_var_traj("tmito")[-1] for t in trajs_after_fit]
tmitodata  = [ex.get_data()[ex.get_data().keys()[0]]['tmito'][100][0] for ex in expts]
tmitoerror  = [ex.get_data()[ex.get_data().keys()[0]]['tmito'][100][1] for ex in expts]
N = len(tmitodata)
ind = scipy.arange(N)
ax = fig.add_subplot(111)
width = 0.2
rects_data = ax.bar(ind, tmitodata, width, color='r', yerr=tmitoerror, ecolor='k')
##Get all tmitos to see the std in the pruned ensemble
ens_stdevs = []
for n in nets:
    filename = pickle_dir + "TRAJ_SET_NONPULS_" + n.id + ".bp"
    traj_set = Utility.load(filename)
    tmitos = [t.get_var_traj("tmito")[-1] for t in traj_set]
    ens_stdevs.append(scipy.std(tmitos))
Utility.save(ens_stdevs, pickle_dir + "ens_stdevs.bp")
rects_after = ax.bar(ind + width, tmitosafter, width, color='y', yerr=ens_stdevs, ecolor='k')
ax.set_xticks(ind+width)
ax.set_xticklabels(ck_activity_percentage)
Plotting.xlabel("relative CK activity\nheart rate (bpm)")
Plotting.ylabel(r"$t_{mito} (s)$")
Plotting.legend((rects_data[0], rects_after[0]), ["experimental data", "model prediction"], loc=0)
##Get rid of ticks at the top and right axes
for line in ax.yaxis.get_ticklines()[::-2] + ax.xaxis.get_ticklines()[::-2]:
    line.set_markersize(0)
if FILE_FORMAT == "eps":
    Plotting.savefig('figure2_fit_results.eps', bbox_inches='tight')
if FILE_FORMAT == "png":
    Plotting.savefig('figure2_fit_results.png', bbox_inches='tight')
###

 

##Figure 3 Make plots of parameter distributions
## 2 column figure: Width has to be 6.83 and height up to 9.19 inch
fig = Plotting.figure(figsize=(6.83,9.19))
keys = nets[4].GetParameters().keys()
ordered_keys =["K_CK_eq","VmaxMif_full_activity","VmaxMib","KiaMi","KibMi","KicMi","KidMi","KbMi","KdMi","KcMi","VmaxMMf_full_activity", \
    "VmaxMMb","KiaMM","KibMM","KicMM","KidMM","KbMM","KcMM","KdMM","Vmaxsyn","Kadp","Kpi","PSmomATP","PSmomPCr","PSmomCr","PSmomPi"]
counter = 0
for i in range(len(ordered_keys)) :        
    if ordered_keys[i] != "ck_factor_iaa" and ordered_keys[i] != "ck_factor_ia" and ordered_keys[i] in keys:
        counter = counter + 1
        formatted_key = param_name_mapping.getByKey(ordered_keys[i])
        if ordered_keys[i] == "K_CK_eq":
            unit = ""
        else:
            unit = "(" + param_unit_mapping.getByKey(ordered_keys[i]) + ")"
        ax = fig.add_subplot(6,4,counter)
        Plotting.subplots_adjust(hspace=1.0)
        Plotting.subplots_adjust(wspace=0.6)
        idx = keys.index(ordered_keys[i])
        count, bins, ignored = Plotting.hist(scipy.transpose(pruned_ens)[idx], normed=False, bins=10)
        ##Plot pdf of lognormal distribution as well but sclale it to the histogram
        mu = scipy.mean(scipy.log(scipy.transpose(ens)[idx]))
        sigma = scipy.std(scipy.log(scipy.transpose(ens)[idx]))
        x = scipy.linspace(min(bins), max(bins), len(pruned_ens))
        pdf = (scipy.exp(-(scipy.log(x) - mu)**2 / (2 * sigma**2))/ (x * sigma * scipy.sqrt(2 * scipy.pi)))
        Plotting.plot(x, pdf * scipy.diff(bins)[0] * len(pruned_ens), linewidth=1.5, color='r')
        if scipy.mean(scipy.transpose(ens)[idx]) > 100:
            Plotting.xticks(Plotting.xticks()[0][::3])
        Plotting.yticks(Plotting.yticks()[0][::2])
        Plotting.title(formatted_key, fontsize=12, fontweight='bold')
        ensmustr = str(round(scipy.mean(scipy.transpose(pruned_ens)[idx]),2))
        enssigmastr = str(round(scipy.std(scipy.transpose(pruned_ens)[idx]),2))
        Plotting.ylim(0, max(count) + max(count)/2)
        ax.annotate(r'$\mu=' + ensmustr + '$', ha='center',xy=(scipy.median(x), max(count) + max(count)/5))
        ax.annotate(r'$\sigma=' + enssigmastr + "$", ha="center", xy=(scipy.median(x), max(count)+ max(count)/16))
        ##Get rid of ticks at the top and right axes
        for line in ax.yaxis.get_ticklines()[::-2] + ax.xaxis.get_ticklines()[::-2]:
            line.set_color('white')
        Plotting.xlabel("value " + unit)
        if scipy.mod(counter,4) == 1:
            Plotting.ylabel("Frequency")
        #ax.ticklabel_format(style='sci', scilimits=(-3,0),axis='y')
if FILE_FORMAT == "eps":
    Plotting.savefig('figure3_param_dist.eps', bbox_inches='tight')
if FILE_FORMAT == "png":
    Plotting.savefig('figure3_param_dist.png', bbox_inches='tight')
Plotting.show()
###



#Figure 4 Make prediction for PCr contribution for IAA and IA nets 220 bpm
# Plot forcing function of ATP hydrolsys on top of it!
##PloS single column figure, width has to be 3.27 inches or 8.3 centimenters 
fig = Plotting.figure(figsize=(3.27, 6.54))
traj_set_220_iaa = Utility.load(pickle_dir + "TRAJ_SET_base_net_220.bp")
traj_set_220_ia = Utility.load(pickle_dir + "TRAJ_SET_ia_net_220.bp")
#plot forcing function first
ax = fig.add_subplot(2,1,1)
n = nets[4]
traj = traj_set_220_iaa[0]
slice = get_last_cycles(n,2)
traj = traj.time_slice(slice[0], slice[1])
Plotting.plot(traj.timepoints-40, traj.get_var_traj("Jhyd"), linewidth=1.2, color='k')
Plotting.xlabel('Time (s)')
Plotting.yticks(Plotting.yticks()[0][::2])
Plotting.xlim(slice[0]-40,slice[1]-40)
yl = Plotting.ylabel(species_name_mapping.getByKey("Jhyd") + " (" + species_unit_mapping.getByKey("Jhyd") + ")")
##Get rid of ticks at the top and right axes
for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
    line.set_markersize(0)
ann = Plotting.annotate('A', (0,1.), xycoords=(yl, "axes fraction"),
                        xytext=(0, 14), textcoords="offset points",
                        fontsize=12, fontweight='bold')
n = nets[4]
hr = n.get_var_val('heartrate_test')
ax = fig.add_subplot(2,1,2)
##Get rid of ticks at the top and right axes
for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
    line.set_markersize(0)
lines = []

for traj_set, cn, light_color, dark_color  in zip([traj_set_220_iaa, traj_set_220_ia], ["CK active", "CK inactive"], \
                                                  ['#6666FF', '#FFCC66'], ['#000099', '#FF0000']):
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    best = traj_set[0]
    slice = get_last_cycles(n,2)
    lower = lower.time_slice(slice[0], slice[1])
    upper = upper.time_slice(slice[0], slice[1])
    best = best.time_slice(slice[0], slice[1])
    xpts = scipy.concatenate((lower.timepoints-40, lower.timepoints[::-1]-40))
    ypts = scipy.concatenate((lower.get_var_traj("flux_ratio"), upper.get_var_traj("flux_ratio")[::-1]))
    lines.append(Plotting.fill(xpts, ypts, label="MC ensemble " + cn, color=light_color))
    lines.append(Plotting.plot(best.timepoints-40, best.get_var_traj("flux_ratio"), label="best parameters " + cn, ls='-', lw=1.2, color=dark_color))
yl = Plotting.ylabel(species_name_mapping.getByKey("flux_ratio"))
Plotting.annotate('B', (0,1.), xycoords=(yl, "axes fraction"),
                  xytext=(0, 14), textcoords="offset points",
                  fontsize=12, fontweight='bold')
Plotting.ylim(-0.24, 0.8)
Plotting.xlim(slice[0]-40,slice[1]-40)
Plotting.xlabel("Time (s)")
Plotting.legend()

if FILE_FORMAT == "eps":
    Plotting.savefig("figure4_predict_220_ia_iaa.eps", transparent='True', bbox_inches='tight', bbox_extra_artists=[ann])
if FILE_FORMAT == "png":
    Plotting.savefig("figure4_predict_220_ia_iaa.png", transparent='True', bbox_inches='tight', bbox_extra_artists=[ann])
Plotting.show()
###



### figure 5: Make nonpulsatile plot of predictions over parameter ranges for heartrate
##   and PSmomAdN.
## 1.5 column figure
fig = Plotting.figure(figsize=(6.83,3.7))

heartrates = range(60,301,1)

mean_pred_vals_upper = []
mean_pred_vals_lower = []
mean_pred_vals_best = []
for hr in heartrates:
    print "Getting set of trajectories for heartrate ", hr
    traj_set = Utility.load(pickle_dir  + "heartrate_alter_trajs_hr_" + str(hr) + ".bp")
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    upper = upper.time_slice(99,100)
    lower = lower.time_slice(99,100)
    mean_pred_vals_upper.append(scipy.mean(upper.get_var_traj("flux_ratio")))
    mean_pred_vals_lower.append(scipy.mean(lower.get_var_traj("flux_ratio")))
    best = traj_set[0].time_slice(99,100)
    mean_pred_vals_best.append(scipy.mean(best.get_var_traj("flux_ratio")))

xpts = scipy.concatenate((heartrates,heartrates [::-1]))
ypts = scipy.concatenate((mean_pred_vals_upper, mean_pred_vals_lower[::-1]))
#Save ypts to file
Utility.save(ypts, pickle_dir + "heartrate_range_prediction_ypts.bp")
Utility.save(mean_pred_vals_best, pickle_dir + "heartrate_range_prediction_bestvals.bp")
ypts = Utility.load(pickle_dir + "heartrate_range_prediction_ypts.bp")
mean_pred_vals_best = Utility.load(pickle_dir + "heartrate_range_prediction_bestvals.bp")

ax = fig.add_subplot(121)
##Get rid of ticks at the top and right axes
for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
    line.set_markersize(0)
Plotting.fill(xpts, ypts, label="MC ensemble", color='GARTENZAUN6666FF')
Plotting.plot(heartrates, mean_pred_vals_best,"k",label="best parameters")
Plotting.xlim(60,300)
Plotting.ylim(0,1)
Plotting.xlabel("heart rate (bpm)")
yl = Plotting.ylabel("average " + species_name_mapping.getByKey("flux_ratio"))
Plotting.annotate("A", (0,1.), xycoords=(yl, "axes fraction"),
                  xytext=(0, 14), textcoords="offset points",
                  fontsize=12, fontweight='bold')    
Plotting.legend()

psmomatps = scipy.arange(0.1, 80.1, 0.5)

mean_pred_vals_upper = []
mean_pred_vals_lower = []
mean_pred_vals_best = []
for ps in psmomatps:
    print "Getting set of trajectories for psmom ", ps
    traj_set = Utility.load(pickle_dir + "psmom_alter_trajs_psmom_" + str(ps) + ".bp")
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    upper = upper.time_slice(99,100)
    lower = lower.time_slice(99,100)
    mean_pred_vals_upper.append(scipy.mean(upper.get_var_traj("flux_ratio")))
    mean_pred_vals_lower.append(scipy.mean(lower.get_var_traj("flux_ratio")))
    best = traj_set[0].time_slice(99,100)
    mean_pred_vals_best.append(scipy.mean(best.get_var_traj("flux_ratio")))

xpts = scipy.concatenate((psmomatps, psmomatps[::-1]))
ypts = scipy.concatenate((mean_pred_vals_upper, mean_pred_vals_lower[::-1]))
##Save ypts to file
Utility.save(ypts, pickle_dir + "psmom_range_prediction_ypts.bp")
Utility.save(mean_pred_vals_best, pickle_dir + "psmom_range_prediction_bestvals.bp")
ypts = Utility.load(pickle_dir + "psmom_range_prediction_ypts.bp")
mean_pred_vals_best = Utility.load(pickle_dir + "psmom_range_prediction_bestvals.bp")

ax = fig.add_subplot(122)
##Get rid of ticks at the top and right axes
for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
    line.set_markersize(0)
Plotting.fill(xpts, ypts, label="MC ensemble", color='GARTENZAUN6666FF')
Plotting.plot(psmomatps, mean_pred_vals_best,"k",label="best parameters")
Plotting.xlim(0,80)
Plotting.ylim(0,1)
Plotting.xlabel(param_name_mapping.getByKey("PSmomATP") + " (" + param_unit_mapping.getByKey("PSmomATP") + ")")
my_ticklabel = ax.get_yticklabels()[-2]
Plotting.annotate("B", (0,1.), xycoords=(my_ticklabel, "axes fraction"),
                  xytext=(0, 14), textcoords="offset points",
                  fontsize=12, fontweight='bold')

#Plotting.ylabel(species_name_mapping.getByKey("flux_ratio"))
if FILE_FORMAT == "eps":
        Plotting.savefig("figure5_hr_psmom_range_preds.eps")
if FILE_FORMAT == "png":
    Plotting.savefig("figure5_hr_psmom_range_preds.png")
### 


### Figure 6: Make plots with relative CK activity of 0.02, 1, 3
##   for the species ATP, ADP, Pi (cytosolic), Jsyn, frac_diff_PCr
#Double column figure with maximum height.
Plotting.figure(figsize=(6.83,9.19))

n = nets[4] ## 220bmp IAA

specs = ["Jhyd", "flux_ratio", "jsyn", "ADP", "P_i"]
#yaxis range should always stay the same for each species
ylimvals = [(0,4000), (-0.7,1.55), (100,1200), (0,250), (600,2500)]  

all_lower_upper_best = []
for filename in ["ck_alter_trajs_factor_0.02.bp", "TRAJ_SET_base_net_220.bp", "ck_alter_trajs_factor_3.bp"]:
    print "Loading trajectories from file ", filename
    traj_set = Utility.load(pickle_dir + filename)
    print "Calculating ensemble quantiles"
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    slice = get_last_cycles(n, 3)
    lower = lower.time_slice(slice[0], slice[1])
    upper = upper.time_slice(slice[0], slice[1])
    best = traj_set[0].time_slice(slice[0], slice[1])
    all_lower_upper_best.append([lower, upper, best])
    
titles = ["2% CK", "100% CK", "300% CK"]
counter = 0 
letters = 'ABCDEFGHIJKLMNO'
for sp, ylim in zip(specs,ylimvals) :
    print "Plotting predictions for species ", sp
    title_counter = 0
    for low_up_best in zip(all_lower_upper_best):
        titlestr = titles[title_counter]
        title_counter = title_counter + 1
        letter = letters[counter]
        counter = counter + 1
        low_up_best = low_up_best[0]
        lower = low_up_best[0]
        upper = low_up_best[1]
        best = low_up_best[2]
        print titlestr
        ax = Plotting.subplot(5,3,counter)
        ##Get rid of ticks at the top and right axes
        for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
            line.set_markersize(0)
        Plotting.subplots_adjust(hspace=0.8)
        Plotting.subplots_adjust(wspace=0.4)
        ypts = scipy.concatenate((upper.get_var_traj(sp), lower.get_var_traj(sp)[::-1]))
        xpts = scipy.concatenate((lower.timepoints-40, lower.timepoints[::-1]-40))
        if sp == "Jhyd":
            Plotting.title(titlestr)
            Plotting.plot(best.timepoints-40, best.get_var_traj(sp), "k-", label="best parameters", lw=0.8)
        else:
            Plotting.fill(xpts, ypts, label="ensemble", fc='\#6666FF', ec='\#6666FF')
            Plotting.plot(best.timepoints-40, best.get_var_traj(sp), "k-", label="best", lw=0.8)
        Plotting.ylim(ylim)
        if sp in ["Jhyd", "jsyn", "ADP"]:
            Plotting.yticks(Plotting.yticks()[0][::2])
        if title_counter == 1: ##Only plot yaxis label on left side of plot matrix
            labelstr = species_name_mapping.getByKey(sp)
            if sp in ["ADP", "P_i", "jsyn"]:
                labelstr = labelstr + " (" + species_unit_mapping.getByKey(sp) + ")"
            if sp == "flux_ratio":
                print "HERE"
                yl = Plotting.ylabel(species_name_mapping.getByKey(sp))
                Plotting.legend()
            else:
                yl = Plotting.ylabel(species_name_mapping.getByKey(sp) + " (" + species_unit_mapping.getByKey(sp) + ")")
            Plotting.annotate(letter, (0,1.), xycoords=(yl, "axes fraction"),
                              xytext=(0, 14), textcoords="offset points",
                              fontsize=12, fontweight='bold')    
        else:
            my_ticklabel = ax.get_yticklabels()[-2]
            Plotting.annotate(letter, (0,1.), xycoords=(my_ticklabel, "axes fraction"),
                              xytext=(0, 14), textcoords="offset points",
                              fontsize=12, fontweight='bold')

        Plotting.xlabel("Time (s)")
        Plotting.xticks(Plotting.xticks()[0][::2])
        Plotting.xlim(slice[0]-40,slice[1]-40)

if FILE_FORMAT == "eps":
    Plotting.savefig("figure6_ck_alter_prediction.eps")
if FILE_FORMAT == "png":
    Plotting.savefig("figure6_ck_alter_prediction.png")
###


###Figure 7: Make plots where either Mi-Ck, MM-Ck, both CKs or no CK is inhibited
##  for the species ADP, Pi (cytosolic), Jsyn, frac_diff_PCr
#Double column figure with maximum height.
Plotting.figure(figsize=(6.83,9.19))

n = nets[4] ## 220bmp IAA

specs = ["Jhyd", "flux_ratio", "jsyn", "ADP", "P_i"]
#yaxis range should always stay the same for each species
ylimvals = [(0,4000), (-0.7,1.55), (100,1200), (0,250), (600,2500)]  

all_lower_upper_best = []
for filename in ["TRAJ_SET_base_net_220.bp", "ck_knockout_trajs_MiCK.bp", "ck_knockout_trajs_MMCK.bp", "ck_alter_trajs_factor_0.02.bp"]:
    print "Loading trajectories from file ", filename
    traj_set = Utility.load(pickle_dir + filename)
    print "Calculating ensemble quantiles"
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    slice = get_last_cycles(n, 3)
    lower = lower.time_slice(slice[0], slice[1])
    upper = upper.time_slice(slice[0], slice[1])
    best = traj_set[0].time_slice(slice[0], slice[1])
    all_lower_upper_best.append([lower, upper, best])
    
titles = ["Mi-CK 100%\nMM-CK 100%", "Mi-CK 2%\nMM-CK 100%", "Mi-CK 100%\nMM-CK 2%", "Mi-CK 2%\nMM-CK 2%"]
counter = 0
letters = 'ABCDEFGHIJKLMNOPQRST'
for sp, ylim in zip(specs,ylimvals) :
    print "Plotting predictions for species ", sp
    title_counter = 0
    for low_up_best in zip(all_lower_upper_best):
        titlestr = titles[title_counter]
        title_counter = title_counter + 1
        letter = letters[counter]
        counter = counter + 1
        low_up_best = low_up_best[0]
        lower = low_up_best[0]
        upper = low_up_best[1]
        best = low_up_best[2]
        print titlestr
        ax = Plotting.subplot(5,4,counter)
        ##Get rid of ticks at the top and right axes
        for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
            line.set_markersize(0)
        Plotting.subplots_adjust(hspace=0.8)
        Plotting.subplots_adjust(wspace=0.4)
        ypts = scipy.concatenate((upper.get_var_traj(sp), lower.get_var_traj(sp)[::-1]))
        xpts = scipy.concatenate((lower.timepoints-40, lower.timepoints[::-1]-40))
        if sp == "Jhyd":
            Plotting.title(titlestr)
            Plotting.plot(best.timepoints-40, best.get_var_traj(sp), "k-", label="best parameters", lw=0.8)
        else:
            Plotting.fill(xpts, ypts, label="ensemble", fc='\#6666FF', ec='\#6666FF')
            Plotting.plot(best.timepoints-40, best.get_var_traj(sp), "k-", label="best", lw=0.8)
        Plotting.ylim(ylim)
        if sp in ["Jhyd", "jsyn", "ADP"]:
            Plotting.yticks(Plotting.yticks()[0][::2])
        if title_counter == 1: ##Only plot yaxis label on left side of plot matrix
            labelstr = species_name_mapping.getByKey(sp)
            if sp in ["ADP", "P_i", "jsyn"]:
                labelstr = labelstr + " (" + species_unit_mapping.getByKey(sp) + ")"
            if sp == "flux_ratio":
                print "HERE"
                yl = Plotting.ylabel(species_name_mapping.getByKey(sp))
                Plotting.legend()
            else:
                yl = Plotting.ylabel(species_name_mapping.getByKey(sp) + " (" + species_unit_mapping.getByKey(sp) + ")")
            Plotting.annotate(letter, (0,1.), xycoords=(yl, "axes fraction"),
                              xytext=(0, 14), textcoords="offset points",
                              fontsize=12, fontweight='bold')    
        else:
            my_ticklabel = ax.get_yticklabels()[-2]
            Plotting.annotate(letter, (0,1.), xycoords=(my_ticklabel, "axes fraction"),
                              xytext=(0, 14), textcoords="offset points",
                              fontsize=12, fontweight='bold')

        Plotting.xlabel("Time (s)")
        Plotting.xticks(Plotting.xticks()[0][::2])
        Plotting.xlim(slice[0]-40,slice[1]-40)

if FILE_FORMAT == "eps":
    Plotting.savefig("figure7_ck_knockout_prediction.eps")
if FILE_FORMAT == "png":
    Plotting.savefig("figure7_ck_knockout_prediction.png")

Plotting.show()

###

#Figure 8: make simple plot of Jhyd and Jsyn
fig = Plotting.figure(figsize=(6.83,3.27))

from Nets_Expts_Model import *
net = nets[4].copy()
net.setInitialVariableValue("pulsatility",1)
net.set_var_val("pulsatility",1)
net.setInitialVariableValue("Jhyd",0)
net.set_var_val("Jhyd",0)
starttime = 0
stepsize = net.get_var_val('stepsize')
print 'Stepsize = ', stepsize
endtime = 100 + stepsize
times = scipy.arange(starttime, endtime, stepsize)

traj=Dynamics.integrate(net, times, params=pruned_ens[0], fill_traj=False, verbose=True)
Utility.save(traj, pickle_dir + "simple_traj.bp")
traj = Utility.load(pickle_dir + "simple_traj.bp")
traj = traj.time_slice(36,50)
ax = fig.add_subplot(121)
##Get rid of ticks at the top and right axes
for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
    line.set_markersize(0)

Plotting.plot(traj.timepoints-40, traj.get_var_traj("Jhyd"), linewidth=0.5, color='k')
Plotting.xlabel('Time (s)')
Plotting.yticks(Plotting.yticks()[0][::2])
yl = Plotting.ylabel(species_name_mapping.getByKey("Jhyd") + " (" + species_unit_mapping.getByKey("Jhyd") + ")")
Plotting.annotate('A', (0,1.), xycoords=(yl, "axes fraction"),
                  xytext=(0, 14), textcoords="offset points",
                  fontsize=12, fontweight='bold')
ax = fig.add_subplot(122)
Plotting.subplots_adjust(wspace=0.3)
##Get rid of ticks at the top and right axes
for line in ax.yaxis.get_ticklines()[::-2]+ ax.xaxis.get_ticklines()[::-2]:
    line.set_markersize(0)
Plotting.plot(traj.timepoints-40, traj.get_var_traj("jsyn"), linewidth=0.5, color='k')
Plotting.xlabel('Time (s)')
Plotting.yticks(Plotting.yticks()[0][::2])
yl = Plotting.ylabel(species_name_mapping.getByKey("jsyn") + " (" + species_unit_mapping.getByKey("Jhyd") + ")")
Plotting.annotate('B', (0,1.), xycoords=(yl, "axes fraction"),
                  xytext=(0, 14), textcoords="offset points",
                  fontsize=12, fontweight='bold')

if FILE_FORMAT == "eps":
    Plotting.savefig('figure8_jhyd_jsyn.eps')
if FILE_FORMAT == "png":
    Plotting.savefig('figure8_jhyd_jsyn.png')
###
