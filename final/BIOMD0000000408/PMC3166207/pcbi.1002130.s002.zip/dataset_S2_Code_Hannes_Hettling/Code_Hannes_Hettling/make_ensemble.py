### This script fits the parameters of the CK model to the available
##  experiment data and samples a parameter ensemble using Metropolis-Hastings.
import os
import scipy
import SloppyCell.ReactionNetworks.RunInParallel
from SloppyCell.ReactionNetworks import *

from Nets_Expts_Model import *

if not os.path.exists('pickled'): os.mkdir('pickled')

Utility.save(m,  "pickled/model.bp")
Utility.save(expts, "pickled/expts.bp")
Utility.save(nets, "pickled/nets.bp")
Utility.save(keys, "pickled/keys.bp")

Network.full_speed()

times = range(0,101)

##Simulate all networks before optimization
trajs_before_fit = scipy.array([Dynamics.integrate(n, times, fill_traj=False) for n in nets])

Utility.save(trajs_before_fit, "pickled/trajs_before_fit.bp")

##do paramter fit using nelder-mead and least squares
initial_cost = m.cost(nets[0].GetParameters())

print "Starting parameter optimization..."

pmin1 = Optimization.fmin_log_params(m, nets[0].GetParameters(), xtol=1e-2, maxiter=scipy.inf)
params = Optimization.leastsq_log_params(m, pmin1)

Utility.save(params, "pickled/opt_params.bp")
opt_cost = m.cost(params)
print "Initial cost = ", initial_cost, ", Optimized cost = ", opt_cost

##Create trajectories with fitted parameters for all conditions
trajs_after_fit = scipy.array([Dynamics.integrate(n, times, params=params, fill_traj=False) for n in nets])
Utility.save(trajs_after_fit, "pickled/trajs_after_fit.bp")

##IMPORTANT: The leastsquares parameter optimization algorithm gives slightly different results 
##           when used with different versions of python and/or scipy. The resulting optimized parameters
##           can therefore differ from those reported in the paper. As a result, the sampled parameter
##           ensemble can differ as well, since the starting point for Monte Carlo is the optimized parameter set. 
##           Although this does not affect the predictions severely, 
##           values after the comma could differ from those reported in the paper. 
##           In order to reproduce the exact results in the paper, comment in the line below to restore the 
##           parameters which were optimized on my machine.
#params = Utility.load("pickled/opt_params_hannes_hettling.bp")

##Create the ensemble
print "Generating ensemble"
mc_steps = 50000

ens, ens_costs, ratio, tried_params = Ensembles.ensemble_log_params(m, scipy.asarray(params), \
                                                                    steps=mc_steps, seeds=(200, 10))
Utility.save(ens, "pickled/ens.bp")
Utility.save(tried_params, "pickled/tried_params.bp")

##Get the maximum correlation time, start with cost autocorrelation and then get autocorrelation of all parameters
cost_acs = Ensembles.autocorrelation(ens_costs)
max_corr = None
for i in range(0, len(cost_acs)) :
    if cost_acs[i]<1/scipy.e :
        max_corr = i + 1
        break
for i, key in zip(range(0, len(ens[0])), keys) :
    acs = Ensembles.autocorrelation(scipy.transpose(ens)[i])
    correlation_time = -1
    for i in range(0, len(acs)) :
        if acs[i]<1/scipy.e :
            correlation_time = i + 1
            break
    print "Correlation time for ", key, " ", correlation_time
    if correlation_time > max_corr:
        max_corr = correlation_time
print "Maximum correlation time = ", max_corr

##Prune the ensemble
pruned_ens = scipy.asarray(ens[::max_corr])
print "Size of pruned ensemble = ", len(pruned_ens)
Utility.save(pruned_ens, "pickled/pruned_ens.bp")
