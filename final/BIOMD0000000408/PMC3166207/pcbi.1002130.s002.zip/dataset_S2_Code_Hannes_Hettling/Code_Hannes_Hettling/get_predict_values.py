##This script extracts all values for predictions on metabolite levels, fluxes,
## parameter values and others for the paper. Note that all pickled objects
## from ensemble calculations and predictions must be present in the 'pickled/'
## directory
import scipy
from SloppyCell.ReactionNetworks import *
from Nets_Expts_Model import *

##return the timepoints (begin and end) for only the last cardiac cycle of the simulation!
def get_last_cycle_test(net):
    endtime = 100
    return [(endtime+net.get_var_val("stepsize"))-(60./net.get_var_val("heartrate_test")), endtime+net.get_var_val("stepsize")]



### 1) Print the changes of parameter values after optimization
##get initial parameter values
print "### Changes after parameter fit "
initial_params = nets[0].GetParameters().copy()
opt_params = Utility.load("pickled/opt_params.bp")
for k,b,a in zip(initial_params.keys(), initial_params.values(), opt_params.values()):
    print k,"\tbefore: ",b,"\tafter: ",a, "\tdiff: ", a-b, "\tperc:",  ((a-b) * 100)/b, "%"
print "\n"

### 2) Mean, max and std value for PSmomAdN in  ensemble and pruned ensemble
print "### Mean, max and std value for PSmomAdN "
ens = Utility.load("pickled/ens.bp")
keys = Utility.load("pickled/keys.bp")
psmomatps = scipy.transpose(ens)[keys.index("PSmomATP")]
max_psmom = max(psmomatps)
min_psmom = min(psmomatps)
mean_psmom = scipy.mean(psmomatps)
std_psmom = scipy.std(psmomatps)
print "### Max and min values for PSmomATP in the whole ensemble"
print "Max PSmomATP = ", max_psmom, "  Min PSmomATP = ", min_psmom
print "Mean PSmomATP = ", mean_psmom, "  Std PSmomATP = ", std_psmom
print "\n"

pruned_ens = Utility.load("pickled/pruned_ens.bp")
keys = Utility.load("pickled/keys.bp")
psmomatps = scipy.transpose(pruned_ens)[keys.index("PSmomATP")]
max_psmom = max(psmomatps)
min_psmom = min(psmomatps)
mean_psmom = scipy.mean(psmomatps)
std_psmom = scipy.std(psmomatps)
print "### Max and min values for PSmomATP in the pruned ensemble"
print "Max PSmomATP = ", max_psmom, "  Min PSmomATP = ", min_psmom
print "Mean PSmomATP = ", mean_psmom, "  Std PSmomATP = ", std_psmom
print "\n"


### 3) Average frac_diff_pcr for best fit parameters and each condition
##     in steady state
print "###Average frac_diff_PCr for best fit parameters for all conditions"
trajs_after_fit = Utility.load("pickled/trajs_after_fit.bp")
nets = Utility.load("pickled/nets.bp")
for t, n in zip(trajs_after_fit, nets):
    slice = get_last_cycle_test(n)
    t = t.time_slice(slice[0], slice[1])
    print "Average R_diff_pcr for ", n.id, " = ", scipy.average(t.get_var_traj("flux_ratio"))
print "\n"

## 4) Upper bound of all IAA predictions for R_diff_pcr
print "###Maximum value of R_diff_PCr for upper bound of 95% confidence interval for all conditions"
nets = Utility.load("pickled/nets.bp")
max_Rdiffpcr = -1
for n in nets:
    traj_set = Utility.load("pickled/TRAJ_SET_" + n.id + ".bp")
    slice = get_last_cycle_test(n)
    traj_set = traj_set = [t.time_slice(slice[0], slice[1]) for t in traj_set]
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    if max(upper.get_var_traj("flux_ratio")) > max_Rdiffpcr:
        max_Rdiffpcr = max(upper.get_var_traj("flux_ratio"))
print "Max R_diff_pcr over cardiac cycle and all conditions = ", max_Rdiffpcr
print "\n"

## 5) R_diff_PCr of ensemble with confidence region
print "###R_diff_PCr of ensemble prediction for  all nets: 95% confidence region, mean and SD "

for n, filename in zip(nets, ["pickled/TRAJ_SET_base_net_160.bp", "pickled/TRAJ_SET_ia_net_160.bp",\
                             "pickled/TRAJ_SET_base_net_190.bp", "pickled/TRAJ_SET_ia_net_190.bp",\
                             "pickled/TRAJ_SET_base_net_220.bp", "pickled/TRAJ_SET_ia_net_220.bp"]):
    print n.id
    traj_set = Utility.load(filename)
    slice = get_last_cycle_test(n)
    traj_set = traj_set = [t.time_slice(slice[0], slice[1]) for t in traj_set]
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    mean_traj, std_traj = Ensembles.traj_ensemble_stats(traj_set)
    best = traj_set[0]
    sp = "flux_ratio"
    ##remove first one later; we want the mean+-SD
    print "\tBest fit concentration for ", sp, " is ", round(scipy.mean(best.get_var_traj(sp)),3), "+- ", \
          round(max(scipy.mean(upper.get_var_traj(sp)) - scipy.mean(best.get_var_traj(sp)), \
              scipy.mean(best.get_var_traj(sp)) - scipy.mean(lower.get_var_traj(sp))),3) 
    print "\tMean: ", round(scipy.mean(mean_traj.get_var_traj(sp)), 3), "  SD: ", round(scipy.mean(std_traj.get_var_traj(sp)), 3)
print "\n"

## 6)  Print average difference of ATP concentration between IMS and cytosol 
##      for best params
print "###Average difference between ATP concentration between cytosol and IMS "
trajs_after_fit = Utility.load("pickled/trajs_after_fit.bp")
nets = Utility.load("pickled/nets.bp")
for t, n in zip(trajs_after_fit, nets):
    slice = get_last_cycle_test(n)
    t = t.time_slice(slice[0], slice[1])
    print "Difference in [ATPc] and [ATPims] for ", n.id, " = ", \
          scipy.average(t.get_var_traj("ATP") - t.get_var_traj("ATPi"))
print "\n"



## 7) Print amplitudes for ATP, ADP, ADPi, Pi and Jsyn for 0, 2, 100, 300, 10000% CK activity predictions
print "### Amplitudes and concentrations for ATP, ADP, ADPi, Pi, Jsyn when CK activity is at 0, 2, 100, 300%"
all_lower_upper_best = []
for filename in ["ck_alter_trajs_factor_0.bp", "ck_alter_trajs_factor_0.02.bp", "TRAJ_SET_base_net_220.bp", "ck_alter_trajs_factor_3.bp", "ck_alter_trajs_factor_10000.bp"]:
    traj_set = Utility.load("pickled/" + filename)
    n = nets[4]
    slice = get_last_cycle_test(n)
    traj_set = traj_set = [t.time_slice(slice[0], slice[1]) for t in traj_set]
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    best = traj_set[0]
    mean, std = Ensembles.traj_ensemble_stats(traj_set)
    all_lower_upper_best.append([lower, upper, best, mean, std])


factors = [0, 2,100, 300, 10000]
for sp in ["ATP", "ADP", "ADPi", "P_i", "jsyn"]:
    for factor, low_up_best in zip(factors, all_lower_upper_best):
        print "CK activity % = ", factor
        lower = low_up_best[0]
        upper = low_up_best[1]
        best = low_up_best[2]
        mean_traj = low_up_best[3]
        std_traj = low_up_best[4]
        print "95% conf. interval Amplitute for ", sp, " is ", max(best.get_var_traj(sp)) - min(best.get_var_traj(sp)), "+- ", \
              max(max(upper.get_var_traj(sp) - best.get_var_traj(sp)), \
                  max((best.get_var_traj(sp) - lower.get_var_traj(sp))))
        print "Mean amplitude for ", sp, " is ", max(mean_traj.get_var_traj(sp))-min(mean_traj.get_var_traj(sp)), "+-", \
              max(std_traj.get_var_traj(sp))-min(std_traj.get_var_traj(sp))
        print "95% conf. interval Average concentration for ", sp, " is ", scipy.mean(best.get_var_traj(sp)), "+- ", \
              max(scipy.mean(upper.get_var_traj(sp)) - scipy.mean(best.get_var_traj(sp)), \
                  scipy.mean(best.get_var_traj(sp)) - scipy.mean(lower.get_var_traj(sp)))
        print "Mean concentration for ", sp, " is ", scipy.mean(mean_traj.get_var_traj(sp)), " +-", \
              scipy.mean(std_traj.get_var_traj(sp))
    
print "\n"


## 8) Print amplitudes for ATP, ATP and Jsyn for CK knockout predictions
print "### Amplitudes and concentrations for ATP, ADP, Jsyn, P_i with seletive CK knockout"
all_lower_upper_best = []
for filename in ["TRAJ_SET_base_net_220.bp", "ck_knockout_trajs_MiCK.bp", "ck_knockout_trajs_MMCK.bp", "ck_alter_trajs_factor_0.02.bp", "ck_full_knockout_trajs_MiCK.bp", "ck_full_knockout_trajs_MMCK.bp","ck_alter_trajs_factor_0.bp"]:
    traj_set = Utility.load("pickled/" + filename)
    n = nets[4]
    slice = get_last_cycle_test(n)
    traj_set = traj_set = [t.time_slice(slice[0], slice[1]) for t in traj_set]
    lower, upper = Ensembles.traj_ensemble_quantiles(traj_set, (0.025, 0.975))
    mean, std = Ensembles.traj_ensemble_stats(traj_set)
    best = traj_set[0]
    all_lower_upper_best.append([lower, upper, best, mean, std])
    
knockouts = ["no inhibition", "Mi-CK inhibition(98%)", "MM-CK inhibition(98%)", "Mi-CK, MM-CK inhibition(98%)", "Mi-CK inhibition(100%)", "MM-CK inhibition(100%)", "Mi-CK, MM-CK inhibition(100%)"]
for knockout, low_up_best in zip(knockouts, all_lower_upper_best):
    print "\n",knockout
    for sp in ["ATP", "ADP", "ADPi", "P_i", "jsyn", "flux_ratio"]:
        lower = low_up_best[0]
        upper = low_up_best[1]
        best = low_up_best[2]
        mean_traj = low_up_best[3]
        std_traj = low_up_best[4]
        print "95% conf. interval Amplitute for ", sp, " is ", max(best.get_var_traj(sp)) - min(best.get_var_traj(sp)), "+- ", \
              max(max(upper.get_var_traj(sp) - best.get_var_traj(sp)), \
                  max((best.get_var_traj(sp) - lower.get_var_traj(sp))))
        print "Mean amplitude for ", sp, " is ", max(mean_traj.get_var_traj(sp))-min(mean_traj.get_var_traj(sp)), "+-", \
              max(std_traj.get_var_traj(sp))-min(std_traj.get_var_traj(sp))
        print "95% conf. interval Average concentration for ", sp, " is ", scipy.mean(best.get_var_traj(sp)), "+- ", \
              max(scipy.mean(upper.get_var_traj(sp)) - scipy.mean(best.get_var_traj(sp)), \
                  scipy.mean(best.get_var_traj(sp)) - scipy.mean(lower.get_var_traj(sp)))
        print "Mean concentration for ", sp, " is ", scipy.mean(mean_traj.get_var_traj(sp)), " +-", \
              scipy.mean(std_traj.get_var_traj(sp))

print "\n"


## 9) mean, SD and sigma(log(theta)) for each parameter in pruned ensemble
print "### Mean, sd and sigme(log(theta)) for each parameter in the pruned ensemble"
pruned_ens = Utility.load("pickled/pruned_ens.bp")
keys = Utility.load("pickled/keys.bp")

for key in keys:
    vals = scipy.transpose(pruned_ens)[keys.index(key)]
    mean = scipy.mean(vals)
    sd = scipy.std(vals)
    sigma_log_theta = scipy.std(scipy.log(vals))
    print key, ": mean=", mean, " sd=", sd, " sigma(log(theta))=", sigma_log_theta

print "\n"
