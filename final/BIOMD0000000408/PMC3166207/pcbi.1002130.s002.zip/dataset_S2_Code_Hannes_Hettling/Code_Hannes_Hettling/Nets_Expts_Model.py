import scipy
from SloppyCell.ReactionNetworks import *

##Sets whether to use a pulsatile ATP hydrolysis function
pulsatility = False

##declare parameters which will not be optimized
fixed_params = ["Jhyd", "Jhyd_basis", "Jhyd_test", "Vol_cyt", "Vol_ims", \
                "epsilon", "VmaxMMb", "VmaxMib", "VmaxMif", \
                "VmaxMMf", "phase", "heartrate_bpm", "heartrate_basis", \
                "heartrate_test","fracDia", "fracSysUp", "fracSysDown",\
                "VhydAmp_basis", "VhydAmp_test", "stepsize", "last_time_fired", "pulsatility", "time_Jhyd_step"]

##Now we code the data used in this analysis. The values are response times of OxPhos to a pace increase of rabbit hearts.
##Heartrates were increased from 132 bpm to
heartrates = [160, 190, 220]
##We linearly interpolated the following ATP hydrolysis rates
atp_hydrolysis_rates = [531.3955, 579.4977, 627.6]
##Below are the values and errors for the response time t_mito in seconds for IAA (normal) and IA (CK inhibited) conditions taken from (Harrison, Am. J. Physiol. 2003)
iaa_tmitos = [3.0, 3.9, 5.25]
iaa_tmito_errors = [0.1, 0.1667, 0.5]
ia_tmitos = [1.8, 2.5, 3.3]
ia_tmito_errors = [0.5, 0.41675, 0.5]
##Below are the standard errors for molecular parameters
sd_list = {"KbMM":2500, "KdMM":40, "KdMi":20, "KiaMi":60, "KibMi":8450, "KbMi":300, \
           "KidMi":200, "Vmaxsyn":152.6487, "K_CK_eq":4, "ck_factor_iaa": 0.000001}
sd_list = KeyedList(sd_list)

#Create network and experiment objects

nets = []
expts = []

##Calculate the stepsize which is dependant on the test heart rate.
##There must be a peak at 60/(test_rate * (1/(fracSysUp + fracSysDown)))
##  and at 60/(base_rate * (1/(fracSysUp + fracSysDown)))
## Note that the stepsize becomes important only/especially for pulsatile simulations
def calc_stepsize(heartrate_basis, heartrate_test, fracSysUp, fracSysDown):
    def gcd(a,b): ##euklid algorithm for finding greatest common divisor
        if (b==0):
            return a
        else:
            return gcd(b, scipy.mod(a,b))
    def lcd(a,b): return abs(a*b)/gcd(a,b)
    sys_factor = round(2./(fracSysUp + fracSysDown),0)
    x = lcd(1./(60./(heartrate_test * sys_factor)),1./(60./(heartrate_basis * sys_factor)))  
    return 1./x


endtime = 100
for heartrate, jhydtest, iaa_tmito, ia_tmito, iaa_error, ia_error in  zip(heartrates, atp_hydrolysis_rates, \
                                                                          iaa_tmitos, ia_tmitos, \
                                                                          iaa_tmito_errors, ia_tmito_errors):    

    ##Base net is IAA net
    basenetname = "base_net_" + str(heartrate)
    base_net = IO.from_SBML_file("ajp_net.xml", basenetname)
    stepsize = calc_stepsize(base_net.get_var_val("heartrate_basis"), heartrate, \
                             base_net.get_var_val("fracSysUp"), base_net.get_var_val("fracSysDown"))
    print "Setting a step size (for pulsatile simulations)  of ", stepsize, " for ", basenetname 
    #Utility.save(base_net, "pickled/"+basenetname+".bp")
    #base_net = Utility.load("pickled/"+basenetname+".bp")
    print "setting Jhyd_test ", jhydtest
    base_net.setInitialVariableValue("Jhyd_test", jhydtest)
    base_net.set_var_val("Jhyd_test", jhydtest)
    if pulsatility:
        base_net.setInitialVariableValue("pulsatility",1)
        base_net.set_var_val("pulsatility",1)
        base_net.setInitialVariableValue("Jhyd", 0)
        base_net.set_var_val("Jhyd", 0)
    else:
        base_net.setInitialVariableValue("pulsatility",0)
        base_net.set_var_val("pulsatility",0)
        base_net.setInitialVariableValue("Jhyd",base_net.get_var_val("Jhyd_basis"))
        base_net.set_var_val("Jhyd",base_net.get_var_val("Jhyd_basis"))
    base_net.setInitialVariableValue("heartrate_test", heartrate)
    base_net.set_var_val("stepsize",stepsize)
    base_net.setInitialVariableValue("stepsize", stepsize)
    data = ({basenetname:{}})
    data[basenetname] = {'tmito' : {}}
    data[basenetname]['tmito'][endtime] = (iaa_tmito, iaa_error)
    ex = Experiment()
    ex.set_data(data)
    ex.set_fixed_sf({'tmito' : 1})
    ex.name="base_data_" + str(heartrate)
    for fp in fixed_params:
        base_net.set_var_optimizable(fp, False)
    nets.append(base_net)
    expts.append(ex)
    ##IA net: IA treatment, inhibited CK activity
    ianetname = "ia_net_" + str(heartrate)
    ia_net = IO.from_SBML_file("ajp_net.xml", ianetname)
    ia_net.assignmentRules.set('VmaxMif', 'VmaxMif_full_activity * ck_factor_ia')
    ia_net.assignmentRules.set('VmaxMMf', 'VmaxMMf_full_activity * ck_factor_ia')
    #Utility.save(ia_net, "pickled/"+ianetname+".bp")
    #ia_net = Utility.load("pickled/"+ianetname+".bp")
    ia_net.setInitialVariableValue("Jhyd_test", jhydtest)
    ia_net.set_var_val("Jhyd_test", jhydtest)
    if pulsatility:
        ia_net.setInitialVariableValue("pulsatility",1)
        ia_net.set_var_val("pulsatility",1)
        ia_net.setInitialVariableValue("Jhyd", 0)
        ia_net.set_var_val("Jhyd", 0)
    else:
        ia_net.setInitialVariableValue("pulsatility",0)
        ia_net.set_var_val("pulsatility",0)
        ia_net.setInitialVariableValue("Jhyd", ia_net.get_var_val("Jhyd_basis"))
        ia_net.set_var_val("Jhyd", ia_net.get_var_val("Jhyd_basis"))
    ia_net.setInitialVariableValue("heartrate_test", heartrate)
    ia_net.set_var_val("stepsize",stepsize)
    ia_net.setInitialVariableValue("stepsize", stepsize)
    data = ({ianetname:{}})
    data[ianetname] = {'tmito' : {}}
    data[ianetname]['tmito'][endtime] = (ia_tmito, ia_error)
    iaex = Experiment()
    iaex.set_data(data)
    iaex.set_fixed_sf({'tmito' : 1})
    iaex.name="ia_data_" + str(heartrate)
    for fp in fixed_params:
        ia_net.set_var_optimizable(fp, False)
    expts.append(iaex)
    nets.append(ia_net)
    

##Timing parameters
starttime = 0
times = scipy.arange(starttime, endtime+stepsize, stepsize)

original_params = nets[0].GetParameters()
keys = nets[0].GetParameters().keys()
m = Model(expts, nets)
net = nets[0]
##Create the sigma values for setting the priors from the standard deviations
##The maximum sigma value for parameters with known standard error is taken for
##all parameters with unknown standard error.
max_sigma = None
for key, sd in zip(sd_list.keys(), sd_list.values()):
    val = net.get_var_val(key)
    sigma = 1/4. * scipy.log((val+2*sd)/(val-2*sd))
    print "Prior sigma for ", key, " : ", sigma
    if sigma > max_sigma:
        max_sigma = sigma
    #Set the prior to the model
    m.AddResidual(Residuals.PriorInLog('prior_on_%s' % key, key, scipy.log(val), sigma))
print "Prior sigma for all other parameters: ", max_sigma
##Set priors for the remaining parameters, but NOT for PSmomATP
for key in keys:
    if key not in fixed_params and key not in sd_list.keys() and key != "PSmomATP":
        val = original_params.get(key)
        m.AddResidual(Residuals.PriorInLog('prior_on_%s' % key, key, scipy.log(val), max_sigma))
