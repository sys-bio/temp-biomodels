% Matlab code for reproduction of 
% HIF network model by A. Coulibaly, A. Bettendorf, ... M.V. Barbarossa
% submitted to Frontiers in Immunology (2019)
% code: MV Barbarossa
% --------------------------------------------------------------------


 clear all;
 close all;


% --------------------------------------------------------------------
% data
[timedata,AKTdata,errAKT,STAT3data,errSTAT3,HIF,HIFerr]=fun_load_data()
% --------------------------------------------------------------------
% integration intervals
tinit=0; % initial time point for computation
tend=100; % end time point for computation
 

% --------------------------------------------------------------------
% -----------------------------------------------------------
% EXPERIMENTAL SETTINGS 
% ------------------------------------------------------------
IL15_0_untr=0; % initial IL15 load in untreated cells

% normoxia, no inhibitor, no priming
% DMOG=0,IL15(0)=0.0, RAPA=0, STAT3inhib=0,O2=21%
C1a=[0,IL15_0_untr,0,0,0,0,21]; %contrl_norm_noinhib_nopriming 

% test 1b: normoxia, no inhibitor, IL15 priming
% DMOG=0,IL15(0)=1, RAPA=0, STAT3inhib=0,O2=21%
C1b=[0,1,0,0,0,0,21]; % contrl_norm_noinhib_priming


% --------------------------
% test 3a: DMOG+normoxia, no other inhibitor, no priming
% DMOG=1,IL15(0)=0.0, RAPA=0, STAT3inhib=0,O2=21%
C3a=[1,IL15_0_untr,0,0,0,0,21];

% test 3b: DMOG+normoxia, no other inhibitor, IL15 priming
% DMOG=1,IL15(0)=1, RAPA=0, STAT3inhib=0,O2=21%
C3b=[1,1,0,0,0,0,21];

% test 3c: DMOG+normoxia, STAT3 inhibitor, IL15 priming
% DMOG=1,IL15(0)=1, RAPA=0, STAT3inhib=1,O2=21%
C3c=[1,1,0,1,0,0,21];

% test 3d: DMOG+normoxia, Rapa+STAT3 inhibitor, IL15 priming
% DMOG=1,IL15(0)=1, RAPA=1, STAT3inhib=1,O2=21%
C3d=[1,1,1,1,0,0,21];

% test 3e: DMOG+normoxia, Rapa, IL15 priming
% DMOG=1,IL15(0)=1, RAPA=1, STAT3inhib=0,O2=21%
C3e=[1,1,1,0,0,0,21];

% test 3f: DMOG+normoxia, Rapa, no IL15 priming
% DMOG=1,IL15(0)=0.0, RAPA=1, STAT3inhib=0,O2=21%
C3f=[1,IL15_0_untr,1,0,0,0,21];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
CC78=[C1b;C3a;C3b;C3c;C3e];

for j=1:size(CC78,1)
% define control vector
controlvector78=CC78(j,:); 
% oxygen level is given in control vector
O2=controlvector78(end);
% load parameter values 
Par=fun_load_parameters(O2);
% --------------------------------------------------------------------

% pass parameters to ode solver
PP=[Par,controlvector78];

% --------------------------------------------------------------------

% initial values
%y0=[IL15,AKT,mTOR,HIF1a,HIF1b,HIF1d,NFkB,STAT3,HIF1a-mRNA,HIF1a-aOH]
y0=[controlvector78(2),1,1,0.05,1,0.05,1,1,1,0.9];

options=odeset('RelTol',1e-6,'AbsTol',1e-6);

[t,sol]= ode23s(@model_rhs,[tinit tend],y0,options,PP);

colcode=[[0,0,0];[0,0.2,1];[1,0,0];[1,0,0.8];[0,0.8,0]];


if j==3
figure(2); 
plot(t,sol(:,2),'k-','LineWidth',3)
hold on
plot(t,sol(:,8),'b-','LineWidth',3);
hold on
plot(t,sol(:,4)+sol(:,6)+sol(:,10),'r-','LineWidth',3)
hold on
ebA=errorbar(timedata(j,:),AKTdata(j,:),errAKT(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','black')
ebA.LineWidth=1;
ebA.Color=[0,0,0];
hold on
ebS=errorbar(timedata(j,:),STAT3data(j,:),errSTAT3(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','blue')
ebS.LineWidth=1;
ebS.Color=[0,0,1];
hold on
ebH=errorbar(timedata(j,:),HIF(j,:),HIFerr(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','red')
ebH.LineWidth=1;
ebH.Color=[1,0,0];
ylabel('HIF1\alpha/STAT3/AKT')
xlabel('Time [h]')
hold on
set(gca,'FontSize',12)
xlim([tinit 12])
xticks([tinit:5:12])
ylim([0 45])
yticks([0:10:45])
%legend('AKT','STAT3','HIF-1\alpha','AKT (data)','STAT3 (data)','HIF-1\alpha (data)','Location','best')
end
    
figure(1);
if j==1
subplot(2,2,1) % j=1 IL15; j=2 DMOG; j=3 DMOG+IL15; j=4 DMOG+IL15+S3I201; j=5 DMOG+IL15+Rapa
plot(t,sol(:,2),'k-','LineWidth',3)
hold on
plot(t,sol(:,8),'b-','LineWidth',3);
hold on
plot(t,sol(:,4)+sol(:,6)+sol(:,10),'r-','LineWidth',3)
hold on
ebA=errorbar(timedata(j,:),AKTdata(j,:),errAKT(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','black')
ebA.LineWidth=1;
ebA.Color=[0,0,0];
hold on
ebS=errorbar(timedata(j,:),STAT3data(j,:),errSTAT3(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','blue')
ebS.LineWidth=1;
ebS.Color=[0,0,1];
hold on
ebH=errorbar(timedata(j,:),HIF(j,:),HIFerr(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','red')
ebH.LineWidth=1;
ebH.Color=[1,0,0];
ylabel('HIF1\alpha/STAT3/AKT')
xlabel('Time [h]')
hold on
set(gca,'FontSize',12)
xlim([tinit 12])
xticks([tinit:5:12])
ylim([0 45])
yticks([0:10:45])

elseif j==2
    subplot(2,2,2) % j=1 IL15; j=2 DMOG; j=3 DMOG+IL15; j=4 DMOG+IL15+S3I201; j=5 DMOG+IL15+Rapa
plot(t,sol(:,2),'k-','LineWidth',3)
hold on
plot(t,sol(:,8),'b-','LineWidth',3);
hold on
plot(t,sol(:,4)+sol(:,6)+sol(:,10),'r-','LineWidth',3)
hold on
ebA=errorbar(timedata(j,:),AKTdata(j,:),errAKT(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','black')
ebA.LineWidth=1;
ebA.Color=[0,0,0];
hold on
ebS=errorbar(timedata(j,:),STAT3data(j,:),errSTAT3(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','blue')
ebS.LineWidth=1;
ebS.Color=[0,0,1];
hold on
ebH=errorbar(timedata(j,:),HIF(j,:),HIFerr(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','red')
ebH.LineWidth=1;
ebH.Color=[1,0,0];
ylabel('HIF1\alpha/STAT3/AKT')
xlabel('Time [h]')
hold on
set(gca,'FontSize',12)
xlim([tinit 12])
xticks([tinit:5:12])
ylim([0 45])
yticks([0:10:45])

elseif j==4
    subplot(2,2,3) % j=1 IL15; j=2 DMOG; j=3 DMOG+IL15; j=4 DMOG+IL15+S3I201; j=5 DMOG+IL15+Rapa
plot(t,sol(:,2),'k-','LineWidth',3)
hold on
plot(t,sol(:,8),'b-','LineWidth',3);
hold on
plot(t,sol(:,4)+sol(:,6)+sol(:,10),'r-','LineWidth',3)
hold on
ebA=errorbar(timedata(j,:),AKTdata(j,:),errAKT(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','black')
ebA.LineWidth=1;
ebA.Color=[0,0,0];
hold on
ebS=errorbar(timedata(j,:),STAT3data(j,:),errSTAT3(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','blue')
ebS.LineWidth=1;
ebS.Color=[0,0,1];
hold on
ebH=errorbar(timedata(j,:),HIF(j,:),HIFerr(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','red')
ebH.LineWidth=1;
ebH.Color=[1,0,0];
ylabel('HIF1\alpha/STAT3/AKT')
xlabel('Time [h]')
hold on
set(gca,'FontSize',12)
xlim([tinit 12])
xticks([tinit:5:12])
ylim([0 45])
yticks([0:10:45])

elseif j==5
    subplot(2,2,4) % j=1 IL15; j=2 DMOG; j=3 DMOG+IL15; j=4 DMOG+IL15+S3I201; j=5 DMOG+IL15+Rapa
plot(t,sol(:,2),'k-','LineWidth',3)
hold on
plot(t,sol(:,8),'b-','LineWidth',3);
hold on
plot(t,sol(:,4)+sol(:,6)+sol(:,10),'r-','LineWidth',3)
hold on
ebA=errorbar(timedata(j,:),AKTdata(j,:),errAKT(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','black')
ebA.LineWidth=1;
ebA.Color=[0,0,0];
hold on
ebS=errorbar(timedata(j,:),STAT3data(j,:),errSTAT3(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','blue')
ebS.LineWidth=1;
ebS.Color=[0,0,1];
hold on
ebH=errorbar(timedata(j,:),HIF(j,:),HIFerr(j,:),'o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','red')
ebH.LineWidth=1;
ebH.Color=[1,0,0];
ylabel('HIF1\alpha/STAT3/AKT')
xlabel('Time [h]')
hold on
set(gca,'FontSize',12)
xlim([tinit 12])
xticks([tinit:5:12])
ylim([0 45])
yticks([0:10:45])
%legend('AKT','STAT3','HIF-1\alpha','AKT (data)','STAT3 (data)','HIF-1\alpha (data)','Location','best')

end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dy=model_rhs(t,y,P) 

% --------------------------------------------------------------------
% general rhs of the model for testing all inhibitors combinations
% --------------------------------------------------------------------

% --------------------------------------------------------------------
% parameters from previous literature/estimates
% --------------------------------------------------------------------

a1=P(1); a2=P(2); a3=P(3); a5=P(4); a7=P(5); a8=P(6); a9=P(7); a11=P(8);

d1=P(9); d2=P(10); d3=P(11); d4=P(12); d5=P(13); d6=P(14); d7=P(15); d8=P(16);
d9=P(17); d10=P(18);

k1=P(19); k2=P(20); k3=P(21); k4=P(22); k5=P(23); k6=P(24); k7=P(25); 
k8=P(26); k9=P(27); k10=P(28); k11=P(29);
k12=P(30); k13=P(31); k14=P(32);
k15=P(33); kalpha=P(34); kS=P(35);  alpha1=P(36); alpha2=P(37); n2=P(38);

xi4=P(39); xi10=P(40); xi28=P(41); xi44=P(42); rho3=P(43); rho4=P(44); 
rho6=P(45); Delta=P(46); phi=P(47);  KO2=P(48);


% --------------------------------------------------------------------
% control parameters
% --------------------------------------------------------------------
DMOG=P(49); IL150=P(50); RAPA=P(51);
STAT3inhi=P(52);
NFkBinhi=P(53);
degrinhi=P(54);

% --------------------------------------------------------------------
% equations
% --------------------------------------------------------------------


dy(1,1)= a1-d1*y(1);
dy(2,1)=a2+k1*y(1)-d2*y(2)+kS*(y(8).^2)./(xi28^2+y(8).^2); %AKT
dy(3,1)=(a3+k2*y(2)).*alpha1/(alpha2+y(6)).*(1-RAPA)-d3.*y(3); % mTOR
dy(4,1)=kalpha.*y(9)-d4.*y(4)-k4.*y(4).*y(5)+k5*y(6)-k10.*KO2*phi.*(1-rho6*DMOG).*y(4)./(xi4+y(4))...
    -k13.*(1-degrinhi)*KO2*(Delta.*y(6)+a11).*(1-rho6*DMOG).*y(4)./(xi44+y(4))+k11*y(10); %HIF1a
dy(5,1)=a5-k4.*y(4).*y(5)+k5.*y(6)-d5*y(5); %HIF1b
dy(6,1)=k4.*y(4).*y(5)-k5.*y(6)-d6.*y(6);% HIF1d
dy(7,1)=(a7+k7.*y(1)+k14.*y(6)+k15*y(3)).*(1-NFkBinhi)-d7*y(7); %NFkB
dy(8,1)=(a8+k6*(1-rho4*DMOG)*y(1)+k8*y(3)).*(1- rho3*STAT3inhi)-d8*y(8); %STAT3
dy(9,1)=a9+k9*y(7)+k3*y(8)-d9*y(9); %HIF1a-mRNA
dy(10,1)=-k11*y(10)-d10*y(10)+k10.*KO2*phi.*(1-rho6*DMOG).*y(4)./(xi4+y(4))-k12.*(1-degrinhi)*KO2*(Delta.*y(6)+a11).*(1-rho6*DMOG).*y(10)./(xi10+y(10)); % HIF1a-aOH

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [time,AKT,AKTerr,STAT3,STAT3err,HIF,HIFerr]=fun_load_data()


% Exp +IL15
TIME_Exp78a=[0,3,6,11];
HIF1a_Exp78a=[1,3.63,7.17,11.58];%
err_7a=[0.0001,1.52,1.27,2.85];%
STAT3_Exp78a=[1,36.90,31.29,26.24];% 
err_8a=0.2*STAT3_Exp78a;
AKT_Exp78a=[1,1.03,1.17,0.96];%
err_78a=0.2.*AKT_Exp78a;

% Exp : +DMOG
TIME_Exp78b=TIME_Exp78a;
HIF1a_Exp78b=[1,5.05,11.19,11.76];
err_7b=[0.0001,0.06,2.53,1.7];%
STAT3_Exp78b=[1,0.83,0.703,0.214];
err_8b=0.2.*STAT3_Exp78b;
AKT_Exp78b=[1.07,0.91,1.05,1.03]./1.07;
err_78b=0.2.*AKT_Exp78b;

% Exp :+IL15+DMOG
TIME_Exp78c=TIME_Exp78a;
HIF1a_Exp78c=[1,10.03,19.5,20.81];
err_7c=[0.0001, 0.95, 0.75,2.6];%
STAT3_Exp78c=[1,20.17,13.25,8.77];
err_8c=0.2.*STAT3_Exp78c;
AKT_Exp78c=[1.07,1.15,1.14,1.16]./1.07;
err_78c=0.2.*AKT_Exp78c;


% Exp :+IL15+DMOG+Rapa
TIME_Exp78d=TIME_Exp78a;
HIF1a_Exp78d=[1,8.67,16.13,16.3]; 
err_7d=[0.0001,1.9,1.5,2.4];%0.2*HIF1a_Exp78d;
AKT_Exp78d=[1.07,0.86,1.17,0.84]./1.07;
err_78d=0.2.*AKT_Exp78d;
STAT3_Exp78d=[1,11.19,9.33,2.49];
err_8d=0.2.*STAT3_Exp78d;


% Exp :+IL15+DMOG+STAT3inhib
TIME_Exp78e=TIME_Exp78a;
HIF1a_Exp78e=[1,6.72,14.57,12.67]; 
err_7e=[0.0001, 0.81,1.75,4.29];%
STAT3_Exp78e=[1,4.88,0.90,0.0001];
err_8e=0.2.*STAT3_Exp78e;
AKT_Exp78e=[1.07,1.03,0.93,0.41]./1.07;
err_78e=0.2.*AKT_Exp78e;


time=[TIME_Exp78a;TIME_Exp78b;TIME_Exp78c;TIME_Exp78e;TIME_Exp78d];
AKT=[AKT_Exp78a;AKT_Exp78b;AKT_Exp78c;AKT_Exp78e;AKT_Exp78d]; 
AKTerr=[err_78a;err_78b;err_78c;err_78e;err_78d];
STAT3=[STAT3_Exp78a;STAT3_Exp78b;STAT3_Exp78c;STAT3_Exp78e;STAT3_Exp78d];
STAT3err=[err_8a;err_8b;err_8c;err_8e;err_8d];
HIF=[HIF1a_Exp78a;HIF1a_Exp78b;HIF1a_Exp78c;HIF1a_Exp78e;HIF1a_Exp78d];
HIFerr=[err_7a;err_7b;err_7c;err_7e;err_7d];

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Par=fun_load_parameters(O2)

a1=0; % P(1)
a2=0.848;% P(2)
a3=0.037;% P(3)
a5=0.211;% P(4) 
a7=0;% P(5) 
a8=0;% P(6)
a9=0;% P(7) 
a11=4.17; % P(8)

d1=0.062;% % P(9)
d2=0.848;% % P(10)
d3=0.919;% % P(11)
d4=0.623; % P(12)
d5=0.196;% % P(13)
d6=0.301;% % P(14)
d7=0.914; % P(15)
d8=0.577; % P(16)
d9=0.934; % P(17)
d10=0.935; % P(18)

k1=0.00002;% P(19)
k2=0.307;% P(20)
k3=0.181; % P(21)
k4=76.196; % P(22)
k5=75.895;% P(23)
k6=25.001;% P(24) 
k7=2.903; % P(25) 
k8=0.577;% P(26) 
k9=0.753;%(27) 
k10=421.353;% P(28)
k11=0.211;% P(29)
k12=0.061;% P(30)
k13=12.152; % P(31)
k14=16.528;% P(32) 
k15=0.088; % P(33) 
kalpha=1.034; % P(34) 
kS=0.0009; % P(35)
alpha1=1.163; % P(36) 
alpha2=0.386; % P(37) 

n2=2; % P(38)

xi4=15.018;% P(39)
xi10=8.127;% P(40) 
xi28=38.44;% P(41)
xi44=128.022;% P(42)

rho3=1; % P(43)
rho4=0.863;% P(44)
rho6=0.99;% P(45)

Delta=200; % P(46)
phi=0.829;% P(47)

if O2==1
    KO2=0.06; %P(48)
elseif O2==21
    KO2=0.96;
end

Par=[a1,a2,a3,a5,a7,a8,a9,a11,d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15,kalpha,kS,alpha1,alpha2,n2,xi4,xi10,xi28,xi44,rho3,rho4,rho6,Delta,phi,KO2];

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

