% Network pharmacology modeling identifies Aurora B and ZAK synergy in MDA-MB-231 breast cancer cells'
% Jing Tang 2017-08-01

% Matlab code for running AURKB-ZAK prediction on 10 breast cancer cell lines
% Remember to set the path to the current folder where 'Timma_matlab_package' is located

% Load the drug sensitivity and drug target interaction data
load('BC_10.mat')

% Run on all cell lines
s = []; % predicted synergy score
for i = 1:10
[M,err,k] = TIMMA_floating_protect(kds_binary,sensitivity_all(:,i)/max(sensitivity_all(:,i)), 1, 2, 1,[23,384]); % fix AURKB and ZAK
s(i) = M(2,2)-M(1,2)*M(2,1);
end
res = {};
res(1,:) = cell_lines;
res(2,:) = num2cell(s);