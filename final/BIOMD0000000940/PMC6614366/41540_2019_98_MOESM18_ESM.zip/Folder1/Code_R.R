# --------------------------------------------
# Code for reproducing the Figures 1C-D and Tables S1-S3 in Tang et al.
# 'Network pharmacology modeling identifies Aurora B and ZAK synergy in MDA-MB-231 breast cancer cells'
# Jing Tang 2017-08-01
# --------------------------------------------



setwd("C://Users//Localadmin_jtang//Documents//FIMM//Drug//data//Breastcancer//MB_231//validation//drugcomb//wrapup//Manuscript//Revision//Submission//Files//Data and Code")

# -----------------------------------------------------
# Drug and target combination prediction for MDA-MB-231
# -----------------------------------------------------
# install.packages(timma)
library(timma)
rm(list = ls(all = T))

load("MDA-MB-231.RData")
# These input data were obtained from Tang et al. (2013)
# drug.target: the drug-target interaction data for 41 kinase inhibitors and 385 kinase targets, c.f. DataSet S4
# sens: the drug sensitivity data for MDA-MB-231, c.f. DataSet S7
# ksel: selected targets by timma, c.f. DataSet S7
# sirna: the siRNA combination experiment data, c.f. DataSet S8

res <- timmaModel(drug.target[, ksel], sens)

# Prediction accuracy
kinase.names <- colnames(drug.target)
select.kinase.names <- findSameSet(drug.target, ksel, kinase.names)
drug.target.select <- drug.target[, ksel]
drug.target.select <- cbind(drug.target.select, sens, res$prediction, abs(sens - res$prediction))
colnames(drug.target.select) <- c(select.kinase.names, "Scaled sensitvity (DSS)", "Prediction", "LOO prediction error")
drug.target.select = data.frame(drug.target.select,check.names = F)

# Predicted target combination efficacy matrix
gc <- graycode3(length(ksel))
gc.names <- graycodeNames(length(ksel), select.kinase.names, 
                          gc$gc_row, gc$gc_col)
nr <- gc.names$nr
nc <- t(gc.names$nc)
efficacy.mat.row <- nrow(nr) + nrow(nc)
efficacy.mat.col <- ncol(nr) + ncol(nc)
efficacy.mat <- array("", dim = c(efficacy.mat.row, efficacy.mat.col))
efficacy.mat[(nrow(nc) + 1):efficacy.mat.row, 1:ncol(nr)] <- nr
efficacy.mat[1:nrow(nc), (ncol(nr) + 1):efficacy.mat.col] <- nc
efficacy.mat[(nrow(nc) + 1):efficacy.mat.row, (ncol(nr) + 1):efficacy.mat.col] <- res$dummy
efficacy.mat[grep("-", efficacy.mat)] = ""

# These are two datasheets essentially of DataSet S7 in Tang et al. 2013
# http://journals.plos.org/ploscompbiol/article/file?type=supplementary&id=info:doi/10.1371/journal.pcbi.1003226.s007
# write.csv(drug.target.select, file = "LOO.prediction.error.csv")
# write.table(efficacy.mat, file = "Predicted.efficacy.matrix.csv", sep = ",", col.names = FALSE, 
#            row.names = FALSE)

# Rank list of drug and target combinations
drug_combo_rank = drugRank(drug.target.select[, c(1:8)], efficacy.mat,drug.target.select$`Scaled sensitvity (DSS)`)
target_comb_rank = targetRank(drug.target.select[, c(1:8)], efficacy.mat)

target.pair.all = list(0)
for(i in 1:dim(target_comb_rank)[1]){
 target.pair = as.character(target_comb_rank$Target.pair[i])
 target1 = unlist(strsplit(strsplit(target.pair,";")[[1]][1],"/"))
 # within target interactions 
 tmp1 = expand.grid(target1,target1)
 target.pair1 = data.frame(t(apply(tmp1,1,sort)), target_comb_rank$Target1.sen[i])
 names(target.pair1) = c("Target1","Target2","TIMMA")
 
 target2 = unlist(strsplit(strsplit(target.pair,";")[[1]][2],"/"))
 tmp2 = expand.grid(target2,target2)
 target.pair2 = data.frame(t(apply(tmp2,1,sort)), target_comb_rank$Target2.sen[i])
 names(target.pair2) = c("Target1","Target2","TIMMA")
 
 # between target interactions
 tmp3 = expand.grid(target1, target2)
 target.pair3 = data.frame(t(apply(tmp3,1,sort)), target_comb_rank$Sensitivity[i])
 names(target.pair3) = c("Target1","Target2","TIMMA")
 target.pair.all[[i]] = rbind(target.pair1,target.pair2,target.pair3)
}

target.pair.mat = do.call("rbind",target.pair.all)
target.pair.mat = cbind(target.pair.mat, apply(target.pair.mat,1,function(x) if(x[1]==x[2]) x[1] else paste(x[1],x[2],sep=" ")))
names(target.pair.mat)[4] = c("Target.Group")


# ----------------------------------------------------------
# Prediction accuracy on siRNA combination screen data
# ----------------------------------------------------------
# Combine the prediction and experiment data
sirna$TIMMA = target.pair.mat$TIMMA[match(sirna$Gene,target.pair.mat$Target.Group)]
# 
single = which(lapply(strsplit(as.character(sirna$Gene), " "), length) == 1)
data.single = as.data.frame(sirna[single,]) # 18 single targets
dim(data.single)

pairwise = which(lapply(strsplit(as.character(sirna$Gene), " "), length) == 2)
data.pairwise = sirna[pairwise,] # 153 double targets
dim(data.pairwise)

# Prediction accuracy
# equivalent targets are not evaluated of synergy
single.inhibition = mat.or.vec(153, 6)
colnames(single.inhibition) = c(
  "X.Inhibition1",
  "X.Inhibition2",
  "Multiplicative",
  "TIMMA1",
  "TIMMA2",
  "TIMMA.multi"
)

for (i in 1:153) {
  pair = data.pairwise$Gene[i]
  pair.name = unlist(strsplit(as.character(pair), "\\s"))
  index = lapply(pair.name, function(x)
    grep(x, data.single$Gene))
  X.Inhibition1 = data.single$`%Inhibition`[unlist(index[1])]
  X.Inhibition2 = data.single$`%Inhibition`[unlist(index[2])]
  Multiplicative = data.pairwise$`%Inhibition`[i] - X.Inhibition1*X.Inhibition2/100
  TIMMA1 = data.single$TIMMA[unlist(index[1])]
  TIMMA2 = data.single$TIMMA[unlist(index[2])]
  TIMMA.multi = data.pairwise$TIMMA[i] - TIMMA1 * TIMMA2
  single.inhibition[i,] = c(
    X.Inhibition1,
    X.Inhibition2,
    Multiplicative,
    TIMMA1,
    TIMMA2,
    TIMMA.multi
  )
}
data.pairwise = cbind(data.pairwise, single.inhibition)

# remove the target pairs that are considered as identical, e.g.EPHA5/TXK
# 110 pairs left
# equivalent targets are averaged
table.drug = read.xlsx("drug_gene.xlsx", 1)
data.pairwise.timma = data.pairwise[data.pairwise$TIMMA1 != data.pairwise$TIMMA2,]
dim(data.pairwise.timma)
group = mat.or.vec(110, 4)
colnames(group) = c("Group1", "Group2", "Group1.s", "Group2.s") # s means sorted
for (i in 1:110) {
  pair = data.pairwise.timma$Gene[i]
  pair.name = unlist(strsplit(as.character(pair), "\\s"))
  index = lapply(pair.name, function(x)
    grep(x, table.drug$Gene))
  group1 = table.drug$Group[unlist(index[1])[1]] # which drug it belongs to
  group2 = table.drug$Group[unlist(index[2])[1]]
  group[i, 1] = group1
  group[i, 2] = group2
  group[i, 3] = min(group1, group2)
  group[i, 4] = max(group1, group2)
}
data.pairwise.timma = cbind(data.pairwise.timma, group)
pair.group = with(data.pairwise.timma, TIMMA1 + TIMMA2) # 15 unique pair groups
data.pairwise.group = aggregate(data.pairwise.timma[,c("Multiplicative","TIMMA.multi","Group1.s","Group2.s")], list(pair.group), mean)
dim(data.pairwise.group)

score.drug = list(0)
for (i in 1:15) {
  drug1.index = grep(data.pairwise.group$Group1.s[i], table.drug$Group)
  drug2.index = grep(data.pairwise.group$Group2.s[i], table.drug$Group)
  drug1 = unique(table.drug$Drug[drug1.index]) # drugs that hit target1
  drug2 = unique(table.drug$Drug[drug2.index]) # drugs that hit target2
  n = expand.grid(drug1, drug2)
  tmp = mat.or.vec(dim(n)[1], 4)
  for (j in 1:dim(n)[1]) {
    tmp[j, 1] = as.character(n[j, 1])
    tmp[j, 2] = as.character(n[j, 2])
    tmp[j, 3] = table.drug$Sens[grep(n[j, 1], table.drug$Drug)[1]]
    tmp[j, 4] = table.drug$Sens[grep(n[j, 2], table.drug$Drug)[1]]
  }
  tmp = cbind(tmp, data.pairwise.group[rep(i, each = dim(n)[1]),])
  score.drug[[i]] = tmp
}
score.drug.mat = score.drug[[1]]
for (i in 2:length(score.drug)) {
  score.drug.mat = rbind(score.drug.mat, score.drug[[i]])
}
colnames(score.drug.mat)[1:4] = c("Drug1", "Drug2", "Drug1.sens", "Drug2.sens")
score.drug.mat$Drug1.sens = as.numeric(as.character(score.drug.mat$Drug1.sens))
score.drug.mat$Drug2.sens = as.numeric(as.character(score.drug.mat$Drug2.sens))
score.drug.mat$Drug1 = as.character(score.drug.mat$Drug1)
score.drug.mat$Drug2 = as.character(score.drug.mat$Drug2)

DrugComb = c(0)
for (i in 1:dim(score.drug.mat)[1]) {
  DrugComb[i] = paste(sort(c(
    score.drug.mat$Drug1[i], score.drug.mat$Drug2[i]
  )), collapse = " ")
}
score.drug.mat$DrugComb = as.factor(DrugComb)
score.drug.comb = aggregate(score.drug.mat[,c("Multiplicative","TIMMA.multi")], list(DrugComb), mean) 
dim(score.drug.comb) # 69 3

d1 = data.frame(
  Multi = score.drug.comb$TIMMA.multi,
  siRNA = score.drug.comb$Multiplicative,
  Group = score.drug.comb$Group.1
)
# --------------
# Table S2
# --------------
write.xlsx(d1,"d1.xlsx")
index = grep(paste(table.drug$Gene[which(table.drug$Drug=="Dasatinib")],collapse ="|"),data.pairwise.timma$Gene)
t.test(data.pairwise.timma$`%Inhibition`[-index],data.pairwise.timma$`%Inhibition`[index]) # 0.017
wilcox.test(data.pairwise.timma$`%Inhibition`[-index],data.pairwise.timma$`%Inhibition`[index]) # 0.04

# -----------
# Table S3
# -----------
pairwise.sirna = cbind(data.pairwise.timma,0)
pairwise.sirna[index,14]=1
write.xlsx(pairwise.sirna,"pairwise.sirna.xlsx")
write.xlsx(data.single, "data.single.xlsx")
# combining pairwise.sirna and data.single results in Table S3

# ----------------------
# Figure 1D right panel
# ----------------------
boxplot(
  data.pairwise.timma$`%Inhibition`[index],
  data.pairwise.timma$`%Inhibition`[-index],
  names = c("Dasatinib target group", "Others"),
  main = "p = 0.02",
  ylab = "% Inhibition"
)

tmp = d1
mean(tmp$Multi)
tmp = cbind(tmp,cut(d1$Multi,breaks=c(0,0.32,1)))
colnames(tmp)[4] = 'group'
# tmp.group = ddply(tmp,.(group),summarise, mean(siRNA),length(siRNA))
t.test(siRNA~group,data=tmp) # p-value = 1.045e-11
wilcox.test(siRNA~group, data=tmp) # p-value = 2.463e-07

# ----------------------
# Figure 1C right panel
# ----------------------
boxplot(siRNA~group, data=tmp,xlab="Predicted drug combination group",ylab="siRNA synergy score")


# ---------------------------------------------------------------------------
# Prediction accuracy on drug combination screen data
# ---------------------------------------------------------------------------
# calculation of drug combination synergy score (bliss score)
library(drc)
library(caTools)
library(plyr)
# rm(list = ls(all = T))

# load the code for calculting the Bliss synergy scores
source('selectcombo.R')
source('get_fittedsingledrugs.R')
source('SDbaselineCor.R')
source('twowayfitting.R')

# load the drug combination plate data
load("plate.mat.all.RData")
load("conc.range.RData")
load("pair.list.all.RData")

# MAIN
nplates=23
combonr=0
bliss_all=list()
pp_cor_final_all=list()
pp_diff_final_all=list()
for (i in 1:nplates){
  
  # baseline correction
  plate.mat = plate.mat.all[[i]]
  pair.list = pair.list.all[which(pair.list.all$plate==i),]
  pair.list = data.frame(lapply(pair.list,as.character),stringsAsFactors=FALSE) # change the factor to character
  pair.list[is.na(pair.list)]="NA"
  # colnames(pair.list)=c("index","drug1","drug2","cell.line","plate")
  if (combonr==0) {
    output_baseline1 = SDbaselineCor(plate.mat,1,conc.range,pair.list)
    output_baseline2 = SDbaselineCor(plate.mat,2,conc.range,pair.list)
    output_baseline3 = SDbaselineCor(plate.mat,3,conc.range,pair.list)
    output_baseline4 = SDbaselineCor(plate.mat,4,conc.range,pair.list)
    output_baseline5 = SDbaselineCor(plate.mat,5,conc.range,pair.list)
    output_baseline6 = SDbaselineCor(plate.mat,6,conc.range,pair.list)
    output_baseline = list(output_baseline1,output_baseline2,output_baseline3,output_baseline4,output_baseline5,output_baseline6)
    
    tmp1 = cbind(output_baseline1[[2]],output_baseline2[[2]],output_baseline3[[2]])
    tmp2 = cbind(output_baseline4[[2]],output_baseline5[[2]],output_baseline6[[2]])
    pp_cor_baseline = rbind(tmp1,tmp2) # after baseline correction
    row.names(pp_cor_baseline) = NULL
    colnames(pp_cor_baseline) = NULL
    
    tmp3 = cbind(output_baseline1[[1]],output_baseline2[[1]],output_baseline3[[1]])
    tmp4 = cbind(output_baseline4[[1]],output_baseline5[[1]],output_baseline6[[1]])
    pp = rbind(tmp3,tmp4) # raw data
    row.names(pp) = NULL
    colnames(pp) = NULL     
  } else {
    output_baseline= SDbaselineCor(plate.mat,combonr,conc.range,pair.list)
    pp_cor_baseline = output_baseline[[2]]
    row.names(pp_cor_baseline) = NULL
    colnames(pp_cor_baseline) = NULL
    pp = output_baseline[[1]]
    row.names(pp) = NULL
    colnames(pp) = NULL
  }
  
  # two way fitting
  if (length(output_baseline)==6){ # whole plate analysis
    output = list()
    for (j in 1:6){
      pp = output_baseline[[j]][[1]]
      pp_cor=output_baseline[[j]][[2]] 
      drug_pair=output_baseline[[j]][[3]]
      output[[j]] = twowayfitting(pp,pp_cor,drug_pair)
    }
    tmp1 = cbind(output[[1]][[2]],output[[2]][[2]],output[[3]][[2]])
    tmp2 = cbind(output[[4]][[2]],output[[5]][[2]],output[[6]][[2]])
    pp_cor_final = rbind(tmp1,tmp2)
    row.names(pp_cor_final) = NULL
    colnames(pp_cor_final) = NULL
    
    tmp3 = cbind(output[[1]][[3]],output[[2]][[3]],output[[3]][[3]])
    tmp4 = cbind(output[[4]][[3]],output[[5]][[3]],output[[6]][[3]])
    pp_diff_final = rbind(tmp3,tmp4)
    row.names(pp_diff_final) = NULL
    colnames(pp_diff_final) = NULL
    
    tmp5 = cbind(output[[1]][[1]],output[[2]][[1]],output[[3]][[1]])
    tmp6 = cbind(output[[4]][[1]],output[[5]][[1]],output[[6]][[1]])
    bliss_final = rbind(tmp5,tmp6)
    
  } else { # single drug comb
    
    pp=output_baseline[[1]] # raw matrix
    pp_cor=output_baseline[[2]] # after baseline correction
    drug_pair=output_baseline[[3]] # drug names
    output = twowayfitting(pp,pp_cor,drug_pair)
    bliss_final = output[[1]]
    pp_cor_final = output[[2]]
    pp_diff_final = output[[3]]
    
  }
  
  bliss_all[[i]] = bliss_final/49 # average on the 7x7 dose combinations
  pp_cor_final_all[[i]] = pp_cor_final
  pp_diff_final_all[[i]] = pp_diff_final
  
}

bliss_list = unlist(lapply(bliss_all,t))
bliss_res = data.frame(pair.list.all,bliss_list,NA,NA)
names(bliss_res)[7] = "TIMMA"
names(bliss_res)[8] = "Group"
for(i in 1:dim(bliss_res)[1]){
  # duplicated drug combinations in different concentration ranges
  tmp = sort(c(strsplit(as.character(bliss_res$drug1[i]),"_")[[1]][1],strsplit(as.character(bliss_res$drug2[i]),"_")[[1]][1]))
  tmp[grep("Barasertib",tmp)] = "AZD1152-HQPA"

  index = which(drug_combo_rank$Drug1 == tmp[1] & drug_combo_rank$Drug2 == tmp[2])
  if (length(index)!=0) {bliss_res$TIMMA[i] = drug_combo_rank$Synergy.multi[index];  bliss_res$Group[i] = paste(tmp, collapse = " ")}
}
bliss_res_valid = bliss_res[is.na(bliss_res$TIMMA)==F,]
dim(bliss_res_valid) # 70 8
bliss_res_output = ddply(bliss_res_valid,.(Group), summarise, Bliss = mean(bliss_list), TIMMA = mean(as.numeric(TIMMA)))

# ------------------
# Table S1
# ------------------
mean(bliss_res_output$TIMMA) # 0.3485
tmp = cbind(bliss_res_output,cut(bliss_res_output$TIMMA,breaks=c(0,0.3485,1)))
colnames(tmp)[4] = 'group'
t.test(Bliss~group,data=tmp) # p-value = 0.0006
wilcox.test(Bliss~group,data=tmp) # p-value = 0.0008
write.xlsx(bliss_res_output,"bliss_res_output.xlsx")

# --------------------
# Figure 1C left panel
# --------------------
boxplot(Bliss~group, data=tmp,xlab="Predicted drug combination group",ylab="Bliss synergy score")


# -------------------
# Figure 1D left panel
# -------------------
dasatinib = bliss_res_output$Bliss[grep("Dasatinib",bliss_res_output$Group)]
nondasatinib = bliss_res_output$Bliss[-grep("Dasatinib",bliss_res_output$Group)]
t.test(dasatinib, nondasatinib) # 6.155e-06
wilcox.test(dasatinib, nondasatinib) # 4.613e-06

boxplot(
  dasatinib,
  nondasatinib,
  names = c("Dasatinib drug group", "Others"),
  main = "p < 0.0001",
  ylab = "Bliss synergy score"
)


