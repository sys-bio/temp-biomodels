# ------------------------------------------------------------------------------------
# Function SDBASELINECOR() 
# for baseline correction using single drugs
# ------------------------------------------------------------------------------------
SDbaselineCor<-function(plate.mat,combonr,conc.range,pair.list){
  combonr = unlist(combonr)
  
  conc.range = apply(conc.range,2,as.character)
  pair.list$index = as.character(pair.list$index)
  pp<-as.matrix(selectcombo(plate.mat,combonr))
  pp=apply(pp,2,as.numeric)
  pp[8,8]<-NA
  
  drugpair<-subset(pair.list,pair.list$index==combonr)
  #print(drugpair)
  d1c<-subset(conc.range,conc.range[,1]==drugpair$drug1)[,2:ncol(conc.range)]
  d2c<-subset(conc.range,conc.range[,1]==drugpair$drug2)[,2:ncol(conc.range)] #conc test range for drug 2 (2nd col in vv/pairslist)
  
  coleffect<-as.vector(as.matrix(pp)) #combined column wise (col1,col2,col3 etc)
  roweffect<-as.vector(t(as.matrix(pp))) 
  rownames(pp)<-as.character(d2c)
  colnames(pp)<-as.character(d1c)
  
  # print(pp)
  d1<-as.vector(unlist(rep(d1c,times=ncol(pp)))) 
  d2<-as.vector(unlist(rep(d2c,times=ncol(pp)))) 
  
  concd1<-as.vector(sapply(d1c,rep,times=nrow(pp)))
  concd2<-as.vector(sapply(d2c,rep,times=nrow(pp)))
  
  rowwise<-data.frame(as.numeric(d1),as.numeric(concd2),roweffect) # data combined row wise, rows are concatenated
  colwise<-data.frame(as.numeric(d2), as.numeric(concd1), coleffect) # data combined column wise, columns are concatenated
  
  colnames(rowwise)[c(1,2)]<-c("conc_d1", "conc_d2")
  colnames(colwise)[c(1,2)]<-c("conc_d2", "conc_d1")
  
  single1<-rowwise[1:8,c(1,3)] # single drug denoted as the first row in the original matrix
  colnames(single1)<-c("conc","effect")
  # print(single1)
  
  single2<-colwise[1:8,c(1,3)] # single drug denoted as the first column in the original matrix
  colnames(single2)<-c("conc","effect")
  
  #fitting single drugs independently
  sd1<-get_fittedsingledrugs(single1[-1,])
  # print(sd1)
  # print(single1)
  sd2<-get_fittedsingledrugs(single2[-1,])
  # print(sd2)
  # print(single2)
  
  baseline1<-(min(as.numeric(sd1))+min(as.numeric(sd2)))/2
  baseline2 = min(min(as.numeric(sd1)),min(as.numeric(sd2)))
  baseline3 = ifelse(baseline1>30,single2[1,1],baseline1)
  
  baseline = baseline1 # VBS4
  # baseline = baseline2 # VBS5
  # baseline = baseline3 # VBS6
  # print(baseline)
  
  # CORRECT MATRIX BY A WEIGHTED CORRECTION FACTOR
  pp_cor<-pp-((100-pp)/100*baseline)
  
  # any negative values will be 0
  # pp_cor[which(pp_cor<0)]=0
  
  rownames(pp_cor)<-as.character(d2c)
  colnames(pp_cor)<-as.character(d1c)
  
  output = list(pp, pp_cor,drugpair)
  return(output) # return the adjusted matrix, and drug names
}
