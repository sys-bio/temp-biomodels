# ------------------------------------------------------------------------------------
# Function TWOWAYFITTING() 
#
# ------------------------------------------------------------------------------------
twowayfitting=function(pp,pp_cor,drug_pair) {
  #print(pp_cor)
  #print(drug_pair)
  
  # Fitting single drugs using logistic functions
  # NA values treated
  # Drug 1 fitting (fitting the first row)
  drug1=as.data.frame(mat.or.vec(7,0)) # first row in the matrix
  drug1$dose=as.numeric(colnames(pp_cor)[-1])
  #print(drug1)
  drug1$logconc=log10(drug1$dose)
  drug1$inhibition=as.numeric(pp_cor[1,-1])
  # NA values now treated
  drug1_model=drm(inhibition ~ logconc, data = drug1, fct = L.4(fixed = c(NA, NA, NA,NA), names = c("SLOPE","MIN","MAX","IC50")),logDose=10,na.action=na.omit)
  drug1$fitted_inhibition = PR(drug1_model,log10(drug1$dose))
  
  # Drug 2 fitting (fitting the first column)
  drug2=as.data.frame(mat.or.vec(7,0)) # first column in the matrix
  drug2$dose=as.numeric(rownames(pp_cor)[-1])
  #print(drug2)
  drug2$logconc=log10(drug2$dose)
  drug2$inhibition=as.numeric(pp_cor[-1,1])
  drug2_model=drm(inhibition ~ logconc, data = drug2, fct = L.4(fixed = c(NA, NA, NA,NA), names = c("SLOPE","MIN","MAX","IC50")),logDose=10,na.action=na.omit)
  drug2$fitted_inhibition = PR(drug2_model,log10(drug2$dose))
  
  # Update the first row and first column
  pp_cor_2 = mat.or.vec(8,8)
  colnames(pp_cor_2) = colnames(pp_cor)
  rownames(pp_cor_2) = rownames(pp_cor)
  pp_cor_2[1,c(2:8)] = drug1$fitted_inhibition
  pp_cor_2[c(2:8),1] = drug2$fitted_inhibition
  #print(pp_cor_2)
  
  # Update the column2-column8
  pp_cor_3 = pp_cor_2
  for (i in 2:8){
    tmp = as.data.frame(mat.or.vec(7,0))
    tmp$dose = drug2$dose
    tmp$logconc = drug2$logconc
    tmp$inhibition = pp_cor[c(2:8),i]
    tmp_min = pp_cor_2[1,i]
    tmp_model=drm(inhibition ~ logconc, data = tmp, fct = L.4(fixed = c(NA, tmp_min, NA,NA), names = c("SLOPE","MIN","MAX","IC50")),logDose=10,na.action=na.omit)
    tmp$fitted_inhibition = PR(tmp_model,tmp$logconc)
    if(tmp$fitted_inhibition[7]<0) tmp$fitted_inhibition[7]=tmp_min
    pp_cor_3[c(2:8),i] = tmp$fitted_inhibition
    #print(tmp)
  }
  #print(pp_cor_3)
  
  # Update the row2-row8
  pp_cor_4 = pp_cor_2
  for (i in 2:8){
    tmp = as.data.frame(mat.or.vec(7,0))
    tmp$dose = drug1$dose
    tmp$logconc = drug1$logconc
    tmp$inhibition = pp_cor[i,c(2:8)]
    tmp_min = pp_cor_2[i,1]
    tmp_model=drm(inhibition ~ logconc, data = tmp, fct = L.4(fixed = c(NA, tmp_min, NA,NA), names = c("SLOPE","MIN","MAX","IC50")),logDose=10,na.action=na.omit)
    tmp$fitted_inhibition = PR(tmp_model,tmp$logconc)
    if(tmp$fitted_inhibition[7]<0) tmp$fitted_inhibition[7]=tmp_min
    pp_cor_4[i,c(2:8)] = tmp$fitted_inhibition
    #print(tmp)
  }
  #print(pp_cor_4)
  
  # take average of pp_cor_3 and pp_cor_4 as pp_cor_final
  pp_cor_final = (pp_cor_3+pp_cor_4)/2
  #print(pp_cor_final)
  #print(pp)
  
  # make pp_cor_bliss based on pp_cor_2
  pp_cor_bliss = pp_cor_2
  for (i in 2:8){
    for (j in 2:8){
      pp_cor_bliss[i,j] = pp_cor_2[i,1]+pp_cor_2[1,j]-pp_cor_2[i,1]*pp_cor_2[1,j]/100
    }
  }
  # negative and positive controls are removed
  pp_cor_final[1,1]=0
  pp_cor_bliss[1,1]=0 
  #pp_cor_bliss[8,8]=0
  pp_cor_final[8,8]=ifelse(pp_cor_final[8,8]>100,100,pp_cor_final[8,8]) # cannot be over 100 for the estimation
  
  pp_diff=(pp_cor_final-pp_cor_bliss)
  
  #print(pp_cor_2)
  #print(pp_cor_bliss)
  #print(pp_cor_final)
  
  # Calculate the volumn difference
  x=c(1:8);
  y=c(1:8);
  z1=pp_cor_final;
  z2=pp_cor_bliss;
  tmp1=mat.or.vec(1,8)
  tmp2=mat.or.vec(1,8)
  for (i in 1:8){
    tmp1[i] = trapz(x,z1[,i])	
    tmp2[i] = trapz(x,z2[,i])
  }
  V_observed = trapz(y,tmp1)
  V_expected = trapz(y,tmp2)
  
  # VBS = (V_observed-V_expected)/V_expected
  # VBS = (V_observed-V_expected)/V_observed
  VBS = V_observed-V_expected
  
  #print(V_observed)
  #print(V_expected)
  #print(VBS)
  
  # output_final = cbind(VBS, V_observed, V_expected)
  # colnames(output_final) = c("VBS","V_observed","V_expected")
  
  # beta = mean(pp_cor_final-pp_cor_bliss,na.rm=T)
  # output_final = beta
  output_final = VBS
  
  
  
  
  # output to visualization
  # add drug names and concentrations into pp_cor_final and pp_diff_final
  # drug_pair_col = t(matrix(rep(c(as.character(drug_pair$drug1),as.character(drug_pair$drug2)),8),nrow=2))
  # colnames(drug_pair_col) = c("drug1","drug2")
  drug_pair_col = cbind(colnames(pp_cor),rownames(pp_cor))
  colnames(drug_pair_col) = c(as.character(drug_pair$drug1),as.character(drug_pair$drug2))
  drug_pair_col[1,] = c(as.character(drug_pair$drug1),as.character(drug_pair$drug2))
  
  pp_cor_final = cbind(pp_cor_final, drug_pair_col) # output to sensitivity plot
  pp_diff_final=cbind(pp_diff,drug_pair_col)        # output to synergy plot
  
  output = list(output_final,pp_cor_final,pp_diff_final)
  return(output)
} #END of the function
