# --------------------------------------------------------------------------------------
# Function SELECTCOMBO()
# select one drug combination data from the plate matrix
# --------------------------------------------------------------------------------------
selectcombo<-function(x,combonr){
	if(combonr==1) (xx<-x[1:8,1:8])
	if(combonr==2) (xx<-x[1:8,9:16])
	if (combonr==3) (xx<-x[1:8,17:24])
	if (combonr==4) (xx<-x[9:16,1:8])
	if (combonr==5) (xx<-x[9:16,9:16])
	if (combonr==6) (xx<-x[9:16,17:24])
	return(xx)
}