# Function GET_FITTEDSINGLEDRUGS()
get_fittedsingledrugs <- function(pp){				
  #Estimate the starting parameters ic50
  pp = as.data.frame(apply(pp,2,as.numeric))
  estimate_param <- tryCatch({ 
    drm(effect ~ conc, data = pp, fct = LL.4(fixed = c(NA,NA,NA,NA),names = c("SLOPE","MIN","MAX","IC50")),na.action=na.omit,control = drmc(errorm = FALSE))
  }, warning=function(w){
    drm(effect ~ conc, data = pp, fct = L.4(fixed = c(NA,NA,NA,NA), names = c("SLOPE","MIN","MAX","IC50")),na.action=na.omit)
    
  },error=function(e){
    drm(effect ~ conc, data = pp, fct = L.4(fixed = c(NA,NA,NA,NA),na.action=na.omit,names = c("SLOPE","MIN","MAX","IC50")))
  })
  fitted(estimate_param)
  # PR(estimate_param,pp$conc)
}