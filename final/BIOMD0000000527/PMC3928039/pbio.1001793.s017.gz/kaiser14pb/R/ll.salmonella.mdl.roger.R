ll.salmonella.mdl.roger <-
function (parms, data) 
{
    if (sum(parms < 0) == 0) {
        n <- dim(data)[1]
        ll <- vector("numeric", length = n)
        gr <- matrix(rep(0, 3 * n), ncol = 3)
        for (i in 1:n) {
            ll[i] <- pk.log(parms, data[i, ])$ll
            gr[i, ] <- pk.log(parms, data[i, ])$gr
        }
        list(ll = sum(ll), gr = colSums(gr))
    }
    else {
        list(ll = NA, gr = c(NA, NA, NA))
    }
}
