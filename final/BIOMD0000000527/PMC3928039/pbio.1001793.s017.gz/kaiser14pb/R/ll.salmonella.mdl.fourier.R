ll.salmonella.mdl.fourier <-
function (parms, data, prob.gen.fct = pgf.treat.d3, N = 2^14) 
{
    if (sum(parms < 0) == 0) {
        n <- dim(data)[1]
        ll <- vector("numeric", length = n)
        gr <- matrix(rep(0, 3 * n), ncol = 3)
        for (t in unique(data$day)) {
            ind <- (data$day == t)
            ll[ind] <- log(Re(fft(Conj(prob.gen.fct(parms, t = t, 
                s = exp((0+1i) * seq(0, N - 1, length = N) * 
                  2 * pi/N))), inverse = T)/N)[(data[ind, ])$number + 
                1])
            gr[ind, ] <- NA
        }
        list(ll = sum(ll), gr = colSums(gr))
    }
    else {
        list(ll = NA, gr = c(NA, NA, NA))
    }
}
