pgf.treat.d3 <-
function (parms = c(r = 3, c = 3.5, muG = 0), t = 3, s) 
{
    t <- t - 1
    with(as.list(parms), {
        s0 <- ((r * s - c) * exp(c * t - r * t) - c * s + c)/((r * 
            s - c) * exp(c * t - r * t) - r * s + r)
        pgf.salmonella(parms = c(r = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300", 
            "r"], c = 0, muG = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300", 
            "muW"]), t = 1, s0)
    })
}
