pgf.salmonella <-
function (parms = c(r = 3, c = 0, muG = 1), t = 1, s) 
{
    with(as.list(parms), {
        return(((r - c)/(r * s * (1 - exp((r - c) * t)) + r * 
            exp((r - c) * t) - c))^(muG/r))
    })
}
