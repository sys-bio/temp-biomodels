pk.log <-
function (parms, dataline) 
{
    if (dim(dataline)[1] != 1) {
        list(ll = NA, gr = c(NA, NA, NA))
        cat("Exactly one datapoint into pk.log, please!\n")
    }
    if (sum(parms < 0) > 0) {
        list(ll = NA, gr = c(NA, NA, NA))
    }
    else {
        with(as.list(parms), {
            k <- as.integer(dataline$number)
            t <- as.numeric(dataline$day)
            if (k == 0) {
                summe <- 0
                dsumme.dr <- 0
                dsumme.dmuG <- 0
            }
            if (k > 0) {
                summe <- sum(sapply(1:k, function(j) log(1 + 
                  (muG/r - 1)/j)))
                dsumme.dr <- sum(sapply(1:k, function(j) -muG/(j * 
                  r^2 * ((muG/r - 1)/j + 1))))
                dsumme.dmuG <- sum(sapply(1:k, function(j) 1/(j * 
                  r * ((muG/r - 1)/j + 1))))
            }
            pk.log <- (muG/r) * log((r - c)/(r * exp((r - c) * 
                t) - c)) + k * log((r * (exp((r - c) * t) - 1))/(r * 
                exp((r - c) * t) - c)) + summe
            gr.r <- -((((c^2 - r^2) * exp(r * t + c * t) + (r^2 - 
                c * r) * exp(2 * r * t) + (c * r - c^2) * exp(2 * 
                c * t)) * log((r - c) * exp(c * t)/(r * exp(r * 
                t) - c * exp(c * t))) + ((c * r^2 - r^3) * t + 
                2 * c * r) * exp(r * t + c * t) + ((r^3 - c * 
                r^2) * t - c * r) * exp(2 * r * t) - c * r * 
                exp(2 * c * t)) * muG + ((-k * r^4 + 2 * c * 
                k * r^3 - c^2 * k * r^2) * t + c * k * r^2 - 
                c^2 * k * r) * exp(r * t + c * t) + (c^2 * k * 
                r - c * k * r^2) * exp(2 * c * t))/((c^2 * r^2 - 
                r^4) * exp(r * t + c * t) + (r^4 - c * r^3) * 
                exp(2 * r * t) + (c * r^3 - c^2 * r^2) * exp(2 * 
                c * t)) + dsumme.dr
            gr.c <- ((((c - r) * t + 2) * exp(r * t + c * t) + 
                ((r - c) * t - 1) * exp(2 * r * t) - exp(2 * 
                c * t)) * muG + ((-k * r^2 + 2 * c * k * r - 
                c^2 * k) * t + k * r - c * k) * exp(r * t + c * 
                t) + (c * k - k * r) * exp(2 * c * t))/((c^2 - 
                r^2) * exp(r * t + c * t) + (r^2 - c * r) * exp(2 * 
                r * t) + (c * r - c^2) * exp(2 * c * t))
            gr.muG <- (1/r) * log((r - c)/(r * exp((r - c) * 
                t) - c)) + dsumme.dmuG
            list(ll = pk.log, gr = c(gr.r, gr.c, gr.muG))
        })
    }
}
