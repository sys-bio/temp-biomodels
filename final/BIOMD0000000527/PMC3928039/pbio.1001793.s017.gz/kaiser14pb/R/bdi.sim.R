bdi.sim <-
function (parms = c(r = 3, c = 0, mu = 1), time.final = 1, M0 = 0, 
    output.data = FALSE) 
{
    if (M0 == 0) {
        if (parms["mu"] > 0)
            t1 <- rexp(1, rate = parms["mu"])
        else
            t1 <- time.final
    }
    if (M0 > 0) 
        t1 <- 0
    if (t1 < time.final) {
        if (M0 == 0) 
            M.init <- c(M = 1)
        if (M0 > 0) 
            M.init <- c(M = M0)
        a <- c("mu", "r*M", "c*M")
        nu <- matrix(c(+1, +1, -1), ncol = 3)
        sim <- ssa(x0 = M.init, a = a, nu = nu, parms = parms, 
            tf = time.final - t1, method = "D", simName = "Simulation of the birth-death process with immigration", 
            ignoreNegativeState = TRUE, consoleInterval = 0, 
            censusInterval = 0, verbose = FALSE, maxWallTime = Inf)
        l <- dim(sim$data)[1]

        if(sim$data[l,2] == 0 & parms["c"] > 0 & parms["mu"] > 0) {
          cat("If c>0, bdi.sim() has to be used with caution.\nYou are seeing this message because you define c>0 and your run went extinct.\nThis simulation is incorrect!\n")
          sim$data[l,2] <- NA
        }
    
        if (!output.data) 
            return(sim$data[l, 2])
        if (output.data) {
            if (M0 == 0) {
                return(list(final = sim$data[l, 2], data = data.frame(t = c(0, 
                  t1 + as.vector(sim$data[1:(l - 1), 1])), M = c(0, 
                  as.vector(sim$data[1:(l - 1), 2])))))
            }
            if (M0 > 0) {
                return(list(final = sim$data[l, 2], data = data.frame(t = t1 + 
                  as.vector(sim$data[1:(l - 1), 1]), M = as.vector(sim$data[1:(l - 
                  1), 2]))))
            }
        }
    }
    else {
        if (!output.data) 
            return(0)
        if (output.data) 
            list(final = 0, data = data.frame(t = c(0, time.final), 
                M = c(0, 0)))
    }
}
