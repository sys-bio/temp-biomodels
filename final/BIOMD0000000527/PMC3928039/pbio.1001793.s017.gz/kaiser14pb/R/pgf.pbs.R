pgf.pbs <-
function (parms = c(r = 3, c = 0, muG = 1), t = 3, s) 
{
    t <- t - 1
    with(as.list(parms), {
        s0 <- ((r * s - c) * exp(c * t - r * t) - c * s + c)/((r * 
            s - c) * exp(c * t - r * t) - r * s + r)
        gs <- pgf.salmonella(parms = c(r = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == 
            "SB300", "r"], c = 0, muG = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == 
            "SB300", "muW"]), t = 1, s0)
        fs <- ((r - c)/(r * s * (1 - exp((r - c) * t)) + r * 
            exp((r - c) * t) - c))^(muG/r)
        gs * fs
    })
}
