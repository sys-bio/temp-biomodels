sim.treat <-
function (parms.d1 = c(r = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300", "r"], 
    c = 0, mu = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300", "mu.total"]), parms.d3 = c(r = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == 
    "SB300.cipro.d3", "r"], c = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300.cipro.d3", 
    "c"], mu = 0), parms.d5 = c(r = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300.cipro.d5", 
    "r"], c = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300.cipro.d5", "c"], mu = 0), 
    parms.d10 = c(r = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300.cipro.d10", 
        "r"], c = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300.cipro.d10", "c"], 
        mu = 0), output.data = TRUE) 
{
    sim.d1 <- bdi.sim(parms = parms.d1, time.final = 1, M0 = 0, 
        output.data = output.data)
    if (output.data) {
        l <- dim(sim.d1$data)[1]
        sim.d1$data <- sim.d1$data[1:(l - 1), ]
    }
    if (output.data) 
        start <- sim.d1$final
    else start <- sim.d1
    sim.d3 <- bdi.sim(parms = parms.d3, time.final = 2, M0 = start, 
        output.data = output.data)
    if (output.data) {
        sim.d3$data[, 1] <- sim.d3$data[, 1] + 1
        l <- dim(sim.d3$data)[1]
        sim.d3$data <- sim.d3$data[1:(l - 1), ]
    }
    if (output.data) 
        start <- sim.d3$final
    else start <- sim.d3
    sim.d5 <- bdi.sim(parms = parms.d5, time.final = 2, M0 = start, 
        output.data = output.data)
    if (output.data) {
        sim.d5$data[, 1] <- sim.d5$data[, 1] + 3
        l <- dim(sim.d5$data)[1]
        sim.d5$data <- sim.d5$data[1:(l - 1), ]
    }
    if (output.data) 
        start <- sim.d5$final
    else start <- sim.d5
    sim.d10 <- bdi.sim(parms = parms.d10, time.final = 5, M0 = start, 
        output.data = output.data)
    if (output.data) 
        if (output.data) 
            sim.d10$data[, 1] <- sim.d10$data[, 1] + 5
    if (output.data) {
        rbind(sim.d1$data, sim.d3$data, sim.d5$data, sim.d10$data)
    }
    else {
        c(d1 = sim.d1, d3 = sim.d3, d5 = sim.d5, d10 = sim.d10)
    }
}
