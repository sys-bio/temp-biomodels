fit.function.muG0 <-
function (data = subset(kaiser14pb.data, mouse.type=="wt+Cipro" & day==3), pgf = pgf.treat.d3, 
    output.sd = T) 
{
    fit.WITS <- try(optim(c(2, 2.5), fn = function(x) ll.salmonella.mdl.fourier(parms = c(r = x[1], 
        c = x[2], muG = 0), data = data, prob.gen.fct = pgf, 
        N = 2^14)$ll, control = list(fnscale = -1), hessian = output.sd))
    if (class(fit.WITS) != "try-error") {
        list(pars = c(r = fit.WITS$par[[1]], c = fit.WITS$par[[2]]), 
            sd = c(sd.r = sqrt(abs(1/fit.WITS$hessian[1, 1])), 
                sd.c = sqrt(abs(1/fit.WITS$hessian[2, 2]))), 
            ll = fit.WITS$value, convergence = fit.WITS$convergence, 
            fit.message = fit.WITS$message)
    }
    else {
        list(pars = c(r = NA, c = NA), ll = NA, sd = c(sd.r = NA, 
            sd.c = NA), convergence = NA, fit.message = NA)
    }
}
