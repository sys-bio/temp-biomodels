fit.function.c0 <-
function (data = subset(kaiser14pb.data, mouse.type=="wt"), pgf = NULL, output.sd = T) 
{
    fit.WITS <- try(optim(c(3, 1), fn = function(x) ll.salmonella.mdl.roger(parms = c(r = x[1], 
        c = 0, muG = x[2]), data = data)$ll, gr = function(x) ll.salmonella.mdl.roger(parms = c(r = x[1], 
        c = 0, muG = x[2]), data = data)$gr[c(1, 3)], method = "BFGS", 
        control = list(fnscale = -1), hessian = output.sd))
    if (class(fit.WITS) != "try-error") {
        list(pars = c(r = fit.WITS$par[[1]], muG = fit.WITS$par[[2]]), 
            sd = c(sd.r = sqrt(abs(1/fit.WITS$hessian[1, 1])), 
                sd.muG = sqrt(abs(1/fit.WITS$hessian[2, 2]))), 
            ll = fit.WITS$value, convergence = fit.WITS$convergence, 
            fit.message = fit.WITS$message)
    }
    else {
        list(pars = c(r = NA, muG = NA), ll = NA, sd = c(sd.r = NA, 
            sd.muG = NA), convergence = NA, fit.message = NA)
    }
}
