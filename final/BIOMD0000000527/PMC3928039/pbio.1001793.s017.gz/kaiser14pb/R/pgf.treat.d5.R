pgf.treat.d5 <-
function (parms = c(r = 3, c = 3.5, muG = 0), t = 5, s) 
{
    t <- t - 3
    with(as.list(parms), {
        s0 <- ((r * s - c) * exp(c * t - r * t) - c * s + c)/((r * 
            s - c) * exp(c * t - r * t) - r * s + r)
        pgf.treat.d3(parms = c(r = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300.cipro.d3", 
            "r"], c = kaiser14pb.MLEs[kaiser14pb.MLEs$dataset == "SB300.cipro.d3", 
            "c"], muG = 0), t = 3, s0)
    })
}
