import numpy as np
import onnxruntime as rt
import pickle

SAVE_DATA = './05_pickled_data/'

def load_pickle(path):
    '''
    :param path:
    :return:
    '''
    with open(path, "rb") as handle: ret = pickle.load(handle)
    return ret

# Loading pickle files of test (Hugo) data and pathway-gene dictionary
hugo_mut_test = load_pickle(SAVE_DATA + 'hugo_mut.pickle')
hugo_clin_test = load_pickle(SAVE_DATA + 'hugo_clin.pickle')
GO_test_genes_dict_intersection = load_pickle(SAVE_DATA + 'GO_test_genes_dict_intersection.pickle')

sess = rt.InferenceSession("rforest_ROLP.onnx")
input_name = sess.get_inputs()[0].name
label_name = sess.get_outputs()[0].name

# Test data for ONNX
hugo_test_data = hugo_mut_test[GO_test_genes_dict_intersection['GO_REGULATION_OF_LEUKOCYTE_PROLIFERATION']]

# Running predictions
pred_onx = sess.run([label_name], {input_name: hugo_test_data.astype(np.float32).values})[0]
print(pred_onx)

# Saving the predictions in a text file named 'onnx_predictions.txt'
np.savetxt('onnx_predictions.txt', pred_onx, fmt='%s')