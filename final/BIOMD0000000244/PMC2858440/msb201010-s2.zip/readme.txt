The Matlab model allows to simulate various scenarios (e.g. the switch from glucose to acetate growth, or the switch back). Details how these simulations can be executed are provided in a comment included in the
Matlab model file.

The SMBL model uses the glucose steady-state values as initial conditions and allows to simulate the glucose to acetate transition.


