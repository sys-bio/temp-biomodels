import PyDSTool as dst
import numpy as np
from matplotlib import pyplot as plt

# model name
DSargs = dst.args(name='AHP6ARR5')

# parameters
DSargs.pars = {'lamb_aux':0.06,'d_aux':1.0,'T_aux':20/6,'diff':1.0/6,'mu_p':1,'l_p':1,'mu_h':1,'Ck':0.2,'PHB':0.01,'th_aux':0.25,'th_ahp':0.04,'th_phb':0.4,
'th_Ck':0.5,'th_arr':0.1,'n_aux':2,'n_Ck':2,'n_ahp':3,'n_phb':3,'n_arr':3}

#parameter ranges
DSargs.pdomain = {'lamb_aux':[0.0,1.0],'d_aux':[0,1000],'T_aux':[0,1000],'diff':[0,1000],'mu_p':[0,1000],
'l_p':[0,1000],'mu_h':[0,1000],'Ck':[0,20],'PHB':[0,2.5],'th_aux':[0,1000],'th_ahp':[0,1000],'th_phb':[0,1000],'th_Ck':[0,1000],
'th_arr':[0,1000],'n_aux':[1,5],'n_Ck':[1,5],'n_ahp':[1,5],'n_phb':[1,5],'n_arr':[1,5]}

#model definition
DSargs.varspecs = {'auxin':'lamb_aux - d_aux*auxin - T_aux*(auxin*PINp-auxin2*PINp2) - diff*(auxin-auxin2)',
		'PINm':'(ARRp/th_arr)^n_arr/((ARRp/th_arr)^n_arr+1)-PINm',
		'ARRm':'20*(Ck/th_Ck)^n_Ck/((Ck/th_Ck)^n_Ck+1+(AHPp/th_ahp)^n_ahp)-10*ARRm',
		'AHPm':'2*(auxin/th_aux)^n_aux/((auxin/th_aux)^n_aux+1+(PHB/th_phb)^n_phb)-AHPm',
		'PINp':'5*PINm-PINp',
		'ARRp':'10*ARRm-10*ARRp',
		'AHPp':'AHPm-AHPp',
		'auxin2':'lamb_aux - d_aux*auxin2 - T_aux*(auxin2*PINp2-auxin*PINp) - diff*(auxin2-auxin)',
		'PINm2':'(ARRp2/th_arr)^n_arr/((ARRp2/th_arr)^n_arr+1)-PINm2',
		'ARRm2':'20*(Ck/th_Ck)^n_Ck/((Ck/th_Ck)^n_Ck+1+(AHPp2/th_ahp)^n_ahp)-10*ARRm2',
		'AHPm2':'2*(auxin2/th_aux)^n_aux/((auxin2/th_aux)^n_aux+1+(PHB/th_phb)^n_phb)-AHPm2',
		'PINp2':'5*PINm2-PINp2',
		'ARRp2':'10*ARRm2-10*ARRp2',
		'AHPp2':'AHPm2-AHPp2'}

# initial conditions
DSargs.ics      = {'auxin':1,'PINp':1,'ARRp':1,'AHPp':0,'PINm':1,'ARRm':1,'AHPm':0,'auxin2':1,'PINp2':0,'ARRp2':0,'AHPp2':1,'PINm2':0,'ARRm2':0,'AHPm2':1}

#run model to near steady state
DSargs.tdomain = [0,100]                         # set the range of integration.
ode  = dst.Generator.Vode_ODEsystem(DSargs)     # an instance of the 'Generator' class.
traj = ode.compute('arb_name')              # integrate ODE
pts  = traj.sample(dt=0.1)                

#parameter for bifurcation diagram
freepar='PHB'

# Prepare the system to start close to steady state
ode.set(pars = {freepar: DSargs.pars[freepar]} )  
ode.set(ics =  pts[-1])    
PC = dst.ContClass(ode)                 # Set up continuation class

PCargs = dst.args(name='EQ1', type='EP-C')  # 'EP-C' stands for Equilibrium Point Curve. The branch will be labeled 'EQ1'.
#numerical settings
PCargs.freepars     = [freepar]
PCargs.MaxNumPoints = 4000                      
PCargs.MaxStepSize  = 0.01
PCargs.MinStepSize  = 1e-15
PCargs.StepSize     = 1e-9
PCargs.LocBifPoints = 'all'                    
PCargs.StopAtPoints = ['B']
PCargs.SaveEigen    = True 
PCargs.verbosity = 2
		  
#run continuation
PC.newCurve(PCargs)
PC['EQ1'].backward()
PC['EQ1'].forward()

#set up plot
PC['EQ1'].display([freepar,'auxin'], stability=True, axes=(2,2,1))  
PC['EQ1'].display([freepar,'PINm'], stability=True, axes=(2,2,2))
PC['EQ1'].display([freepar,'AHPm'], stability=True, axes=(2,2,3)) 
PC['EQ1'].display([freepar,'ARRm'], stability=True, axes=(2,2,4)) 
PC.plot.toggleLabels(visible='off',bytype=['LP','BP','B','P'])
PC.plot.togglePoints(visible='off',bytype=['P','B'])

#change initial value of PHB to pick up all solution branches
DSargs.pars['PHB']=1.0

#run model to near steady state
DSargs.tdomain = [0,100]                         # set the range of integration.
ode  = dst.Generator.Vode_ODEsystem(DSargs)     # an instance of the 'Generator' class.
traj = ode.compute('arb_name')              # integrate ODE
pts  = traj.sample(dt=0.1)                    

# Prepare the system to start close to steady state
ode.set(pars = {freepar: DSargs.pars[freepar]} )      
ode.set(ics =  pts[-1])      

PC = dst.ContClass(ode)                 # Set up continuation class

PCargs = dst.args(name='EQ1', type='EP-C')  # 'EP-C' stands for Equilibrium Point Curve. The branch will be labeled 'EQ1'.
PCargs.freepars     = [freepar]
#numerical settings
PCargs.MaxNumPoints = 4000                      
PCargs.MaxStepSize  = 0.01
PCargs.MinStepSize  = 1e-15
PCargs.StepSize     = 1e-9
PCargs.LocBifPoints = 'all'                      
PCargs.StopAtPoints = ['B']
PCargs.SaveEigen    = True 
PCargs.verbosity = 2
		    
#run continuation
PC.newCurve(PCargs)
PC['EQ1'].forward()

#set up plot
PC['EQ1'].display([freepar,'auxin'], stability=True, axes=(2,2,1))
plt.title('auxin')  
plt.xlim([0,1])
plt.ylim([0.0,0.12])  
PC['EQ1'].display([freepar,'PINm'], stability=True, axes=(2,2,2))
plt.xlim([0,1])
plt.title('PIN7')
plt.ylim([-0.05,1.05])  
PC['EQ1'].display([freepar,'AHPm'], stability=True, axes=(2,2,3))
plt.xlim([0,1])
plt.title('AHP6')
plt.ylim([-0.01,0.4])  
PC['EQ1'].display([freepar,'ARRm'], stability=True, axes=(2,2,4))
plt.xlim([0,1])
plt.title('ARR5')
plt.ylim([-0.01,0.3])  
PC.plot.toggleLabels(visible='off',bytype=None)
PC.plot.togglePoints(visible='off',bytype=['P','B'])

#show plot
plt.show()

