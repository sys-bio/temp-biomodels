function output = firm_ode(tin)
% template script for running integrating FIRM model
% originally constructed in Mathematica and converted to Matlab
% integration of :
% Marino and Kirschner, "The human immune response to Mycobacterium tuberculosis in the lung and lymph node"
% DeBoer, "Macrophage T Lymphocyte Interactions in the Anti-Tumor Immune Response: A Mathematical Model"
% Bell, "Mathematical Model of Clonal Selection and Antibody Production"

% function call is simply:
% firm_ode(time)

% optional argument is the time point for the simulations, default is 400

if nargin > 0,
    endpoint = tin;
else
    endpoint = 400;
end
% increased tolerance on all variables

RelTol = 1e-22;     %  Set the scalar relative tolerance
AbsTol = 1e-22*ones(52,1);

%%%% Volumes of different compartments
volLung = 1000;       % Lung
volLymphT = 10;       % Lymph T
volLymphB = 150;      % Lymph B
volBlood = 4500;      % Volume of Plasma

%%%%%%%%%%%%%%%%%%%
volTB = 1.e-12; 
volMI = 16.e-9; 
volMA = 16.e-9; 
volMR = 8.e-9;
volT = 2.e-9;
volSite = volBlood;
%%%%%%%%%%%%%%%%%%%%

ic = [
    % Macrophages
    100000000	%	x1 is the resting macrophage
    0	%	x2 is the activated macrophage
    0.0000001	%	x3 is the infected macrophage
    
    % Bacteria
    100000	%	x4 is the extra-cellular bacteria
    0	%	x5 is the intra-cellular bacteria
    
    % Immature Dendritic Cell
    50000000	%	x6 is the immature dendritic cell
    
    % Th Cells in the target organ
    0	%	x7 is the Th precursor cell in the target organ.
    0	%	x8 is the T cell helper type 1 in the target organ.
    0	%	x9 is the T cell helper type 2 in the target organ.
    
    % Cells in Lymphoid T and Blood
    0	%	x10 is the mature dendritic cell in the lymphoid T.
    78431.37255	%	x11 is the naive T cell in the lymphoid T
    1111.183514	%	x12 is the Th precursor cell in the lymphoid T
    3000.495537	%	x13 is the Th precursor cell in the blood.
    
    % Th Cells in Blood and Lymphoid B
    0	%	x14 is the T helper 2 cells in the blood
    0	%	x15 is the T helper 2 cells in the lymphoid B
    
    % Naive and Activated B Cells in the blood and site of recongition
    18750	%	x16 is the Naive B cells at the site of recognition
    0	%	x17 is the Activated B cells at the site of recognition
    0	%	x18 is the Activated B cells in the blood
    0	%	x19 is the Memory B cells in the blood
    
    % B cells in the lymphoid B
    0	%	x20 is the Activated B cells in the lymphoid B
    0	%	x21 is the Plasma B cells in the lymphoid B
    
    % Antibodies
    0	%	x22 is the Antibodies in the blood
    0	%	x23 is the antibodies in the target organ
    
    % T Cells in the lymphoid T
    1111.111111	%	x24 is the cytotoxic T cell precursors in the lymphoid T
    
    % Cytotoxic T Cells in Blood and Target organ
    50000	%	x25 is the cytotoxic T cell precursors in the blood
    0	%	x26 is the cytotoxic T cell precursors in the target organ
    0	%	x27 is the cytotoxic T cells in the target organ
    
    % APC Macrophages in target organ
    0	%	x28 is the antigen presenting macrophages in the target organ
    
    % Tumor cells in target organ
    0	%	x29 is the tumor cells in the target organ
    0	%	x30 is the tumor debris cells in the target organ
    
    % Interleukin growth factors in target organ
    0	%	x31 is the Interleukin-1 growth factor in the target organ
    0	%	x32 is the Interleukin-2 growth factor in the target organ
    0	%	x33 is the Interleukin-4 growth factor in the target organ
    
    % Interleukin growth factors in Lymphoid B
    0	%	x34 is the Interleukin-4 growth factor in the lymphoid B
    
    % Interleukin growth factor in target organ
    0	%	x35 is the Interleukin-10 growth factor in the target organ
    
    % Interleuking growth factor in lymphoid T
    0	%	x36 is the Interleukin-12 growth factor in the lymphoid T
    
    % Interleukin growth factor in blood
    0	%	x37 is the Interleukin-12 growth factor in the blood
    275	%	x38 is the Interleukin-12 growth factor in the target organ
    
    % Other growth factors in target organ
    0	%	x39 is the IFN-gamma growth factor in the target organ
    0	%	x40 is the TGF-beta growth factor in the target organ
    
    % Antigen or Bacteria in the blood
    0	%	x41 is the antigen (bacteria or debris) in the blood
    0	%	x42 is the antigen (bacteria or debris) in the site of recognition
    
    % Receptor sites on the naive and activated B cells
    18750000	%	x43 is the free receptor sites on the naive B cells in the site of recognition
    0	%	x44 is the bound receptor sites on the naive B cells in the site of recognition
    0	%	x45 is the free receptor sites on the activated B cells in the site of recognition
    0	%	x46 is the bound receptor sites on the activated B cells in the site of recognition
    0	%	x47 is the free receptor sites on the activated B cells in the blood
    0	%	x48 is the bound receptor sites on the activated B cells in the blood
    
    % Single or double bound antibidy in the blood
    0	%	x49 is the single-bound antibody in the blood
    0	%	x50 is the double bound antibody in the blood
    0	%	x51 is the single bound antibody in the target organ
    0	%	x52 is the double bound antibody in the target organ
    ];

tic;
tspan = [0;endpoint];
options = odeset('RelTol',RelTol,'AbsTol',AbsTol,'Stats','on');
% options = odeset('RelTol',RelTol,'AbsTol',AbsTol,'Stats','on', 'MaxStep', 0.01);

[t,x] = ode15s(@massbal,tspan,ic,options);
output = [t,x];

% keyboard;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot a set of figures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
semilogy(output(:,1), output(:,2)/volLung,'b', ...
         output(:,1), output(:,3)/volLung,'r',...
		 output(:,1), output(:,4)/volLung,'g');
title('Macrophages - Figure 5 (top, left)')
legend('MR', 'MA','MI')
ylabel('Cells/mL')
xlabel('Time (days)')
ylim([1e-37 1e5])

figure
semilogy(output(:,1),  output(:,[34 36 39 40])/volLung)
title('Cytokines')
legend('IL4','IL10', 'IL12','IFNg')
ylabel('pg/mL')
xlabel('Time (days)')
% ylim([1e-17 1])
ylim([1e-8 10])

figure
plot(output(:,1), output(:,9:10)/volLung)
title('T Helper Cells')
legend('Th1','Th2')
ylabel('Cells/mL')
xlabel('Time (days)')
% ylim([0 10e-19])
ylim([0 35])

figure
semilogy(output(:,1), output(:,5:6)/volLung)
title('Bacteria')
legend('PE','PI')
ylabel('Cells/mL')
xlabel('Time (days)')
% ylim([1e-17 100])
ylim([1e-3 1e8])

figure
plot(output(:,1), output(:,[12 13 25])/volLymphT)
legend('T','ThP', 'TcP')
ylabel('Cells/mL')
xlabel('Time (days)')
% ylim([0 8000])
ylim([0 200000])

figure
plot(output(1:20000,1), [output(1:20000,18)/volSite, output(1:20000,19)/volBlood, output(1:20000,21)/volLymphB, output(1:20000,22)/volLymphB])
title('B cells')
legend('BA_s','BA_b', 'BA_s_p', 'BP')
ylabel('Cells/mL')
xlabel('Time (days)')
ylim([0 0.15])

figure
semilogy(output(:,1), [output(:,5)/volLung, output(:,6)/volLung, output(:,42)/volBlood, output(:,43)/volSite])
title('Antigen')
legend('PE','PI', 'Ag_b_l', 'Ag_s_i_t_e')
ylabel('Cells/mL')
xlabel('Time (days)')
xlim([0 100])
ylim([1e-17 100])

figure
semilogy(output(:,1), [output(:,23)/volBlood, output(:,24)/volLung] )
title('Free Ab')
legend('Ab_b_l','Ab_l_u_n_g')
ylabel('Molecules/mL')
xlabel('Time (days)')
xlim([0 100])
ylim([1e-8 1e5])

figure
semilogy(output(:,1), output(:,[50 51])/volBlood)
title('Ab bound in Blood')
legend('Ab1','Ab2')
ylabel('Parts/mL')
xlabel('Time (days)')
xlim([0 100])
ylim([1e-23 1])

% figure
% semilogy(output(:,1), output(:,[52 53])/volLung)
% title('Ab bound in Lung')
% legend('Ab_b_l','Ab_l_u_n_g')
% ylabel('Parts/mL')
% xlabel('Time (days)')
% ylim([1e-31 0])


toc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function call for odes. these were directly imported from mathematica
% in which the model was actually constructed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function xdot = massbal(t,x)

volLung = 1000;  
volLymphT = 10; 
volLymphB = 150; 
volBlood = 4500;
volTB = 1.e-12; 
volMI = 16.e-9; 
volMA = 16.e-9; 
volMR = 8.e-9;
volT = 2.e-9;

volSite = volBlood;

vMI = volMI*x(3);        

MA = x(5)/x(3);
MC = volLung/vMI;
MB = x(5)/x(3)*MC;
MD = volLung/volLymphT;
ME = volLymphT/volBlood;
MF = volBlood/volLung;
MG = volLung/volBlood;
MH = volBlood/volLymphB;
MI = volSite/volBlood;
MJ = volLymphB/volBlood;
MK = volBlood/volSite;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set of parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bacteria and Macrophages
Mu1 = 0.005;                   % Alpha20 - Taken from Marino-Kirschner (MK) model, Bacterial Growth rate (1/day)
k2 = 0.4;                      % k2 - Taken from MK model, Max Mr - chronic infection induced by Bacteria
c2 = 1000000.;                 % c9 - Half-sat for infecting Macrophages - see equation 1.3 of MK c2 is in Bacteria/ml, so has to be multiplied by volLung
k3 = 0.11;                     % k17+MuI
K3s = 50;                       %N % k3 is the summation of the burst rate k17 and the death rate MuI
Alpha4 = 0.5 ;                 % k14 - Maximal T cell killing of MI
c4 = 0.15;                     % c4 - Half-saturation, Th1 to MI ratio for MI lysis
Alpha5 = 1.25e-7;              % k15 - Max killing of Bacteria by MA
Alpha6 = 1.25e-8;              % k18 - Max killing of Bacteria by MR
k7 = 1.e-7 ;                   % Delta12 - Bacteria uptake by Immature Dendritic cells (IDC)
Mu8 = 0.1;                     %Alpha19 - Growth rate of intra-cellular bacteria (1/day)
Rho9 = 5000.; %sM              % Rh
Mu9 = 0.04; %Alpha4
w9 = 0.14; %w
Mui9 = 125000;
Eta10 = 0.05; %EM%MuR in MK model is .01
Delta11 = 0.36; %k4
cf11 = 100;%sc8
Delta12 = 0.4; %k3
c12 = 5.e5; %c8
Deltai12 = 0.009; % A*H
ci12 = 1000; %KMT
fi12 = 2.333; %f3
cf12 = 150;%sc3
Eta13 = 1;%DM%MuA in MK model is .01
Eta14 = 0.; %MuI% Modified rate; rate law not used

% Dendritic Cells
Rho15 = 500; %sIDC
Mu15 = 0.02; %Delta8
c15 = 1.5e5;%Delta9
Eta16 = 0.01;%MuIDC
Gamma17 = 0.2; %Delta10
c17 = 1.e4;%Delta11
Eta18 = 0.02;%MuMDC

% T Cells
Rho19 = 1000; %sT
Mu19 = 0.1;%Delta2
Eta20 =  0.102;%Lambda1+MuT %added recirculation and death of naive T cells together
Delta21 = 0.0001; %Delta4
Rho21 = 100;%I2
Mu22 = 0.9; %Delta5
c22 = 3e3;%Rho
Gamma23 = 0.9;%Zeta
Gamma24 = 0.9; %Zeta
c24 = 1.5e4;%Delta6
Mu25 = 0.4; %Alpha2
c25 = 1e5;%c15
Eta26 = 0.3333;%MuT0
Delta27 = 0.1; %k6
fi27 = 4.1; %f1
fii27 = 4.8; %f7
cf27 = 30; %sc1
cAPC = 10e7/10; %KMD
Deltai27 = .001; %A
MuI = 9; %H
cI = 50;%KMF
Eta28 = 0.3333; %MuT1
Mu28 = 1; %R
cf28 = 50;%KMF
Delta29 = 0.05; %k7
fi29 = 0.12; %f2
cf29 = 2;%sc2
Eta30 = 0.3333;%MuT2%will be set to zero in flux vector
Gamma31 = 0.3333;%takes death rate from v30; so not to deplete Th2 population in the lung
Gamma32 = 0.9;%Zeta
Eta33 = 0.3333;% same as death rate for v28 and v30

% ^^*Lymphocyte death rates are .3333 per day in MK model; and .02 per day in the deBoer model^^^

%B Cells and Antibodies
Rho34 = 10.;
Eta35 = 2.4;%1/T1
Delta36 = 2.4;%1/T1
Gamma37 = 0.9;
Delta38 = 2.4;%1/T2
Delta39 = 0.;
Gamma40 = 0.9;
Gamma41 = 0.9;
Mu42 = 2.4;%1/T2
Delta43 = 2.4;%1/T2
Eta44 = 1.2;%1/T3
q45a = 10e6/10;
q45b = 10e6/10;
q45c = q45b;%c2;c3
P46 = 9.;
Eta47 = 0.0024;%1/T4
Eta48 = 0.024;%1/T`2
Eta49 = 0.048;%1/T`5

% Cytotoxic T Cells
Delta50 = 0.0001;%same as v21
Rho50 = 100;%I1
Gamma51 = 0.9; %same as v23
Gamma52 = 0.9;
c52 = 1.5e4;%same as v24
Eta53 = 0.02;%EL
Delta54 = 0.001;%A
Mu55 = 1.; %R
c55 = 50; %KMF
cF = 1000;%KMT
Eta56 = 0.02;%EL

% Antigen-Precenting Macrophages
Delta57 = 0.;
Eta58 = 0.;

% Tumor
Mu59 = 1.; %R
c59 = 10e9/10;%KR
Eta60 = 0.001;%D
Alpha61 = 10; %KILL
c61 = 10e5/10;%KMK
Alpha62 = 10; %KILL
c62 = 10e5/10;%KMK
k63 = 2.;%ED

% Cytokines
q68a = 0.0029; q68b = 0.0218;
Eta69 = 2.77;

q72a = 6.e-3; q72b = 5.e-5; q72c = 1.e-4; q72d = 1.e-4; q72e = 1.e-4; c72 = 51; ci72 = .05;
Eta73 = 3.6968;
q74 = 0.0035;
Eta75 = 1.188;

q78a = 2.75e-6; q78b = 0.0008;
Eta79 = 1;
Rho80 = 700; c80 = 5.e3; ci80 = 50; q80 = 0.02; cii80 = 1.e5;
Eta81 = 3;

q82 = 0;
Eta83 = 0;

% DeBoer Integration
Eta84 = 0.3333;%MuT0
Eta85 = 0.02;%EL
Mu86 = 1; %R
cf86 = 50;%KMF

% Bell Integration
P87 = 3.;
P88 = 3.;
P89 = 100000.;
Beta90 = 1000; K90 = 100;
Beta91 = Beta90; K91 = K90;
Beta92 = Beta90; K92 = K90;
Beta93 = Beta90; K93 = 100;
Beta94 = Beta90; K94 = K93;
Eta95 = 4.8;%1/T5
Eta96 = 4.8;%1/T5
Beta97 = Beta93; K97 = K93;
Beta98 = Beta93; K98 = K93;
Eta99 = 4.8;%1/T5
Eta100 = 4.8;%1/T5


% rate equations
APC = ((x(1) + x(2))*x(30))/(cAPC + x(30));
FACTOR = x(8)*(x(29)/(cF + x(29))); % FACTOR has units of cells; an absolute number
INFLAM = MuI*(x(29)/(cF + x(29)))/(cI + (x(29)/(cF + x(29))));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% reaction rates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bacteria and Macrophages

v1 = Mu1*(x(4)/volLung);
%	v1 is the growth of extra cellular-bacteria in the target organ. SN -
%	Mu1 is the growth rate per day (from MK model), x(4) is extra-cellular
%	bacteria

v2 = k2*(x(1)/volLung)*x(4)/(x(4) + c2*volLung); 
% it takes N/2 bacteria in the MK pub to infect; here it only takes one. SN - c2 is in Bacteria/ml, so multiplied by volLung here
%	v2 is the infection of a resting macrophage by a extra-cellular
%	bacteria to create an infected macrophage in the target organ. x(1) is
%	resting macrophage

v3 = k3*(x(3)/volLung)*(x(5)/x(3))^2/((x(5)/x(3))^2 + K3s^2) ; % Modified rate law
%	v3 is the release of bacteria from intra-cellular to extra-cellular when an infected macrophage bursts in the target organ.
%  SN - x(3) is infected macrophage, x(5) is intra-cellular bacteria, K3 is the sum of k17 and MuI form MK, 2 comes from equation
%  1.2 of MK

v4 = Alpha4*(x(3)/volLung)*((x(8)/x(3))/((x(8)/x(3)) + c4*volLung)); % N1 not included in rate law; instead x(5)/x(3) bacteria released in stoich matrix
%	v4 is the release of bacteria from intra-cellular to extra-cellular when a T cell kills an infected macrophage.
% Alpha4 is k14 in MK - Relates to Maximal T cell killing of M_I, x(8) is
% T helper type 1 in the target organ
% See equation 1.3 of MK


v5 = Alpha5*(x(2)/volLung)*(x(4)/volLung);
%	v5 is the killing of extra-cellular bacteria by an activated macrophage in the target organ.
%  x(2) is activated macrophage, x(4) is extra-cellular bacteria, x(2) is
%  activated macrophage, taken from MK

v6 = Alpha6*(x(1)/volLung)*(x(4)/volLung);
%	v6 is the killing of extra-cellular bacteria by an resting macrophage in the target organ.
%   x(4) is extra-cellular bacteria, x(1) is resting macrophage, taken from
%   MK

v7 = k7*(x(6)/volLung)*(x(4)/volLung);
%	v7 is the uptake of an extra-cellular bacteria by an immature dendritic cell in the target organ.
%   x(6) is immature dendritic cell, x(4) is extra-cellular bacteria

v8 = Mu8*(x(5)/vMI)*(1 - (x(5)/x(3))^2/((x(5)/x(3))^2 + K3s^2)); % Modified rate law
%	v8 is the growth of intra-cellular bacteria within an infected macrophage in the target organ.
%   x(5) is intra-cellular bacteria, x(3) is infected macrophage 


v9 = Rho9 + Mu9*(x(2)/volLung + w9*x(3)/volLung) + Mui9*INFLAM;
%	v9 is the recruitment of resting macrophages to the target organ.
%   x(2) is activated macrophage, x(3) is infected macrophage 


v10 = Eta10*(x(1)/volLung);
%	v10 is the death of resting macrophages in the target organ.
v11 = Delta11*(x(2)/volLung)*x(35)/(x(35) + cf11*volLung);
%	v11 is the deactivation of an activated macrophages into a resting macrophages in the target organ.
v12 = Delta12*(x(1)/volLung)*(x(4) + x(5))/(c12*volLung + x(4) + x(5))*x(39)/(x(39) ...
    + fi12*x(33) + cf12*volLung) + Deltai12*(x(1)/volLung)*(x(29)/(ci12 + x(29)));
%Deboer tumor triggered activation doesnt have FACTOR; because we need MA to bring HTLs into the lung
%	v12 is the activation of a resting macrophage into an activated macrophage in the target organ.
v13 = Eta13*(x(2)/volLung);
%	v13 is the death of an activated macrophage in the target organ.
v14 = 0.; % v14 and v3 have the same functionality; so this rate law was eliminated
%	v14 is the death of an infected macrophage also releasing extra-cellular bacteria into the target organ.

% Dendritic Cells
v15 = Rho15 + Mu15*x(4)/(c15*volLung + x(4)) + (Rho21 + Rho50)*INFLAM;
%	v15 is the generation of immature dendritic cells in the target organ.
v16 = Eta16*(x(6)/volLung);
%	v16 is the death of immature dendritic cells in the target organ.
v17 = Gamma17*(x(6)/volLung)*x(4)/(c17*volLung + x(4)) + Gamma17*(x(6)/volLung)*1*INFLAM;
%If the multiplier in red is 17.3 it will kill the TUMOR; if it is 17.29 it will not kill the TUMOR
%	v17 is the migration of immature dendritic cells from the target organ to the lymph node via the afferent lymphatic vessel.
v18 = Eta18*(x(10)/volLymphT);
%	v18 is the MDC death in lymphoid T

% T Cells
v19 = Rho19 + Mu19*(x(10)/volLymphT);
%	v19 is the recruitment of naive T cells by MDC in lymphoid T

v20 = Eta20*(x(11)/volLymphT);
%	v20 is the death of naive T cells in the lymphoid T
v21 = Rho21 + Delta21*(x(11)/volLymphT)*(x(10)/volLymphT);
%	v21 is the differentiation of naive T cells to T helper precursor cells in the lymphoid T
v22 = Mu22*(x(12)/volLymphT)/(c22 + (x(12)/volLymphT)^2);%modified rate law;
%  different from MK publication;
%  made it so that rate cannot be negative. When full model is compelte;
%  consider returning logistical growth law from MK publication
%	v22 is the T helper cell precursor proliferation in the lymphoid T
v23 = Gamma23*(x(12)/volLymphT);
%	v23 is the migration of T helper precursor cells from the lymphoid T to the blood.
v24 = Gamma24*(x(13)/volBlood)*x(2)/(c24*volLung + x(2));
%	v24 is the migration of T helper precursor cells from the blood to the target organ
v25 = Mu25*(x(7)/volLung)*x(2)/(c25*volLung + x(2));
%	v25 is the proliferation of T helper precursor cells in the target organ
v26 = Eta26*(x(7)/volLung);
%	v26 is the death of T helper precursor cells in the target organ
v27 = Delta27*(x(7)/volLung)*(x(38)/volLung)*(x(36)/(x(36) + fi27*x(33) + fii27*x(35) + cf27*volLung)) + Deltai27*(x(7)/volLung)*APC;
%	v27 is the THP differentiation to T helper type 1 in the target organ
v28 = Eta28*(x(8)/volLung);
%vi28=Mu28*(x(8)/volLung)*(FACTOR/(cf28+FACTOR));
% Will subtract vi28 from v28 in order to imitate a proliferation flux for Th1 from the DB model
%	v28 is the death of T helper type 1 in the target organ
v29 = Delta29*(x(7)/volLung)*x(33)/(x(33) + fi29*x(39) + cf29*volLung);
%	v29 is the THP differentiation to T helper type 2 in the target organ
v30 = Eta30*(x(9)/volLung);
%	v30 is the death of T helper type 2 in the target organ
v31 = Gamma31*(x(9)/volLung);
%	v31 is the migration of T helper 2 cells from the target organ to the
%	blood
v32 = Gamma32*(x(14)/volBlood);
%	v32 is the migration of T helper 2 cells from the blood to the lymphoid	B
v33 = Eta33*(x(15)/volLymphB);
%	v33 is the death and circulation of T helper 2 cells in the lymphoid B

%B Cells and Antibodies
v34 = Rho34;
%	v34 is the recruitment of naive B cells at the site of recognition
v35 = Eta35*(x(16)/volSite)*(x(43)/(x(43) + x(44) + .00001));
%	v35 is the death of naive B cells at the site of recognition
v36 = Delta36*(x(16)/volSite)*(x(44)/(x(43) + x(44) + .00001));
%	v36 is the B cell activation at the site of recognition
v37 = Gamma37*(x(17)/volSite);
%	v37 is the migration of activated B cells from the site of recognition
%	to the blood
v38 = Delta38*(x(18)/volBlood/2)*(x(47)/(x(47) + x(48) + .00001));
%	v38 is the differentiation of activated B cells to memory B cells in the blood
v39 = Eta47*(x(19)/volBlood); %this needs to occur at a similar rate as the death of memory B cells or they will all recycle before they can die
%	v39 is the migration of memory B cells to the site of recognition and conversion to naive B cells
v40 = Gamma40*(x(18)/volBlood);
%	v40 is the migration of activated B cells from the blood to the lymphoid B
v41 = 0;%Gamma41*(x(20)/volLymphB)
%	v41 is the migration of activated B cells from the lymphoid B to the blood
v42 = Mu42*(x(20)/volLymphB)*(x(48)/(x(47) + x(48) + .00001));
%	v42 is the proliferation of B cells in the lymphoid B
v43 = Delta43*(x(20)/volLymphB/2)*(x(47)/(x(47) + x(48) + .00001));
%	v43 is the differentiation of activated B cells to plasma B cells in the lymphoid B
v44 = Eta44*(x(21)/volLymphB);
%	v44 is the death of plasma B cells in the lymphoid B
v45 = q45a*(x(18)/volBlood) + q45b*(x(20)/volBlood) + q45c*(x(21)/volBlood);
%	v45 is the release (production) of antibodies by plasma b cells in the blood
v46 = P46*((x(22)/volBlood) - (x(23)/volLung));
%	v46 is the migration of antibodies from the blood to the target organ
v47 = Eta47*(x(19)/volBlood);
%	v47 is the slow death of memory B cells in the blood
v48 = Eta48*(x(20)/volLymphB);
%	v48 is the death of activated B cells in the lymphoid B
v49 = Eta49*(x(22)/volBlood);
%	v49 is the decay of antibodies in the blood

% Cytotoxic T Cells
v50 = Rho50 + Delta50*(x(11)/volLymphT)*(x(10)/volLymphT); % Added MDC stimulation of differentiation to TcP; modeled after thp differentiation from MK model
%	v50 is the differentiation of naive T cells to cytotoxic T cell precursors in the lymphoid T
v51 = Gamma51*(x(24)/volLymphT);
%	v51 is the migration of cytotoxic T cell precursors from the lymphoid T to the blood
v52 = Gamma52*(x(25)/volBlood)*x(2)/(c52*volLung + x(2));
%	v52 is the migration of cytotoxic T cell precursors from the blood to the target organ
v53 = Eta53*(x(26)/volLung);
%	v53 is the death of cytotoxic T cell precursors in the target organ
v54 = Delta54*(x(26)/volLung)*(x(29)/volLung);
%	v54 is the differentiation of cytotoxic T cell precursors to cytotoxic T cells in the target organ
v55 = Mu55*(x(27)/volLung)*(FACTOR/(cF + FACTOR));
%	v55 is the proliferation of cytotoxic T cells in the target organ
v56 = Eta56*(x(27)/volLung);
%	v56 is the death of cytotoxic T cells in the target organ

% Antigen-Precenting Macrophages
v57 = 0;
%	v57 is the conversion of a resting macrophage to an antigen presenting macrophage when in contact with a debris cell in the target organ
v58 = 0;
%	v58 is the death of antigen presenting macrophages inthe target organ

% Tumor
v59 = Mu59*(x(29)/volLung)/(1. + (x(29)/c59));
%	v59 is growth of tumor cells in the target organ
v60 = Eta60*(x(29)/volLung);
%	v60 is the natural death of tumor cells in the target organ
v61 = Alpha61*(x(2)/volLung)*(x(29)/(c61 + x(29)));
%	v61 is the killing of tumor cells by an activated macrophage in the target organ
v62 = Alpha61*(x(27)/volLung)*(x(29)/(c61 + x(29)));
%	v62 is the killing of tumor cells by a cytotoxic T cell in the target organ
v63 = k63*(x(30)/volLung);
%	v63 is the decay/clearing of debris cells in the target organ

% Cytokines
v64 = 0;
%	v64 is the production of Interleukin-1 in the target organ
v65 = 0;
%	v65 is the decay of Interleukin-1 in the target organ
v66 = 0;
%	v66 is the production of Interleukin-2 in the target organ
v67 = 0;
%	v67 is the decay of Interleukin-2 in the target organ
v68 = q68a*(x(7)/volLung) + q68b*(x(9)/volLung);
%	v68 is the production of Interleukin-4 in the target organ
v69 = Eta69*(x(33)/volLung);
%	v69 is the decay of Interleukin-4 in the target organ
v70 = 0;
%	v70 is the production of Interleukin-4 in the lymphoid B
v71 = 0;
%	v71 is the decay of Interleukin-4 in the lymphoid B

v72 = q72a*(x(2)/volLung)*((c72*volLung)/(x(35) + ci72*x(39) + c72*volLung)) ...
    + q72b*(x(8)/volLung) + q72c*(x(9)/volLung) + q72d*(x(7)/volLung) + q72e*(x(3)/volLung);
%	v72 is the production of Interleukin-10 in the target organ

v73 = Eta73*(x(35)/volLung);
%	v73 is the decay of Interleukin-10 in the target organ
v74 = q74*(x(10)/volLymphT);
%	v74 is the production of Interleukin-12 in the lymphoid T
v75 = Eta75*(x(36)/volLymphT);
%	v75 is the decay of Interleukin-12 in the lymphoid T
v76 = 0;
%	v76 is the migration of Interleukin-12 from the lymphoid T to the blood
v77 = 0;
%	v77 is the migration of Interleukin-12 from the blood to the target
%	organ
v78 = q78a*(x(1)/volLung) + q78b*(x(2)/volLung);
%	v78 is the production of Interleukin-12 in the target organ
v79 = Eta79*(x(38)/volLung);
%	v79 is the decay of Interleukin-12 in the target organ
v80 = Rho80*((x(4) + x(5))/(c80*volLung + (x(4) + x(5))))*(x(38)/(ci80*volLung + x(38)))...
    + q80*x(8)*(x(2)/(cii80*volLung + x(2)));
%	v80 is the production of IFN-gamma in the target organ
v81 = Eta81*(x(39)/volLung);
%	v81 is the decay of IFN-gamma in the target organ
v82 = 0;
%	v82 is the production of TGF-beta in the target organ
v83 = 0;
%	v83 is the decay of TGF-beta in the target organ
%DeBoer Integration
v84 = Eta84*(x(13)/volBlood);
%	v84 is the death of T helper precursors in the blood
v85 = Eta85*(x(25)/volBlood);
%	v85 is the death of cytotoxic T precursors in the blood
v86 = Mu86*(x(8)/volLung)*(FACTOR/(cf86 + FACTOR));
%	v86 is the proliferation of T helper 1 cells in the target organ

%Bell Integration
v87 = 0; %P87*((x(4)/volLung) - (x(41)/volBlood));
%	v87 is the migration of a bacteria (to an antigen)  from the target organ to the blood
v88 = P88*((x(30)/volLung) - (x(41)/volBlood));
%	v88 is the migration of a debris (to an antigen)  from the target organ to the blood
v89 = P89*((x(41)/volBlood) - (x(42)/volSite));
%	v89 is the migration of an antigen (bacteria or debris) from the blood to the site of recognition
v90 = Beta90*((x(42)/volSite)*(x(43)/volSite) - (x(44)/volSite)/K90);
%	v90 is the binding of the antigen (bacteria or debris) to a free receptor site on the naive B cells in the site of recognition
v91 = Beta91*((x(42)/volSite)*(x(45)/volSite) - (x(46)/volSite)/K91);
%	v91 is the binding of the antigen (bacteria or debris) to a free receptor site on the activated B cells in the site of recognition
v92 = Beta92*((x(41)/volSite)*(x(47)/volSite) - (x(48)/volSite)/K92);
%	v92 is the binding of the antigen (bacteria or debris) to a free receptor site on the activated B cells in the blood
v93 = Beta93*((x(41)/volBlood)*(x(22)/volBlood) - (x(49)/volBlood)/K93);
%	v93 is the binding of an antigen to a free antibody in the blood
v94 = Beta94*((x(41)/volBlood)*(x(49)/volBlood) - (x(50)/volBlood)/K94);
%	v94 is the binding of an antigen to a single-bound antibody in the blood
v95 = Eta95*(x(49)/volBlood);
%	v95 is the removal of a single bound antibody in the blood
v96 = Eta96*(x(50)/volBlood);
%	v96 is the removal of a double bound antibody in the blood
v97 = Beta97*((x(4)/volLung)*(x(23)/volLung) - (x(51)/volLung)/K97);
%	v97 is the binding of an antigen to a free antibody in the target organ
v98 = Beta98*((x(4)/volLung)*(x(51)/volLung) - (x(52)/volLung)/K98);
%	v98 is the binding of an antigen to a single bound antibody in the target organ
v99 = Eta99*(x(51)/volLung);
%	v99 is the removal of a single bound antibody in the target organ
v100 = Eta100*(x(52)/volLung);
%	v100 is the removal of a double bound antibody in the target organ

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% adjustments made in mathematica FIRM notebook v7.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
v14 = 0; v30 = 0; v57 = 0; v58 = 0; v59 = 0; v64 = 0; v65 = 0; v66 = 0;
v67 = 0; v70 = 0; v71 = 0; v76 = 0; v77 = 0; v82 = 0; v83 = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% mass balances
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xdot = [
    -(v10*volLung) + v11*volLung - v12*volLung - v2*volLung - v57*volLung + v9*volLung;	% mass balance on 	x1 is the resting macrophage
    -(v11*volLung) + v12*volLung - v13*volLung;	% mass balance on 	x2 is the activated macrophage
    -(v14*volLung) + v2*volLung - v3*volLung - v4*volLung;	% mass balance on 	x3 is the infected macrophage
    v1*volLung + MA*v14*volLung - 25*v2*volLung + MA*v3*volLung + MA*v4*volLung - v5*volLung...	% mass balance on 	x4 is the extra-cellular bacteria
    - v6*volLung - v7*volLung - v87*volLung - v97*volLung - v98*volLung;
    -(MB*v14*vMI) + 25*MC*v2*vMI - MB*v3*vMI - MB*v4*vMI + v8*vMI;	% mass balance on 	x5 is the intra-cellular bacteria
    v15*volLung - v16*volLung - v17*volLung;	% mass balance on 	x6 is the immature dendritic cell
    MF*v24*volLung + v25*volLung - v26*volLung - v27*volLung - v29*volLung;	% mass balance on 	x7 is the Th precursor cell in the target organ.
    v27*volLung - v28*volLung + v86*volLung;	% mass balance on 	x8 is the T cell helper type 1 in the target organ.
    v29*volLung - v30*volLung - v31*volLung;	% mass balance on 	x9 is the T cell helper type 2 in the target organ.
    MD*v17*volLymphT - v18*volLymphT;	% mass balance on 	x10 is the mature dendritic cell in the lymphoid T.
    v19*volLymphT - v20*volLymphT - v21*volLymphT - v50*volLymphT;	% mass balance on 	x11 is the naive T cell in the lymphoid T
    v21*volLymphT + v22*volLymphT - v23*volLymphT;	% mass balance on 	x12 is the Th precursor cell in the lymphoid T
    ME*v23*volBlood - v24*volBlood - v84*volBlood;	% mass balance on 	x13 is the Th precursor cell in the blood.
    MG*v31*volBlood - v32*volBlood;	% mass balance on 	x14 is the T helper 2 cells in the blood
    MH*v32*volLymphB - v33*volLymphB;	% mass balance on 	x15 is the T helper 2 cells in the lymphoid B
    v34*volSite - v35*volSite - v36*volSite + MK*v39*volSite;	% mass balance on 	x16 is the Naive B cells at the site of recognition
    v36*volSite - v37*volSite;	% mass balance on 	x17 is the Activated B cells at the site of recognition
    MI*v37*volBlood - v38*volBlood - v40*volBlood + MJ*v41*volBlood;	% mass balance on 	x18 is the Activated B cells in the blood
    v38*volBlood - v39*volBlood - v47*volBlood;	% mass balance on 	x19 is the Memory B cells in the blood
    MH*v40*volLymphB - v41*volLymphB + v42*volLymphB - v43*volLymphB - v48*volLymphB;	% mass balance on 	x20 is the Activated B cells in the lymphoid B
    v43*volLymphB - v44*volLymphB;	% mass balance on 	x21 is the Plasma B cells in the lymphoid B
    v45*volBlood - v46*volBlood - v49*volBlood - v93*volBlood;	% mass balance on 	x22 is the Antibodies in the blood
    MF*v46*volLung - v97*volLung;	% mass balance on 	x23 is the antibodies in the target organ
    v50*volLymphT - v51*volLymphT;	% mass balance on 	x24 is the cytotoxic T cell precursors in the lymphoid T
    ME*v51*volBlood - v52*volBlood - v85*volBlood;	% mass balance on 	x25 is the cytotoxic T cell precursors in the blood
    MF*v52*volLung - v53*volLung - v54*volLung;	% mass balance on 	x26 is the cytotoxic T cell precursors in the target organ
    v54*volLung + v55*volLung - v56*volLung;	% mass balance on 	x27 is the cytotoxic T cells in the target organ
    v57*volLung - v58*volLung;	% mass balance on 	x28 is the antigen presenting macrophages in the target organ
    v59*volLung - v60*volLung - v61*volLung - v62*volLung;	% mass balance on 	x29 is the tumor cells in the target organ
    v60*volLung + v61*volLung + v62*volLung - v63*volLung - v88*volLung;	% mass balance on 	x30 is the tumor debris cells in the target organ
    v64*volLung - v65*volLung;	% mass balance on 	x31 is the Interleukin-1 growth factor in the target organ
    v66*volLung - v67*volLung;	% mass balance on 	x32 is the Interleukin-2 growth factor in the target organ
    v68*volLung - v69*volLung;	% mass balance on 	x33 is the Interleukin-4 growth factor in the target organ
    v70*volLymphB - v71*volLymphB;	% mass balance on 	x34 is the Interleukin-4 growth factor in the lymphoid B
    v72*volLung - v73*volLung;	% mass balance on 	x35 is the Interleukin-10 growth factor in the target organ
    v74*volLymphT - v75*volLymphT - v76*volLymphT;	% mass balance on 	x36 is the Interleukin-12 growth factor in the lymphoid T
    v76*volBlood - v77*volBlood;	% mass balance on 	x37 is the Interleukin-12 growth factor in the blood
    v77*volLung + v78*volLung - v79*volLung;	% mass balance on 	x38 is the Interleukin-12 growth factor in the target organ
    v80*volLung - v81*volLung;	% mass balance on 	x39 is the IFN-gamma growth factor in the target organ
    v82*volLung - v83*volLung;	% mass balance on 	x40 is the TGF-beta growth factor in the target organ
    MG*v87*volBlood + MG*v88*volBlood - v89*volBlood - v92*volBlood - v93*volBlood - v94*volBlood;	% mass balance on 	x41 is the antigen (bacteria or debris) in the blood
    MK*v89*volSite - v90*volSite - v91*volSite;	% mass balance on 	x42 is the antigen (bacteria or debris) in the site of recognition
    1000*v34*volSite - 1000*v35*volSite - 1000*v36*volSite + 1000*MK*v39*volSite - v90*volSite;	% mass balance on 	x43 is the free receptor sites on the naive B cells in the site of recognition
    v90*volSite;	% mass balance on 	x44 is the bound receptor sites on the naive B cells in the site of recognition
    1000*v36*volSite - 1000*v37*volSite - v91*volSite;	% mass balance on 	x45 is the free receptor sites on the activated B cells in the site of recognition
    v91*volSite;	% mass balance on 	x46 is the bound receptor sites on the activated B cells in the site of recognition
    1000*MI*v37*volBlood - 1000*v38*volBlood - 1000*v40*volBlood + 1000*MJ*v41*volBlood - v92*volBlood;	% mass balance on 	x47 is the free receptor sites on the activated B cells in the blood
    v92*volBlood;	% mass balance on 	x48 is the bound receptor sites on the activated B cells in the blood
    v93*volBlood - v94*volBlood - v95*volBlood;	% mass balance on 	x49 is the single-bound antigbody in the blood
    v94*volBlood - v96*volBlood;	% mass balance on 	x50 is the double bound antibody in the blood
    v97*volLung - v98*volLung - v99*volLung;	% mass balance on 	x51 is the single bound antibody in the target organ
    -(v100*volLung) + v98*volLung;	% mass balance on 	x52 is the double bound antibody in the target organ
    ];