import pandas as pd
import numpy
import onnxruntime as rt

#Loading test dataset
data_test = pd.read_excel('41587_2021_1070_MOESM3_ESM.xlsx', sheet_name='Test')

# Defining labels
y_test = pd.DataFrame(data_test, columns=["Response (1:Responder; 0:Non-responder)"])

# Features names
rf16=["Cancer_Type2", "Albumin", "HED", "TMB", "FCNA", "BMI", "NLR", "Platelets", "HGB", "Stage (1:IV; 0:I-III)", "Age", "Drug (1:Combo; 0:PD1/PDL1orCTLA4)", "Chemo_before_IO (1:Yes; 0:No)", "HLA_LOH", "MSI (1:Unstable; 0:Stable_Indeterminate)", "Sex (1:Male; 0:Female)"]

# Test features
x_test16 = pd.DataFrame(data_test, columns=rf16)

# Loading forest16 onnx model
sess = rt.InferenceSession("forest16.onnx")
input_name = sess.get_inputs()[0].name
label_name = sess.get_outputs()[0].name

# Running predictions
pred_onx = sess.run([label_name], {input_name: x_test16.astype(numpy.float32).values})[0]
print(pred_onx)

# Saving the predictions in a text file named 'onnx_predictions.txt'
numpy.savetxt('onnx_predictions.txt', pred_onx, fmt='%s')