from myFunctions import *

# define output variables
outVar = 'Class'

# define list of folds
nfold = 3

# define a label for output files
label = 'Outer'

seed = 74

sFile = './path/to/Mix_BreastCancer.csv file' # path to the "Mix_BreastCancer.csv" file
df = pd.read_csv(sFile)

# Clean columns (remove all extra columns except ProtID!)
df = ClearDatasets(df)

# Drop ProtID to have only descriptors + Class (raw dataset)
df = df.drop(['ProtID'],axis = 1)

# Remove zero variance columns
df = Remove0VarCols(df)

# Selecting best 300 features followed by Scaling/Standardizing the dataframe
nFeats = 300
Xdata, Ydata, Features = getDataFromDataFrame(df)
# Scaling
scaler = MinMaxScaler()
Xdata = scaler.fit_transform(Xdata)
# Feature Selection
selector= SelectKBest(chi2, k=nFeats)
Xdata = selector.fit_transform(Xdata, Ydata)
# Selected features
SelFeatures = []
for i in selector.get_support(indices=True):
    SelFeatures.append(Features[i])
# Recreating the dataframe
df = pd.DataFrame(Xdata,columns=SelFeatures)
df['Class'] = Ydata # add class column

# Balancing dataframe using SMOTE technique
Xdata, Ydata, Features = getDataFromDataFrame(df)
smote = SMOTE(sampling_strategy='minority',random_state=seed)
X_sm, y_sm = smote.fit_resample(Xdata, Ydata)
df = pd.DataFrame(X_sm,columns=Features)
df['Class'] = y_sm

# Training the Multi Layer Perceptron (MLP) model
Xdata, Ydata, Features = getDataFromDataFrame(df)
# Calculate class weights
class_weights = set_weights(Ydata)
print("Class weights = ", class_weights)
# Defining the cross validator
outer_cv = StratifiedKFold(n_splits=3,shuffle=True,random_state=seed)

ifold = 0
ACCs  =[]
AUROCs=[]
models =[]

for train_index, test_index in outer_cv.split(Xdata, Ydata):
    ifold +=1

    print("Fold =",ifold)
    start = time.time()

    #print("TRAIN:", train_index, "TEST:", test_index)
    X_train, X_test = Xdata[train_index], Xdata[test_index]
    y_train, y_test = Ydata[train_index], Ydata[test_index]

    #scaler.transform(X_test)
    clf = MLPClassifier(hidden_layer_sizes= (20),
                        random_state = seed,
                        max_iter=50000, shuffle=False)
    clf.fit(X_train, y_train)
    # Uncomment the below line if you wish to save the model for each iteration
    #joblib.dump(clf, './best_classifier/MLP_model'+str(ifold)+'.pkl', compress = 1)
    models.append(clf)

    y_pred = clf.predict_proba(X_test)
    AUROC = roc_auc_score(y_test, y_pred[:, 1])
    AUROCs.append(AUROC)

    ACC = clf.score(X_test,y_test)
    ACCs.append(ACC)

    print("AUROC=",AUROC,"ACC=",ACC, (time.time() - start)/60,"mins")