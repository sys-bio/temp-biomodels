import pandas as pd
import numpy
import onnxruntime as rt

#Loading test dataset
data_test = pd.read_excel('immunotherapy_112_V4.xlsx', sheet_name='Test')

# Defining labels
y_test = pd.DataFrame(data_test, columns=["Label_0 (DCB=0 PFS>6,NDB=1 PFS≤6)"])

# Features names
feature=['Sex (Female=0,Male=1)', 'Age',
       'Smoking history（NO=0，YES=1）', 'ECOG score',
       'Histologic type（Squamous cell carcinoma=0，nonsquamous cell carcinoma=1）',
       'Classification of Immunotherapy Drugs（PD-L1=0,PD-1=1）',
       'Therapy line（1st=1，2nd=2，≥3rd=3）', 'BMI（kg/㎡）',
       'BMI category（<18.5=0,18.5-23.9=1,24-27.9=2,≥28=3）',
       'Hemoglobin (g/dL)', 'Hemoglobin level （normal=0，decreased=1）',
       'Albumin g/dl', 'Albumin level（normal=0，decreased=1）', 'LDH U/L',
       'LDH level（normal=0， increased =1）',
       'LIPI (good=0, intermediate=1, poor=2)', 'dNLR ', 'NLR', 'LMR ', 'PLR ',
       'ALI', 'tumor stage（IIIB=0,IIIC=1,IVA=2,IVB=3）', 'COPD (NO=0，YES=1)',
       'Bone metastasis (none=0, single=1, multiple=2)',
       'Brain  metastasis (none=0, single=1, multiple=2)',
       'Liver metastasis (none=0, single=1, multiple=2)',
       'Pleural effusion(NO=0, YES=1)', 'Pericardial effusion(NO=0, YES=1)']

# Test features
X_test = pd.DataFrame(data_test, columns=feature)

# Loading forest16 onnx model
sess_lr = rt.InferenceSession("lr_ibi.onnx")
sess_rf = rt.InferenceSession("rf_ibi.onnx")
sess_mlp = rt.InferenceSession("mlp_ibi.onnx")
sess_xgboost = rt.InferenceSession("xgboost_ibi.onnx")

input_name = sess_mlp.get_inputs()[0].name
label_name = sess_mlp.get_outputs()[0].name
# input_name = sess_lr.get_inputs()[0].name
# label_name = sess_lr.get_outputs()[0].name
# input_name = sess_rf.get_inputs()[0].name
# label_name = sess_rf.get_outputs()[0].name
# input_name = sess_xgboost.get_inputs()[0].name
# label_name = sess_xgboost.get_outputs()[0].name

# Running predictions
pred_onx = sess_mlp.run([label_name], {input_name: X_test.astype(numpy.float32).values})[0]
print(pred_onx)

# Saving the predictions in a text file named 'onnx_predictions.txt'
numpy.savetxt('onnx_predictions.txt', pred_onx, fmt='%s')


# reproduce the table
from sklearn.metrics import roc_auc_score, accuracy_score, confusion_matrix

# Assuming you have prediction set and corresponding true labels in test set
predictions = pred_onx  
true_labels = Ytest  


# Accuracy
accuracy = accuracy_score(true_labels, predictions.round())  # Rounding predictions to convert them to binary labels
print("Accuracy:", accuracy)

# AUC (Area Under the Curve)
auc = roc_auc_score(true_labels, predictions)
print("AUC:", auc)

# Confusion Matrix
tn, fp, fn, tp = confusion_matrix(true_labels, predictions.round()).ravel()

# Specificity
specificity = tn / (tn + fp)
print("Specificity:", specificity)

# Sensitivity
sensitivity = tp / (tp + fn)
print("Sensitivity:", sensitivity)