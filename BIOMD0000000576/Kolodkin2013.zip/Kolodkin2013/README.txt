File contained in the directory:

Simulation information for Figures for biomodels.docx
  - Author's explaination of how to reproduce figures in paper.


Kolodkin2013-Figure4a-1perHour.xml
Kolodkin2013-Figure4a-1perHour.cps
  - SBML and Copasi files for Figure 4a 1 per hour
  - This model is an extension of the core model in which the initial 
    concentrations are those obtained for the core model in steady state. 
    The CortAdded species is then given an initial concentration of
    130 nM and the boundaryCondition and constant attributes both set to 
    false. Additionally, an event has been added to add 130 nM to 
    CorAdded once per hour.


Kolodkin2013-Figure4a-1perDay.xml
Kolodkin2013-Figure4a-1perDay.cps
  - SBML and Copasi files for Figure 4a 1 per day
  - This model is an extension of the core model in which the initial 
    concentrations are those obtained for the core model in steady state. 
    The CortAdded species is then given an initial concentration of
    130 nM and the boundaryCondition and constant attributes both set to 
    false. Additionally, an event has been added to add 130 nM to 
    CorAdded once per day.


Kolodkin2013-Figure4a-1perWeek.xml
Kolodkin2013-Figure4a-1perWeek.cps
  - SBML and Copasi files for Figure 4a 1 per week
  - This model is an extension of the core model in which the initial 
    concentrations are those obtained for the core model in steady state. 
    The CortAdded species is then given an initial concentration of
    130 nM and the boundaryCondition and constant attributes both set to 
    false. Additionally, an event has been added to add 130 nM to 
    CorAdded once per week.


Kolodkin2013-Figure5-Continuous.cps
Kolodkin2013-Figure5-Continuous.xml
  - SBML and Copasi files for Figure 5 Continuous
  - This model is an extension of the core model in which the initial 
    concentrations are those obtained for the core model in steady state. 
    The CortAdded species is then given an initial concentration of
    95 + 3 * CortOUT(0) nM and the boundaryCondition and constant
    attributes both set to false. Additionally, an event has been added
    to add 95 + 3 * CortOUT(t) nM to CorAdded once per day.

Kolodkin2013-Figure5-Vacation.cps
Kolodkin2013-Figure5-Vacation.xml
  - SBML and Copasi files for Figure 5 Vacation
  - This model is an extension of the core model in which the initial 
    concentrations are those obtained for the core model in steady state. 
    The CortAdded species is then given an initial concentration of
    95 + 3 * CortOUT(0) nM and the boundaryCondition and constant
    attributes both set to false. Additionally, an event has been added
    to add 95 + 3 * CortOUT(t) nM to CorAdded once per day except during
    a 9 day vacation that starts after 5 days have elapsed.

Kolodkin2013-Figure5-Weekend.cps
Kolodkin2013-Figure5-Weekend.xml
  - SBML and Copasi files for Figure 5 Weekend
  - This model is an extension of the core model in which the initial 
    concentrations are those obtained for the core model in steady state. 
    The CortAdded species is then given an initial concentration of
    95 + 3 * CortOUT(0) nM and the boundaryCondition and constant
    attributes both set to false. Additionally, an event has been added
    to add 95 + 3 * CortOUT(t) nM to CorAdded once per day except during 
    weekends.
              

